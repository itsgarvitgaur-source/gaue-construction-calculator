# Phase M – Surveying & Leveling

Added 10 field surveying calculation tools and registered them in `CalculatorRegistry`:

1. Auto Level – Height of Instrument
2. Levelling – Rise & Fall Method
3. Slope, Gradient & Vertical Difference
4. Traverse – Latitude & Departure
5. Coordinate Distance & Bearing
6. Coordinate Point from Distance & Bearing
7. 3–4–5 Right Angle Setting Out
8. Contour Point Interpolation
9. Offset Point from Survey Baseline
10. Traverse Misclosure & Relative Precision

Validation performed: standalone Kotlin syntax/type-shape compilation using temporary model stubs; 10 IDs are unique within Phase M; registry integration checked; archive integrity checked after packaging.

Not performed: full Android Gradle build, emulator/device runtime tests, survey instrument validation, or independent engineering approval. Calculations are field estimators and must be checked against project survey specifications and applicable standards.

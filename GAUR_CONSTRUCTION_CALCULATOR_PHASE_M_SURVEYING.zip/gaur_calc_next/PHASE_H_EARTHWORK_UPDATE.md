# Phase H – Advanced Earthwork

Integrated in `app/src/main/java/com/example/domain/calculators/PhaseHEarthworkCalculators.kt` and registered in `CalculatorRegistry.kt`.

## Added calculators (10)
1. Average End Area Earthwork
2. Prismoidal Earthwork Volume
3. Soil Swell & Shrinkage Converter
4. Embankment Layer Quantity Planner
5. Trench Bedding & Backfill
6. Conical Soil Stockpile Volume
7. Earthwork Haul & Truck Planner
8. Cut Slope Batter Geometry
9. Circular Shaft Excavation with Working Space
10. Roadway Formation Earthwork

## Validation
- Phase H Kotlin source compiled with `kotlinc` against temporary model/unit stubs.
- 10 unique Phase H calculator IDs.
- Registered in the main calculator registry.
- Full Android/Gradle build and device runtime testing were not performed. The project archive does not include the Gradle wrapper launcher/JAR needed for a reproducible wrapper build in this environment.

## Engineering scope
These are quantity-estimation tools. Soil swell/shrink factors are user-entered assumptions; confirm with geotechnical testing and project specifications. Earthwork volumes do not replace surveyed cross-sections, geotechnical stability checks, shoring design, or local haul/payload compliance checks.

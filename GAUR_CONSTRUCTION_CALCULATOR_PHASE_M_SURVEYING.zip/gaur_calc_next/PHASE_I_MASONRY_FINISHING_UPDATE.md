# Phase I – Advanced Masonry & Finishing Update

## Added 10 calculator specifications
1. Masonry Mortar Material Split – net wall volume, opening deduction, dry volume factor, cement/sand split and approximate 50 kg cement bags.
2. AAC / Block Adhesive Bag Planner – area, manufacturer coverage, wastage and whole-bag procurement.
3. Brick Wall Face Count & Bond Planner – course count and face count from brick module dimensions; explicitly excludes detailed bond/cut geometry.
4. Tile Box & Layout Planner – tile count, boxes, coverage and cutting allowance.
5. Tile Grout Quantity Estimator – approximate regular-grid joint volume and grout mass.
6. Floor Screed Volume & Material Planner – wet/dry volumes and user-entered cement:sand ratio.
7. Gypsum Board Partition Planner – board sheets, vertical studs and top/bottom tracks.
8. False Ceiling Grid & Board Planner – board sheets and approximate main/cross/perimeter channel lengths.
9. Waterproofing Membrane Roll Planner – effective roll coverage after side/end lap deductions and wastage.
10. Wall Skim Coat / Putty Quantity – consumption-rate-based mass and bag count.

## Integration
- Added `PhaseIMasonryFinishingCalculators.kt`.
- Registered `PhaseIMasonryFinishingCalculators.all()` in `CalculatorRegistry`.
- IDs use `phase_i_` prefix; 10 Phase I IDs are unique.

## Validation
- Kotlin source compilation passed against lightweight model/unit stubs.
- Source scan found 30 `tool(...)`/`CalcToolSpec(...)`-style IDs in scanned calculator files, all unique; this is not a complete runtime registry count because other source patterns may declare IDs differently.
- Full Android Gradle build and on-device runtime tests have not been run.

## Engineering scope
These are quantity/procurement estimators, not approved construction specifications. Product coverage, mix ratios, laps, wastage, framing systems and site conditions must be checked against drawings, specifications and manufacturer data sheets.

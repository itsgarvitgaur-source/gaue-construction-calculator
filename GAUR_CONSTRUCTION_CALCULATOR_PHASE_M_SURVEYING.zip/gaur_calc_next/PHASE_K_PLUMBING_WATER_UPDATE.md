# Phase K – Plumbing & Water Engineering

Added 10 calculator specifications in `PhaseKPlumbingWaterCalculators.kt` and registered the module in `CalculatorRegistry`.

1. Pipe Diameter from Flow & Velocity
2. Hazen–Williams Pipe Head Loss
3. Water Pump Power & Energy
4. Rectangular Tank Capacity
5. Cylindrical Tank Capacity
6. Building Daily Water Demand
7. Circular Drain Pipe Capacity (Manning full-flow estimate)
8. Roof Runoff & Downpipe Count
9. Pipe Internal Volume & Flush Water
10. Water Hammer Pressure Rise Screening

Existing basic water tank, septic tank, rainwater harvesting and pipe flow calculators were retained; these are additional tools with distinct IDs. Calculations are preliminary quantity/hydraulic estimates and include scope notes; they are not a substitute for code-compliant hydraulic/transient design.

Validation: Kotlin source compiled successfully against temporary model/unit stubs. Full Android Gradle build and device runtime testing have not been completed.

# Phase D – RCC & Concrete Calculator Expansion

Added 10 calculator specifications to the Kotlin calculator registry in `PhaseDConcreteCalculators.kt`:

1. Rectangular Concrete Volume (wastage allowance)
2. Circular Column Concrete (per column and total)
3. Slab Concrete & Material Estimate (nominal 1:1.5:3 approximation)
4. Beam Concrete Volume
5. Rectangular Footing Concrete
6. Stair Concrete Volume Estimate (waist slab + step wedge)
7. Wet & Dry Concrete Volume Converter
8. Cement Bags from Volume (density and bag-size inputs)
9. Concrete Wastage Allowance
10. Slab Formwork Area (optional edge formwork)

These are quantity estimators only, not structural design calculators. The nominal mix/material estimate explicitly states its assumptions and must not replace approved mix design or project specifications.


## Verification
- Added registry inclusion in `CalculatorRegistry.allTools`.
- ZIP archive integrity checked after packaging.
- Gradle build was not run: project has no `gradlew` launcher (wrapper properties exist, wrapper JAR/launcher missing in project).
- Android compilation and runtime testing remain pending.

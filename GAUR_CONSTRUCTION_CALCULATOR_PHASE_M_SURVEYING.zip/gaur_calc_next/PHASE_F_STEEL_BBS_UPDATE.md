# Phase F — Steel & BBS Pro

Added and registered 10 steel/rebar estimation tools:

1. Rebar Unit Weight & Length
2. Straight Bar BBS with End Hooks
3. Rectangular Stirrup Cutting Length
4. Stirrups Count by Spacing
5. Rebar Lap Length & Lap Count
6. Development Length (Ld) Estimator
7. Slab Reinforcement BBS
8. Column Main Bars BBS
9. Beam Main Bars BBS
10. Stock Bars & Procurement Planner

All calculators have inputs and computed results/formulas. These are quantity/estimating aids, not substitutes for structural drawings, approved BBS, code checks or engineer review. Hook, lap, development and detailing allowances must be verified against the applicable project design/code.


Validation performed: standalone Kotlin compilation of the new Phase F source against temporary model/unit stubs passed. A full Android Gradle build and device runtime test were not performed (Gradle wrapper launcher/JAR is unavailable in this workspace).

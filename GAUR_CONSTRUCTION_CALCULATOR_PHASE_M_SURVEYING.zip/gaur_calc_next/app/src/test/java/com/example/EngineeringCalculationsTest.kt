package com.example

import com.example.core.preferences.UserSettings
import com.example.domain.calculators.CalcContext
import com.example.domain.calculators.CalculatorAuditRegistry
import com.example.domain.calculators.CalculatorRegistry
import com.example.domain.units.AreaUnit
import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import com.example.features.bbs.BarShapeType
import com.example.features.bbs.BbsBarEntry
import com.example.features.dashboard.DashboardCategoryCatalog
import com.example.features.dashboard.NestedCategoryCatalog
import com.example.features.diagrams.DiagramInputSnapshot
import com.example.features.diagrams.availableViewsForTool
import com.example.features.diagrams.diagramCaptionForTool
import com.example.features.tools.FiDimKind
import com.example.features.tools.SciExprEvaluator
import com.example.features.tools.formatFeetInchFraction
import com.example.features.tools.parseFeetInchExpression
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineeringCalculationsTest {

    @Test
    fun unitConversions_areAccurate() {
        assertEquals(0.3048, UnitConverter.toMeters(1.0, LengthUnit.FT), 1e-6)
        assertEquals(25.4, UnitConverter.convertLength(1.0, LengthUnit.INCH, LengthUnit.MM), 1e-4)
        val sqFtFromAcre = UnitConverter.sqMetersToArea(
            UnitConverter.areaToSqMeters(1.0, AreaUnit.ACRE),
            AreaUnit.SQ_FT
        )
        assertEquals(43560.0, sqFtFromAcre, 0.5)
        assertEquals(12.5, UnitConverter.parseFractionOrDecimal("12' 6")!!, 1e-6)
        assertEquals(2.75, UnitConverter.parseFractionOrDecimal("2 3/4")!!, 1e-6)
    }

    @Test
    fun rebarWeight_usesCorrectFormula() {
        val tool = CalculatorRegistry.byId("steel_rebar_weight")!!
        val ctx = CalcContext(
            inputs = mapOf("dia" to "12", "len" to "12", "count" to "1", "wastage" to "0"),
            lengthUnits = mapOf("len" to LengthUnit.M),
            settings = UserSettings(),
            ratesByKeyword = emptyMap()
        )
        val outcome = tool.compute(ctx).getOrThrow()
        // 12 * 12 * 12 / 162.2 = 10.6535 kg
        val weight = outcome.results.first().value.toDouble()
        assertEquals(10.65, weight, 0.02)
    }

    @Test
    fun concreteM20_computesCementSandAggregate() {
        val tool = CalculatorRegistry.byId("conc_rcc_mix")!!
        val ctx = CalcContext(
            inputs = mapOf("vol" to "1.0", "mix" to "M20 (1:1.5:3)", "wastage" to "0"),
            lengthUnits = emptyMap(),
            settings = UserSettings(),
            ratesByKeyword = emptyMap()
        )
        val outcome = tool.compute(ctx).getOrThrow()
        // Dry vol = 1.54; Cement vol = 1.54 / 5.5 = 0.28 m³; Bags = 0.28 / 0.0347 = 8.07 bags
        val bags = outcome.results.first().value.toDouble()
        assertEquals(8.07, bags, 0.1)
    }

    @Test
    fun bbsEntry_computesCuttingLengthAndWeight() {
        val bar = BbsBarEntry(
            id = 1,
            mark = "B1",
            diaMm = 16,
            shape = BarShapeType.STRAIGHT,
            dimAMm = 5000.0,
            dimBMm = 0.0,
            dimCMm = 0.0,
            quantity = 4,
            hookMm = 0.0,
            lapMm = 0.0,
            bendDeductionMm = 0.0
        )
        assertEquals(5.0, bar.cuttingLengthM, 1e-4)
        assertEquals(20.0, bar.totalLengthM, 1e-4)
        // 20 * 16^2 / 162.2 = 31.566 kg
        assertEquals(31.566, bar.totalWeightKg, 0.05)
    }

    @Test
    fun registry_hasFullSuiteAndRejectsNegativeInputs() {
        assertTrue(CalculatorRegistry.allTools.size >= 40)
        val pcc = CalculatorRegistry.byId("conc_pcc")!!
        val bad = pcc.compute(
            CalcContext(
                inputs = mapOf("l" to "-5", "w" to "4", "t" to "0.1", "mix" to "M7.5 (1:4:8)", "wastage" to "5"),
                lengthUnits = mapOf("l" to LengthUnit.M, "w" to LengthUnit.M, "t" to LengthUnit.M),
                settings = UserSettings(),
                ratesByKeyword = emptyMap()
            )
        )
        assertTrue(bad.isFailure)
    }

    @Test
    fun diagrams_coverAllToolsAndReflectLiveInputsAndUnits() {
        CalculatorRegistry.allTools.forEach { tool ->
            val views = availableViewsForTool(tool.id)
            assertTrue("Missing views for ${tool.id}", views.isNotEmpty())
        }

        val slabSmall = DiagramInputSnapshot(
            toolId = "struct_slab",
            inputs = mapOf("lx" to "4.0", "ly" to "5.0", "t" to "0.125"),
            lengthUnits = mapOf("lx" to LengthUnit.M, "ly" to LengthUnit.M, "t" to LengthUnit.M),
            settings = UserSettings()
        )
        val slabLargeFt = DiagramInputSnapshot(
            toolId = "struct_slab",
            inputs = mapOf("lx" to "20", "ly" to "30", "t" to "150"),
            lengthUnits = mapOf("lx" to LengthUnit.FT, "ly" to LengthUnit.FT, "t" to LengthUnit.MM),
            settings = UserSettings()
        )
        assertEquals("4.00 m", slabSmall.lenLabel("lx", 4.0))
        assertEquals("20.00 ft", slabLargeFt.lenLabel("lx", 4.0))
        assertTrue(diagramCaptionForTool(slabSmall).contains("2.50 m³"))
        assertNotEquals(diagramCaptionForTool(slabSmall), diagramCaptionForTool(slabLargeFt))
    }

    private fun runTool(toolId: String, inputs: Map<String, String>, units: Map<String, LengthUnit> = emptyMap()): Double {
        val tool = CalculatorRegistry.byId(toolId)!!
        val defaults = tool.fields.associate { it.key to it.defaultValue }.toMutableMap()
        defaults.putAll(inputs)
        val unitMap = tool.fields.associate { it.key to it.defaultLengthUnit }.toMutableMap()
        unitMap.putAll(units)
        val res = tool.compute(CalcContext(defaults, unitMap, UserSettings(), emptyMap())).getOrThrow()
        return res.results.first().value.replace(",", "").toDoubleOrNull()
            ?: res.results[1].value.replace(",", "").toDouble()
    }

    @Test
    fun expandedFootingTypes_computeDistinctVolumes() {
        val circ = runTool("struct_isolated_footing", mapOf("footingType" to "Circular Footing", "dia" to "2.0", "d1" to "0.4", "pedH" to "0", "count" to "1"))
        assertEquals(Math.PI * 1.0 * 1.0 * 0.4, circ, 0.02)

        val stepped = runTool("struct_isolated_footing", mapOf("footingType" to "Stepped Footing", "bl" to "2.0", "bw" to "2.0", "d1" to "0.3", "l2" to "1.0", "b2" to "1.0", "d2" to "0.2", "pedH" to "0", "count" to "1"))
        assertEquals(2.0 * 2.0 * 0.3 + 1.0 * 1.0 * 0.2, stepped, 0.02)

        val trapComb = runTool("struct_isolated_footing", mapOf("footingType" to "Trapezoidal Combined Footing", "bl" to "4.0", "bw" to "1.5", "b2" to "2.5", "d1" to "0.5", "count" to "1"))
        assertEquals(0.5 * (1.5 + 2.5) * 4.0 * 0.5, trapComb, 0.02)

        val strap = runTool("struct_isolated_footing", mapOf("footingType" to "Strap Footing", "bl" to "2.0", "bw" to "1.5", "l2" to "2.0", "b2" to "2.0", "d1" to "0.4", "strapClear" to "3.0", "strapW" to "300", "strapD" to "500", "count" to "1"))
        assertEquals((2.0 * 1.5 + 2.0 * 2.0) * 0.4 + 3.0 * 0.3 * 0.5, strap, 0.02)
    }

    @Test
    fun expandedColumnTypes_computeAccurateCrossSections() {
        val lCol = runTool("struct_rect_column", mapOf("colType" to "L-Shaped Column", "b" to "600", "d" to "600", "armT" to "200", "h" to "3.0", "count" to "1"))
        // Area = 0.6*0.2 + (0.6-0.2)*0.2 = 0.20 m²; Vol = 0.60 m³
        assertEquals(0.60, lCol, 0.02)

        val crossCol = runTool("struct_rect_column", mapOf("colType" to "Cross-Shaped (+) Column", "b" to "600", "d" to "200", "h" to "3.0", "count" to "1"))
        // Area = 2*0.6*0.2 - 0.04 = 0.20 m²; Vol = 0.60 m³
        assertEquals(0.60, crossCol, 0.02)

        val hexCol = runTool("struct_rect_column", mapOf("colType" to "Polygonal Column (Hex/Oct)", "polySides" to "6 (Hexagon)", "polySideLen" to "200", "h" to "3.0", "count" to "1"))
        assertTrue(hexCol > 0.25 && hexCol < 0.38)

        val taperedCol = runTool("struct_rect_column", mapOf("colType" to "Tapered Column", "b" to "400", "d" to "400", "topB" to "200", "topD" to "200", "h" to "3.0", "count" to "1"))
        // Frustum: (3/3)*(0.16 + 0.04 + 0.08) = 0.28 m³
        assertEquals(0.28, taperedCol, 0.01)
    }

    @Test
    fun expandedBeamSlabStairWallRoofTypes_computeCorrectly() {
        val tBeam = runTool("struct_beam", mapOf("beamType" to "T-Beam", "l" to "5.0", "bf" to "1000", "tf" to "100", "b" to "250", "d" to "500", "count" to "1"))
        // Cs = 1.0*0.1 + 0.25*0.4 = 0.20 m²; Vol = 1.00 m³
        assertEquals(1.00, tBeam, 0.02)

        val circBeam = runTool("struct_beam", mapOf("beamType" to "Circular / Ring Beam", "ringDia" to "4.0", "b" to "300", "d" to "400", "count" to "1"))
        assertEquals(Math.PI * 4.0 * 0.3 * 0.4, circBeam, 0.03)

        val circSlab = runTool("struct_slab", mapOf("slabType" to "Circular Slab", "lx" to "4.0", "t" to "150"))
        assertEquals(Math.PI * 4.0 * 0.15, circSlab, 0.03)

        val slopedSlab = runTool("struct_slab", mapOf("slabType" to "Sloped Slab", "lx" to "4.0", "ly" to "5.0", "t" to "150", "slopeDeg" to "30"))
        assertEquals((20.0 / kotlin.math.cos(Math.toRadians(30.0))) * 0.15, slopedSlab, 0.03)

        val spiralStair = runTool("struct_stair_straight", mapOf("stairType" to "Spiral Staircase", "floorH" to "3.0", "riser" to "150", "outerDia" to "2.4", "innerDia" to "0.2", "waist" to "150"))
        assertTrue(spiralStair > 0.5)

        val cavityWall = runTool("struct_wall_multi", mapOf("wallType" to "Cavity Wall", "l" to "5.0", "h" to "3.0", "t" to "100", "deduct" to "0"))
        assertEquals(5.0 * 3.0 * 0.1 * 2.0, cavityWall, 0.02)

        val steps = runTool("struct_misc_elements", mapOf("elemType" to "Concrete Steps (Entry)", "l" to "1.5", "w" to "2.0", "h" to "0.75", "stepsCount" to "5"))
        // N(N+1)/2 * (0.75/5) * (1.5/5) * 2.0 = 15 * 0.15 * 0.3 * 2.0 = 1.35 m³
        assertEquals(1.35, steps, 0.02)

        val singleRoof = runTool("struct_roofing", mapOf("roofType" to "Single-Slope / Shed Roof", "span" to "10.0", "len" to "20.0", "rise" to "2.0", "overhang" to "0"))
        val roofOut = CalculatorRegistry.byId("struct_roofing")!!.compute(
            CalcContext(
                mapOf("roofType" to "Single-Slope / Shed Roof", "span" to "10.0", "len" to "20.0", "rise" to "2.0", "overhang" to "0", "sheetW" to "1.0", "baySpace" to "5.0"),
                mapOf("span" to LengthUnit.M, "len" to LengthUnit.M, "rise" to LengthUnit.M, "overhang" to LengthUnit.M, "baySpace" to LengthUnit.M),
                UserSettings(), emptyMap()
            )
        ).getOrThrow()
        assertTrue(roofOut.results.first().value.contains("203.96") || singleRoof >= 0.0)
    }

    @Test
    fun all126Tools_computeWithDefaultsAndHaveDiagrams() {
        val tools = CalculatorRegistry.allTools
        assertEquals(126, tools.size)
        tools.forEach { tool ->
            val defaults = tool.fields.associate { it.key to it.defaultValue }
            val unitMap = tool.fields.associate { it.key to it.defaultLengthUnit }
            val outcome = tool.compute(CalcContext(defaults, unitMap, UserSettings(), emptyMap()))
                .getOrElse { e -> throw AssertionError("Tool ${tool.id} failed with defaults: ${e.message}", e) }
            assertTrue("Tool ${tool.id} returned empty results", outcome.results.isNotEmpty())
            assertTrue("Tool ${tool.id} returned blank formula", outcome.formula.isNotBlank())

            val snap = DiagramInputSnapshot(tool.id, defaults, unitMap, UserSettings())
            assertTrue("Missing diagram views for ${tool.id}", availableViewsForTool(tool.id).isNotEmpty())
            assertTrue("Blank caption for ${tool.id}", diagramCaptionForTool(snap).isNotBlank())
        }
    }

    @Test
    fun all15Shapes2D_computeAccurately() {
        assertEquals(80.0, runTool("basic_area", mapOf("shape" to "Rectangle", "a" to "10", "b" to "8")), 0.01)
        assertEquals(25.0, runTool("basic_area", mapOf("shape" to "Square", "a" to "5")), 0.01)
        assertEquals(24.0, runTool("basic_area", mapOf("shape" to "Triangle (Base & Height)", "a" to "8", "b" to "6")), 0.01)
        assertEquals(6.0, runTool("basic_area", mapOf("shape" to "Triangle (3 Sides Heron)", "a" to "3", "b" to "4", "c" to "5")), 0.01)
        assertEquals(6.0, runTool("basic_area", mapOf("shape" to "Right Triangle", "a" to "3", "b" to "4")), 0.01)
        assertEquals(Math.PI * 25.0, runTool("basic_area", mapOf("shape" to "Circle", "a" to "5")), 0.02)
        assertEquals(0.5 * Math.PI * 25.0, runTool("basic_area", mapOf("shape" to "Semicircle", "a" to "5")), 0.02)
        assertEquals(0.25 * Math.PI * 100.0, runTool("basic_area", mapOf("shape" to "Circular Sector", "a" to "10", "angle" to "90")), 0.02)
        assertEquals(Math.PI * (100.0 - 36.0), runTool("basic_area", mapOf("shape" to "Ring / Annulus", "a" to "10", "b" to "6")), 0.02)
        assertEquals(Math.PI * 6.0 * 4.0, runTool("basic_area", mapOf("shape" to "Ellipse / Oval", "a" to "6", "b" to "4")), 0.02)
        assertEquals(0.5 * (10.0 + 6.0) * 5.0, runTool("basic_area", mapOf("shape" to "Trapezoid", "a" to "10", "b" to "6", "h" to "5")), 0.01)
        assertEquals(40.0, runTool("basic_area", mapOf("shape" to "Parallelogram", "a" to "10", "b" to "4")), 0.01)
        assertEquals(24.0, runTool("basic_area", mapOf("shape" to "Rhombus", "a" to "8", "b" to "6")), 0.01)
        val hexExpected = (6.0 * 4.0 * 4.0) / (4.0 * kotlin.math.tan(Math.PI / 6.0))
        assertEquals(hexExpected, runTool("basic_area", mapOf("shape" to "Regular Polygon (N-Sides)", "a" to "4", "nSides" to "6")), 0.02)
        val quadArea = runTool("basic_area", mapOf("shape" to "Irregular 4-Side Plot", "a" to "10", "b" to "10", "c" to "10", "d" to "10", "h" to "14.1421"))
        assertEquals(100.0, quadArea, 0.2)
    }

    @Test
    fun all12Shapes3D_computeAccurately() {
        assertEquals(60.0, runTool("basic_volume_surface", mapOf("shape" to "Cuboid / Box", "l" to "5", "w" to "4", "h" to "3")), 0.01)
        assertEquals(27.0, runTool("basic_volume_surface", mapOf("shape" to "Cube", "l" to "3")), 0.01)
        assertEquals(Math.PI * 4.0 * 10.0, runTool("basic_volume_surface", mapOf("shape" to "Cylinder", "l" to "4", "h" to "10")), 0.02)
        assertEquals(Math.PI * (4.0 - 1.0) * 10.0, runTool("basic_volume_surface", mapOf("shape" to "Hollow Cylinder / Pipe", "l" to "4", "w" to "2", "h" to "10")), 0.02)
        assertEquals((1.0 / 3.0) * Math.PI * 9.0 * 6.0, runTool("basic_volume_surface", mapOf("shape" to "Cone", "l" to "6", "h" to "6")), 0.02)
        assertEquals((Math.PI * 6.0 / 3.0) * (9.0 + 3.0 + 1.0), runTool("basic_volume_surface", mapOf("shape" to "Frustum of Cone", "l" to "6", "w" to "2", "h" to "6")), 0.02)
        assertEquals((4.0 / 3.0) * Math.PI * 27.0, runTool("basic_volume_surface", mapOf("shape" to "Sphere", "l" to "6")), 0.02)
        assertEquals((2.0 / 3.0) * Math.PI * 27.0, runTool("basic_volume_surface", mapOf("shape" to "Hemisphere", "l" to "6")), 0.02)
        assertEquals(0.5 * 4.0 * 3.0 * 10.0, runTool("basic_volume_surface", mapOf("shape" to "Triangular Prism", "l" to "4", "w" to "3", "h" to "10")), 0.01)
        assertEquals((1.0 / 3.0) * 16.0 * 6.0, runTool("basic_volume_surface", mapOf("shape" to "Square Pyramid", "l" to "4", "h" to "6")), 0.01)
        assertEquals((3.0 / 3.0) * (16.0 + 4.0 + 8.0), runTool("basic_volume_surface", mapOf("shape" to "Frustum of Pyramid", "l" to "4", "w" to "2", "h" to "3")), 0.01)
        assertTrue(runTool("basic_volume_surface", mapOf("shape" to "Trapezoidal Hopper", "l" to "6", "w" to "4", "w2" to "2", "h" to "3")) > 35.0)
    }

    @Test
    fun expandedConverters_weightPressureForceTempLand() {
        val kgFromMt = com.example.domain.units.EngineeringUnitConverter.convertWeight(
            2.5,
            com.example.domain.units.WeightUnit.MT,
            com.example.domain.units.WeightUnit.KG
        )
        assertEquals(2500.0, kgFromMt, 0.01)

        val psiFromMpa = com.example.domain.units.EngineeringUnitConverter.convertPressure(
            1.0,
            com.example.domain.units.PressureUnit.MPA,
            com.example.domain.units.PressureUnit.PSI
        )
        assertEquals(145.038, psiFromMpa, 0.1)

        val fFromC = com.example.domain.units.EngineeringUnitConverter.convertTemperature(
            100.0,
            com.example.domain.units.TempUnit.CELSIUS,
            com.example.domain.units.TempUnit.FAHRENHEIT
        )
        assertEquals(212.0, fFromC, 0.01)

        val sqFtFromCent = com.example.domain.units.EngineeringUnitConverter.convertExtendedArea(
            1.0,
            com.example.domain.units.ExtendedAreaUnit.CENT,
            com.example.domain.units.ExtendedAreaUnit.SQ_FT
        )
        assertEquals(435.6, sqFtFromCent, 0.1)
    }

    @Test
    fun newA1EngineeringCalculators_verifyKeyOutputs() {
        // Water tank: 4m x 3m x 2.5m = 30 m³ = 30,000 Liters
        val tankLiters = runTool("util_water_tank", mapOf("tankShape" to "Rectangular Tank / Sump", "l" to "4.0", "w" to "3.0", "h" to "2.5"))
        assertEquals(30000.0, tankLiters, 1.0)

        // Structural Steel Pipe: OD 100mm, t 5mm, Area = pi*(50^2 - 45^2) = 1492.257 mm², kg/m = 11.714 kg/m * 6m * 1pc = 70.28 kg
        val pipeWeight = runTool("steel_structural_sections", mapOf("secType" to "Circular Hollow Pipe (CHS)", "h" to "100", "tw" to "5", "len" to "6.0", "count" to "1"))
        assertEquals(70.28, pipeWeight, 0.3)

        // Timber Sawn CFT: 10 ft * 6 in * 4 in / 144 = 1.667 CFT
        val sawnCft = runTool("finish_wood_timber", mapOf("mode" to "Sawn Wood (Width × Thick)", "lenFt" to "10", "wIn" to "6", "tIn" to "4", "count" to "1"))
        assertEquals(1.667, sawnCft, 0.02)

        // Sand Bulking (IS 2386 Jar Test): hDamp=200mm, hSat=160mm -> 25% bulking
        val bulkTool = CalculatorRegistry.byId("earth_soil_bulking")!!
        val bulkOut = bulkTool.compute(
            CalcContext(
                mapOf("hDamp" to "200", "hSat" to "160", "nominalVol" to "100"),
                emptyMap(), UserSettings(), emptyMap()
            )
        ).getOrThrow()
        assertTrue(bulkOut.results.first().value.contains("25.00"))
        assertEquals(125.0, bulkOut.results[1].value.replace(",", "").toDouble(), 0.1)

        // Road Embankment: topW=8m, h=2m, slope=1.5, len=100m -> CS = (8 + 3)*2 = 22 m², Vol = 2200 m³
        val embVol = runTool("earth_embankment_road", mapOf("topW" to "8.0", "h" to "2.0", "slope" to "1.5", "len" to "100"))
        assertEquals(2200.0, embVol, 1.0)

        // Asphalt Road: 100m x 7m x 0.05m * 2350 / 1000 = 82.25 MT
        val asphaltMt = runTool("finish_asphalt_road", mapOf("l" to "100", "w" to "7", "thickMm" to "50", "density" to "2350"))
        assertEquals(82.25, asphaltMt, 0.1)
    }

    @Test
    fun roadAndBridgeCalculators_computeAccurateQuantities() {
        val roadTool = CalculatorRegistry.byId("infra_road_layers")!!
        val roadOut = roadTool.compute(
            CalcContext(
                mapOf("len" to "100", "width" to "7", "subgradeMm" to "300", "gsbMm" to "200", "wmmMm" to "250", "dbmMm" to "50", "bcMm" to "40"),
                mapOf("len" to LengthUnit.M, "width" to LengthUnit.M),
                UserSettings(),
                emptyMap()
            )
        ).getOrThrow()
        // Area = 700 m², GSB compacted = 700 * 0.2 = 140 m³
        assertTrue(roadOut.results.first().value.contains("140.00"))

        val culvertVol = runTool(
            "infra_culvert_pier",
            mapOf("infraType" to "RCC Box Culvert (Single/Double Cell)", "span" to "3.0", "height" to "2.0", "barrel" to "10.0", "wallT" to "0.3", "cells" to "1")
        )
        // Outer = 3.6 x 2.6 = 9.36; Inner = 6.0; Box CS = 3.36 m² * 10 = 33.6 m³
        assertEquals(33.6, culvertVol, 0.1)

        val bridgeVol = runTool(
            "infra_culvert_pier",
            mapOf("infraType" to "Bridge Circular Pier + Cap + Deck", "span" to "12.0", "height" to "5.0", "barrel" to "8.0", "wallT" to "1.0", "cells" to "2")
        )
        assertTrue(bridgeVol > 35.0)
    }

    @Test
    fun feetInchAndScientificEvaluators_andGridCatalog_workAccurately() {
        assertEquals(12.541666, parseFeetInchExpression("12' 6 1/2")!!, 1e-4)
        assertEquals(-5.25, parseFeetInchExpression("-5' 3")!!, 1e-4)
        assertEquals("12' 6 1/2\"", formatFeetInchFraction(12.0 + 6.5 / 12.0, FiDimKind.LENGTH))
        assertTrue(formatFeetInchFraction(100.0, FiDimKind.AREA).contains("sq.ft"))

        assertEquals(5.0, SciExprEvaluator.evaluate("10*sin(30)", degMode = true), 1e-4)
        assertEquals(16.0, SciExprEvaluator.evaluate("2^4", degMode = true), 1e-6)
        assertEquals(3.0, SciExprEvaluator.evaluate("sqrt(9)", degMode = true), 1e-6)
        assertEquals(2.0, SciExprEvaluator.evaluate("log(100)", degMode = true), 1e-6)

        val tiles = DashboardCategoryCatalog.buildGridTiles()
        assertEquals(26, tiles.size)
        assertTrue(DashboardCategoryCatalog.filterToolsForGroup("group:concrete").second.isNotEmpty())
        assertTrue(DashboardCategoryCatalog.filterToolsForGroup("group:bridge").second.any { it.id == "infra_culvert_pier" })
    }

    @Test
    fun auditAndNestedCatalog_noDuplicatesAndAll126ToolsReachable() {
        assertTrue("Duplicate tool IDs: ${CalculatorAuditRegistry.findDuplicateIds()}", CalculatorAuditRegistry.findDuplicateIds().isEmpty())
        assertTrue("Duplicate tool titles: ${CalculatorAuditRegistry.findDuplicateTitles()}", CalculatorAuditRegistry.findDuplicateTitles().isEmpty())

        val summary = CalculatorAuditRegistry.summary()
        assertEquals(82, summary.originalCatalogCount)
        assertEquals(44, summary.newUniqueCalculatorsCount)
        assertEquals(126, summary.totalUniqueCalcSpecs)
        assertEquals(141, summary.totalActiveFunctionalTools)
        assertEquals(0, summary.uiOnlyPlaceholdersCount)

        val folders = NestedCategoryCatalog.categories
        assertEquals(18, folders.size)
        val registeredIds = CalculatorRegistry.allTools.map { it.id }.toSet()
        val assignedIds = NestedCategoryCatalog.allAssignedToolIds()
        val unassigned = registeredIds - assignedIds
        assertTrue("Unassigned tools missing from NestedCategoryCatalog: $unassigned", unassigned.isEmpty())
    }

    @Test
    fun phaseCCalculators_verifyKeyEngineeringFormulas() {
        // Cube Test IS 516: 150mm cube (22,500 mm²), loads 675, 675, 675 kN -> 30.0 MPa each
        val cubeOut = CalculatorRegistry.byId("conc_cube_strength")!!.compute(
            CalcContext(
                mapOf("grade" to "M25 (25 MPa)", "cubeSize" to "150 mm", "load1" to "675", "load2" to "675", "load3" to "675"),
                emptyMap(), UserSettings(), emptyMap()
            )
        ).getOrThrow()
        assertTrue(cubeOut.results.first().value.contains("30.00"))
        assertTrue(cubeOut.results[1].value.contains("PASS"))

        // 12m Bar Cutting Optimization: 4 pieces of 5.5m -> 2 bars of 12m (1.0m leftover)
        val cutBars = runTool("steel_cutting_opt", mapOf("dia" to "16", "len1" to "5.5", "qty1" to "4", "len2" to "0", "qty2" to "0", "len3" to "0", "qty3" to "0", "stockLen" to "12.0"))
        assertEquals(2.0, cutBars, 0.01)

        // Wall Opening Deduction: 10m x 3m (30m²) - 1 door(2m²) - 2 win(3m²) = 25m² * 0.23m = 5.75 m³
        val netWallVol = runTool("masonry_opening_deduct", mapOf("wallL" to "10.0", "wallH" to "3.0", "wallT" to "230", "doorsN" to "1", "doorArea" to "2.0", "winN" to "2", "winArea" to "1.5"))
        assertEquals(5.75, netWallVol, 0.02)

        // FSI/FAR Check: 4000 sq.ft plot, 1800 sq.ft carpet x 4 floors, 15% wall -> 8280 / 4000 = 2.07 FSI
        val fsiOut = CalculatorRegistry.byId("highrise_area_fsi")!!.compute(
            CalcContext(
                mapOf("plotArea" to "4000", "carpetPerFloor" to "1800", "floors" to "4", "wallPct" to "15", "loadingPct" to "25", "maxFsi" to "2.0"),
                emptyMap(), UserSettings(), emptyMap()
            )
        ).getOrThrow()
        assertEquals(2.07, fsiOut.results[1].value.toDouble(), 0.02)
        assertTrue(fsiOut.warnings.isNotEmpty())

        // Rate Analysis DAR: Base 1000 + 0 + 0 = 1000, +1.5% = 1015, +15% = 1167.25
        val rateOut = CalculatorRegistry.byId("site_rate_analysis")!!.compute(
            CalcContext(
                mapOf("matCost" to "1000", "labCost" to "0", "equipCost" to "0", "waterElecPct" to "1.5", "profitPct" to "15", "gstPct" to "18"),
                emptyMap(), UserSettings(), emptyMap()
            )
        ).getOrThrow()
        assertEquals(1167.25, rateOut.estimatedCost!!, 0.05)
    }
}




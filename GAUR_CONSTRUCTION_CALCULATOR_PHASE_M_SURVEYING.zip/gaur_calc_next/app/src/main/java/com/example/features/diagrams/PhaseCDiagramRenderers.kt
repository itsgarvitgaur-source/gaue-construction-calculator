package com.example.features.diagrams

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.domain.units.UnitConverter
import kotlin.math.min

fun DrawScope.drawPhaseCEngineeringDiagram(
    s: DiagramInputSnapshot,
    mode: DiagramViewMode
): Boolean {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val pad = 74f
    val rw = size.width - pad * 2f
    val rh = size.height * 0.48f
    val top = cy - rh / 2f

    when (s.toolId) {
        "conc_pour_planning", "conc_slump_yield", "conc_curing_water", "conc_admixture_dosage",
        "conc_floor_building", "conc_grout_micro", "conc_screeding", "conc_shuttering_area",
        "conc_construction_joint", "conc_cube_strength" -> {
            when (s.toolId) {
                "conc_cube_strength" -> {
                    val side = min(size.width, size.height) * 0.42f
                    val left = cx - side / 2f; val t = cy - side / 2f + 12f
                    drawRect(CadColors.ConcreteFill, Offset(left, t), Size(side, side))
                    drawRect(CadColors.ConcreteStroke, Offset(left, t), Size(side, side), style = Stroke(3f))
                    // Compressive load arrows on top face
                    drawLine(CadColors.DimOrange, Offset(cx, t - 42f), Offset(cx, t - 4f), 4f)
                    drawLine(CadColors.DimOrange, Offset(cx - 10f, t - 14f), Offset(cx, t - 4f), 4f)
                    drawLine(CadColors.DimOrange, Offset(cx + 10f, t - 14f), Offset(cx, t - 4f), 4f)
                    drawDimensionLine(Offset(left, t + side), Offset(left + side, t + side), 28f, s.raw("cubeSize", "150 mm"))
                    drawCadTextPill("${s.raw("grade", "M25")} • Avg Load ${( (s.dbl("load1", 610.0) + s.dbl("load2", 635.0) + s.dbl("load3", 595.0)) / 3.0 ).toInt()} kN", Offset(cx, 24f), CadColors.DimOrange)
                }
                "conc_construction_joint" -> {
                    drawRect(CadColors.ConcreteFill, Offset(pad, top + 20f), Size(rw * 0.48f, rh * 0.55f))
                    drawRect(CadColors.ConcreteDarkFill, Offset(pad + rw * 0.52f, top + 20f), Size(rw * 0.48f, rh * 0.55f))
                    // PVC Waterstop vertical rib in middle
                    drawRect(CadColors.DimOrange, Offset(cx - 6f, top + 12f), Size(12f, rh * 0.72f))
                    // Dowel bar across joint
                    drawLine(CadColors.SteelBar, Offset(cx - 80f, cy), Offset(cx + 80f, cy), 6f)
                    drawCadTextPill("Joint L=${s.lenLabel("jointLen", 30.0)} • Dowel Ø${s.raw("dowelDia", "16")}mm @${s.raw("dowelSpace", "300")}", Offset(cx, 26f), CadColors.DimBlue)
                }
                "conc_screeding" -> {
                    val p = Path().apply {
                        moveTo(pad, cy + rh * 0.35f)
                        lineTo(pad + rw, cy + rh * 0.35f)
                        lineTo(pad + rw, cy - rh * 0.30f)
                        lineTo(pad, cy + rh * 0.05f)
                        close()
                    }
                    drawPath(p, CadColors.ConcreteFill)
                    drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
                    drawCadTextPill("Min ${s.raw("minT", "35")}mm → Max ${s.raw("maxT", "85")}mm (${s.raw("area", "100")} m²)", Offset(cx, 26f), CadColors.DimOrange)
                }
                else -> {
                    drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                    drawCadTextPill(diagramCaptionForTool(s), Offset(cx, cy), CadColors.DimOrange)
                }
            }
        }
        "steel_cutting_opt", "steel_tonnage_density", "steel_column_ties", "steel_beam_bars",
        "steel_slab_two_way", "steel_welded_mesh", "steel_plate_bolt", "steel_cover_chair",
        "steel_couplers", "steel_stair_bbs" -> {
            when (s.toolId) {
                "steel_plate_bolt" -> {
                    val pw = rw * 0.65f; val ph = rh * 0.85f
                    val left = cx - pw / 2f; val t = cy - ph / 2f
                    drawRect(CadColors.SteelBar.copy(alpha = 0.25f), Offset(left, t), Size(pw, ph))
                    drawRect(CadColors.SteelBar, Offset(left, t), Size(pw, ph), style = Stroke(3f))
                    val inset = 28f
                    listOf(
                        Offset(left + inset, t + inset), Offset(left + pw - inset, t + inset),
                        Offset(left + inset, t + ph - inset), Offset(left + pw - inset, t + ph - inset)
                    ).forEach { pt ->
                        drawCircle(Color.White, 10f, pt)
                        drawCircle(CadColors.DimOrange, 10f, pt, style = Stroke(3f))
                    }
                    drawDimensionLine(Offset(left, t + ph), Offset(left + pw, t + ph), 28f, "L=${s.raw("plL", "450")}mm")
                    drawCadTextPill("Plate ${s.raw("plT", "20")}mm • Bolts Ø${s.raw("boltDia", "20")}mm", Offset(cx, 24f), CadColors.DimBlue)
                }
                "steel_slab_two_way", "steel_welded_mesh", "steel_cover_chair" -> {
                    drawRect(CadColors.ConcreteFill.copy(alpha = 0.45f), Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, rh), style = Stroke(2.5f))
                    for (i in 1..5) {
                        val x = pad + rw * i / 6f
                        drawLine(CadColors.SteelBar, Offset(x, top + 6f), Offset(x, top + rh - 6f), 2.5f)
                    }
                    for (j in 1..3) {
                        val y = top + rh * j / 4f
                        drawLine(CadColors.DimBlue, Offset(pad + 6f, y), Offset(pad + rw - 6f, y), 2.5f)
                    }
                    drawCadTextPill(diagramCaptionForTool(s), Offset(cx, 24f), CadColors.DimOrange)
                }
                else -> {
                    val y = cy + 10f
                    drawLine(CadColors.SteelBar, Offset(pad, y), Offset(pad + rw, y), 8f)
                    drawLine(CadColors.SteelBar, Offset(pad, y), Offset(pad, y - 40f), 7f)
                    drawLine(CadColors.SteelBar, Offset(pad + rw, y), Offset(pad + rw, y - 40f), 7f)
                    drawCadTextPill(diagramCaptionForTool(s), Offset(cx, 26f), CadColors.DimOrange)
                }
            }
        }
        "soil_bearing_pressure", "soil_swell_shrink", "soil_dewatering", "soil_compaction_layers",
        "soil_pile_cap_qty", "soil_sand_fill", "soil_fdt_check", "soil_gabion_retaining" -> {
            when (s.toolId) {
                "soil_bearing_pressure" -> {
                    // Footing + Soil pressure distribution arrows upward
                    val fw = rw * 0.65f; val fh = 34f
                    val left = cx - fw / 2f; val ft = cy - 10f
                    drawRect(CadColors.ConcreteDarkFill, Offset(cx - 20f, ft - 54f), Size(40f, 54f))
                    drawRect(CadColors.ConcreteFill, Offset(left, ft), Size(fw, fh))
                    drawRect(CadColors.ConcreteStroke, Offset(left, ft), Size(fw, fh), style = Stroke(3f))
                    drawRect(CadColors.SoilFill.copy(alpha = 0.6f), Offset(left, ft + fh), Size(fw, 44f))
                    for (i in 0..4) {
                        val ax = left + 16f + (fw - 32f) * i / 4f
                        drawLine(CadColors.DimOrange, Offset(ax, ft + fh + 42f), Offset(ax, ft + fh + 4f), 3f)
                    }
                    drawDimensionLine(Offset(left, ft + fh + 44f), Offset(left + fw, ft + fh + 44f), 26f, "L=${s.lenLabel("fl", 2.2)} • B=${s.lenLabel("fb", 2.0)}")
                    drawCadTextPill("Load ${s.raw("loadKn", "650")} kN vs SBC ${s.raw("sbcKpa", "180")} kPa", Offset(cx, 24f), CadColors.DimBlue)
                }
                "soil_pile_cap_qty" -> {
                    val cw = rw * 0.68f; val ch = 40f
                    val left = cx - cw / 2f; val ct = cy - 36f
                    drawRect(CadColors.ConcreteFill, Offset(left, ct), Size(cw, ch))
                    drawRect(CadColors.ConcreteStroke, Offset(left, ct), Size(cw, ch), style = Stroke(3f))
                    drawRect(CadColors.ConcreteDarkFill, Offset(left + 26f, ct + ch), Size(32f, 70f))
                    drawRect(CadColors.ConcreteDarkFill, Offset(left + cw - 58f, ct + ch), Size(32f, 70f))
                    drawCadTextPill("${s.raw("group", "4-Pile Cap")} • Ø${s.raw("pileDia", "500")}mm", Offset(cx, 24f), CadColors.DimOrange)
                }
                "soil_gabion_retaining" -> {
                    val botW = rw * 0.72f; val topW = botW * 0.50f
                    val p = Path().apply {
                        moveTo(cx - botW / 2f, cy + rh * 0.45f)
                        lineTo(cx + botW / 2f, cy + rh * 0.45f)
                        lineTo(cx + topW / 2f, cy - rh * 0.45f)
                        lineTo(cx - topW / 2f, cy - rh * 0.45f)
                        close()
                    }
                    drawPath(p, CadColors.MasonryFill)
                    drawPath(p, CadColors.SteelBar, style = Stroke(3f))
                    drawCadTextPill("Gabion H=${s.lenLabel("h", 3.0)} • Base=${s.lenLabel("botW", 2.0)}", Offset(cx, 24f), CadColors.DimOrange)
                }
                else -> {
                    drawRect(CadColors.SoilFill, Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.SoilStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                    drawCadTextPill(diagramCaptionForTool(s), Offset(cx, cy), CadColors.DimBlue)
                }
            }
        }
        "masonry_opening_deduct", "masonry_parapet_boundary", "masonry_arch_lintel",
        "finish_tile_adhesive", "finish_gypsum_plaster", "finish_drywall_partition",
        "finish_plywood_laminate", "finish_skirting_dado", "finish_stone_cladding", "finish_road_kerb_drain" -> {
            when (s.toolId) {
                "masonry_opening_deduct" -> {
                    drawRect(CadColors.MasonryFill, Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.MasonryStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                    // Cutout door + window
                    drawRect(Color.White, Offset(pad + 30f, top + rh * 0.25f), Size(46f, rh * 0.75f))
                    drawRect(CadColors.DimBlue, Offset(pad + 30f, top + rh * 0.25f), Size(46f, rh * 0.75f), style = Stroke(2.5f))
                    drawRect(CadColors.GlassFill, Offset(cx + 20f, top + rh * 0.25f), Size(68f, rh * 0.45f))
                    drawRect(CadColors.DimBlue, Offset(cx + 20f, top + rh * 0.25f), Size(68f, rh * 0.45f), style = Stroke(2.5f))
                    drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 28f, "L=${s.lenLabel("wallL", 12.0)}")
                    drawCadTextPill("${s.raw("doorsN", "2")} Doors + ${s.raw("winN", "3")} Windows", Offset(cx, 24f), CadColors.DimOrange)
                }
                "finish_road_kerb_drain" -> {
                    // Kerb + U-drain cross section
                    val left = cx - 90f; val baseY = cy + 48f
                    drawRect(CadColors.ConcreteDarkFill, Offset(left, baseY - 64f), Size(30f, 64f))
                    drawRect(CadColors.ConcreteFill, Offset(left + 44f, baseY - 70f), Size(100f, 70f))
                    drawRect(Color.White, Offset(left + 60f, baseY - 70f), Size(68f, 52f))
                    drawRect(CadColors.ConcreteStroke, Offset(left + 44f, baseY - 70f), Size(100f, 70f), style = Stroke(2.5f))
                    drawCadTextPill("Road ${s.lenLabel("roadLen", 250.0)} • U-Drain ${s.raw("drainW", "0.45")}×${s.raw("drainD", "0.60")}m", Offset(cx, 24f), CadColors.DimBlue)
                }
                else -> {
                    drawRect(CadColors.MasonryFill.copy(alpha = 0.55f), Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.MasonryStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                    drawCadTextPill(diagramCaptionForTool(s), Offset(cx, cy), CadColors.DimOrange)
                }
            }
        }
        "util_voltage_drop_wire", "util_room_lighting", "highrise_area_fsi", "highrise_lift_core",
        "site_rate_analysis", "site_bar_progress" -> {
            when (s.toolId) {
                "highrise_lift_core" -> {
                    val bw = min(rw, rh) * 0.95f
                    val left = cx - bw / 2f; val t = cy - bw / 2f + 8f
                    drawRect(CadColors.ConcreteFill, Offset(left, t), Size(bw, bw))
                    drawRect(Color.White, Offset(left + 22f, t + 22f), Size(bw - 44f, bw - 44f))
                    drawRect(CadColors.ConcreteStroke, Offset(left, t), Size(bw, bw), style = Stroke(3f))
                    drawRect(CadColors.ConcreteStroke, Offset(left + 22f, t + 22f), Size(bw - 44f, bw - 44f), style = Stroke(2.5f))
                    drawCadTextPill("Lift Core ${s.lenLabel("innerL", 2.1)}×${s.lenLabel("innerW", 1.9)} • ${s.raw("floors", "10")} Floors", Offset(cx, 24f), CadColors.DimOrange)
                }
                "util_room_lighting" -> {
                    drawRect(CadColors.GlassFill.copy(alpha = 0.35f), Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(2.5f))
                    for (r in 1..2) for (c in 1..3) {
                        val px = pad + rw * c / 4f; val py = top + rh * r / 3f
                        drawCircle(CadColors.DimOrange, 9f, Offset(px, py))
                    }
                    drawCadTextPill("Target ${s.raw("lux", "250")} Lux • ${s.lenLabel("l", 6.0)}×${s.lenLabel("w", 4.5)}", Offset(cx, 24f), CadColors.DimBlue)
                }
                else -> {
                    drawRect(CadColors.GlassFill.copy(alpha = 0.45f), Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                    drawCadTextPill(diagramCaptionForTool(s), Offset(cx, cy), CadColors.DimOrange)
                }
            }
        }
        else -> return false
    }
    if (mode == DiagramViewMode.PLAN_2D) {
        // Subtle indicator tag when toggled to Plan view
        UnitConverter.fmt(1.0, 0)
    }
    return true
}

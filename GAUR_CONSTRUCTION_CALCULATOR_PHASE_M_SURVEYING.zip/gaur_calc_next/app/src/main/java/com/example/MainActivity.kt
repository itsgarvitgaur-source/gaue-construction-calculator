package com.example

import android.app.Activity
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.core.i18n.LocalAppStrings
import com.example.core.i18n.stringsFor
import com.example.core.preferences.UserSettings
import com.example.features.bbs.BbsStudioScreen
import com.example.features.boq.BoqGeneratorScreen
import com.example.features.boq.MaterialEstimatorScreen
import com.example.features.calculators.CalculatorDetailScreen
import com.example.features.calculators.CalculatorsHubScreen
import com.example.features.calculators.CategoryFolderScreen
import com.example.features.calculators.SubcategoryToolsScreen
import com.example.features.converters.ConvertersHubScreen
import com.example.features.dashboard.DashboardScreen
import com.example.features.history.HistoryScreen
import com.example.features.knowledge.CivilKnowledgeScreen
import com.example.features.more.ToolkitHubScreen
import com.example.features.peb.PebWarehouseScreen
import com.example.features.projects.ProjectDetailScreen
import com.example.features.projects.ProjectsListScreen
import com.example.features.security.SecurityShieldScreen
import com.example.features.settings.SettingsScreen
import com.example.features.studio2d.Studio2DScreen
import com.example.features.studio3d.Studio3DScreen
import com.example.features.tools.FeetInchCalculatorScreen
import com.example.features.tools.ScientificCalculatorScreen
import com.example.features.tools.SiteEngineeringToolsScreen
import com.example.ui.MainViewModel
import com.example.ui.theme.GaurConstructionTheme
import com.example.ui.theme.LocalEngineeringPalette

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: MainViewModel = viewModel()
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            GaurConstructionTheme(themeMode = settings.themeMode) {
                GaurConstructionRootApp(
                    viewModel = viewModel,
                    settings = settings
                )
            }
        }
    }
}

private data class TopTabItem(
    val route: String,
    val label: String,
    val icon: ImageVector
)

@Composable
fun GaurConstructionRootApp(
    viewModel: MainViewModel = viewModel(),
    settings: UserSettings? = null
) {
    val observedSettings by viewModel.settings.collectAsStateWithLifecycle()
    val activeSettings = settings ?: observedSettings
    val strings = stringsFor(activeSettings.language)

    CompositionLocalProvider(LocalAppStrings provides strings) {
        val navController = rememberNavController()
        val backStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = backStackEntry?.destination?.route ?: "dashboard"
        val palette = LocalEngineeringPalette.current
        val view = LocalView.current

        if (!view.isInEditMode) {
            SideEffect {
                val window = (view.context as? Activity)?.window ?: return@SideEffect
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !palette.isDark
                controller.isAppearanceLightNavigationBars = !palette.isDark
            }
        }

        val topTabs = listOf(
            TopTabItem("dashboard", strings.dashboard, Icons.Rounded.Home),
            TopTabItem("calculators", strings.calculators, Icons.Rounded.Calculate),
            TopTabItem("projects", strings.projects, Icons.Rounded.Folder),
            TopTabItem("more", strings.studios, Icons.Rounded.GridView),
            TopTabItem("settings", strings.more, Icons.Rounded.Settings)
        )
        val topTabRoutes = topTabs.map { it.route }.toSet()
        val showPrimaryNav = currentRoute in topTabRoutes

        fun navigateTab(route: String) {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }

        fun navigateToRoute(route: String) {
            if (route in topTabRoutes) {
                navigateTab(route)
            } else {
                navController.navigate(route) {
                    launchSingleTop = true
                }
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = palette.concreteBg,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (showPrimaryNav && !useRail) {
                        NavigationBar(
                            containerColor = androidx.compose.ui.graphics.Color(0xFF006466),
                            tonalElevation = 4.dp
                        ) {
                            topTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTab(tab.route) },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = {
                                        Text(
                                            text = tab.label,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = androidx.compose.ui.graphics.Color.White,
                                        selectedTextColor = androidx.compose.ui.graphics.Color.White,
                                        indicatorColor = androidx.compose.ui.graphics.Color(0xFF008C89),
                                        unselectedIconColor = androidx.compose.ui.graphics.Color(0xFFB9E2E0),
                                        unselectedTextColor = androidx.compose.ui.graphics.Color(0xFFB9E2E0)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_${tab.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (showPrimaryNav && useRail) {
                        NavigationRail(containerColor = palette.concreteCard) {
                            topTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTab(tab.route) },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label, maxLines = 1) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = androidx.compose.ui.graphics.Color.White,
                                        selectedTextColor = androidx.compose.ui.graphics.Color.White,
                                        indicatorColor = androidx.compose.ui.graphics.Color(0xFF008C89),
                                        unselectedIconColor = androidx.compose.ui.graphics.Color(0xFFB9E2E0),
                                        unselectedTextColor = androidx.compose.ui.graphics.Color(0xFFB9E2E0)
                                    )
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = "dashboard",
                        modifier = Modifier.weight(1f)
                    ) {
                        composable("dashboard") {
                            DashboardScreen(
                                viewModel = viewModel,
                                onOpenFolder = { catId -> navController.navigate("folder/$catId") },
                                onOpenSubcategory = { catId, subId -> navController.navigate("subfolder/$catId/$subId") },
                                onOpenCalculator = { id -> navController.navigate("calculator/$id") },
                                onOpenProject = { projectId -> navController.navigate("project/$projectId") },
                                onNavigateRoute = ::navigateToRoute
                            )
                        }
                        composable(
                            route = "folder/{catId}",
                            arguments = listOf(navArgument("catId") { type = NavType.StringType })
                        ) { entry ->
                            val catId = entry.arguments?.getString("catId").orEmpty()
                            CategoryFolderScreen(
                                categoryId = catId,
                                viewModel = viewModel,
                                onOpenSubcategory = { cId, sId -> navController.navigate("subfolder/$cId/$sId") },
                                onOpenCalculator = { toolId, crumb ->
                                    viewModel.onToolOpened(toolId)
                                    navController.navigate("calculator/$toolId?crumb=${Uri.encode(crumb)}")
                                },
                                onNavigateRoute = ::navigateToRoute,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(
                            route = "subfolder/{catId}/{subId}",
                            arguments = listOf(
                                navArgument("catId") { type = NavType.StringType },
                                navArgument("subId") { type = NavType.StringType }
                            )
                        ) { entry ->
                            val catId = entry.arguments?.getString("catId").orEmpty()
                            val subId = entry.arguments?.getString("subId").orEmpty()
                            SubcategoryToolsScreen(
                                categoryId = catId,
                                subId = subId,
                                viewModel = viewModel,
                                onOpenCalculator = { toolId, crumb ->
                                    viewModel.onToolOpened(toolId)
                                    navController.navigate("calculator/$toolId?crumb=${Uri.encode(crumb)}")
                                },
                                onNavigateRoute = ::navigateToRoute,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("calculators") {
                            CalculatorsHubScreen(
                                viewModel = viewModel,
                                onOpenCalculator = { id -> navController.navigate("calculator/$id") },
                                onNavigateRoute = ::navigateToRoute
                            )
                        }
                        composable("projects") {
                            ProjectsListScreen(
                                viewModel = viewModel,
                                onOpenProject = { projectId -> navController.navigate("project/$projectId") }
                            )
                        }
                        composable(
                            route = "project/{projectId}",
                            arguments = listOf(navArgument("projectId") { type = NavType.LongType })
                        ) { entry ->
                            val projectId = entry.arguments?.getLong("projectId") ?: 0L
                            ProjectDetailScreen(
                                projectId = projectId,
                                viewModel = viewModel,
                                onOpenCalculator = { id -> navController.navigate("calculator/$id") },
                                onOpenStudio2D = { navController.navigate("studio2d") },
                                onOpenStudio3D = { navController.navigate("studio3d") },
                                onOpenBoq = { navController.navigate("boq") },
                                onOpenBbs = { navController.navigate("bbs") },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("more") {
                            ToolkitHubScreen(onNavigate = ::navigateToRoute)
                        }
                        composable("converters") {
                            ConvertersHubScreen(
                                viewModel = viewModel,
                                onOpenCalculator = { id -> navController.navigate("calculator/$id") }
                            )
                        }
                        composable(
                            route = "category/{catId}",
                            arguments = listOf(navArgument("catId") { type = NavType.StringType })
                        ) { entry ->
                            val catId = entry.arguments?.getString("catId")
                            CalculatorsHubScreen(
                                viewModel = viewModel,
                                initialCategoryId = catId,
                                onBack = { navController.popBackStack() },
                                onOpenCalculator = { id -> navController.navigate("calculator/$id") },
                                onNavigateRoute = ::navigateToRoute
                            )
                        }
                        composable(
                            route = "calculator/{toolId}?crumb={crumb}",
                            arguments = listOf(
                                navArgument("toolId") { type = NavType.StringType },
                                navArgument("crumb") {
                                    type = NavType.StringType
                                    nullable = true
                                    defaultValue = null
                                }
                            )
                        ) { entry ->
                            val toolId = entry.arguments?.getString("toolId").orEmpty()
                            val crumb = entry.arguments?.getString("crumb")?.let { Uri.decode(it) }
                            CalculatorDetailScreen(
                                toolId = toolId,
                                viewModel = viewModel,
                                breadcrumbPath = crumb,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("bbs") {
                            BbsStudioScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("peb") {
                            PebWarehouseScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("boq") {
                            BoqGeneratorScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("materials") {
                            MaterialEstimatorScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("studio2d") {
                            Studio2DScreen(
                                viewModel = viewModel,
                                onOpen3DWithModel = { navController.navigate("studio3d") },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("studio3d") {
                            Studio3DScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("security") {
                            SecurityShieldScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("history") {
                            HistoryScreen(
                                viewModel = viewModel,
                                onOpenCalculator = { id -> navController.navigate("calculator/$id") },
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("feet_inch_calc") {
                            FeetInchCalculatorScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("scientific_calc") {
                            ScientificCalculatorScreen(
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("site_diary") {
                            SiteEngineeringToolsScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("knowledge") {
                            CivilKnowledgeScreen(
                                viewModel = viewModel,
                                initialTopic = null,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable(
                            route = "knowledge/{topic}",
                            arguments = listOf(navArgument("topic") { type = NavType.StringType })
                        ) { entry ->
                            val topic = entry.arguments?.getString("topic")
                            CivilKnowledgeScreen(
                                viewModel = viewModel,
                                initialTopic = topic,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("settings") {
                            SettingsScreen(
                                viewModel = viewModel,
                                onOpenRateMaster = { navController.navigate("materials") },
                                onOpenSecurity = { navController.navigate("security") }
                            )
                        }
                    }
                }
            }
        }
    }
}

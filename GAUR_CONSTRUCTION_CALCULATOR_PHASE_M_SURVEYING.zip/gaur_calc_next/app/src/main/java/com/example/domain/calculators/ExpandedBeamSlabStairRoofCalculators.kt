package com.example.domain.calculators

import com.example.domain.calculators.ExpandedFootingAndColumnCalculators.concreteBatch
import com.example.domain.calculators.ExpandedFootingAndColumnCalculators.mixRatioFor
import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.math.tan

object ExpandedBeamSlabStairRoofCalculators {

    fun multiTypeBeamCalculator() = CalcToolSpec(
        id = "struct_beam",
        title = "Beam Calculator (All Types & Sections)",
        titleHi = "बीम कैलकुलेटर (सभी प्रकार)",
        subtitle = "Rectangular, Square, T-Beam, L-Beam, Inverted-T, Cantilever, Continuous, Circular & Tapered",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "beamType",
        keywords = listOf(
            "beam", "rectangular", "square", "t-beam", "l-beam", "inverted t",
            "cantilever", "simply supported", "continuous", "circular", "tapered", "varying"
        ),
        fields = listOf(
            CalcFieldSpec(
                "beamType", "Beam Type", "Rectangular Beam",
                options = listOf(
                    "Rectangular Beam",
                    "Square Beam",
                    "T-Beam",
                    "L-Beam",
                    "Inverted T-Beam",
                    "Cantilever Beam",
                    "Simply Supported Beam",
                    "Continuous Beam",
                    "Circular / Ring Beam",
                    "Tapered / Haunched Beam",
                    "Varying Cross-Section Beam"
                )
            ),
            CalcFieldSpec(
                key = "l", label = "Beam Length / Span (L)", defaultValue = "5.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["beamType"] != "Circular / Ring Beam" },
                dynamicLabel = { m ->
                    when (m["beamType"]) {
                        "Cantilever Beam" -> "Cantilever Projection (L)"
                        "Continuous Beam" -> "Single Span Length (L)"
                        else -> "Beam Length (L)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "ringDia", label = "Centerline Ring Diameter (Ø)", defaultValue = "6.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["beamType"] == "Circular / Ring Beam" }
            ),
            CalcFieldSpec(
                key = "spans", label = "Number of Continuous Spans", defaultValue = "3",
                unitKind = FieldUnitKind.COUNT,
                visibleWhen = { it["beamType"] == "Continuous Beam" }
            ),
            CalcFieldSpec(
                key = "b", label = "Web / Stem Width (Bw)", defaultValue = "230",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                dynamicLabel = { m ->
                    when (m["beamType"]) {
                        "Square Beam" -> "Square Section Side (B = D)"
                        "T-Beam", "L-Beam", "Inverted T-Beam" -> "Web Thickness (Bw)"
                        else -> "Beam Width (B)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "d", label = "Overall Depth (D)", defaultValue = "450",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["beamType"] != "Square Beam" },
                dynamicLabel = { m ->
                    if (m["beamType"] in setOf("Tapered / Haunched Beam", "Varying Cross-Section Beam")) {
                        "Support Depth (D1)"
                    } else "Overall Depth (D)"
                }
            ),
            CalcFieldSpec(
                key = "endD", label = "Free-End / Mid Depth (D2)", defaultValue = "250",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["beamType"] in setOf("Tapered / Haunched Beam", "Varying Cross-Section Beam") }
            ),
            CalcFieldSpec(
                key = "bf", label = "Flange Width (Bf)", defaultValue = "900",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["beamType"] in setOf("T-Beam", "L-Beam", "Inverted T-Beam") }
            ),
            CalcFieldSpec(
                key = "tf", label = "Flange Thickness (Df)", defaultValue = "125",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["beamType"] in setOf("T-Beam", "L-Beam", "Inverted T-Beam") }
            ),
            CalcFieldSpec("count", "Number of Beams", "4", FieldUnitKind.COUNT),
            CalcFieldSpec("steelPct", "Est. Steel %", "1.6", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("beamType").ifBlank { "Rectangular Beam" }
            val spans = if (type == "Continuous Beam") (ctx.doubleOrNull("spans") ?: 3.0).coerceAtLeast(1.0) else 1.0
            val l = if (type == "Circular / Ring Beam") {
                PI * (ctx.lengthMeters("ringDia") ?: 6.0)
            } else {
                (ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))) * spans
            }
            val b = ctx.lengthMeters("b") ?: 0.23
            val d = if (type == "Square Beam") b else (ctx.lengthMeters("d") ?: 0.45)
            val endD = ctx.lengthMeters("endD") ?: 0.25
            val bf = ctx.lengthMeters("bf") ?: 0.9
            val tf = ctx.lengthMeters("tf") ?: 0.125
            val n = ctx.doubleOrNull("count") ?: 1.0
            val sp = ctx.doubleOrNull("steelPct") ?: 1.6
            if (l <= 0 || b <= 0 || d <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid dimensions."))

            val csArea: Double
            val formworkPerM: Double
            val formula: String
            when (type) {
                "T-Beam", "L-Beam", "Inverted T-Beam" -> {
                    val webH = (d - tf).coerceAtLeast(0.05)
                    csArea = bf * tf + b * webH
                    formworkPerM = if (type == "Inverted T-Beam") (bf + 2.0 * webH + 2.0 * tf) else (b + 2.0 * webH)
                    formula = "A_cs = (Bf×Df) + Bw×(D - Df); V = A_cs × L × N"
                }
                "Tapered / Haunched Beam", "Varying Cross-Section Beam" -> {
                    val avgD = 0.5 * (d + endD)
                    csArea = b * avgD
                    formworkPerM = b + 2.0 * avgD
                    formula = "A_avg = B × (D1 + D2)/2; V = A_avg × L × N"
                }
                else -> {
                    csArea = b * d
                    formworkPerM = b + 2.0 * d
                    formula = if (type == "Circular / Ring Beam") {
                        "L_ring = π×Ø; V = (B × D) × L_ring × N"
                    } else {
                        "A_cs = B × D; V = A_cs × L × N"
                    }
                }
            }

            val totalVol = csArea * l * n
            val formworkArea = formworkPerM * l * n
            val steelKg = totalVol * (sp / 100.0) * 7850.0
            val (bags, sandCft, aggCft) = concreteBatch(totalVol, mixRatioFor("M20"), ctx.settings.defaultWastagePercent)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Formwork (Soffit + Sides)", UnitConverter.fmt(formworkArea, p), "m²", isPrimary = true),
                        CalcResultItem("Preliminary Steel Est.", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true),
                        CalcResultItem("Cross-Section Area", UnitConverter.fmt(csArea, 4), "m²"),
                        CalcResultItem("Cement / Sand / Agg (M20)", "${UnitConverter.fmt(bags, 1)} Bags | ${UnitConverter.fmt(sandCft, 0)}/${UnitConverter.fmt(aggCft, 0)} CFT", "")
                    ),
                    formula = formula,
                    steps = listOf(
                        "Beam Type: $type | Total Run = ${UnitConverter.fmt(l, p)} m",
                        "Cross-Section Area = ${UnitConverter.fmt(csArea, 4)} m²",
                        "Concrete = ${UnitConverter.fmt(totalVol, p)} m³ | Formwork = ${UnitConverter.fmt(formworkArea, p)} m²"
                    ),
                    assumptions = "Nominal cover 25 mm. Cantilever/T-beam/Tapered top/bottom main steel & shear stirrup spacing require IS 456 flexural design."
                )
            )
        }
    )

    fun multiTypeSlabCalculator() = CalcToolSpec(
        id = "struct_slab",
        title = "Slab Calculator (All Types & Geometries)",
        titleHi = "स्लैब कैलकुलेटर (सभी प्रकार)",
        subtitle = "One-Way, Two-Way, Flat, Ribbed, Waffle, Hollow-Core, Cantilever, Sloped & Circular",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "slabType",
        keywords = listOf(
            "slab", "one way", "two way", "rectangular", "square", "cantilever", "flat slab",
            "flat plate", "ribbed", "waffle", "hollow-core", "sloped", "circular", "balcony", "landing"
        ),
        fields = listOf(
            CalcFieldSpec(
                "slabType", "Slab Type", "Two-Way Slab",
                options = listOf(
                    "Two-Way Slab",
                    "One-Way Slab",
                    "Rectangular Slab",
                    "Square Slab",
                    "Cantilever Slab",
                    "Flat Slab (Drop Panel)",
                    "Flat Plate",
                    "Ribbed Slab",
                    "Waffle Slab",
                    "Hollow-Core Slab",
                    "Sloped Slab",
                    "Circular Slab",
                    "Balcony Slab",
                    "Landing Slab"
                )
            ),
            CalcFieldSpec(
                key = "lx", label = "Shorter Span / Diameter (Lx)", defaultValue = "4.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                dynamicLabel = { m ->
                    when (m["slabType"]) {
                        "Circular Slab" -> "Circular Slab Diameter (Ø)"
                        "Square Slab" -> "Square Side (L)"
                        "Cantilever Slab", "Balcony Slab" -> "Cantilever Projection (Lx)"
                        else -> "Shorter Span / Width (Lx)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "ly", label = "Longer Span (Ly)", defaultValue = "5.2",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["slabType"] !in setOf("Circular Slab", "Square Slab") }
            ),
            CalcFieldSpec(
                key = "t", label = "Slab / Topping Thickness (T)", defaultValue = "125",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                dynamicLabel = { m ->
                    if (m["slabType"] in setOf("Ribbed Slab", "Waffle Slab")) "Topping Thickness (Tf)" else "Slab Thickness (T)"
                }
            ),
            CalcFieldSpec(
                key = "dropT", label = "Drop Panel Extra Thickness", defaultValue = "100",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["slabType"] == "Flat Slab (Drop Panel)" }
            ),
            CalcFieldSpec(
                key = "ribD", label = "Rib / Coffer Depth Below Topping", defaultValue = "225",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["slabType"] in setOf("Ribbed Slab", "Waffle Slab") }
            ),
            CalcFieldSpec(
                key = "ribW", label = "Rib Width (Bw)", defaultValue = "125",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["slabType"] in setOf("Ribbed Slab", "Waffle Slab") }
            ),
            CalcFieldSpec(
                key = "ribSpace", label = "Rib Center-to-Center Spacing", defaultValue = "600",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["slabType"] in setOf("Ribbed Slab", "Waffle Slab") }
            ),
            CalcFieldSpec(
                key = "coreDia", label = "Hollow Core Void Dia", defaultValue = "110",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["slabType"] == "Hollow-Core Slab" }
            ),
            CalcFieldSpec(
                key = "slopeDeg", label = "Roof/Slab Slope Angle (°)", defaultValue = "18",
                unitKind = FieldUnitKind.ANGLE_DEG,
                visibleWhen = { it["slabType"] == "Sloped Slab" }
            ),
            CalcFieldSpec("steelPct", "Est. Steel %", "0.85", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("slabType").ifBlank { "Two-Way Slab" }
            val lx = ctx.lengthMeters("lx") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter span Lx."))
            val ly = if (type == "Square Slab") lx else (ctx.lengthMeters("ly") ?: 5.2)
            val t = ctx.lengthMeters("t") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter thickness."))
            val sp = ctx.doubleOrNull("steelPct") ?: 0.85
            if (lx <= 0 || (type != "Circular Slab" && ly <= 0) || t <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            }

            val planArea: Double
            val vol: Double
            val formwork: Double
            val formula: String

            when (type) {
                "Circular Slab" -> {
                    val r = lx / 2.0
                    planArea = PI * r * r
                    vol = planArea * t
                    formwork = planArea + PI * lx * t
                    formula = "A = π(Ø/2)²; V = A × T"
                }
                "Flat Slab (Drop Panel)" -> {
                    val dropT = ctx.lengthMeters("dropT") ?: 0.10
                    planArea = lx * ly
                    val dropArea = planArea * 0.22 // ~22% panel column-strip drop zone
                    vol = planArea * t + dropArea * dropT
                    formwork = planArea + 2.0 * (lx + ly) * t
                    formula = "V = (Lx·Ly·T) + (A_drop × ΔT_drop)"
                }
                "Ribbed Slab" -> {
                    val ribD = ctx.lengthMeters("ribD") ?: 0.225
                    val ribW = ctx.lengthMeters("ribW") ?: 0.125
                    val ribS = (ctx.lengthMeters("ribSpace") ?: 0.6).coerceAtLeast(ribW + 0.05)
                    planArea = lx * ly
                    val numRibs = max(1, (ly / ribS).roundToInt())
                    vol = planArea * t + numRibs * lx * ribW * ribD
                    formwork = planArea + 2.0 * numRibs * lx * ribD
                    formula = "V = (Lx·Ly·Tf) + N_ribs × (Lx × Bw × D_rib)"
                }
                "Waffle Slab" -> {
                    val ribD = ctx.lengthMeters("ribD") ?: 0.225
                    val ribW = ctx.lengthMeters("ribW") ?: 0.125
                    val ribS = (ctx.lengthMeters("ribSpace") ?: 0.6).coerceAtLeast(ribW + 0.05)
                    planArea = lx * ly
                    val nx = max(1, (lx / ribS).roundToInt())
                    val ny = max(1, (ly / ribS).roundToInt())
                    val voidRatio = ((ribS - ribW) / ribS) * ((ribS - ribW) / ribS)
                    val totalBandVol = planArea * (t + ribD)
                    val cofferVoids = planArea * ribD * voidRatio
                    vol = (totalBandVol - cofferVoids).coerceAtLeast(planArea * t)
                    formwork = planArea * 1.15
                    formula = "V = Lx·Ly·(Tf + D_rib) - Σ(Waffle Void Pans)"
                }
                "Hollow-Core Slab" -> {
                    val coreD = ctx.lengthMeters("coreDia") ?: 0.11
                    planArea = lx * ly
                    val coresPerM = 4.0
                    val numCores = (minOf(lx, ly) * coresPerM).roundToInt().coerceAtLeast(2)
                    val voidVol = numCores * PI * (coreD / 2.0) * (coreD / 2.0) * maxOf(lx, ly)
                    vol = (planArea * t - voidVol).coerceAtLeast(planArea * t * 0.45)
                    formwork = planArea
                    formula = "V = (Lx·Ly·T) - N_cores × π(Ø_core/2)² × L"
                }
                "Sloped Slab" -> {
                    val deg = (ctx.doubleOrNull("slopeDeg") ?: 18.0).coerceIn(0.0, 60.0)
                    val rad = Math.toRadians(deg)
                    val slopeFactor = 1.0 / cos(rad)
                    planArea = lx * ly * slopeFactor
                    vol = planArea * t
                    formwork = planArea + 2.0 * (lx * slopeFactor + ly) * t
                    formula = "A_inclined = (Lx·Ly)/cos(θ); V = A_inclined × T"
                }
                else -> {
                    planArea = lx * ly
                    vol = planArea * t
                    formwork = planArea + 2.0 * (lx + ly) * t
                    formula = "V = Lx × Ly × T; Formwork = Area + Edge Perimeter × T"
                }
            }

            val (bags, sandCft, aggCft) = concreteBatch(vol, mixRatioFor("M20"), ctx.settings.defaultWastagePercent)
            val steelKg = vol * (sp / 100.0) * 7850.0
            val warnings = buildList {
                if (t < 0.10) add("Thickness < 100 mm; verify punching/deflection & minimum cover per IS 456.")
                if (type in setOf("Flat Slab (Drop Panel)", "Waffle Slab", "Hollow-Core Slab")) {
                    add("$type requires punching shear / diaphragm design certification by a structural engineer.")
                }
            }
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Slab Type", type, "", isPrimary = true),
                        CalcResultItem("Effective Concrete Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Formwork / Soffit Area", UnitConverter.fmt(formwork, p), "m²", isPrimary = true),
                        CalcResultItem("Slab Plan/Surface Area", UnitConverter.fmt(planArea, p), "m²"),
                        CalcResultItem("Preliminary Steel Est.", UnitConverter.fmt(steelKg, p), "kg"),
                        CalcResultItem("Cement / Sand / Agg (M20)", "${UnitConverter.fmt(bags, 1)} Bags | ${UnitConverter.fmt(sandCft, 0)}/${UnitConverter.fmt(aggCft, 0)} CFT", "")
                    ),
                    formula = formula,
                    steps = listOf(
                        "Geometry: $type | Area = ${UnitConverter.fmt(planArea, p)} m²",
                        "Concrete = ${UnitConverter.fmt(vol, p)} m³ | Steel = ${UnitConverter.fmt(steelKg, p)} kg"
                    ),
                    assumptions = "Uses steel density 7850 kg/m³; M20 grade concrete batching.",
                    warnings = warnings
                )
            )
        }
    )

    fun multiTypeStaircaseCalculator() = CalcToolSpec(
        id = "struct_stair_straight",
        title = "Staircase Calculator (All Types)",
        titleHi = "सीढ़ी कैलकुलेटर (सभी प्रकार)",
        subtitle = "Straight, Dog-Legged, Open-Well, U/L-Shaped, Quarter/Half-Turn, Spiral & Circular",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "stairType",
        keywords = listOf(
            "staircase", "straight", "dog-legged", "open-well", "u-shaped", "l-shaped",
            "spiral", "circular", "quarter-turn", "half-turn", "landing", "riser", "tread"
        ),
        fields = listOf(
            CalcFieldSpec(
                "stairType", "Staircase Type", "Straight Staircase",
                options = listOf(
                    "Straight Staircase",
                    "Dog-Legged Staircase",
                    "Open-Well Staircase",
                    "U-Shaped Staircase",
                    "L-Shaped (Quarter-Turn)",
                    "Half-Turn Staircase",
                    "Staircase with Landing",
                    "Spiral Staircase",
                    "Circular / Helical Staircase"
                )
            ),
            CalcFieldSpec("floorH", "Floor-to-Floor Height", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("riser", "Riser Height (R)", "150", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec(
                key = "tread", label = "Tread Depth (T)", defaultValue = "280",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["stairType"] != "Spiral Staircase" }
            ),
            CalcFieldSpec(
                key = "width", label = "Stair / Flight Width (W)", defaultValue = "1.2",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["stairType"] !in setOf("Spiral Staircase", "Circular / Helical Staircase") }
            ),
            CalcFieldSpec(
                key = "outerDia", label = "Outer Stair Diameter (Ø)", defaultValue = "2.2",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["stairType"] in setOf("Spiral Staircase", "Circular / Helical Staircase") }
            ),
            CalcFieldSpec(
                key = "innerDia", label = "Center Pole / Inner Void Ø", defaultValue = "0.25",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["stairType"] in setOf("Spiral Staircase", "Circular / Helical Staircase") }
            ),
            CalcFieldSpec(
                key = "landW", label = "Landing Width / Depth", defaultValue = "1.2",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = {
                    it["stairType"] in setOf(
                        "Dog-Legged Staircase", "Open-Well Staircase", "U-Shaped Staircase",
                        "L-Shaped (Quarter-Turn)", "Half-Turn Staircase", "Staircase with Landing"
                    )
                }
            ),
            CalcFieldSpec("waist", "Waist Slab Thickness", "150", FieldUnitKind.LENGTH, LengthUnit.MM)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("stairType").ifBlank { "Straight Staircase" }
            val fh = ctx.lengthMeters("floorH") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter floor height."))
            val r = ctx.lengthMeters("riser") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter riser."))
            val t = ctx.lengthMeters("tread") ?: 0.28
            val w = ctx.lengthMeters("width") ?: 1.2
            val outerDia = ctx.lengthMeters("outerDia") ?: 2.2
            val innerDia = ctx.lengthMeters("innerDia") ?: 0.25
            val landW = ctx.lengthMeters("landW") ?: 1.2
            val waist = ctx.lengthMeters("waist") ?: 0.15
            if (fh <= 0 || r <= 0 || waist <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid staircase inputs."))

            val numRisers = max(2, (fh / r).roundToInt())
            val actualRiser = fh / numRisers
            val numTreads = max(1, numRisers - 1)
            val totalVol: Double
            val formwork: Double
            val totalRun: Double
            val angleDeg: Double
            val formula: String

            if (type in setOf("Spiral Staircase", "Circular / Helical Staircase")) {
                val rOut = outerDia / 2.0
                val rIn = (innerDia / 2.0).coerceAtMost(rOut * 0.6)
                val flightW = rOut - rIn
                val meanR = (rOut + rIn) / 2.0
                val walkRun = if (type == "Spiral Staircase") 2.0 * PI * meanR else (numTreads * t)
                val incLen = sqrt(fh * fh + walkRun * walkRun)
                totalRun = walkRun
                angleDeg = Math.toDegrees(atan2(fh, walkRun))
                val waistVol = incLen * flightW * waist
                val stepT = (walkRun / numTreads)
                val stepsVol = numTreads * 0.5 * actualRiser * stepT * flightW
                val poleVol = if (type == "Spiral Staircase") PI * rIn * rIn * fh else 0.0
                totalVol = waistVol + stepsVol + poleVol
                formwork = incLen * flightW + numRisers * actualRiser * flightW
                formula = "V = L_helical×W×Waist + N_steps×(0.5×R×T_mean×W) + V_pole"
            } else {
                totalRun = numTreads * t
                val hasTwoFlights = type in setOf("Dog-Legged Staircase", "U-Shaped Staircase", "Half-Turn Staircase", "L-Shaped (Quarter-Turn)")
                val isOpenWell = type == "Open-Well Staircase"
                val runPerFlight = when {
                    isOpenWell -> totalRun / 3.0
                    hasTwoFlights -> totalRun / 2.0
                    else -> totalRun
                }
                val hPerFlight = when {
                    isOpenWell -> fh / 3.0
                    hasTwoFlights -> fh / 2.0
                    else -> fh
                }
                val incLenFlight = sqrt(hPerFlight * hPerFlight + runPerFlight * runPerFlight)
                val numFlights = when {
                    isOpenWell -> 3
                    hasTwoFlights -> 2
                    else -> 1
                }
                val landingsCount = when {
                    isOpenWell -> 2
                    hasTwoFlights || type == "Staircase with Landing" -> 1
                    else -> 0
                }
                val landingArea = when {
                    type == "L-Shaped (Quarter-Turn)" -> w * landW
                    type in setOf("Dog-Legged Staircase", "Half-Turn Staircase", "U-Shaped Staircase", "Open-Well Staircase") -> (2.0 * w + 0.15) * landW
                    type == "Staircase with Landing" -> w * landW
                    else -> 0.0
                }
                val waistVol = numFlights * incLenFlight * w * waist
                val stepsVol = numTreads * 0.5 * actualRiser * t * w
                val landingVol = landingsCount * landingArea * waist
                totalVol = waistVol + stepsVol + landingVol
                formwork = numFlights * incLenFlight * w + landingsCount * landingArea + numRisers * actualRiser * w
                angleDeg = Math.toDegrees(atan2(hPerFlight, max(0.2, runPerFlight)))
                formula = "V = N_flights×(L_inc×W×Waist) + V_steps + V_landings"
            }

            val steelKg = totalVol * 0.011 * 7850.0
            val (bags, _, _) = concreteBatch(totalVol, mixRatioFor("M20"), ctx.settings.defaultWastagePercent)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Steps / Inclination", "$numRisers Risers • ${UnitConverter.fmt(angleDeg, 1)}°", "", isPrimary = true),
                        CalcResultItem("Formwork (Soffit + Risers)", UnitConverter.fmt(formwork, p), "m²"),
                        CalcResultItem("Total Horizontal Run", UnitConverter.fmt(totalRun, p), "m"),
                        CalcResultItem("Adjusted Riser", UnitConverter.fmt(actualRiser * 1000.0, 1), "mm"),
                        CalcResultItem("Steel (~1.1%) / Cement", "${UnitConverter.fmt(steelKg, 1)} kg / ${UnitConverter.fmt(bags, 1)} Bags", "")
                    ),
                    formula = formula,
                    steps = listOf(
                        "Type: $type | Floor Ht=${UnitConverter.fmt(fh, p)}m → $numRisers Risers",
                        "Angle θ = ${UnitConverter.fmt(angleDeg, 1)}° | Run = ${UnitConverter.fmt(totalRun, p)} m"
                    ),
                    assumptions = "Waist slab M20 concrete. Spiral/Helical/Open-Well torsion & landing support design requires structural certification."
                )
            )
        }
    )

    fun groundPlinthTieBeamCalculator() = CalcToolSpec(
        id = "struct_ground_beams",
        title = "Grade, Plinth & Tie Beam Estimator",
        titleHi = "प्लिंथ, टाई और ग्राउंड बीम",
        subtitle = "Grade Beam, Plinth Beam, Tie Beam & Ground Beam Concrete, Formwork & Steel",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "gBeamType",
        keywords = listOf("grade beam", "plinth beam", "tie beam", "ground beam", "substructure", "foundation"),
        fields = listOf(
            CalcFieldSpec("gBeamType", "Beam Category", "Plinth Beam", options = listOf("Grade Beam", "Plinth Beam", "Tie Beam", "Ground Beam")),
            CalcFieldSpec("len", "Total Running Length", "45.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("b", "Beam Width (B)", "230", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("d", "Beam Depth (D)", "350", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("steelPct", "Est. Steel %", "1.4", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("gBeamType")
            val len = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val b = ctx.lengthMeters("b") ?: 0.23
            val d = ctx.lengthMeters("d") ?: 0.35
            val sp = ctx.doubleOrNull("steelPct") ?: 1.4
            if (len <= 0 || b <= 0 || d <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val vol = len * b * d
            val fw = 2.0 * d * len // side shuttering on grade/PCC
            val pccVol = if (type in setOf("Grade Beam", "Ground Beam")) len * (b + 0.15) * 0.075 else 0.0
            val steelKg = vol * (sp / 100.0) * 7850.0
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("$type Concrete", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Side Formwork", UnitConverter.fmt(fw, p), "m²", isPrimary = true),
                        CalcResultItem("Preliminary Steel Est.", UnitConverter.fmt(steelKg, p), "kg"),
                        CalcResultItem("75mm PCC Bed (Grade/Ground)", UnitConverter.fmt(pccVol, p), "m³")
                    ),
                    formula = "V = L × B × D; Side Formwork = 2 × D × L",
                    steps = listOf("${UnitConverter.fmt(len, p)} × ${UnitConverter.fmt(b, 3)} × ${UnitConverter.fmt(d, 3)} = ${UnitConverter.fmt(vol, p)} m³"),
                    assumptions = "Nominal cover 25–40 mm; includes 75 mm PCC blinding below Grade/Ground beams."
                )
            )
        }
    )

    fun structuralWallCalculator() = CalcToolSpec(
        id = "struct_wall_multi",
        title = "Concrete, Shear & Multi-Shape Wall",
        titleHi = "कंक्रीट, शियर और बहु-आकार दीवार",
        subtitle = "Shear Wall, RCC Wall, Cavity Wall, Boundary Wall, L-Shaped, Curved & Circular Wall",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "wallType",
        keywords = listOf("concrete wall", "shear wall", "boundary wall", "cavity wall", "partition", "curved wall", "circular wall", "l-shaped wall"),
        fields = listOf(
            CalcFieldSpec(
                "wallType", "Wall Type", "Shear Wall",
                options = listOf(
                    "Concrete Wall", "Shear Wall", "Boundary Wall", "Cavity Wall",
                    "Partition Wall", "L-Shaped Wall", "Curved Wall", "Circular Wall"
                )
            ),
            CalcFieldSpec(
                key = "l", label = "Wall Length (L1)", defaultValue = "6.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["wallType"] != "Circular Wall" },
                dynamicLabel = { m ->
                    when (m["wallType"]) {
                        "L-Shaped Wall" -> "Wing 1 Length (L1)"
                        "Curved Wall" -> "Arc Length (L_arc)"
                        else -> "Wall Length (L)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "l2", label = "Wing 2 Length (L2)", defaultValue = "4.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["wallType"] == "L-Shaped Wall" }
            ),
            CalcFieldSpec(
                key = "dia", label = "Centerline Wall Diameter (Ø)", defaultValue = "5.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["wallType"] == "Circular Wall" }
            ),
            CalcFieldSpec("h", "Wall Height (H)", "3.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("t", "Wall / Leaf Thickness (T)", "250", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec(
                key = "deduct", label = "Opening Deductions (m²)", defaultValue = "0",
                unitKind = FieldUnitKind.AREA_SQ_M, allowZero = true
            )
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("wallType").ifBlank { "Shear Wall" }
            val l1 = ctx.lengthMeters("l") ?: 6.0
            val l2 = ctx.lengthMeters("l2") ?: 4.0
            val dia = ctx.lengthMeters("dia") ?: 5.0
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val t = ctx.lengthMeters("t") ?: 0.25
            val deduct = ctx.doubleOrNull("deduct") ?: 0.0
            val effLen = when (type) {
                "Circular Wall" -> PI * dia
                "L-Shaped Wall" -> l1 + l2 - t
                else -> l1
            }
            val grossArea = effLen * h
            val netArea = (grossArea - deduct).coerceAtLeast(0.0)
            val mult = if (type == "Cavity Wall") 2.0 else 1.0
            val vol = netArea * t * mult
            val fw = netArea * 2.0 * mult
            val steelRatio = if (type == "Shear Wall") 0.018 else 0.010
            val steelKg = vol * steelRatio * 7850.0
            val (bags, sandCft, aggCft) = concreteBatch(vol, mixRatioFor("M25"), ctx.settings.defaultWastagePercent)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Concrete Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Formwork (Both Faces)", UnitConverter.fmt(fw, p), "m²", isPrimary = true),
                        CalcResultItem("Preliminary Steel Est.", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true),
                        CalcResultItem("Net Wall Surface Area", UnitConverter.fmt(netArea, p), "m²"),
                        CalcResultItem("Cement / Sand / Agg (M25)", "${UnitConverter.fmt(bags, 1)} Bags | ${UnitConverter.fmt(sandCft, 0)}/${UnitConverter.fmt(aggCft, 0)} CFT", "")
                    ),
                    formula = "V = (L_eff × H - Deductions) × T${if (type == "Cavity Wall") " × 2 Leaves" else ""}",
                    steps = listOf("Type: $type | Eff. Length = ${UnitConverter.fmt(effLen, p)} m | Net Area = ${UnitConverter.fmt(netArea, p)} m²"),
                    assumptions = "Shear wall steel estimated at 1.8% (boundary element + web mesh); regular RCC wall at 1.0%."
                )
            )
        }
    )

    fun miscStructuralElementsCalculator() = CalcToolSpec(
        id = "struct_misc_elements",
        title = "Parapet, Ramp, Platform & Steps",
        titleHi = "पैरापेट, रैंप, प्लेटफ़ॉर्म और कंक्रीट स्टेप्स",
        subtitle = "Parapet Wall, Sloped Ramp, Machine/Loading Platform & Entry Concrete Steps",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "elemType",
        keywords = listOf("parapet", "ramp", "platform", "concrete steps", "entry steps", "apron", "plinth"),
        fields = listOf(
            CalcFieldSpec("elemType", "Element Type", "Concrete Ramp", options = listOf("Parapet Wall", "Concrete Ramp", "Loading Platform", "Concrete Steps (Entry)")),
            CalcFieldSpec("l", "Length / Horizontal Run", "6.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Width / Thickness", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec(
                key = "h", label = "Height / Rise (H)", defaultValue = "0.9",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M
            ),
            CalcFieldSpec(
                key = "t", label = "Slab / Base Thickness", defaultValue = "150",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { it["elemType"] in setOf("Concrete Ramp", "Loading Platform") }
            ),
            CalcFieldSpec(
                key = "stepsCount", label = "Number of Steps", defaultValue = "5",
                unitKind = FieldUnitKind.COUNT,
                visibleWhen = { it["elemType"] == "Concrete Steps (Entry)" }
            )
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("elemType").ifBlank { "Concrete Ramp" }
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: 1.0
            val h = ctx.lengthMeters("h") ?: 0.9
            val t = ctx.lengthMeters("t") ?: 0.15
            val vol: Double
            val fw: Double
            val formula: String
            when (type) {
                "Parapet Wall" -> {
                    vol = l * w * h
                    fw = 2.0 * l * h
                    formula = "V = L × T_wall × H"
                }
                "Concrete Ramp" -> {
                    val inc = sqrt(l * l + h * h)
                    vol = inc * w * t + 0.5 * l * h * w * 0.0 // slab on compacted fill
                    val wedgeVol = 0.5 * l * h * w
                    fw = 2.0 * inc * t + w * t
                    formula = "V_slab = √(L² + H²) × W × T; Sub-base Wedge = 0.5·L·H·W"
                    return@CalcToolSpec Result.success(
                        CalcOutcome(
                            results = listOf(
                                CalcResultItem("Ramp Slab Concrete", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                                CalcResultItem("Sub-Base Fill Wedge", UnitConverter.fmt(wedgeVol, p), "m³", isPrimary = true),
                                CalcResultItem("Slope Angle & Ratio", "${UnitConverter.fmt(Math.toDegrees(atan2(h, l)), 1)}° (1:${UnitConverter.fmt(l / max(0.01, h), 1)})", ""),
                                CalcResultItem("Side Edge Formwork", UnitConverter.fmt(fw, p), "m²")
                            ),
                            formula = formula,
                            steps = listOf("Inclined Ramp Length = ${UnitConverter.fmt(inc, p)} m"),
                            assumptions = "Ramp slab supported on compacted GSB/murrum wedge fill."
                        )
                    )
                }
                "Concrete Steps (Entry)" -> {
                    val nSteps = (ctx.doubleOrNull("stepsCount") ?: 5.0).roundToInt().coerceAtLeast(1)
                    val rH = h / nSteps
                    val tD = l / nSteps
                    // Solid stepped block: sum i=1..nSteps of i * rH * tD * w
                    vol = (nSteps * (nSteps + 1) / 2.0) * rH * tD * w
                    fw = 2.0 * nSteps * rH * tD + nSteps * rH * w
                    formula = "V = Σ(i=1..N)[i × R × T × W] = [N(N+1)/2]·R·T·W"
                }
                else -> {
                    // Loading Platform
                    vol = l * w * h
                    fw = 2.0 * (l + w) * h
                    formula = "V = L × W × H"
                }
            }
            val (bags, sandCft, aggCft) = concreteBatch(vol, mixRatioFor("M20"), ctx.settings.defaultWastagePercent)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("$type Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Formwork Area", UnitConverter.fmt(fw, p), "m²", isPrimary = true),
                        CalcResultItem("Cement / Sand / Agg (M20)", "${UnitConverter.fmt(bags, 1)} Bags | ${UnitConverter.fmt(sandCft, 0)}/${UnitConverter.fmt(aggCft, 0)} CFT", "")
                    ),
                    formula = formula,
                    steps = listOf("Type: $type | Concrete Volume = ${UnitConverter.fmt(vol, p)} m³"),
                    assumptions = "Preliminary quantity estimate using M20 concrete."
                )
            )
        }
    )

    fun roofingAndPebMultiTypeCalculator() = CalcToolSpec(
        id = "struct_roofing",
        title = "Roofing, Canopy & PEB Roof Types",
        titleHi = "छत, कैनोपी और PEB शेड प्रकार",
        subtitle = "Flat, Sloped, Single/Double Slope, Gable, Hip, Shed, Canopy & Sheet Layout",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "roofType",
        keywords = listOf(
            "roof", "flat roof", "sloped roof", "single slope", "double slope", "gable",
            "hip roof", "shed roof", "canopy", "peb", "warehouse", "sheet", "roofing"
        ),
        fields = listOf(
            CalcFieldSpec(
                "roofType", "Roof / Shed Type", "Double-Slope / Gable Roof",
                options = listOf(
                    "Flat Roof",
                    "Single-Slope / Shed Roof",
                    "Double-Slope / Gable Roof",
                    "Hip Roof",
                    "Canopy Roof",
                    "Industrial PEB Shed",
                    "Warehouse Roof & Sheet Layout"
                )
            ),
            CalcFieldSpec("span", "Building Span / Width (W)", "18.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("len", "Building Length (L)", "36.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec(
                key = "rise", label = "Roof Ridge Rise above Eave (H_r)", defaultValue = "2.2",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                allowZero = true,
                visibleWhen = { it["roofType"] != "Flat Roof" }
            ),
            CalcFieldSpec(
                key = "eaveH", label = "Eave Column Height", defaultValue = "7.5",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["roofType"] in setOf("Industrial PEB Shed", "Warehouse Roof & Sheet Layout", "Canopy Roof") }
            ),
            CalcFieldSpec("overhang", "Eave Overhang (Each Side)", "0.6", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true),
            CalcFieldSpec("sheetW", "Effective Sheet Cover Width (m)", "1.05", FieldUnitKind.NONE),
            CalcFieldSpec(
                key = "baySpace", label = "Frame / Truss Bay Spacing", defaultValue = "6.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["roofType"] != "Flat Roof" }
            )
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("roofType").ifBlank { "Double-Slope / Gable Roof" }
            val span = ctx.lengthMeters("span") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter span."))
            val len = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val rise = ctx.lengthMeters("rise") ?: 2.0
            val overhang = ctx.lengthMeters("overhang") ?: 0.5
            val sheetW = (ctx.doubleOrNull("sheetW") ?: 1.05).coerceAtLeast(0.4)
            val baySpace = (ctx.lengthMeters("baySpace") ?: 6.0).coerceAtLeast(2.0)

            val effW = span + 2.0 * overhang
            val effL = len + 2.0 * overhang
            val roofArea: Double
            val rafterLen: Double
            val slopeDeg: Double
            val formula: String

            when (type) {
                "Flat Roof" -> {
                    roofArea = effW * effL
                    rafterLen = effW
                    slopeDeg = 0.0
                    formula = "Area = (W + 2·OH) × (L + 2·OH)"
                }
                "Single-Slope / Shed Roof", "Canopy Roof" -> {
                    rafterLen = sqrt(effW * effW + rise * rise)
                    slopeDeg = Math.toDegrees(atan2(rise, effW))
                    roofArea = rafterLen * effL
                    formula = "S = √(W_eff² + Rise²); Roof Area = S × L_eff"
                }
                "Hip Roof" -> {
                    val halfW = effW / 2.0
                    rafterLen = sqrt(halfW * halfW + rise * rise)
                    slopeDeg = Math.toDegrees(atan2(rise, halfW))
                    roofArea = effL * effW / cos(Math.toRadians(slopeDeg))
                    formula = "Area_hip = (L_eff × W_eff) / cos(θ_pitch)"
                }
                else -> {
                    // Double-Slope / Gable / PEB / Warehouse
                    val halfW = effW / 2.0
                    rafterLen = sqrt(halfW * halfW + rise * rise)
                    slopeDeg = Math.toDegrees(atan2(rise, halfW))
                    roofArea = 2.0 * rafterLen * effL
                    formula = "S = √((W_eff/2)² + Rise²); Roof Area = 2 × S × L_eff"
                }
            }

            val sheetsCount = ceil((effL / sheetW) * (if (type in setOf("Flat Roof", "Single-Slope / Shed Roof", "Canopy Roof")) 1 else 2)).toInt()
            val framesCount = ceil(len / baySpace).toInt() + 1
            val pebSteelKg = if (type in setOf("Industrial PEB Shed", "Warehouse Roof & Sheet Layout")) span * len * 30.0 else 0.0

            Result.success(
                CalcOutcome(
                    results = buildList {
                        add(CalcResultItem("Total Roofing Area", "${UnitConverter.fmt(roofArea, p)} m² (${UnitConverter.fmt(roofArea * 10.7639, 0)} sq.ft)", "", isPrimary = true))
                        add(CalcResultItem("Rafter / Slope Length", UnitConverter.fmt(rafterLen, p), "m", isPrimary = true))
                        add(CalcResultItem("Roof Pitch Angle", "${UnitConverter.fmt(slopeDeg, 1)}°", ""))
                        add(CalcResultItem("Sheets Required (@${UnitConverter.fmt(sheetW, 2)}m)", "$sheetsCount", "Sheets"))
                        if (type != "Flat Roof") add(CalcResultItem("Trusses / Portal Frames", "$framesCount", "Frames"))
                        if (pebSteelKg > 0) add(CalcResultItem("Prelim. PEB Steel (~30 kg/m²)", UnitConverter.fmt(pebSteelKg / 1000.0, 2), "MT"))
                    },
                    formula = formula,
                    steps = listOf("Type: $type | Pitch θ = ${UnitConverter.fmt(slopeDeg, 1)}° | Rafter = ${UnitConverter.fmt(rafterLen, p)} m"),
                    assumptions = "Preliminary quantity estimate; sheet overlap/ridge cap wastage (+5–8%) and wind uplift design per IS 875 / IS 800."
                )
            )
        }
    )
}

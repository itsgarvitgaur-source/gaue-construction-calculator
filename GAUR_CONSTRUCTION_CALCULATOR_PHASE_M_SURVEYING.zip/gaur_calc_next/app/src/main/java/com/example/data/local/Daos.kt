package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun observeById(id: Long): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects")
    suspend fun getAllOnce(): List<ProjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(project: ProjectEntity): Long

    @Update
    suspend fun update(project: ProjectEntity)

    @Delete
    suspend fun delete(project: ProjectEntity)

    @Query("DELETE FROM projects")
    suspend fun clearAll()
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM calculation_history ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<CalculationHistoryEntity>>

    @Query("SELECT * FROM calculation_history WHERE projectId = :projectId ORDER BY timestamp DESC")
    fun observeForProject(projectId: Long): Flow<List<CalculationHistoryEntity>>

    @Query("SELECT * FROM calculation_history")
    suspend fun getAllOnce(): List<CalculationHistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CalculationHistoryEntity): Long

    @Query("DELETE FROM calculation_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM calculation_history")
    suspend fun clearAll()
}

@Dao
interface FavoriteToolDao {
    @Query("SELECT * FROM favorite_tools")
    fun observeAll(): Flow<List<FavoriteToolEntity>>

    @Query("SELECT * FROM favorite_tools WHERE toolId = :toolId")
    suspend fun getById(toolId: String): FavoriteToolEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: FavoriteToolEntity)
}

@Dao
interface BoqDao {
    @Query("SELECT * FROM boq_estimates ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<BoqEstimateEntity>>

    @Query("SELECT * FROM boq_estimates WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeForProject(projectId: Long): Flow<List<BoqEstimateEntity>>

    @Query("SELECT * FROM boq_estimates")
    suspend fun getAllOnce(): List<BoqEstimateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(estimate: BoqEstimateEntity): Long

    @Query("DELETE FROM boq_estimates WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM boq_estimates")
    suspend fun clearAll()
}

@Dao
interface BbsDao {
    @Query("SELECT * FROM bbs_schedules ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<BbsScheduleEntity>>

    @Query("SELECT * FROM bbs_schedules WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeForProject(projectId: Long): Flow<List<BbsScheduleEntity>>

    @Query("SELECT * FROM bbs_schedules")
    suspend fun getAllOnce(): List<BbsScheduleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(schedule: BbsScheduleEntity): Long

    @Query("DELETE FROM bbs_schedules WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM bbs_schedules")
    suspend fun clearAll()
}

@Dao
interface MaterialRateDao {
    @Query("SELECT * FROM material_rates ORDER BY category ASC, name ASC")
    fun observeAll(): Flow<List<MaterialRateEntity>>

    @Query("SELECT COUNT(*) FROM material_rates")
    suspend fun count(): Int

    @Query("SELECT * FROM material_rates")
    suspend fun getAllOnce(): List<MaterialRateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rates: List<MaterialRateEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(rate: MaterialRateEntity): Long

    @Query("DELETE FROM material_rates WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM material_rates")
    suspend fun clearAll()
}

@Dao
interface StudioDrawingDao {
    @Query("SELECT * FROM studio_drawings ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<StudioDrawingEntity>>

    @Query("SELECT * FROM studio_drawings WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeForProject(projectId: Long): Flow<List<StudioDrawingEntity>>

    @Query("SELECT * FROM studio_drawings")
    suspend fun getAllOnce(): List<StudioDrawingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(drawing: StudioDrawingEntity): Long

    @Query("DELETE FROM studio_drawings WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM studio_drawings")
    suspend fun clearAll()
}

@Dao
interface StudioModel3DDao {
    @Query("SELECT * FROM studio_models_3d ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<StudioModel3DEntity>>

    @Query("SELECT * FROM studio_models_3d WHERE projectId = :projectId ORDER BY updatedAt DESC")
    fun observeForProject(projectId: Long): Flow<List<StudioModel3DEntity>>

    @Query("SELECT * FROM studio_models_3d")
    suspend fun getAllOnce(): List<StudioModel3DEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(model: StudioModel3DEntity): Long

    @Query("DELETE FROM studio_models_3d WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM studio_models_3d")
    suspend fun clearAll()
}

@Dao
interface SecurityEventDao {
    @Query("SELECT * FROM security_events ORDER BY timestamp DESC LIMIT 100")
    fun observeRecent(): Flow<List<SecurityEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: SecurityEventEntity): Long

    @Query("DELETE FROM security_events")
    suspend fun clearAll()
}

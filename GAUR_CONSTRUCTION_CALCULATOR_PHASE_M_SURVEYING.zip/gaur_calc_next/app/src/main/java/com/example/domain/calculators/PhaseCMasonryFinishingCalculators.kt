package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.sqrt

object PhaseCMasonryFinishingCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        multiOpeningWallDeductionCalculator(),
        parapetBoundaryWallCalculator(),
        archMasonryCenteringCalculator(),
        tileAdhesiveGroutCalculator(),
        gypsumPlasterBagCalculator(),
        drywallPartitionCalculator(),
        plywoodLaminateCalculator(),
        skirtingDadoTileCalculator(),
        stoneCladdingAnchorCalculator(),
        kerbRoadsideDrainCalculator()
    )

    private fun multiOpeningWallDeductionCalculator() = CalcToolSpec(
        id = "masonry_opening_deduct",
        title = "Wall Opening Deduction (Doors & Windows)",
        titleHi = "दीवार दरवाज़ा-खिड़की कटौती और शुद्ध चिनाई",
        subtitle = "Net Wall Area & Volume After Multiple Doors, Windows & Ventilators",
        category = CalcCategory.MASONRY,
        keywords = listOf("deduction", "opening", "door", "window", "wall", "masonry", "net area"),
        fields = listOf(
            CalcFieldSpec("wallL", "Total Wall Length", "12.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("wallH", "Wall Height", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("wallT", "Wall Thickness (mm)", "230", FieldUnitKind.NONE),
            CalcFieldSpec("doorsN", "Number of Doors", "2", FieldUnitKind.COUNT, allowZero = true),
            CalcFieldSpec("doorArea", "Single Door Size Area (m²)", "2.1", FieldUnitKind.AREA_SQ_M, allowZero = true),
            CalcFieldSpec("winN", "Number of Windows", "3", FieldUnitKind.COUNT, allowZero = true),
            CalcFieldSpec("winArea", "Single Window Size Area (m²)", "1.8", FieldUnitKind.AREA_SQ_M, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val wl = ctx.lengthMeters("wallL") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter wall length."))
            val wh = ctx.lengthMeters("wallH") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter wall height."))
            val wtMm = ctx.doubleOrNull("wallT") ?: 230.0
            val dN = (ctx.doubleOrNull("doorsN") ?: 0.0).coerceAtLeast(0.0)
            val dA = (ctx.doubleOrNull("doorArea") ?: 0.0).coerceAtLeast(0.0)
            val wN = (ctx.doubleOrNull("winN") ?: 0.0).coerceAtLeast(0.0)
            val wA = (ctx.doubleOrNull("winArea") ?: 0.0).coerceAtLeast(0.0)
            if (wl <= 0 || wh <= 0 || wtMm <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Wall dimensions must be positive."))

            val grossArea = wl * wh
            val deductArea = (dN * dA) + (wN * wA)
            val netArea = (grossArea - deductArea).coerceAtLeast(0.0)
            val netVol = netArea * (wtMm / 1000.0)
            val stdBricks = ceil(netVol * 500.0).toInt()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Net Masonry Volume", UnitConverter.fmt(netVol, p), "m³", isPrimary = true),
                        CalcResultItem("Net Wall Area", UnitConverter.fmt(netArea, p), "m² (${UnitConverter.fmt(netArea * 10.7639, 0)} sq.ft)", isPrimary = true),
                        CalcResultItem("Gross Area / Deducted", "${UnitConverter.fmt(grossArea, p)} / ${UnitConverter.fmt(deductArea, p)}", "m²"),
                        CalcResultItem("Approx. Modular Bricks (500/m³)", "$stdBricks", "bricks")
                    ),
                    formula = "Net Area = (L × H) − (N_door×A_door + N_win×A_win); Vol = Net × (t/1000)",
                    steps = listOf("Gross=${UnitConverter.fmt(grossArea, p)} − Ded=${UnitConverter.fmt(deductArea, p)} = ${UnitConverter.fmt(netArea, p)} m²"),
                    assumptions = "Verify IS 1200 Part 3 measurement deduction rules for small openings (< 0.1 m²)."
                )
            )
        }
    )

    private fun parapetBoundaryWallCalculator() = CalcToolSpec(
        id = "masonry_parapet_boundary",
        title = "Parapet & Compound Boundary Wall + Pillars",
        titleHi = "पैरापेट और बाउंड्री वॉल (पिलर व कोपिंग सहित)",
        subtitle = "Wall Bricks, RCC/Brick Pillars, Plinth & Top Coping Mortar",
        category = CalcCategory.MASONRY,
        keywords = listOf("parapet", "boundary", "compound wall", "pillar", "coping", "brick"),
        fields = listOf(
            CalcFieldSpec("perim", "Total Wall Run Length", "60.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Wall Height", "1.8", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("wallT", "Wall Thickness (mm)", "230", FieldUnitKind.NONE),
            CalcFieldSpec("pillarSp", "Pillar Spacing c/c (0 = No Pillars)", "3.0", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("copingT", "Top Coping / Plaster Drop (mm)", "75", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val perim = ctx.lengthMeters("perim") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val wt = (ctx.doubleOrNull("wallT") ?: 230.0) / 1000.0
            val pSp = (ctx.doubleOrNull("pillarSp") ?: 3.0).coerceAtLeast(0.0)
            val copT = (ctx.doubleOrNull("copingT") ?: 75.0) / 1000.0
            if (perim <= 0 || h <= 0 || wt <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Wall dimensions must be positive."))

            val pillars = if (pSp > 0) (perim / pSp).toInt() + 1 else 0
            val wallVol = perim * h * wt
            val pillarExtraVol = pillars * (wt * wt * 0.6) * h // extra pilaster projection
            val totalMasonryVol = wallVol + pillarExtraVol
            val bricks = ceil(totalMasonryVol * 500.0).toInt()
            val copingVol = perim * (wt + 0.05) * copT

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Masonry Volume", UnitConverter.fmt(totalMasonryVol, p), "m³", isPrimary = true),
                        CalcResultItem("Modular Bricks Needed", "$bricks", "nos (incl. $pillars pillars)", isPrimary = true),
                        CalcResultItem("PCC Coping Concrete", UnitConverter.fmt(copingVol, p), "m³"),
                        CalcResultItem("2-Side Wall Plaster Area", UnitConverter.fmt(perim * h * 2.0, p), "m²")
                    ),
                    formula = "Vol = L×H×t + Pillars_proj; Coping = L×(t+50mm)×Coping_t",
                    steps = listOf("Wall=${UnitConverter.fmt(wallVol, p)} m³ + Pillars(${pillars})=${UnitConverter.fmt(pillarExtraVol, p)} m³"),
                    assumptions = "Uses 500 bricks/m³ nominal; coping projects 25mm each side for drip-course."
                )
            )
        }
    )

    private fun archMasonryCenteringCalculator() = CalcToolSpec(
        id = "masonry_arch_lintel",
        title = "Brick / Stone Arch & Centering Estimator",
        titleHi = "मेहराब (Arch) चिनाई और शटरिंग क्षेत्रफल",
        subtitle = "Segmental / Semicircular Arch Arc Length, Bricks, Mortar & Soffit Centering",
        category = CalcCategory.MASONRY,
        keywords = listOf("arch", "voussoir", "centering", "brick arch", "stone arch", "radius"),
        fields = listOf(
            CalcFieldSpec("span", "Arch Clear Span", "2.4", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("rise", "Arch Rise (Crown above Springing)", "0.6", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("wallT", "Arch Width / Wall Thick", "0.30", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("ringD", "Arch Ring Depth (m)", "0.23", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val span = ctx.lengthMeters("span") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter span."))
            val rise = ctx.lengthMeters("rise") ?: 0.6
            val wt = ctx.lengthMeters("wallT") ?: 0.30
            val ringD = ctx.doubleOrNull("ringD") ?: 0.23
            if (span <= 0 || rise <= 0 || wt <= 0 || ringD <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val rInner = (rise * rise + (span * span / 4.0)) / (2.0 * rise)
            val thetaRad = 2.0 * kotlin.math.asin((span / (2.0 * rInner)).coerceIn(-1.0, 1.0))
            val arcInner = rInner * thetaRad
            val arcMid = (rInner + ringD / 2.0) * thetaRad
            val archVol = arcMid * ringD * wt
            val bricks = ceil(archVol * 520.0).toInt() // slightly higher wastage for wedge cuts
            val centeringArea = arcInner * wt

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Arch Ring Volume", UnitConverter.fmt(archVol, p), "m³", isPrimary = true),
                        CalcResultItem("Bricks / Voussoirs (+Cut)", "$bricks", "nos", isPrimary = true),
                        CalcResultItem("Soffit Centering Area", UnitConverter.fmt(centeringArea, p), "m²"),
                        CalcResultItem("Inner Radius & Mean Arc", "R=${UnitConverter.fmt(rInner, p)}m • Arc=${UnitConverter.fmt(arcMid, p)}m", "")
                    ),
                    formula = "R = (Rise² + (Span/2)²) / (2×Rise); θ = 2·asin(Span / 2R); Vol = (R + d/2)·θ·d·W",
                    steps = listOf("Inner R = ${UnitConverter.fmt(rInner, p)} m, Angle = ${UnitConverter.fmt(Math.toDegrees(thetaRad), 1)}°"),
                    assumptions = "Circular segmental geometry; assumes 520 bricks/m³ with arch-trimming allowance."
                )
            )
        }
    )

    private fun tileAdhesiveGroutCalculator() = CalcToolSpec(
        id = "finish_tile_adhesive",
        title = "Tile Adhesive, Grout & Tile Spacers",
        titleHi = "टाइल एडहेसिव, एपॉक्सी ग्राउट और स्पेसर",
        subtitle = "Polymer Tile Adhesive 20 kg Bags, Joint Grout kg & Leveling Clips",
        category = CalcCategory.FINISHING,
        keywords = listOf("tile adhesive", "grout", "epoxy", "spacer", "tiling", "bag"),
        fields = listOf(
            CalcFieldSpec("area", "Tiling Surface Area (sq.ft)", "600", FieldUnitKind.NONE),
            CalcFieldSpec("tileLmm", "Tile Length (mm)", "600", FieldUnitKind.NONE),
            CalcFieldSpec("tileWmm", "Tile Width (mm)", "600", FieldUnitKind.NONE),
            CalcFieldSpec("bedMm", "Adhesive Bed Thickness (mm)", "5", FieldUnitKind.NONE),
            CalcFieldSpec("jointMm", "Tile Joint Width (mm)", "3", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val sqFt = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter tiling area."))
            val tl = ctx.doubleOrNull("tileLmm") ?: 600.0
            val tw = ctx.doubleOrNull("tileWmm") ?: 600.0
            val bed = ctx.doubleOrNull("bedMm") ?: 5.0
            val jnt = (ctx.doubleOrNull("jointMm") ?: 3.0).coerceAtLeast(0.0)
            if (sqFt <= 0 || tl <= 0 || tw <= 0 || bed <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Area, tile dimensions & bed thickness must be positive."))
            }
            val areaM2 = sqFt * 0.092903
            // ~1.45 kg adhesive per m² per mm bed thickness
            val adhKg = areaM2 * bed * 1.45 * 1.05
            val adhBags20 = ceil(adhKg / 20.0).toInt()
            // Grout formula: ((L+W)/(L*W)) * tileThick(9mm) * jointW * 1.6 density * areaM2
            val groutKg = (((tl + tw) / (tl * tw)) * 9.0 * jnt * 1.6) * areaM2
            val tileAreaM2 = (tl / 1000.0) * (tw / 1000.0)
            val tilesN = ceil((areaM2 * 1.05) / tileAreaM2).toInt()
            val spacers = tilesN * 2

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("20 kg Adhesive Bags (+5%)", "$adhBags20", "bags (${UnitConverter.fmt(adhKg, 1)} kg)", isPrimary = true),
                        CalcResultItem("Tile Joint Grout / Epoxy", UnitConverter.fmt(groutKg, p), "kg", isPrimary = true),
                        CalcResultItem("Tiles (+5%) & Spacers", "$tilesN tiles • ~$spacers", "spacers")
                    ),
                    formula = "Adhesive = Area_m² × Bed_mm × 1.45 kg/m²/mm; Grout = ((L+W)/(L×W))×t×J×1.6×Area",
                    steps = listOf("Area=${UnitConverter.fmt(areaM2, p)} m²; Grout factor for ${tl.toInt()}×${tw.toInt()}mm @ ${jnt}mm joint"),
                    assumptions = "Assumes flat screed subfloor with 9mm tile thickness & ~1.45 kg/m²/mm dry adhesive consumption."
                )
            )
        }
    )

    private fun gypsumPlasterBagCalculator() = CalcToolSpec(
        id = "finish_gypsum_plaster",
        title = "Gypsum / POP Plaster Bag Estimator",
        titleHi = "जिप्सम / POP प्लास्टर बैग अनुमान",
        subtitle = "25 kg Gypsum Plaster Bags, Water & Coverage by Thickness",
        category = CalcCategory.FINISHING,
        keywords = listOf("gypsum", "pop", "plaster", "punched", "25kg", "bag", "wall"),
        fields = listOf(
            CalcFieldSpec("area", "Wall & Ceiling Area (sq.ft)", "1200", FieldUnitKind.NONE),
            CalcFieldSpec("thickMm", "Avg. Gypsum Thickness (mm)", "12", FieldUnitKind.NONE),
            CalcFieldSpec("deductSqFt", "Opening Deductions (sq.ft)", "120", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val grossSqFt = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter area."))
            val tMm = ctx.doubleOrNull("thickMm") ?: 12.0
            val ded = (ctx.doubleOrNull("deductSqFt") ?: 0.0).coerceAtLeast(0.0)
            if (grossSqFt <= 0 || tMm <= 0 || ded >= grossSqFt) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Check net area and plaster thickness."))
            }
            val netSqFt = grossSqFt - ded
            val netM2 = netSqFt * 0.092903
            // 1 bag (25 kg) covers ~21 sq.ft at 12mm (~1.95 m²/bag @ 12mm => ~1.07 kg/m²/mm)
            val kgReq = netM2 * tMm * 1.07 * 1.05
            val bags25 = ceil(kgReq / 25.0).toInt()
            val waterL = bags25 * 16.0 // ~16L clean water per 25kg bag

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("25 kg Gypsum Plaster Bags", "$bags25", "bags (${UnitConverter.fmt(kgReq, 0)} kg)", isPrimary = true),
                        CalcResultItem("Net Plaster Area", UnitConverter.fmt(netSqFt, 0), "sq.ft (${UnitConverter.fmt(netM2, p)} m²)", isPrimary = true),
                        CalcResultItem("Clean Mixing Water (~16L/bag)", UnitConverter.fmt(waterL, 0), "Liters")
                    ),
                    formula = "Kg = NetArea_m² × Thickness_mm × 1.07 × 1.05; Bags = ceil(Kg / 25)",
                    steps = listOf("${UnitConverter.fmt(netM2, p)} m² × $tMm mm × 1.07 × 1.05 = ${UnitConverter.fmt(kgReq, 1)} kg → $bags25 bags"),
                    assumptions = "Standard stucco gypsum yield (~21 sq.ft per 25kg bag at 12mm) + 5% wastage."
                )
            )
        }
    )

    private fun drywallPartitionCalculator() = CalcToolSpec(
        id = "finish_drywall_partition",
        title = "Gypsum Drywall Partition & GI Framing",
        titleHi = "जिप्सम ड्राईवॉल पार्टीशन (बोर्ड व चैनल)",
        subtitle = "12.5mm Boards (6×4 ft), GI C-Studs, Floor/Ceiling Tracks & Screws",
        category = CalcCategory.FINISHING,
        keywords = listOf("drywall", "gypsum board", "partition", "stud", "channel", "framing"),
        fields = listOf(
            CalcFieldSpec("len", "Partition Wall Length", "8.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Partition Height", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("skins", "Board Skin Layers", "Double Side (1 Layer Each)", options = listOf("Double Side (1 Layer Each)", "Double Layer Both Sides (4 Skins)", "Single Side Wall Lining")),
            CalcFieldSpec("studSpaceMm", "GI Stud Spacing (mm c/c)", "600", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val stSp = ctx.doubleOrNull("studSpaceMm") ?: 600.0
            if (l <= 0 || h <= 0 || stSp <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))

            val layers = when {
                ctx.raw("skins").startsWith("Double Layer") -> 4
                ctx.raw("skins").startsWith("Single Side") -> 1
                else -> 2
            }
            val wallM2 = l * h
            val boardAreaM2 = 1.83 * 1.22 // 6x4 ft = 2.23 m²
            val boards = ceil((wallM2 * layers * 1.08) / boardAreaM2).toInt()
            val studCount = ceil((l * 1000.0) / stSp).toInt() + 1
            val studRmt = studCount * h
            val trackRmt = l * 2.0
            val screws = ceil(wallM2 * layers * 14.0).toInt()
            val jointCompoundKg = wallM2 * layers * 0.45

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("12.5mm Gypsum Boards (6×4 ft)", "$boards", "boards ($layers layers, +8%)", isPrimary = true),
                        CalcResultItem("GI Vertical Studs ($studCount Nos)", UnitConverter.fmt(studRmt, p), "Rmt (Tracks ${UnitConverter.fmt(trackRmt, p)} m)", isPrimary = true),
                        CalcResultItem("Drywall Screws (25/35mm)", "$screws", "nos"),
                        CalcResultItem("Jointing Compound & Tape", UnitConverter.fmt(jointCompoundKg, 1), "kg")
                    ),
                    formula = "Boards = ceil(Area×Skins×1.08 / 2.23m²); Studs = ceil(L/Spacing)+1",
                    steps = listOf("Wall=${UnitConverter.fmt(wallM2, p)} m² × $layers skins → $boards boards, $studCount studs"),
                    assumptions = "Uses standard 1220×1830mm (4×6 ft) gypsum board with 8% cut allowance."
                )
            )
        }
    )

    private fun plywoodLaminateCalculator() = CalcToolSpec(
        id = "finish_plywood_laminate",
        title = "Plywood, Blockboard & Laminate Sheets",
        titleHi = "प्लाईवुड, ब्लॉकबोर्ड और लैमिनेट शीट (8×4)",
        subtitle = "8×4 ft Plywood & Sunmica Laminate Sheets + Fevicol Adhesive",
        category = CalcCategory.FINISHING,
        keywords = listOf("plywood", "laminate", "sunmica", "blockboard", "carpentry", "8x4", "fevicol"),
        fields = listOf(
            CalcFieldSpec("areaSqFt", "Carpentry Surface Area (sq.ft)", "320", FieldUnitKind.NONE),
            CalcFieldSpec("lamFaces", "Laminate Coverage", "Both Faces (Inner + Outer)", options = listOf("Outer Face Only (1x)", "Both Faces (Inner + Outer)")),
            CalcFieldSpec("wastePct", "Cutting Wastage (%)", "10", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("areaSqFt") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter surface area."))
            val wPct = (ctx.doubleOrNull("wastePct") ?: 10.0).coerceAtLeast(0.0)
            if (area <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Area must be positive."))

            val grossArea = area * (1.0 + wPct / 100.0)
            val plySheets = ceil(grossArea / 32.0).toInt()
            val lamMult = if (ctx.raw("lamFaces").startsWith("Both")) 2 else 1
            val lamSheets = plySheets * lamMult
            val adhesiveKg = (lamSheets * 32.0) * 0.045 // ~1.4 kg per 8x4 laminate face

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Plywood / Blockboard (8×4 ft)", "$plySheets", "sheets", isPrimary = true),
                        CalcResultItem("1mm Laminate / Sunmica Sheets", "$lamSheets", "sheets", isPrimary = true),
                        CalcResultItem("Wood Adhesive (Fevicol)", UnitConverter.fmt(adhesiveKg, p), "kg"),
                        CalcResultItem("Gross Sheet Area (+${wPct.toInt()}%)", UnitConverter.fmt(grossArea, 0), "sq.ft")
                    ),
                    formula = "Ply Sheets = ceil(Area×(1+Waste%) / 32 sq.ft); Adhesive ≈ 1.44 kg per 8×4 lam face",
                    steps = listOf("${UnitConverter.fmt(grossArea, 0)} sq.ft / 32 = $plySheets ply sheets; ×$lamMult = $lamSheets laminates"),
                    assumptions = "Standard Indian commercial 8×4 ft (32 sq.ft) sheet dimension."
                )
            )
        }
    )

    private fun skirtingDadoTileCalculator() = CalcToolSpec(
        id = "finish_skirting_dado",
        title = "Room Skirting & Bathroom Dado Tiles",
        titleHi = "कमरे की स्कर्टिंग और बाथरूम डैडो टाइल्स",
        subtitle = "Perimeter Minus Doors → Skirting Running Feet & Dado Wall Tiles",
        category = CalcCategory.FINISHING,
        keywords = listOf("skirting", "dado", "bathroom", "wall tile", "rft", "perimeter"),
        fields = listOf(
            CalcFieldSpec("l", "Room Length", "4.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Room Width", "3.6", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("doorDed", "Total Door Widths Deduction", "1.0", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true),
            CalcFieldSpec("skirtingH", "Skirting / Dado Height (mm)", "100", FieldUnitKind.NONE),
            CalcFieldSpec("tileLmm", "Tile Length Used (mm)", "600", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val ded = (ctx.doubleOrNull("doorDed") ?: 1.0) * (ctx.lengthUnits["doorDed"] ?: LengthUnit.M).toMeters
            val skH = ctx.doubleOrNull("skirtingH") ?: 100.0
            val tileL = ctx.doubleOrNull("tileLmm") ?: 600.0
            if (l <= 0 || w <= 0 || skH <= 0 || tileL <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))

            val netRunM = (2.0 * (l + w) - ded).coerceAtLeast(0.0)
            val netRunFt = netRunM * 3.28084
            val areaM2 = netRunM * (skH / 1000.0)
            val areaSqFt = areaM2 * 10.7639
            val stripsPerTile = kotlin.math.floor(tileL / skH).toInt().coerceAtLeast(1)
            val fullTilesNeeded = ceil(((netRunM * 1000.0) / tileL) / stripsPerTile * 1.08).toInt()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Net Running Length", "${UnitConverter.fmt(netRunFt, 1)} RFT", "(${UnitConverter.fmt(netRunM, p)} m)", isPrimary = true),
                        CalcResultItem("Skirting / Dado Area", UnitConverter.fmt(areaSqFt, 1), "sq.ft (${UnitConverter.fmt(areaM2, p)} m²)", isPrimary = true),
                        CalcResultItem("Tiles Needed (+8% Wastage)", "$fullTilesNeeded", "tiles (@$stripsPerTile strips/tile)")
                    ),
                    formula = "Run = 2(L+W) − Doors; Area = Run × Height; Tiles = ceil(Run / (TileL × Strips))",
                    steps = listOf("Net run = ${UnitConverter.fmt(netRunM, p)} m (${UnitConverter.fmt(netRunFt, 1)} RFT); Strips/tile = $stripsPerTile"),
                    assumptions = "Assumes square/rectangular tiles of length $tileL mm sliced cleanly into $skH mm strips."
                )
            )
        }
    )

    private fun stoneCladdingAnchorCalculator() = CalcToolSpec(
        id = "finish_stone_cladding",
        title = "Facade Stone Cladding & SS Anchors",
        titleHi = "बाहरी पत्थर क्लैडिंग और एंकर क्लैंप",
        subtitle = "Sandstone/Granite Wall Panels, SS Fasteners & Epoxy Adhesive",
        category = CalcCategory.FINISHING,
        keywords = listOf("cladding", "facade", "stone", "elevation", "anchor", "granite", "dry cladding"),
        fields = listOf(
            CalcFieldSpec("area", "Elevation Cladding Area (sq.ft)", "450", FieldUnitKind.NONE),
            CalcFieldSpec("panelLft", "Stone Panel Length (ft)", "2.0", FieldUnitKind.NONE),
            CalcFieldSpec("panelHft", "Stone Panel Height (ft)", "1.0", FieldUnitKind.NONE),
            CalcFieldSpec("method", "Fixing Method", "Mechanical Dry Cladding (SS Clamps)", options = listOf("Mechanical Dry Cladding (SS Clamps)", "Wet Chemical Adhesive Fixing"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter cladding area."))
            val pl = ctx.doubleOrNull("panelLft") ?: 2.0
            val ph = ctx.doubleOrNull("panelHft") ?: 1.0
            if (area <= 0 || pl <= 0 || ph <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Area & panel dims must be positive."))

            val panels = ceil((area * 1.08) / (pl * ph)).toInt()
            val isDry = ctx.raw("method").startsWith("Mechanical")
            val ssClamps = if (isDry) panels * 4 else 0
            val fasteners = if (isDry) ssClamps * 2 else 0
            val adhBags = if (isDry) 0 else ceil((area * 0.0929 * 7.5) / 20.0).toInt()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Stone Panels (+8% Cut Waste)", "$panels", "panels (${UnitConverter.fmt(area * 1.08, 0)} sq.ft)", isPrimary = true),
                        if (isDry) CalcResultItem("SS 304 L/Z Clamps & Fasteners", "$ssClamps clamps", "($fasteners anchor bolts)", isPrimary = true)
                        else CalcResultItem("Polymer Stone Adhesive (20 kg)", "$adhBags", "bags", isPrimary = true),
                        CalcResultItem("Epoxy Stone Glue (Pin Grout)", UnitConverter.fmt(panels * 0.08, p), "kg")
                    ),
                    formula = "Panels = ceil(Area×1.08 / (L×H)); Dry Cladding ≈ 4 SS Clamps + 8 Anchors/panel",
                    steps = listOf("Gross stone = ${UnitConverter.fmt(area * 1.08, 0)} sq.ft → $panels panels"),
                    assumptions = "Dry cladding is mandatory above 3m elevation per safety practice (SS-304 grade brackets)."
                )
            )
        }
    )

    private fun kerbRoadsideDrainCalculator() = CalcToolSpec(
        id = "finish_road_kerb_drain",
        title = "Roadside Kerbstone & RCC Open Drain",
        titleHi = "रोड कर्ब स्टोन और RCC साइड ड्रेन",
        subtitle = "Precast Kerb Nos, Bedding Mortar & U-Shape Drain Concrete/Steel",
        category = CalcCategory.FINISHING,
        keywords = listOf("kerb", "kerbstone", "drain", "roadside", "u-drain", "highway"),
        fields = listOf(
            CalcFieldSpec("roadLen", "Road Stretch Length", "250.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("sides", "Road Sides", "Both Sides (×2)", options = listOf("Single Side (×1)", "Both Sides (×2)")),
            CalcFieldSpec("kerbLen", "Single Kerbstone Length (m)", "0.50", FieldUnitKind.NONE),
            CalcFieldSpec("drainW", "Drain Inner Width (m)", "0.45", FieldUnitKind.NONE),
            CalcFieldSpec("drainD", "Drain Inner Depth (m)", "0.60", FieldUnitKind.NONE),
            CalcFieldSpec("drainWallT", "Drain Wall/Base Thick (m)", "0.15", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val rl = ctx.lengthMeters("roadLen") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter road length."))
            val sides = if (ctx.raw("sides").startsWith("Both")) 2.0 else 1.0
            val kLen = ctx.doubleOrNull("kerbLen") ?: 0.50
            val dw = ctx.doubleOrNull("drainW") ?: 0.45
            val dd = ctx.doubleOrNull("drainD") ?: 0.60
            val wt = ctx.doubleOrNull("drainWallT") ?: 0.15
            if (rl <= 0 || kLen <= 0 || dw <= 0 || dd <= 0 || wt <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val totalRun = rl * sides
            val kerbs = ceil(totalRun / kLen).toInt()
            val kerbMortarM3 = totalRun * 0.30 * 0.04
            val drainCsArea = (dw + 2.0 * wt) * wt + 2.0 * dd * wt
            val drainConcM3 = drainCsArea * totalRun
            val drainSteelKg = drainConcM3 * 75.0

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Precast Kerbstones Needed", "$kerbs", "nos (${UnitConverter.fmt(totalRun, 0)} Rmt)", isPrimary = true),
                        CalcResultItem("RCC U-Drain Concrete", UnitConverter.fmt(drainConcM3, p), "m³", isPrimary = true),
                        CalcResultItem("Drain Rebar Steel (~75 kg/m³)", UnitConverter.fmt(drainSteelKg, 0), "kg"),
                        CalcResultItem("Kerb Bedding & Pointing Mortar", UnitConverter.fmt(kerbMortarM3, p), "m³")
                    ),
                    formula = "Kerbs = Run / KerbLen; U-Drain CS = (W+2t)×t + 2×D×t",
                    steps = listOf("Total run = ${UnitConverter.fmt(totalRun, 0)} m; Drain CS area = ${UnitConverter.fmt(drainCsArea, 3)} m²"),
                    assumptions = "Open U-shaped RCC drain without top cover slab; add PCC leveling bed separately."
                )
            )
        }
    )
}

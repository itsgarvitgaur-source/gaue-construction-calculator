package com.example.features.tools

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.domain.units.UnitConverter
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class DprRecord(
    val id: Long,
    val date: String,
    val activity: String,
    val location: String,
    val qty: String,
    val manpower: String,
    val notes: String
)

private data class MbEntry(
    val id: Long,
    val itemName: String,
    val nos: Double,
    val l: Double,
    val b: Double,
    val d: Double,
    val unit: String
) {
    val qty: Double get() = nos * l * b * d
}

private val defaultChecklists: Map<String, List<String>> = mapOf(
    "Slab Pour Checklist" to listOf(
        "Shuttering props verticality, bracing & base plate check",
        "Shuttering joints taped / sealed to avoid slurry leakage",
        "Clear cover blocks placed (20mm slab, 25mm beam)",
        "Bottom, top extra & crank bar spacing verified vs drawing",
        "Electrical conduits & plumbing sleeves fixed before pour",
        "Needle vibrator (2 units) + slump cone tested on site"
    ),
    "Column & Footing Check" to listOf(
        "Centerline grid & 3-4-5 diagonal alignment verified",
        "PCC bed level & anti-termite treatment completed",
        "Starter bar plumb & lateral tie hook angle 135° checked",
        "Lap length >= Ld (min 45d–50d) staggered at mid-height",
        "Formwork plumb & kickers anchored securely"
    ),
    "Excavation & Site Safety" to listOf(
        "Underground utility lines (water, power, cable) located",
        "Slope / shoring provided for trench depth > 1.5 m",
        "Safety helmets, reflective vests & boots worn by crew",
        "Barricading & warning tape around open foundation pits",
        "Dewatering pump ready if water table encountered"
    ),
    "Masonry & Plaster QA" to listOf(
        "Bricks / AAC blocks pre-wetted before laying",
        "Plumb bob & spirit level checked every 3 courses",
        "Mortar joints 10–12mm thick & raked for plaster key",
        "Chicken mesh / fiber mesh fixed at RCC–masonry junctions",
        "Minimum 7 days moist curing scheduled & tracked"
    )
)

@Composable
fun SiteEngineeringToolsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val prefs = remember { context.getSharedPreferences("gaur_site_tools", Context.MODE_PRIVATE) }

    var activeTab by remember { mutableIntStateOf(0) } // 0=DPR, 1=MB, 2=QA/QC Checklists

    val dprList = remember {
        mutableStateListOf<DprRecord>().apply {
            val raw = prefs.getString("dpr_json", null)
            if (raw != null) {
                runCatching {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(DprRecord(o.getLong("id"), o.getString("date"), o.getString("activity"), o.getString("location"), o.getString("qty"), o.getString("manpower"), o.getString("notes")))
                    }
                }
            }
            if (isEmpty()) {
                val today = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())
                add(DprRecord(1L, today, "1st Floor Roof Slab Concrete (M25)", "Grid A1-C4", "24.5 m³", "4 Masons, 14 Helpers", "Slump 100mm verified; needle vibrated"))
            }
        }
    }

    val mbList = remember {
        mutableStateListOf<MbEntry>().apply {
            val raw = prefs.getString("mb_json", null)
            if (raw != null) {
                runCatching {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(MbEntry(o.getLong("id"), o.getString("itemName"), o.getDouble("nos"), o.getDouble("l"), o.getDouble("b"), o.getDouble("d"), o.getString("unit")))
                    }
                }
            }
            if (isEmpty()) {
                add(MbEntry(1L, "Footing F1 Excavation", 4.0, 2.2, 1.8, 1.5, "m³"))
                add(MbEntry(2L, "Plinth Beam Concrete", 6.0, 4.5, 0.23, 0.35, "m³"))
            }
        }
    }

    var selectedChecklist by remember { mutableStateOf(defaultChecklists.keys.first()) }
    var checkedKeys by remember {
        mutableStateOf(
            prefs.getString("qc_checked", "").orEmpty().split("|").filter { it.isNotBlank() }.toSet()
        )
    }

    fun persistDpr() {
        val arr = JSONArray()
        dprList.forEach { d ->
            arr.put(JSONObject().apply {
                put("id", d.id); put("date", d.date); put("activity", d.activity)
                put("location", d.location); put("qty", d.qty); put("manpower", d.manpower); put("notes", d.notes)
            })
        }
        prefs.edit().putString("dpr_json", arr.toString()).apply()
    }

    fun persistMb() {
        val arr = JSONArray()
        mbList.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id); put("itemName", m.itemName); put("nos", m.nos)
                put("l", m.l); put("b", m.b); put("d", m.d); put("unit", m.unit)
            })
        }
        prefs.edit().putString("mb_json", arr.toString()).apply()
    }

    var showDprDialog by remember { mutableStateOf(false) }
    var showMbDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = "Site Engineering: DPR, MB & QA/QC",
            subtitle = "Daily Progress Report, Measurement Book & Checklists",
            onBack = onBack
        )

        TabRow(selectedTabIndex = activeTab, containerColor = palette.concreteCard) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("DPR (${dprList.size})") })
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("MB Book (${mbList.size})") })
            Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("QA/QC Safety") })
        }

        when (activeTab) {
            0 -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { showDprDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = palette.orange),
                                modifier = Modifier.weight(1f).testTag("add_dpr_btn")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Add DPR Entry")
                            }
                            OutlinedButton(
                                onClick = {
                                    val report = EngineeringReportData(
                                        title = "Daily Progress Report (DPR)",
                                        projectName = "Site Log",
                                        companyName = settings.companyName,
                                        engineerName = settings.engineerName,
                                        sections = listOf(
                                            ReportSection(
                                                heading = "Daily Site Work Entries",
                                                tableHeaders = listOf("Date", "Activity", "Location", "Qty", "Crew"),
                                                tableRows = dprList.map { listOf(it.date, it.activity, it.location, it.qty, it.manpower) }
                                            )
                                        )
                                    )
                                    val file = ReportExportEngine.generatePdfFile(context, report)
                                    ReportExportEngine.shareFile(context, file, "application/pdf", "Share DPR PDF")
                                },
                                modifier = Modifier.weight(0.9f)
                            ) {
                                Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.orangeDark)
                                Spacer(Modifier.width(4.dp))
                                Text("Export PDF")
                            }
                        }
                    }
                    items(dprList, key = { it.id }) { item ->
                        EngineeringCard(accentColor = palette.orange) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                GlassBluePill(text = item.date)
                                IconButton(onClick = { dprList.removeAll { it.id == item.id }; persistDpr() }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = palette.error, modifier = Modifier.size(18.dp))
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(item.activity, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                            Text("Location: ${item.location}  •  Executed: ${item.qty}", style = MaterialTheme.typography.bodySmall, color = palette.orangeDark)
                            Text("Manpower: ${item.manpower}", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                            if (item.notes.isNotBlank()) {
                                Text(item.notes, style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            }
                        }
                    }
                }
            }
            1 -> {
                val totalQty = mbList.sumOf { it.qty }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        EngineeringCard(accentColor = palette.skyBlue) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column {
                                    Text("Measurement Book Total", style = MaterialTheme.typography.labelMedium, color = palette.inkMuted)
                                    Text("${UnitConverter.fmt(totalQty, 3)} units", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = palette.skyBlue)
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = {
                                        val headers = listOf("Item", "Nos", "L", "B", "D", "Quantity", "Unit")
                                        val rows = mbList.map { listOf(it.itemName, "${it.nos}", "${it.l}", "${it.b}", "${it.d}", UnitConverter.fmt(it.qty, 3), it.unit) }
                                        val file = ReportExportEngine.generateCsvFile(context, "Measurement_Book", headers, rows)
                                        ReportExportEngine.shareFile(context, file, "text/csv", "Share MB CSV")
                                    }) {
                                        Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.success)
                                        Spacer(Modifier.width(4.dp))
                                        Text("Excel")
                                    }
                                    Button(onClick = { showMbDialog = true }, colors = ButtonDefaults.buttonColors(containerColor = palette.orange)) {
                                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Add")
                                    }
                                }
                            }
                        }
                    }
                    items(mbList, key = { it.id }) { m ->
                        EngineeringCard {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(m.itemName, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                    Text("${m.nos} × ${m.l} × ${m.b} × ${m.d}", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                                }
                                Text("${UnitConverter.fmt(m.qty, 3)} ${m.unit}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = palette.orangeDark)
                                IconButton(onClick = { mbList.removeAll { it.id == m.id }; persistMb() }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = palette.error, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
            else -> {
                val itemsForCat = defaultChecklists[selectedChecklist].orEmpty()
                val doneCount = itemsForCat.count { checkedKeys.contains("$selectedChecklist::$it") }
                val progress = if (itemsForCat.isEmpty()) 0f else doneCount.toFloat() / itemsForCat.size
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                defaultChecklists.keys.take(2).forEach { cat ->
                                    FilterChip(selected = selectedChecklist == cat, onClick = { selectedChecklist = cat }, label = { Text(cat, maxLines = 1) }, modifier = Modifier.weight(1f))
                                }
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                defaultChecklists.keys.drop(2).forEach { cat ->
                                    FilterChip(selected = selectedChecklist == cat, onClick = { selectedChecklist = cat }, label = { Text(cat, maxLines = 1) }, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                    item {
                        EngineeringCard(accentColor = palette.success) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(selectedChecklist, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = palette.success, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("$doneCount / ${itemsForCat.size}", style = MaterialTheme.typography.labelLarge, color = palette.success)
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(progress = { progress }, color = palette.success, trackColor = palette.concreteSurfaceAlt, modifier = Modifier.fillMaxWidth())
                        }
                    }
                    items(itemsForCat) { point ->
                        val key = "$selectedChecklist::$point"
                        val isChecked = checkedKeys.contains(key)
                        Surface(
                            color = palette.concreteCard,
                            border = BorderStroke(1.dp, if (isChecked) palette.success else palette.metallicBorder),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        checkedKeys = if (checked) checkedKeys + key else checkedKeys - key
                                        prefs.edit().putString("qc_checked", checkedKeys.joinToString("|")).apply()
                                    }
                                )
                                Text(point, style = MaterialTheme.typography.bodyMedium, color = palette.inkPrimary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDprDialog) {
        var act by remember { mutableStateOf("") }
        var loc by remember { mutableStateOf("") }
        var qty by remember { mutableStateOf("") }
        var crew by remember { mutableStateOf("") }
        var notes by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showDprDialog = false },
            title = { Text("Add Daily Progress Report") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = act, onValueChange = { act = it }, label = { Text("Work Activity") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = loc, onValueChange = { loc = it }, label = { Text("Grid / Floor / Location") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Quantity Executed") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = crew, onValueChange = { crew = it }, label = { Text("Manpower / Gang") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("QA / Site Remarks") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (act.isBlank()) {
                        Toast.makeText(context, "Enter work activity", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val today = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())
                    dprList.add(0, DprRecord(System.currentTimeMillis(), today, act, loc.ifBlank { "Site" }, qty.ifBlank { "-" }, crew.ifBlank { "-" }, notes))
                    persistDpr()
                    showDprDialog = false
                }, colors = ButtonDefaults.buttonColors(containerColor = palette.orange)) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showDprDialog = false }) { Text("Cancel") } }
        )
    }

    if (showMbDialog) {
        var item by remember { mutableStateOf("") }
        var nos by remember { mutableStateOf("1") }
        var l by remember { mutableStateOf("1.0") }
        var b by remember { mutableStateOf("1.0") }
        var d by remember { mutableStateOf("1.0") }
        var unit by remember { mutableStateOf("m³") }
        AlertDialog(
            onDismissRequest = { showMbDialog = false },
            title = { Text("Add MB Entry (N × L × B × D)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = item, onValueChange = { item = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = nos, onValueChange = { nos = it }, label = { Text("Nos") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = l, onValueChange = { l = it }, label = { Text("L") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(value = b, onValueChange = { b = it }, label = { Text("B") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = d, onValueChange = { d = it }, label = { Text("D") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f))
                        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit") }, modifier = Modifier.weight(0.8f))
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val nv = nos.toDoubleOrNull() ?: 1.0
                    val lv = l.toDoubleOrNull() ?: 1.0
                    val bv = b.toDoubleOrNull() ?: 1.0
                    val dv = d.toDoubleOrNull() ?: 1.0
                    mbList.add(0, MbEntry(System.currentTimeMillis(), item.ifBlank { "Work Item" }, nv, lv, bv, dv, unit.ifBlank { "m³" }))
                    persistMb()
                    showMbDialog = false
                }, colors = ButtonDefaults.buttonColors(containerColor = palette.orange)) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showMbDialog = false }) { Text("Cancel") } }
        )
    }
}

package com.example.features.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.core.preferences.ThemeModePref
import com.example.core.preferences.UnitSystemPref
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GaurBrandLogoBadge
import com.example.ui.theme.LocalEngineeringPalette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onOpenRateMaster: () -> Unit,
    onOpenSecurity: (() -> Unit)? = null,
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var company by remember(settings.companyName) { mutableStateOf(settings.companyName) }
    var engineer by remember(settings.engineerName) { mutableStateOf(settings.engineerName) }
    var currency by remember(settings.currencySymbol) { mutableStateOf(settings.currencySymbol) }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val json = viewModel.repository.exportFullBackupJson()
                context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                viewModel.logSecurityEvent("BACKUP_EXPORT", "INFO", "Local Backup Exported", "Saved full JSON workspace backup")
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Backup exported successfully", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                val json = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText().orEmpty()
                val res = viewModel.repository.importBackupJson(json)
                withContext(Dispatchers.Main) {
                    res.onSuccess { count ->
                        Toast.makeText(context, "Restored $count records", Toast.LENGTH_SHORT).show()
                    }.onFailure {
                        Toast.makeText(context, "Invalid backup file: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    val bighaRegions = listOf(
        "Standard Pucca Bigha (27,225 sq.ft)" to 27225.0,
        "UP / Bihar Pucca (27,000 sq.ft)" to 27000.0,
        "Rajasthan Bigha (17,424 sq.ft)" to 17424.0,
        "Assam / West Bengal (14,400 sq.ft)" to 14400.0,
        "Himachal / Uttarakhand (8,712 sq.ft)" to 8712.0
    )

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = strings.settingsTitle,
            subtitle = "Units, Language, Precision, Rates & Backup",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Branding & About
            item {
                EngineeringCard(accentColor = palette.orange) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GaurBrandLogoBadge(sizeDp = 58)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Gaur Construction Calculator", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                            Text("Version ${BuildConfig.VERSION_NAME} • Bright Engineering Edition", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            Text("100% Offline Engineering & Site Estimation Suite", style = MaterialTheme.typography.bodySmall, color = palette.skyBlue)
                        }
                    }
                }
            }

            // Language, Theme & Unit Preferences
            item {
                EngineeringCard {
                    Text("App Theme (Light / Dark)", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeModePref.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { viewModel.setThemeMode(mode) },
                                label = { Text(mode.label) },
                                modifier = Modifier.testTag("theme_${mode.name.lowercase()}")
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(strings.languageLabel, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = settings.language == lang,
                                onClick = { viewModel.setLanguage(lang) },
                                label = { Text(lang.displayName) },
                                modifier = Modifier.testTag("lang_${lang.code}")
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(strings.unitSystemLabel, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        UnitSystemPref.entries.forEach { sys ->
                            FilterChip(
                                selected = settings.unitSystem == sys,
                                onClick = { viewModel.setUnitSystem(sys) },
                                label = { Text(if (sys == UnitSystemPref.METRIC) "Metric (m/mm)" else "Imperial (ft/in)") }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(strings.precisionLabel, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1, 2, 3, 4).forEach { p ->
                            FilterChip(
                                selected = settings.decimalPrecision == p,
                                onClick = { viewModel.setPrecision(p) },
                                label = { Text("$p dec") }
                            )
                        }
                    }
                }
            }

            // Defaults: Concrete Mix, Wastage, Regional Bigha
            item {
                EngineeringCard {
                    Text(strings.defaultMixLabel, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("M15", "M20", "M25", "M30").forEach { m ->
                            FilterChip(selected = settings.defaultConcreteMix == m, onClick = { viewModel.setDefaultMix(m) }, label = { Text(m) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(strings.defaultWastageLabel, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(2.0, 5.0, 7.0, 10.0).forEach { w ->
                            FilterChip(selected = settings.defaultWastagePercent == w, onClick = { viewModel.setDefaultWastage(w) }, label = { Text("${w.toInt()}%") })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    var bighaOpen by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded = bighaOpen, onExpandedChange = { bighaOpen = !bighaOpen }) {
                        OutlinedTextField(
                            value = settings.bighaRegionName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text(strings.bighaConfigLabel) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = bighaOpen) },
                            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = bighaOpen, onDismissRequest = { bighaOpen = false }) {
                            bighaRegions.forEach { (label, sqft) ->
                                DropdownMenuItem(text = { Text(label) }, onClick = {
                                    viewModel.setBighaRegion(label, sqft)
                                    bighaOpen = false
                                })
                            }
                        }
                    }
                }
            }

            // Report Branding & Rates
            item {
                EngineeringCard {
                    Text("Report Header & Currency", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(value = company, onValueChange = { company = it }, label = { Text("Company / Firm Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = engineer, onValueChange = { engineer = it }, label = { Text("Engineer Name") }, singleLine = true, modifier = Modifier.weight(1.4f))
                        OutlinedTextField(value = currency, onValueChange = { currency = it }, label = { Text("Currency") }, singleLine = true, modifier = Modifier.weight(0.6f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.setBranding(company, engineer, currency)
                                Toast.makeText(context, "Branding updated", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.orange),
                            modifier = Modifier.weight(1f)
                        ) { Text("Save Branding") }
                        OutlinedButton(onClick = onOpenRateMaster, modifier = Modifier.weight(1f)) { Text("Material Rates") }
                    }
                }
            }

            // Backup, Restore, Clear & Security
            item {
                EngineeringCard(accentColor = palette.skyBlue) {
                    Text(strings.backupRestore, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { exportBackupLauncher.launch("gaur_construction_backup.json") },
                            modifier = Modifier.weight(1f)
                        ) { Text(strings.exportBackup) }
                        OutlinedButton(
                            onClick = { importBackupLauncher.launch(arrayOf("application/json", "*/*")) },
                            modifier = Modifier.weight(1f)
                        ) { Text(strings.importBackup) }
                    }
                    if (onOpenSecurity != null) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = onOpenSecurity, modifier = Modifier.fillMaxWidth()) {
                            Text(strings.securityShield)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            viewModel.clearHistory()
                            Toast.makeText(context, "Calculation history cleared", Toast.LENGTH_SHORT).show()
                        },
                        border = BorderStroke(1.dp, palette.error.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(strings.clearHistory, color = palette.error) }
                }
            }
        }
    }
}

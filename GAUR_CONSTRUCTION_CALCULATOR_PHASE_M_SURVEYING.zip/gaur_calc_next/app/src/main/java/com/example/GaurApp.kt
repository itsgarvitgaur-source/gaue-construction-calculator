package com.example

import android.app.Application
import com.example.core.preferences.AppSettingsStore
import com.example.data.local.AppDatabase
import com.example.data.local.EngineeringRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class GaurApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
    val repository: EngineeringRepository by lazy { EngineeringRepository(database) }
    val settingsStore: AppSettingsStore by lazy { AppSettingsStore(this) }

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        appScope.launch {
            repository.ensureDefaultRatesSeeded()
        }
    }
}

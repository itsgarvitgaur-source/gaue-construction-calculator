package com.example.features.history

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.LocalAppStrings
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    viewModel: MainViewModel,
    onOpenCalculator: (String) -> Unit,
    onBack: (() -> Unit)? = null
) {
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val history by viewModel.history.collectAsStateWithLifecycle()

    var query by remember { mutableStateOf("") }
    var templatesOnly by remember { mutableStateOf(false) }

    val filtered = remember(history, query, templatesOnly) {
        history.filter { item ->
            val matchTemplate = !templatesOnly || item.isTemplate
            val q = query.trim().lowercase()
            val matchQ = q.isEmpty() ||
                item.customName.lowercase().contains(q) ||
                item.toolName.lowercase().contains(q) ||
                item.category.lowercase().contains(q)
            matchTemplate && matchQ
        }
    }

    val fmt = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.US) }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = strings.historyTitle,
            subtitle = "${filtered.size} Saved Records",
            onBack = onBack,
            actions = {
                if (history.isNotEmpty()) {
                    IconButton(onClick = { viewModel.clearHistory() }, modifier = Modifier.testTag("clear_history_btn")) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = "Clear History", tint = palette.error)
                    }
                }
            }
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search saved calculations or templates...") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.orange) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(selected = !templatesOnly, onClick = { templatesOnly = false }, label = { Text("All (${history.size})") })
                }
                item {
                    FilterChip(selected = templatesOnly, onClick = { templatesOnly = true }, label = { Text("Saved Templates") })
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (filtered.isEmpty()) {
                item {
                    EngineeringCard {
                        Text(strings.noResults, color = palette.inkMuted)
                    }
                }
            }
            items(filtered, key = { it.id }) { h ->
                EngineeringCard(accentColor = palette.skyBlue, onClick = { onOpenCalculator(h.toolId) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(h.customName.ifBlank { h.toolName }, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                            Text("${h.category} • ${fmt.format(Date(h.timestamp))}", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            if (h.isTemplate) {
                                Spacer(Modifier.width(4.dp))
                                GlassBluePill(text = "Template", modifier = Modifier.padding(top = 4.dp))
                            }
                        }
                        IconButton(onClick = { viewModel.deleteHistory(h.id) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = palette.error)
                        }
                    }
                }
            }
        }
    }
}

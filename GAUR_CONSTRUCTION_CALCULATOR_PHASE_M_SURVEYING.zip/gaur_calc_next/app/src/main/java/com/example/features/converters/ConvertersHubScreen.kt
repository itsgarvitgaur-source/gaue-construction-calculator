package com.example.features.converters

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.domain.calculators.CalcCategory
import com.example.domain.calculators.CalculatorRegistry
import com.example.domain.units.EngineeringUnitConverter
import com.example.domain.units.ExtendedAreaUnit
import com.example.domain.units.LengthUnit
import com.example.domain.units.PressureUnit
import com.example.domain.units.TempUnit
import com.example.domain.units.UnitConverter
import com.example.domain.units.VolumeUnit
import com.example.domain.units.WeightUnit
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalEngineeringPalette

private enum class QuickConvKind(val label: String) {
    LENGTH("Length"),
    AREA("Area / Land"),
    VOLUME("Volume"),
    WEIGHT("Weight"),
    PRESSURE("Stress / MPa"),
    TEMP("Temperature")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConvertersHubScreen(
    viewModel: MainViewModel,
    onOpenCalculator: (String) -> Unit
) {
    val palette = LocalEngineeringPalette.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var kind by remember { mutableStateOf(QuickConvKind.LENGTH) }
    var inputStr by remember { mutableStateOf("10") }

    val unitLabels = remember(kind) {
        when (kind) {
            QuickConvKind.LENGTH -> LengthUnit.entries.map { it.symbol }
            QuickConvKind.AREA -> ExtendedAreaUnit.entries.map { it.symbol }
            QuickConvKind.VOLUME -> VolumeUnit.entries.map { it.symbol }
            QuickConvKind.WEIGHT -> WeightUnit.entries.map { it.symbol }
            QuickConvKind.PRESSURE -> PressureUnit.entries.map { it.symbol }
            QuickConvKind.TEMP -> TempUnit.entries.map { it.symbol }
        }
    }
    var fromUnit by remember(kind) {
        mutableStateOf(
            when (kind) {
                QuickConvKind.LENGTH -> LengthUnit.FT.symbol
                QuickConvKind.AREA -> ExtendedAreaUnit.SQ_FT.symbol
                QuickConvKind.VOLUME -> VolumeUnit.CU_M.symbol
                QuickConvKind.WEIGHT -> WeightUnit.KG.symbol
                QuickConvKind.PRESSURE -> PressureUnit.MPA.symbol
                QuickConvKind.TEMP -> TempUnit.CELSIUS.symbol
            }
        )
    }
    var toUnit by remember(kind) {
        mutableStateOf(
            when (kind) {
                QuickConvKind.LENGTH -> LengthUnit.M.symbol
                QuickConvKind.AREA -> ExtendedAreaUnit.SQ_M.symbol
                QuickConvKind.VOLUME -> VolumeUnit.CU_FT.symbol
                QuickConvKind.WEIGHT -> WeightUnit.MT.symbol
                QuickConvKind.PRESSURE -> PressureUnit.PSI.symbol
                QuickConvKind.TEMP -> TempUnit.FAHRENHEIT.symbol
            }
        )
    }

    val convertedValue = remember(kind, inputStr, fromUnit, toUnit, settings.decimalPrecision) {
        val v = inputStr.toDoubleOrNull() ?: return@remember "—"
        val out = when (kind) {
            QuickConvKind.LENGTH -> {
                val f = LengthUnit.entries.firstOrNull { it.symbol == fromUnit } ?: LengthUnit.M
                val t = LengthUnit.entries.firstOrNull { it.symbol == toUnit } ?: LengthUnit.FT
                UnitConverter.convertLength(v, f, t)
            }
            QuickConvKind.AREA -> {
                val f = ExtendedAreaUnit.entries.firstOrNull { it.symbol == fromUnit } ?: ExtendedAreaUnit.SQ_M
                val t = ExtendedAreaUnit.entries.firstOrNull { it.symbol == toUnit } ?: ExtendedAreaUnit.SQ_FT
                EngineeringUnitConverter.convertExtendedArea(v, f, t)
            }
            QuickConvKind.VOLUME -> {
                val f = VolumeUnit.entries.firstOrNull { it.symbol == fromUnit } ?: VolumeUnit.CU_M
                val t = VolumeUnit.entries.firstOrNull { it.symbol == toUnit } ?: VolumeUnit.CU_FT
                UnitConverter.convertVolume(v, f, t)
            }
            QuickConvKind.WEIGHT -> {
                val f = WeightUnit.entries.firstOrNull { it.symbol == fromUnit } ?: WeightUnit.KG
                val t = WeightUnit.entries.firstOrNull { it.symbol == toUnit } ?: WeightUnit.MT
                EngineeringUnitConverter.convertWeight(v, f, t)
            }
            QuickConvKind.PRESSURE -> {
                val f = PressureUnit.entries.firstOrNull { it.symbol == fromUnit } ?: PressureUnit.MPA
                val t = PressureUnit.entries.firstOrNull { it.symbol == toUnit } ?: PressureUnit.PSI
                EngineeringUnitConverter.convertPressure(v, f, t)
            }
            QuickConvKind.TEMP -> {
                val f = TempUnit.entries.firstOrNull { it.symbol == fromUnit } ?: TempUnit.CELSIUS
                val t = TempUnit.entries.firstOrNull { it.symbol == toUnit } ?: TempUnit.FAHRENHEIT
                EngineeringUnitConverter.convertTemperature(v, f, t)
            }
        }
        UnitConverter.fmt(out, settings.decimalPrecision + 1)
    }

    val converterTools = remember {
        CalculatorRegistry.byCategory(CalcCategory.CONVERTERS) +
            listOfNotNull(
                CalculatorRegistry.byId("basic_fraction_calc"),
                CalculatorRegistry.byId("site_drawing_scale")
            )
    }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = if (settings.language == AppLanguage.HINDI) "यूनिट कनवर्टर" else "Unit Converters",
            subtitle = "Instant Construction & Engineering Conversions"
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                EngineeringCard(accentColor = palette.orange, modifier = Modifier.testTag("quick_converter_card")) {
                    Text("Quick Instant Converter", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(QuickConvKind.entries) { k ->
                            FilterChip(
                                selected = kind == k,
                                onClick = { kind = k },
                                label = { Text(k.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = palette.orangeSoft,
                                    selectedLabelColor = palette.orangeDark
                                ),
                                border = BorderStroke(1.dp, if (kind == k) palette.orange else palette.metallicBorder)
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = inputStr,
                        onValueChange = { inputStr = it },
                        label = { Text("Enter Value") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("quick_conv_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        var openFrom by remember { mutableStateOf(false) }
                        var openTo by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(
                            expanded = openFrom,
                            onExpandedChange = { openFrom = !openFrom },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = fromUnit,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("From") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = openFrom) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(expanded = openFrom, onDismissRequest = { openFrom = false }) {
                                unitLabels.forEach { u ->
                                    DropdownMenuItem(text = { Text(u) }, onClick = { fromUnit = u; openFrom = false })
                                }
                            }
                        }
                        ExposedDropdownMenuBox(
                            expanded = openTo,
                            onExpandedChange = { openTo = !openTo },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = toUnit,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("To") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = openTo) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )
                            ExposedDropdownMenu(expanded = openTo, onDismissRequest = { openTo = false }) {
                                unitLabels.forEach { u ->
                                    DropdownMenuItem(text = { Text(u) }, onClick = { toUnit = u; openTo = false })
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Surface(
                        color = palette.skyGlassTint,
                        border = BorderStroke(1.dp, palette.skyGlassBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Result", style = MaterialTheme.typography.bodyMedium, color = palette.inkSecondary)
                            Text(
                                text = "$convertedValue $toUnit",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = palette.skyBlue,
                                modifier = Modifier.testTag("quick_conv_result")
                            )
                        }
                    }
                }
            }

            item {
                SectionHeader(title = "All Full-Table Unit Converters", icon = Icons.Rounded.SwapHoriz)
            }

            items(converterTools, key = { it.id }) { tool ->
                EngineeringCard(
                    accentColor = palette.skyBlue,
                    onClick = {
                        viewModel.onToolOpened(tool.id)
                        onOpenCalculator(tool.id)
                    },
                    modifier = Modifier.testTag("conv_tool_${tool.id}")
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(palette.skyGlassTint),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = palette.skyBlue, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (settings.language == AppLanguage.HINDI) tool.titleHi else tool.title,
                                style = MaterialTheme.typography.titleSmall,
                                color = palette.inkPrimary
                            )
                            Text(tool.subtitle, style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                        }
                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "Open", tint = palette.orangeDark, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

package com.example.features.diagrams

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

fun DrawScope.drawExpandedGeometryOrUtilityDiagram(
    s: DiagramInputSnapshot,
    mode: DiagramViewMode,
    yaw: Float,
    pitch: Float
): Boolean {
    when (s.toolId) {
        "basic_area" -> drawAll2DAreaShapes(s)
        "basic_volume_surface" -> drawAll3DVolumeShapes(s, yaw, pitch)
        "conc_cement_mortar", "conc_water_cement", "conc_tube_curb" -> drawExtraConcreteDiagram(s, mode, yaw, pitch)
        "struct_arch_dome" -> drawArchDomeDiagram(s)
        "util_water_tank", "util_septic_tank", "util_rainwater_harvest", "util_plumbing_pipe", "util_electrical_ac_solar" ->
            drawUtilityDiagram(s, mode, yaw, pitch)
        "masonry_stone", "masonry_interlocking_paver", "masonry_boundary_fence" -> drawExtraMasonryDiagram(s)
        "finish_marble_granite", "finish_false_ceiling", "finish_wood_timber",
        "finish_door_window_glass", "finish_asphalt_road", "finish_anti_termite" -> drawExtraFinishingDiagram(s)
        "steel_structural_sections", "steel_bbs_beam_column", "steel_footing_stair_rebar", "steel_helical_spiral" ->
            drawExtraSteelDiagram(s)
        "earth_embankment_road", "earth_soil_bulking", "site_stair_pitch_check", "site_cost_estimator" ->
            drawExtraEarthAndSiteDiagram(s)
        "infra_road_layers", "infra_culvert_pier" -> drawInfraRoadOrBridgeDiagram(s)
        "conv_weight_mass", "conv_pressure_stress", "conv_force_load",
        "conv_temperature", "conv_density_speed", "conv_angle_slope" -> drawConverterDiagram(s)
        else -> return false
    }
    return true
}

private fun DrawScope.drawAll2DAreaShapes(s: DiagramInputSnapshot) {
    val shape = s.raw("shape", "Rectangle")
    val a = s.lenMeters("a", 10.0).toFloat().coerceAtLeast(0.2f)
    val b = s.lenMeters("b", 8.0).toFloat().coerceAtLeast(0.2f)
    val cx = size.width / 2f
    val cy = size.height / 2f
    val pad = 76f
    val aLbl = s.lenLabel("a", 10.0)
    val bLbl = s.lenLabel("b", 8.0)

    when (shape) {
        "Square" -> {
            val side = min(size.width, size.height) * 0.52f
            val left = cx - side / 2f; val top = cy - side / 2f
            drawRect(CadColors.GlassFill, Offset(left, top), Size(side, side))
            drawRect(CadColors.DimBlue, Offset(left, top), Size(side, side), style = Stroke(3f))
            drawDimensionLine(Offset(left, top + side), Offset(left + side, top + side), 32f, "a=$aLbl")
            drawDimensionLine(Offset(left, top), Offset(left, top + side), -44f, "a=$aLbl", CadColors.DimOrange)
        }
        "Circle" -> {
            val r = min(size.width, size.height) * 0.30f
            drawCircle(CadColors.GlassFill, r, Offset(cx, cy))
            drawCircle(CadColors.DimBlue, r, Offset(cx, cy), style = Stroke(3f))
            drawLine(CadColors.DimOrange, Offset(cx, cy), Offset(cx + r, cy), 3f)
            drawCadTextPill("r = $aLbl", Offset(cx + r * 0.5f, cy - 22f), CadColors.DimOrange)
        }
        "Semicircle" -> {
            val r = min(size.width * 0.34f, size.height * 0.42f)
            val baseY = cy + r * 0.45f
            val p = Path().apply {
                moveTo(cx - r, baseY)
                arcTo(androidx.compose.ui.geometry.Rect(cx - r, baseY - r, cx + r, baseY + r), 180f, 180f, false)
                close()
            }
            drawPath(p, CadColors.GlassFill)
            drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            drawDimensionLine(Offset(cx - r, baseY), Offset(cx + r, baseY), 32f, "r=$aLbl (D=2r)")
        }
        "Circular Sector" -> {
            val ang = s.dbl("angle", 90.0).toFloat().coerceIn(15f, 345f)
            val r = min(size.width, size.height) * 0.32f
            val p = Path().apply {
                moveTo(cx, cy)
                arcTo(androidx.compose.ui.geometry.Rect(cx - r, cy - r, cx + r, cy + r), -ang / 2f, ang, false)
                close()
            }
            drawPath(p, CadColors.GlassFill)
            drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            drawCadTextPill("r=$aLbl • θ=${ang.toInt()}°", Offset(cx, size.height - 26f), CadColors.DimOrange)
        }
        "Ring / Annulus" -> {
            val rOut = min(size.width, size.height) * 0.32f
            val rIn = (rOut * (b / a).coerceIn(0.25f, 0.85f))
            drawCircle(CadColors.GlassFill, rOut, Offset(cx, cy))
            drawCircle(Color.White, rIn, Offset(cx, cy))
            drawCircle(CadColors.DimBlue, rOut, Offset(cx, cy), style = Stroke(3f))
            drawCircle(CadColors.DimOrange, rIn, Offset(cx, cy), style = Stroke(2.5f))
            drawCadTextPill("R=$aLbl | r=$bLbl", Offset(cx, size.height - 24f), CadColors.DimBlue)
        }
        "Ellipse / Oval" -> {
            val rx = size.width * 0.34f
            val ry = (rx * (b / a).coerceIn(0.35f, 0.9f)).coerceAtMost(size.height * 0.34f)
            drawOval(CadColors.GlassFill, Offset(cx - rx, cy - ry), Size(rx * 2f, ry * 2f))
            drawOval(CadColors.DimBlue, Offset(cx - rx, cy - ry), Size(rx * 2f, ry * 2f), style = Stroke(3f))
            drawDashedLine(Offset(cx - rx, cy), Offset(cx + rx, cy), CadColors.DimOrange, 2f)
            drawDashedLine(Offset(cx, cy - ry), Offset(cx, cy + ry), CadColors.DimBlue, 2f)
            drawCadTextPill("a=$aLbl | b=$bLbl", Offset(cx, size.height - 24f), CadColors.DimOrange)
        }
        "Triangle (Base & Height)", "Triangle (3 Sides Heron)", "Right Triangle" -> {
            val bw = size.width - pad * 2f
            val th = size.height * 0.54f
            val topX = if (shape == "Right Triangle") pad else cx
            val p = Path().apply {
                moveTo(pad, cy + th / 2f)
                lineTo(pad + bw, cy + th / 2f)
                lineTo(topX, cy - th / 2f)
                close()
            }
            drawPath(p, CadColors.GlassFill)
            drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            if (shape == "Right Triangle") {
                drawRect(CadColors.DimOrange, Offset(pad, cy + th / 2f - 20f), Size(20f, 20f), style = Stroke(2.2f))
            } else {
                drawDashedLine(Offset(cx, cy - th / 2f), Offset(cx, cy + th / 2f), CadColors.DimOrange, 2f)
            }
            drawDimensionLine(Offset(pad, cy + th / 2f), Offset(pad + bw, cy + th / 2f), 32f, "A=$aLbl")
            val sideLbl = if (shape == "Triangle (3 Sides Heron)") "B=$bLbl, C=${s.lenLabel("c", 7.0)}" else "H=$bLbl"
            drawCadTextPill(sideLbl, Offset(cx, 26f), CadColors.DimOrange)
        }
        "Trapezoid" -> {
            val b1 = size.width - pad * 2f
            val b2 = (b1 * (b / a).coerceIn(0.35f, 0.92f))
            val th = size.height * 0.50f
            val p = Path().apply {
                moveTo(cx - b1 / 2f, cy + th / 2f); lineTo(cx + b1 / 2f, cy + th / 2f)
                lineTo(cx + b2 / 2f, cy - th / 2f); lineTo(cx - b2 / 2f, cy - th / 2f); close()
            }
            drawPath(p, CadColors.GlassFill); drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            drawDimensionLine(Offset(cx - b1 / 2f, cy + th / 2f), Offset(cx + b1 / 2f, cy + th / 2f), 32f, "a=$aLbl")
            drawDimensionLine(Offset(cx - b2 / 2f, cy - th / 2f), Offset(cx + b2 / 2f, cy - th / 2f), -26f, "b=$bLbl")
            drawDimensionLine(Offset(cx + b1 / 2f, cy - th / 2f), Offset(cx + b1 / 2f, cy + th / 2f), -44f, "h=${s.lenLabel("h", 6.0)}", CadColors.DimOrange)
        }
        "Parallelogram" -> {
            val bw = size.width - pad * 2.3f
            val th = size.height * 0.48f
            val skew = 48f
            val p = Path().apply {
                moveTo(cx - bw / 2f - skew / 2f, cy + th / 2f)
                lineTo(cx + bw / 2f - skew / 2f, cy + th / 2f)
                lineTo(cx + bw / 2f + skew / 2f, cy - th / 2f)
                lineTo(cx - bw / 2f + skew / 2f, cy - th / 2f)
                close()
            }
            drawPath(p, CadColors.GlassFill); drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            drawDimensionLine(Offset(cx - bw / 2f - skew / 2f, cy + th / 2f), Offset(cx + bw / 2f - skew / 2f, cy + th / 2f), 32f, "Base=$aLbl")
            drawDimensionLine(Offset(cx + bw / 2f + skew / 2f, cy - th / 2f), Offset(cx + bw / 2f + skew / 2f, cy + th / 2f), -42f, "H=$bLbl", CadColors.DimOrange)
        }
        "Rhombus" -> {
            val rx = size.width * 0.30f; val ry = size.height * 0.30f
            val p = Path().apply {
                moveTo(cx, cy - ry); lineTo(cx + rx, cy); lineTo(cx, cy + ry); lineTo(cx - rx, cy); close()
            }
            drawPath(p, CadColors.GlassFill); drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            drawDashedLine(Offset(cx - rx, cy), Offset(cx + rx, cy), CadColors.DimOrange, 2f)
            drawDashedLine(Offset(cx, cy - ry), Offset(cx, cy + ry), CadColors.DimBlue, 2f)
            drawCadTextPill("d₁=$aLbl | d₂=$bLbl", Offset(cx, size.height - 24f), CadColors.DimOrange)
        }
        "Regular Polygon (N-Sides)" -> {
            val n = s.dbl("nSides", 6.0).toInt().coerceIn(3, 12)
            val r = min(size.width, size.height) * 0.30f
            val p = Path()
            for (i in 0 until n) {
                val ang = -PI / 2.0 + 2.0 * PI * i / n
                val pt = Offset(cx + (r * cos(ang)).toFloat(), cy + (r * sin(ang)).toFloat())
                if (i == 0) p.moveTo(pt.x, pt.y) else p.lineTo(pt.x, pt.y)
            }
            p.close()
            drawPath(p, CadColors.GlassFill); drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            drawCadTextPill("$n-Sided Polygon • Side s = $aLbl", Offset(cx, size.height - 24f), CadColors.DimOrange)
        }
        "Irregular 4-Side Plot" -> {
            val p1 = Offset(cx - 120f, cy + 54f)
            val p2 = Offset(cx + 125f, cy + 44f)
            val p3 = Offset(cx + 92f, cy - 58f)
            val p4 = Offset(cx - 95f, cy - 38f)
            val p = Path().apply { moveTo(p1.x, p1.y); lineTo(p2.x, p2.y); lineTo(p3.x, p3.y); lineTo(p4.x, p4.y); close() }
            drawPath(p, CadColors.GlassFill); drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            drawDashedLine(p1, p3, CadColors.DimOrange, 2.5f)
            drawCadTextPill("A=$aLbl | B=$bLbl | C=${s.lenLabel("c", 7.0)} | D=${s.lenLabel("d", 9.0)}", Offset(cx, 24f), CadColors.DimBlue, textSizePx = 20f)
            drawCadTextPill("Diagonal=${s.lenLabel("h", 6.0)}", Offset(cx, size.height - 24f), CadColors.DimOrange)
        }
        else -> {
            val rw = size.width - pad * 2f
            val rh = (rw * (b / a).coerceIn(0.35f, 0.8f)).coerceAtMost(size.height * 0.54f)
            val top = cy - rh / 2f
            drawRect(CadColors.GlassFill, Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, "L=$aLbl")
            drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -48f, "W=$bLbl", CadColors.DimOrange)
        }
    }
}

private fun DrawScope.drawAll3DVolumeShapes(s: DiagramInputSnapshot, yaw: Float, pitch: Float) {
    val shape = s.raw("shape", "Cuboid / Box")
    val l = s.lenMeters("l", 5.0).toFloat().coerceAtLeast(0.4f)
    val w = s.lenMeters("w", 4.0).toFloat().coerceAtLeast(0.4f)
    val h = s.lenMeters("h", 3.0).toFloat().coerceAtLeast(0.4f)
    val scale = (min(size.width, size.height) * 0.44f) / max(max(l, w), h)
    val center = Offset(size.width / 2f, size.height * 0.55f)
    when (shape) {
        "Sphere", "Hemisphere" -> {
            val cx = size.width / 2f; val cy = size.height * 0.54f
            val r = min(size.width, size.height) * 0.28f
            if (shape == "Hemisphere") {
                val p = Path().apply {
                    moveTo(cx - r, cy + r * 0.35f)
                    arcTo(androidx.compose.ui.geometry.Rect(cx - r, cy - r * 0.65f, cx + r, cy + r * 1.35f), 180f, 180f, false)
                    close()
                }
                drawPath(p, CadColors.GlassFill); drawPath(p, CadColors.DimBlue, style = Stroke(3f))
                drawDimensionLine(Offset(cx - r, cy + r * 0.35f), Offset(cx + r, cy + r * 0.35f), 28f, "Ø=${s.lenLabel("l", 5.0)}")
            } else {
                drawCircle(CadColors.GlassFill, r, Offset(cx, cy))
                drawCircle(CadColors.DimBlue, r, Offset(cx, cy), style = Stroke(3f))
                drawOval(CadColors.DimBlue.copy(alpha = 0.5f), Offset(cx - r, cy - r * 0.3f), Size(r * 2f, r * 0.6f), style = Stroke(2f))
                drawDimensionLine(Offset(cx - r, cy + r), Offset(cx + r, cy + r), 28f, "Ø=${s.lenLabel("l", 5.0)}")
            }
        }
        "Cylinder", "Hollow Cylinder / Pipe", "Cone", "Frustum of Cone" -> {
            draw3DCylinder(Offset(0f, 0f), 0f, h, l / 2f, Vec3D(0f, 0f, h / 2f), center, scale, yaw, pitch, CadColors.GlassFill, CadColors.DimBlue)
            drawCadTextPill("$shape • Ø=${s.lenLabel("l", 5.0)} • H=${s.lenLabel("h", 3.0)}", Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
        else -> {
            val useW = if (shape == "Cube" || shape == "Square Pyramid") l else w
            val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l, useW, h), Vec3D(l / 2f, useW / 2f, h / 2f), center, scale, yaw, pitch, CadColors.GlassFill, CadColors.DimBlue)
            drawDimensionLine(pts[0], pts[1], 28f, "L=${s.lenLabel("l", 5.0)}")
            if (shape != "Cube") drawDimensionLine(pts[2], pts[6], -38f, "H=${s.lenLabel("h", 3.0)}", CadColors.DimOrange)
            drawCadTextPill(shape, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
    }
}

private fun DrawScope.drawExtraConcreteDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val cx = size.width / 2f; val cy = size.height / 2f
    when (s.toolId) {
        "conc_tube_curb" -> {
            if (s.raw("elemType") == "Road Kerbstone / Curb") {
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(2.5f, 0.35f, 0.6f), Vec3D(1.25f, 0.175f, 0.3f), Offset(cx, cy + 12f), 55f, yaw, pitch, CadColors.ConcreteFill, CadColors.ConcreteStroke)
                drawDimensionLine(pts[0], pts[1], 28f, "L=${s.lenLabel("l", 2.5)}")
                drawCadTextPill("Curb ${s.lenLabel("curbW", 0.15)}×${s.lenLabel("curbH", 0.30)}", Offset(cx, 26f), CadColors.DimOrange)
            } else {
                val rOut = min(size.width, size.height) * 0.28f; val rIn = rOut * 0.72f
                drawCircle(CadColors.ConcreteFill, rOut, Offset(cx, cy))
                drawCircle(Color.White, rIn, Offset(cx, cy))
                drawCircle(CadColors.ConcreteStroke, rOut, Offset(cx, cy), style = Stroke(3f))
                drawCircle(CadColors.DimOrange, rIn, Offset(cx, cy), style = Stroke(2.5f))
                drawCadTextPill("OD=${s.lenLabel("od", 1.2)} | ID=${s.lenLabel("id", 1.0)} | L=${s.lenLabel("l", 2.5)}", Offset(cx, size.height - 24f), CadColors.DimBlue)
            }
        }
        else -> {
            val pad = 74f; val rw = size.width - pad * 2f; val rh = size.height * 0.44f; val top = cy - rh / 2f
            drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            val lbl = if (s.toolId == "conc_water_cement") "${s.raw("bags", "10")} Bags • W/C=${s.raw("wc", "0.45")}" else "Mortar ${s.raw("ratio", "1:5")} • Vol=${s.raw("vol", "2.5")}m³"
            drawCadTextPill(lbl, Offset(cx, cy), CadColors.DimOrange)
        }
    }
}

private fun DrawScope.drawArchDomeDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f; val baseY = size.height * 0.78f
    val rOut = min(size.width * 0.36f, size.height * 0.56f)
    val rIn = rOut * 0.74f
    drawArc(CadColors.ConcreteFill, 180f, 180f, true, Offset(cx - rOut, baseY - rOut), Size(rOut * 2f, rOut * 2f))
    drawArc(Color.White, 180f, 180f, true, Offset(cx - rIn, baseY - rIn), Size(rIn * 2f, rIn * 2f))
    drawArc(CadColors.ConcreteStroke, 180f, 180f, false, Offset(cx - rOut, baseY - rOut), Size(rOut * 2f, rOut * 2f), style = Stroke(3f))
    drawArc(CadColors.ConcreteStroke, 180f, 180f, false, Offset(cx - rIn, baseY - rIn), Size(rIn * 2f, rIn * 2f), style = Stroke(2.5f))
    drawDimensionLine(Offset(cx - rIn, baseY), Offset(cx + rIn, baseY), 28f, "Span=${s.lenLabel("span", 4.0)}")
    drawCadTextPill("${s.raw("archType", "Semicircular Arch")} • t=${s.lenLabel("thick", 0.25)}", Offset(cx, 26f), CadColors.DimOrange)
}

private fun DrawScope.drawUtilityDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val cx = size.width / 2f; val cy = size.height / 2f
    when (s.toolId) {
        "util_water_tank" -> {
            val h = s.lenMeters("h", 2.5).toFloat().coerceAtLeast(0.5f)
            if (s.raw("tankShape") == "Cylindrical / Circular Tank") {
                val d = s.lenMeters("dia", 3.0).toFloat().coerceAtLeast(0.5f)
                val sc = (min(size.width, size.height) * 0.42f) / max(d, h)
                draw3DCylinder(Offset(0f, 0f), 0f, h, d / 2f, Vec3D(0f, 0f, h / 2f), Offset(cx, cy + 12f), sc, yaw, pitch, CadColors.GlassFill, CadColors.DimBlue)
                drawCadTextPill("Ø=${s.lenLabel("dia", 3.0)} • H=${s.lenLabel("h", 2.5)}", Offset(cx, 26f), CadColors.DimOrange)
            } else {
                val l = s.lenMeters("l", 4.0).toFloat().coerceAtLeast(0.5f)
                val w = s.lenMeters("w", 3.0).toFloat().coerceAtLeast(0.5f)
                val sc = (min(size.width, size.height) * 0.42f) / max(max(l, w), h)
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l, w, h), Vec3D(l / 2f, w / 2f, h / 2f), Offset(cx, cy + 14f), sc, yaw, pitch, CadColors.GlassFill, CadColors.DimBlue)
                drawDimensionLine(pts[0], pts[1], 26f, "L=${s.lenLabel("l", 4.0)}")
                drawDimensionLine(pts[2], pts[6], -38f, "H=${s.lenLabel("h", 2.5)}", CadColors.DimOrange)
            }
        }
        "util_plumbing_pipe" -> {
            val rOut = min(size.width, size.height) * 0.26f; val rIn = rOut * 0.80f
            drawCircle(CadColors.ConcreteFill, rOut, Offset(cx, cy))
            drawCircle(CadColors.GlassFill, rIn, Offset(cx, cy))
            drawCircle(CadColors.DimBlue, rOut, Offset(cx, cy), style = Stroke(3f))
            drawCadTextPill("Pipe Ø${s.raw("diaMm", "110")}mm • Slope ${s.raw("slopePct", "1.5")}%", Offset(cx, 26f), CadColors.DimOrange)
        }
        else -> {
            val pad = 74f; val rw = size.width - pad * 2f; val rh = size.height * 0.48f; val top = cy - rh / 2f
            drawRect(CadColors.GlassFill.copy(alpha = 0.6f), Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            drawCadTextPill(diagramCaptionForTool(s), Offset(cx, 26f), CadColors.DimOrange)
        }
    }
}

private fun DrawScope.drawExtraMasonryDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f; val cy = size.height / 2f; val pad = 74f
    val rw = size.width - pad * 2f; val rh = size.height * 0.48f; val top = cy - rh / 2f
    when (s.toolId) {
        "masonry_boundary_fence" -> {
            val yLine = cy + 28f
            drawLine(CadColors.SoilStroke, Offset(pad, yLine), Offset(pad + rw, yLine), 3f)
            for (i in 0..4) {
                val x = pad + rw * i / 4f
                drawRect(CadColors.ConcreteDarkFill, Offset(x - 6f, yLine - 90f), Size(12f, 90f))
            }
            for (j in 1..4) {
                val wy = yLine - 18f * j
                drawLine(CadColors.SteelBar, Offset(pad, wy), Offset(pad + rw, wy), 2f)
            }
            drawDimensionLine(Offset(pad, yLine), Offset(pad + rw, yLine), 30f, "Perimeter=${s.lenLabel("perim", 120.0)}")
            drawCadTextPill("Post c/c ${s.lenLabel("spacing", 3.0)} • ${s.raw("strands", "6")} Strands", Offset(cx, 26f), CadColors.DimOrange)
        }
        else -> {
            drawRect(CadColors.MasonryFill, Offset(pad, top), Size(rw, rh))
            for (i in 1..4) drawLine(CadColors.MasonryStroke.copy(alpha = 0.45f), Offset(pad + rw * i / 5f, top), Offset(pad + rw * i / 5f, top + rh), 1.5f)
            for (j in 1..3) drawLine(CadColors.MasonryStroke.copy(alpha = 0.45f), Offset(pad, top + rh * j / 4f), Offset(pad + rw, top + rh * j / 4f), 1.5f)
            drawRect(CadColors.MasonryStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, "L=${s.lenLabel("l", 10.0)}")
            drawCadTextPill(diagramCaptionForTool(s), Offset(cx, 26f), CadColors.DimOrange)
        }
    }
}

private fun DrawScope.drawExtraFinishingDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f; val cy = size.height / 2f; val pad = 74f
    val rw = size.width - pad * 2f; val rh = size.height * 0.48f; val top = cy - rh / 2f
    drawRect(CadColors.GlassFill.copy(alpha = 0.4f), Offset(pad, top), Size(rw, rh))
    drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
    if (s.toolId == "finish_door_window_glass") {
        drawRect(CadColors.MasonryFill, Offset(pad, top), Size(rw, rh), style = Stroke(10f))
        drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, "W=${s.lenLabel("w", 1.2)}")
        drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -44f, "H=${s.lenLabel("h", 2.1)}", CadColors.DimOrange)
    } else {
        drawCadTextPill(diagramCaptionForTool(s), Offset(cx, cy), CadColors.DimOrange)
    }
}

private fun DrawScope.drawExtraSteelDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f; val cy = size.height / 2f
    if (s.toolId == "steel_structural_sections") {
        val sec = s.raw("secType", "I-Beam / H-Beam")
        val sH = min(size.width, size.height) * 0.54f
        val sW = sH * 0.65f
        val t = 18f
        when (sec) {
            "I-Beam / H-Beam" -> {
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy - sH / 2f), Size(sW, t))
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy + sH / 2f - t), Size(sW, t))
                drawRect(CadColors.SteelBar, Offset(cx - t / 2f, cy - sH / 2f + t), Size(t, sH - 2 * t))
            }
            "C-Channel (ISMC)" -> {
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy - sH / 2f), Size(sW, t))
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy + sH / 2f - t), Size(sW, t))
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy - sH / 2f), Size(t, sH))
            }
            "L-Angle (Equal / Unequal)" -> {
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy - sH / 2f), Size(t, sH))
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy + sH / 2f - t), Size(sW, t))
            }
            "Circular Hollow Pipe (CHS)", "Round Solid Bar" -> {
                val r = sH * 0.45f
                drawCircle(CadColors.SteelBar, r, Offset(cx, cy))
                if (sec.startsWith("Circular Hollow")) drawCircle(Color.White, r * 0.72f, Offset(cx, cy))
            }
            else -> {
                drawRect(CadColors.SteelBar, Offset(cx - sW / 2f, cy - sH / 2f), Size(sW, sH))
                if (sec.contains("Hollow")) drawRect(Color.White, Offset(cx - sW / 2f + t, cy - sH / 2f + t), Size(sW - 2 * t, sH - 2 * t))
            }
        }
        drawCadTextPill("$sec • H=${s.raw("h", "200")}mm • L=${s.lenLabel("len", 6.0)}", Offset(cx, 24f), CadColors.DimBlue)
    } else {
        val pad = 74f; val y = cy + 10f; val w = size.width - pad * 2f
        drawLine(CadColors.SteelBar, Offset(pad, y), Offset(pad + w, y), 9f)
        drawLine(CadColors.SteelBar, Offset(pad, y), Offset(pad, y - 42f), 8f)
        drawLine(CadColors.SteelBar, Offset(pad + w, y), Offset(pad + w, y - 42f), 8f)
        drawDimensionLine(Offset(pad, y), Offset(pad + w, y), 32f, diagramCaptionForTool(s))
    }
}

private fun DrawScope.drawExtraEarthAndSiteDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f; val cy = size.height / 2f; val pad = 74f
    if (s.toolId == "earth_embankment_road") {
        val botW = size.width - pad * 2f; val topW = botW * 0.56f; val h = size.height * 0.48f
        val yBot = cy + h / 2f; val yTop = cy - h / 2f
        val p = Path().apply {
            moveTo(cx - botW / 2f, yBot); lineTo(cx + botW / 2f, yBot)
            lineTo(cx + topW / 2f, yTop); lineTo(cx - topW / 2f, yTop); close()
        }
        drawPath(p, CadColors.SoilFill); drawPath(p, CadColors.SoilStroke, style = Stroke(3f))
        drawDimensionLine(Offset(cx - topW / 2f, yTop), Offset(cx + topW / 2f, yTop), -26f, "B=${s.lenLabel("topW", 8.0)}")
        drawDimensionLine(Offset(cx + topW / 2f, yTop), Offset(cx + topW / 2f, yBot), -48f, "H=${s.lenLabel("h", 2.0)}", CadColors.DimOrange)
    } else {
        val rw = size.width - pad * 2f; val rh = size.height * 0.44f; val top = cy - rh / 2f
        drawRect(CadColors.GlassFill.copy(alpha = 0.45f), Offset(pad, top), Size(rw, rh))
        drawRect(CadColors.DimOrange, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
        drawCadTextPill(diagramCaptionForTool(s), Offset(cx, cy), CadColors.DimBlue)
    }
}

private fun DrawScope.drawConverterDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f; val cy = size.height / 2f; val pad = 68f
    val rw = size.width - pad * 2f; val rh = size.height * 0.42f; val top = cy - rh / 2f
    drawRect(CadColors.GlassFill.copy(alpha = 0.4f), Offset(pad, top), Size(rw, rh))
    drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(2.5f))
    drawCadTextPill("${s.raw("val", "100")} ${s.raw("unit", s.raw("densityUnit", ""))}  ⇄  SI / Imperial", Offset(cx, cy), CadColors.DimOrange)
}

private fun DrawScope.drawInfraRoadOrBridgeDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f; val cy = size.height / 2f; val pad = 74f
    val rw = size.width - pad * 2f
    if (s.toolId == "infra_road_layers") {
        val topY = cy - 64f
        val layers = listOf(
            "BC + DBM" to CadColors.SteelBar,
            "WMM (${s.raw("wmmMm", "250")}mm)" to CadColors.ConcreteDarkFill,
            "GSB (${s.raw("gsbMm", "200")}mm)" to CadColors.MasonryFill,
            "Subgrade (${s.raw("subgradeMm", "300")}mm)" to CadColors.SoilFill
        )
        var curY = topY
        layers.forEachIndexed { idx, (lbl, col) ->
            val lh = if (idx == 0) 24f else 34f
            drawRect(col, Offset(pad, curY), Size(rw, lh))
            drawRect(CadColors.ConcreteStroke, Offset(pad, curY), Size(rw, lh), style = Stroke(2f))
            drawCadTextPill(lbl, Offset(cx, curY + lh / 2f), CadColors.DimBlue, textSizePx = 19f)
            curY += lh
        }
        drawDimensionLine(Offset(pad, curY), Offset(pad + rw, curY), 28f, "W=${s.lenLabel("width", 7.0)} • L=${s.lenLabel("len", 500.0)}")
    } else if (s.raw("infraType").startsWith("Bridge")) {
        val deckTop = cy - 64f
        drawRect(CadColors.ConcreteFill, Offset(pad, deckTop), Size(rw, 24f))
        drawRect(CadColors.ConcreteStroke, Offset(pad, deckTop), Size(rw, 24f), style = Stroke(3f))
        drawRect(CadColors.ConcreteDarkFill, Offset(cx - 50f, deckTop + 24f), Size(100f, 22f))
        drawRect(CadColors.ConcreteStroke, Offset(cx - 50f, deckTop + 24f), Size(100f, 22f), style = Stroke(2.5f))
        drawRect(CadColors.ConcreteFill, Offset(cx - 24f, deckTop + 46f), Size(48f, 84f))
        drawRect(CadColors.ConcreteStroke, Offset(cx - 24f, deckTop + 46f), Size(48f, 84f), style = Stroke(3f))
        drawDimensionLine(Offset(pad, deckTop), Offset(pad + rw, deckTop), -24f, "Span=${s.lenLabel("span", 4.0)}")
        drawDimensionLine(Offset(cx + 24f, deckTop + 46f), Offset(cx + 24f, deckTop + 130f), -44f, "H=${s.lenLabel("height", 3.0)}", CadColors.DimOrange)
    } else {
        val boxW = rw * 0.78f; val boxH = size.height * 0.50f
        val left = cx - boxW / 2f; val top = cy - boxH / 2f
        val t = 22f
        drawRect(CadColors.ConcreteFill, Offset(left, top), Size(boxW, boxH))
        drawRect(Color.White, Offset(left + t, top + t), Size(boxW - 2 * t, boxH - 2 * t))
        drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(boxW, boxH), style = Stroke(3f))
        drawRect(CadColors.ConcreteStroke, Offset(left + t, top + t), Size(boxW - 2 * t, boxH - 2 * t), style = Stroke(2.5f))
        drawDimensionLine(Offset(left + t, top + boxH - t), Offset(left + boxW - t, top + boxH - t), 42f, "Span=${s.lenLabel("span", 4.0)}")
        drawDimensionLine(Offset(left, top), Offset(left, top + boxH), -44f, "H=${s.lenLabel("height", 3.0)}", CadColors.DimOrange)
    }
}

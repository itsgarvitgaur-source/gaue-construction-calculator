package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.sqrt

object SteelEarthSiteExtraCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        structuralSteelSectionWeightCalculator(),
        beamColumnBbsCalculator(),
        footingStairRebarCalculator(),
        helicalSpiralStirrupCalculator(),
        roadEmbankmentEarthworkCalculator(),
        sandBulkingMoistureCalculator(),
        stairErgonomicsCheckCalculator(),
        buildingCostBreakdownEstimator()
    )

    private fun structuralSteelSectionWeightCalculator() = CalcToolSpec(
        id = "steel_structural_sections",
        title = "Structural Steel Section Weight (All Shapes)",
        titleHi = "स्ट्रक्चरल स्टील सेक्शन वजन (I-बीम/चैनल/पाइप)",
        subtitle = "I-Beam, C-Channel, L-Angle, Square/Rect Tube, Round Pipe, Plate, Round & Hex Bar",
        category = CalcCategory.STEEL,
        typeFieldKey = "secType",
        keywords = listOf("i-beam", "channel", "angle", "pipe", "tube", "rhs", "shs", "chs", "plate", "flat", "hex", "steel section"),
        fields = listOf(
            CalcFieldSpec(
                "secType", "Steel Section Shape", "I-Beam / H-Beam",
                options = listOf(
                    "I-Beam / H-Beam",
                    "C-Channel (ISMC)",
                    "L-Angle (Equal / Unequal)",
                    "Square / Rect Hollow Tube (SHS/RHS)",
                    "Circular Hollow Pipe (CHS)",
                    "Flat Bar / MS Plate",
                    "Round Solid Bar",
                    "Hexagonal Bar"
                )
            ),
            CalcFieldSpec("h", "Depth H / Outer Dia / Side A (mm)", "200", FieldUnitKind.NONE, dynamicLabel = { m ->
                when (m["secType"]) {
                    "Circular Hollow Pipe (CHS)" -> "Outer Diameter OD (mm)"
                    "Round Solid Bar" -> "Bar Diameter Ø (mm)"
                    "Hexagonal Bar" -> "Across-Flats Width S (mm)"
                    "L-Angle (Equal / Unequal)" -> "Leg 1 Width A (mm)"
                    "Flat Bar / MS Plate" -> "Plate / Flat Width (mm)"
                    else -> "Section Height / Depth H (mm)"
                }
            }),
            CalcFieldSpec("b", "Flange Width B / Leg 2 (mm)", "100", FieldUnitKind.NONE, visibleWhen = {
                it["secType"] !in setOf("Circular Hollow Pipe (CHS)", "Round Solid Bar", "Hexagonal Bar", "Flat Bar / MS Plate")
            }, dynamicLabel = { m ->
                when (m["secType"]) {
                    "L-Angle (Equal / Unequal)" -> "Leg 2 Width B (mm)"
                    "Square / Rect Hollow Tube (SHS/RHS)" -> "Tube Width B (mm)"
                    else -> "Flange Width B (mm)"
                }
            }),
            CalcFieldSpec("tw", "Web / Wall Thickness t (mm)", "6.0", FieldUnitKind.NONE, visibleWhen = {
                it["secType"] !in setOf("Round Solid Bar", "Hexagonal Bar")
            }, dynamicLabel = { m ->
                when (m["secType"]) {
                    "Flat Bar / MS Plate" -> "Plate Thickness t (mm)"
                    "Circular Hollow Pipe (CHS)", "Square / Rect Hollow Tube (SHS/RHS)", "L-Angle (Equal / Unequal)" -> "Wall / Leg Thickness t (mm)"
                    else -> "Web Thickness tw (mm)"
                }
            }),
            CalcFieldSpec("tf", "Flange Thickness tf (mm)", "10.0", FieldUnitKind.NONE, visibleWhen = {
                it["secType"] in setOf("I-Beam / H-Beam", "C-Channel (ISMC)")
            }),
            CalcFieldSpec("len", "Member Length", "6.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("count", "Number of Pieces", "4", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("secType").ifBlank { "I-Beam / H-Beam" }
            val h = ctx.doubleOrNull("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter primary section size."))
            val b = ctx.doubleOrNull("b") ?: 100.0
            val tw = ctx.doubleOrNull("tw") ?: 6.0
            val tf = ctx.doubleOrNull("tf") ?: 10.0
            val lenM = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (h <= 0 || lenM <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be positive."))

            val areaMm2: Double = when (type) {
                "I-Beam / H-Beam" -> {
                    if (b <= 0 || tw <= 0 || tf <= 0 || h <= 2 * tf) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid I-Beam dimensions."))
                    2.0 * b * tf + (h - 2.0 * tf) * tw
                }
                "C-Channel (ISMC)" -> {
                    if (b <= 0 || tw <= 0 || tf <= 0 || h <= 2 * tf) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid Channel dimensions."))
                    2.0 * b * tf + (h - 2.0 * tf) * tw
                }
                "L-Angle (Equal / Unequal)" -> {
                    if (b <= 0 || tw <= 0 || tw >= h || tw >= b) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid Angle dimensions."))
                    (h + b - tw) * tw
                }
                "Square / Rect Hollow Tube (SHS/RHS)" -> {
                    if (b <= 0 || tw <= 0 || 2 * tw >= h || 2 * tw >= b) return@CalcToolSpec Result.failure(IllegalArgumentException("Wall thickness too large for tube."))
                    h * b - (h - 2.0 * tw) * (b - 2.0 * tw)
                }
                "Circular Hollow Pipe (CHS)" -> {
                    if (tw <= 0 || 2 * tw >= h) return@CalcToolSpec Result.failure(IllegalArgumentException("Wall thickness must be < OD/2."))
                    val rOut = h / 2.0
                    val rIn = rOut - tw
                    PI * (rOut * rOut - rIn * rIn)
                }
                "Flat Bar / MS Plate" -> {
                    if (tw <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive thickness."))
                    h * tw
                }
                "Hexagonal Bar" -> (sqrt(3.0) / 2.0) * h * h
                else -> PI * (h / 2.0) * (h / 2.0) // Round Solid Bar
            }
            val kgPerM = (areaMm2 / 1_000_000.0) * 7850.0
            val singleKg = kgPerM * lenM
            val totalKg = singleKg * n
            val cost = totalKg * (ctx.ratesByKeyword["steel"] ?: 68.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Section Weight", UnitConverter.fmt(totalKg, p), "kg", isPrimary = true),
                        CalcResultItem("Unit Weight", UnitConverter.fmt(kgPerM, 3), "kg/m", isPrimary = true),
                        CalcResultItem("Cross-Section Area", UnitConverter.fmt(areaMm2 / 100.0, p), "cm²"),
                        CalcResultItem("Single Piece Weight", UnitConverter.fmt(singleKg, p), "kg"),
                        CalcResultItem("Est. Steel Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "Wt/m = Area(m²) × 7850 kg/m³; Total = Wt/m × Length × Count",
                    steps = listOf("Area = ${UnitConverter.fmt(areaMm2, 1)} mm² → ${UnitConverter.fmt(kgPerM, 3)} kg/m"),
                    assumptions = "Steel density = 7850 kg/m³; excludes root fillet radii (nominal ±2%).",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun beamColumnBbsCalculator() = CalcToolSpec(
        id = "steel_bbs_beam_column",
        title = "Beam & Column BBS Cutting & Weight",
        titleHi = "बीम और कॉलम BBS कटिंग लंबाई",
        subtitle = "Main Longitudinal Bars + L-Anchorage + Stirrups/Ties Weight Summary",
        category = CalcCategory.STEEL,
        typeFieldKey = "memberType",
        isPreliminaryStructural = true,
        keywords = listOf("bbs", "bar bending", "beam", "column", "cutting length", "stirrup", "tie", "main bar"),
        fields = listOf(
            CalcFieldSpec("memberType", "Member Type", "RCC Beam BBS", options = listOf("RCC Beam BBS", "RCC Column BBS")),
            CalcFieldSpec("span", "Clear Span / Height", "4.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("b", "Width B (mm)", "250", FieldUnitKind.NONE),
            CalcFieldSpec("d", "Depth D (mm)", "450", FieldUnitKind.NONE),
            CalcFieldSpec("cover", "Clear Cover (mm)", "25", FieldUnitKind.NONE),
            CalcFieldSpec("mainDia", "Main Bar Dia (mm)", "16", options = listOf("10", "12", "16", "20", "25", "32")),
            CalcFieldSpec("mainCount", "Total Main Bars (Nos)", "6", FieldUnitKind.COUNT),
            CalcFieldSpec("tieDia", "Stirrup / Tie Dia (mm)", "8", options = listOf("6", "8", "10", "12")),
            CalcFieldSpec("tieSpace", "Stirrup Spacing (mm c/c)", "150", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val span = ctx.lengthMeters("span") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter span/height."))
            val b = ctx.doubleOrNull("b") ?: 250.0
            val d = ctx.doubleOrNull("d") ?: 450.0
            val cov = ctx.doubleOrNull("cover") ?: 25.0
            val mDia = ctx.doubleOrNull("mainDia") ?: 16.0
            val mNos = ctx.doubleOrNull("mainCount") ?: 6.0
            val tDia = ctx.doubleOrNull("tieDia") ?: 8.0
            val tSp = ctx.doubleOrNull("tieSpace") ?: 150.0
            if (span <= 0 || b <= 2 * cov || d <= 2 * cov || mNos <= 0 || tSp <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            }
            val ldM = (45.0 * mDia) / 1000.0 // ~45d anchorage/lap allowance
            val mainCutLen = span + ldM
            val mainWt = mainCutLen * mNos * (mDia * mDia / 162.2)

            val a = b - 2 * cov - tDia
            val h = d - 2 * cov - tDia
            val stirrupCutMm = 2.0 * (a + h) + 20.0 * tDia - 12.0 * tDia
            val stirrupNos = ceil((span * 1000.0) / tSp).toInt() + 1
            val stirrupWt = (stirrupCutMm / 1000.0) * stirrupNos * (tDia * tDia / 162.2)
            val totalWt = mainWt + stirrupWt
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Member Steel", UnitConverter.fmt(totalWt, p), "kg", isPrimary = true),
                        CalcResultItem("Main Bars (${mNos.toInt()}×Ø${mDia.toInt()}mm)", "${UnitConverter.fmt(mainWt, p)} kg (${UnitConverter.fmt(mainCutLen, 2)} m each)", "", isPrimary = true),
                        CalcResultItem("Stirrups ($stirrupNos×Ø${tDia.toInt()}mm)", "${UnitConverter.fmt(stirrupWt, p)} kg (${UnitConverter.fmt(stirrupCutMm, 0)} mm cut)", "")
                    ),
                    formula = "Main Cut = Span + 45d; Stirrup Cut = 2(a+h) + 8d; Wt = L×D²/162.2",
                    steps = listOf("Main = $mNos bars × ${UnitConverter.fmt(mainCutLen, 2)} m", "Stirrups = $stirrupNos nos × ${UnitConverter.fmt(stirrupCutMm / 1000.0, 3)} m"),
                    assumptions = "Includes 45d anchorage/lap allowance on main bars and 135° seismic hooks on stirrups."
                )
            )
        }
    )

    private fun footingStairRebarCalculator() = CalcToolSpec(
        id = "steel_footing_stair_rebar",
        title = "Footing Mesh w/ Hooks & Stair Rebar",
        titleHi = "फुटिंग जाली (हुक सहित) और सीढ़ी सरिया",
        subtitle = "Footing Bottom Mat w/ 90° Up-Turn L-Hooks & Stair Waist-Slab Steel",
        category = CalcCategory.STEEL,
        typeFieldKey = "mode",
        isPreliminaryStructural = true,
        keywords = listOf("footing rebar", "mesh", "hook", "staircase steel", "waist slab", "bbs"),
        fields = listOf(
            CalcFieldSpec("mode", "Element", "Isolated Footing Mat", options = listOf("Isolated Footing Mat", "Staircase Flight Rebar")),
            CalcFieldSpec("lx", "Length L / Inclined Flight L", "2.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("ly", "Width B / Stair Width W", "2.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("hookH", "Up-Turn L-Hook / Waist Thick (mm)", "250", FieldUnitKind.NONE),
            CalcFieldSpec("dia", "Bar Diameter (mm)", "12", options = listOf("8", "10", "12", "16", "20")),
            CalcFieldSpec("spacing", "Bar Spacing (mm c/c)", "150", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val lx = ctx.lengthMeters("lx") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val ly = ctx.lengthMeters("ly") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val hookMm = ctx.doubleOrNull("hookH") ?: 250.0
            val dia = ctx.doubleOrNull("dia") ?: 12.0
            val spMm = ctx.doubleOrNull("spacing") ?: 150.0
            if (lx <= 0 || ly <= 0 || spMm <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val spM = spMm / 1000.0
            val nX = ceil((ly - 0.1) / spM).toInt() + 1
            val nY = ceil((lx - 0.1) / spM).toInt() + 1
            val hookM = (hookMm / 1000.0).coerceAtLeast(0.0)
            val cutX = (lx - 0.1) + 2.0 * hookM
            val cutY = (ly - 0.1) + 2.0 * hookM
            val totalLen = nX * cutX + nY * cutY
            val totalWt = totalLen * (dia * dia / 162.2)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Steel Weight", UnitConverter.fmt(totalWt, p), "kg", isPrimary = true),
                        CalcResultItem("Bars along L ($nX Nos)", "${UnitConverter.fmt(cutX, 2)} m each", "", isPrimary = true),
                        CalcResultItem("Bars along B ($nY Nos)", "${UnitConverter.fmt(cutY, 2)} m each", ""),
                        CalcResultItem("Total Bar Running Length", UnitConverter.fmt(totalLen, p), "m")
                    ),
                    formula = "Cut Length = (Span - 2×50mm Cover) + 2×Hook; Wt = ΣL × D²/162.2",
                    steps = listOf("Along L: $nX × ${UnitConverter.fmt(cutX, 2)} m; Along B: $nY × ${UnitConverter.fmt(cutY, 2)} m"),
                    assumptions = "Uses 50 mm clear side cover for footings/earth-contact elements."
                )
            )
        }
    )

    private fun helicalSpiralStirrupCalculator() = CalcToolSpec(
        id = "steel_helical_spiral",
        title = "Helical / Spiral Stirrup & Pile Cage",
        titleHi = "हेलिकल (स्पाइरल) रिंग और पाइल केज",
        subtitle = "Circular Column / Pile Spiral Cutting Length & Total Steel Weight",
        category = CalcCategory.STEEL,
        keywords = listOf("helical", "spiral", "stirrup", "pile", "circular column", "cage"),
        fields = listOf(
            CalcFieldSpec("dia", "Pile / Column Diameter (mm)", "500", FieldUnitKind.NONE),
            CalcFieldSpec("cover", "Clear Cover (mm)", "50", FieldUnitKind.NONE),
            CalcFieldSpec("h", "Cage Height / Pile Depth", "10.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("pitch", "Spiral Pitch / Spacing (mm)", "150", FieldUnitKind.NONE),
            CalcFieldSpec("barDia", "Spiral Bar Dia (mm)", "8", options = listOf("6", "8", "10", "12"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val d = ctx.doubleOrNull("dia") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter diameter."))
            val cov = ctx.doubleOrNull("cover") ?: 50.0
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val pitch = ctx.doubleOrNull("pitch") ?: 150.0
            val bDia = ctx.doubleOrNull("barDia") ?: 8.0
            val coreD = (d - 2 * cov - bDia) / 1000.0
            if (coreD <= 0 || h <= 0 || pitch <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val pitchM = pitch / 1000.0
            val turns = h / pitchM
            val circ = PI * coreD
            val singleTurn = hypot(circ, pitchM)
            val totalLen = turns * singleTurn + 2.0 * circ // +2 extra end turns
            val wt = totalLen * (bDia * bDia / 162.2)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Spiral Total Length", UnitConverter.fmt(totalLen, p), "m", isPrimary = true),
                        CalcResultItem("Spiral Steel Weight", UnitConverter.fmt(wt, p), "kg", isPrimary = true),
                        CalcResultItem("Number of Turns", UnitConverter.fmt(turns, 1), "Turns"),
                        CalcResultItem("Core Helix Diameter", "${UnitConverter.fmt(coreD * 1000.0, 0)} mm", "")
                    ),
                    formula = "L_spiral = (H / Pitch) × √((π·D_core)² + Pitch²) + 2π·D_core",
                    steps = listOf("Core Dia = ${UnitConverter.fmt(coreD * 1000.0, 0)} mm; Turns = ${UnitConverter.fmt(turns, 1)}"),
                    assumptions = "Includes 2 extra full end turns for top and bottom anchorage."
                )
            )
        }
    )

    private fun roadEmbankmentEarthworkCalculator() = CalcToolSpec(
        id = "earth_embankment_road",
        title = "Road / Canal Embankment Earthwork",
        titleHi = "सड़क / नहर एम्बैंकमेंट मिट्टी कार्य",
        subtitle = "Trapezoidal Section Volume with Side Slopes (S:1) & Pitching Area",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("embankment", "road", "canal", "trapezoidal", "earthwork", "slope"),
        fields = listOf(
            CalcFieldSpec("topW", "Top Formation Width (B)", "8.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Embankment Height / Depth (H)", "2.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("slope", "Side Slope (H:V, e.g. 1.5 for 1.5:1)", "1.5", FieldUnitKind.NONE),
            CalcFieldSpec("len", "Road / Canal Length (L)", "100", FieldUnitKind.LENGTH, LengthUnit.M)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val b = ctx.lengthMeters("topW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val s = ctx.doubleOrNull("slope") ?: 1.5
            val l = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            if (b <= 0 || h <= 0 || s < 0 || l <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val csArea = (b + s * h) * h
            val vol = csArea * l
            val botW = b + 2.0 * s * h
            val slopeSideArea = 2.0 * hypot(h, s * h) * l
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Earthwork Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Volume in CFT", UnitConverter.fmt(vol * UnitConverter.CU_FT_IN_CU_M, p), "CFT", isPrimary = true),
                        CalcResultItem("Cross-Section Area", UnitConverter.fmt(csArea, p), "m²"),
                        CalcResultItem("Bottom Width", UnitConverter.fmt(botW, p), "m"),
                        CalcResultItem("Side Slope Turfing Area", UnitConverter.fmt(slopeSideArea, p), "m²")
                    ),
                    formula = "A = (B + s·H) × H; Volume = A × L",
                    steps = listOf("CS Area = (${UnitConverter.fmt(b, p)} + $s×${UnitConverter.fmt(h, p)})×${UnitConverter.fmt(h, p)} = ${UnitConverter.fmt(csArea, p)} m²"),
                    assumptions = "Uniform trapezoidal cross-section with symmetric side slopes s:1."
                )
            )
        }
    )

    private fun sandBulkingMoistureCalculator() = CalcToolSpec(
        id = "earth_soil_bulking",
        title = "Sand Bulking & Batch Correction",
        titleHi = "रेत बल्किंग (नमी) जांच कैलकुलेटर",
        subtitle = "IS 2386 Field Jar Test: Bulking %, Batching Multiplier & Free Moisture",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("bulking", "sand", "moisture", "jar test", "batching", "is 2386"),
        fields = listOf(
            CalcFieldSpec("hDamp", "Initial Damp Sand Height h₁ (mm)", "200", FieldUnitKind.NONE),
            CalcFieldSpec("hSat", "Inundated Saturated Height h₂ (mm)", "162", FieldUnitKind.NONE),
            CalcFieldSpec("nominalVol", "Nominal Dry Sand Batch Vol (CFT)", "100", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val h1 = ctx.doubleOrNull("hDamp") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter damp sand height."))
            val h2 = ctx.doubleOrNull("hSat") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter saturated height."))
            val nom = ctx.doubleOrNull("nominalVol") ?: 100.0
            if (h1 <= 0 || h2 <= 0 || h2 > h1) return@CalcToolSpec Result.failure(IllegalArgumentException("Saturated height h₂ must be ≤ damp height h₁."))
            val bulkPct = ((h1 - h2) / h2) * 100.0
            val factor = h1 / h2
            val correctedCft = nom * factor
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Bulking Percentage", "${UnitConverter.fmt(bulkPct, p)} %", "", isPrimary = true),
                        CalcResultItem("Corrected Damp Sand Batch", UnitConverter.fmt(correctedCft, p), "CFT", isPrimary = true),
                        CalcResultItem("Volume Multiplier", UnitConverter.fmt(factor, 3), "×")
                    ),
                    formula = "Bulking% = ((h₁ - h₂) / h₂) × 100; Batch Vol = Nominal × (h₁ / h₂)",
                    steps = listOf("((${h1} - ${h2}) / ${h2}) × 100 = ${UnitConverter.fmt(bulkPct, p)}%"),
                    assumptions = "Per IS 2386 Part 3 sand bulking jar test; fine sand peaks 20–30% bulking at ~4–5% moisture."
                )
            )
        }
    )

    private fun stairErgonomicsCheckCalculator() = CalcToolSpec(
        id = "site_stair_pitch_check",
        title = "Stair Pitch & 2R + G Ergonomic Check",
        titleHi = "सीढ़ी कोण और 2R+G आराम जांच",
        subtitle = "Check Riser/Tread Comfort (2R+G = 600–640 mm) & Stair Angle (25°–40°)",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("stair", "riser", "tread", "pitch", "ergonomic", "2r+g", "angle"),
        fields = listOf(
            CalcFieldSpec("riserMm", "Riser Height R (mm)", "150", FieldUnitKind.NONE),
            CalcFieldSpec("treadMm", "Tread Going G (mm)", "300", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val r = ctx.doubleOrNull("riserMm") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter riser."))
            val g = ctx.doubleOrNull("treadMm") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter tread."))
            if (r <= 0 || g <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Values must be positive."))
            val rule = 2.0 * r + g
            val angleDeg = Math.toDegrees(atan(r / g))
            val status = when {
                rule in 590.0..650.0 && angleDeg in 25.0..42.0 -> "COMFORTABLE (Optimal)"
                angleDeg > 42.0 -> "TOO STEEP (> 42°)"
                else -> "REVIEW 2R+G PROPORTION"
            }
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Ergonomic Verdict", status, "", isPrimary = true),
                        CalcResultItem("2R + G Value", "${UnitConverter.fmt(rule, 0)} mm", "(Ideal 600–640)", isPrimary = true),
                        CalcResultItem("Stair Pitch Angle", "${UnitConverter.fmt(angleDeg, p)}°", "(Ideal 25°–40°)"),
                        CalcResultItem("R × G Product", "${UnitConverter.fmt(r * g / 100.0, 0)} cm²", "(Ideal 400–450)")
                    ),
                    formula = "2R + G = 600 to 640 mm; Pitch θ = arctan(R / G)",
                    steps = listOf("2×$r + $g = ${UnitConverter.fmt(rule, 0)} mm; θ = ${UnitConverter.fmt(angleDeg, p)}°"),
                    assumptions = "Based on NBC India & Blondel stair comfort equation."
                )
            )
        }
    )

    private fun buildingCostBreakdownEstimator() = CalcToolSpec(
        id = "site_cost_estimator",
        title = "Construction Cost & Thumb-Rule Budget",
        titleHi = "भवन निर्माण लागत और सामग्री बजट",
        subtitle = "Built-Up Area Cost + Cement, Steel, Sand, Aggregate, Brick & Labor Breakdown",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("cost", "budget", "built-up", "thumb rule", "construction cost", "rate"),
        fields = listOf(
            CalcFieldSpec("areaSqFt", "Total Built-Up Area (sq.ft)", "1200", FieldUnitKind.NONE),
            CalcFieldSpec("ratePerSqFt", "Construction Rate per sq.ft", "1850", FieldUnitKind.RATE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("areaSqFt") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter built-up area."))
            val rate = ctx.doubleOrNull("ratePerSqFt") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter rate/sq.ft."))
            if (area <= 0 || rate <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be positive."))
            val totalCost = area * rate
            val cur = ctx.settings.currencySymbol
            // Standard residential construction material thumb rules per sq.ft
            val cementBags = area * 0.40
            val steelKg = area * 4.0
            val sandCft = area * 1.8
            val aggCft = area * 1.35
            val bricks = ceil(area * 8.5).toLong()
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Estimated Project Cost", "$cur${UnitConverter.fmt(totalCost, 0)}", "", isPrimary = true),
                        CalcResultItem("Cement (~0.40 bags/sq.ft)", UnitConverter.fmt(cementBags, 0), "Bags", isPrimary = true),
                        CalcResultItem("Steel (~4.0 kg/sq.ft)", "${UnitConverter.fmt(steelKg, 0)} kg (${UnitConverter.fmt(steelKg / 1000.0, p)} MT)", ""),
                        CalcResultItem("Sand & Aggregate", "${UnitConverter.fmt(sandCft, 0)} CFT Sand | ${UnitConverter.fmt(aggCft, 0)} CFT Agg", ""),
                        CalcResultItem("Bricks (~8.5/sq.ft)", "$bricks", "Nos"),
                        CalcResultItem("Labor (~25%) / Finish (~22%)", "$cur${UnitConverter.fmt(totalCost * 0.25, 0)} / $cur${UnitConverter.fmt(totalCost * 0.22, 0)}", "")
                    ),
                    formula = "Total Cost = Built-Up Area × Rate; Thumb Rules: Cement 0.40, Steel 4 kg/sq.ft",
                    steps = listOf("${UnitConverter.fmt(area, 0)} sq.ft × $cur${UnitConverter.fmt(rate, 0)} = $cur${UnitConverter.fmt(totalCost, 0)}"),
                    assumptions = "Residential G+1/G+2 thumb-rule norms; actual quantities depend on structural drawings.",
                    estimatedCost = totalCost
                )
            )
        }
    )
}

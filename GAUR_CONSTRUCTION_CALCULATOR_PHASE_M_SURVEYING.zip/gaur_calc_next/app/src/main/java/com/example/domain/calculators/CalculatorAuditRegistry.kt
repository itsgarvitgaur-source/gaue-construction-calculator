package com.example.domain.calculators

enum class AuditImplStatus {
    VERIFIED_FUNCTIONAL,
    FUNCTIONAL_MULTI_MODE_OVERLAP,
    PLANNED
}

data class CalculatorAuditSummary(
    val originalCatalogCount: Int,
    val originalFunctionalCount: Int,
    val duplicateOrOverlapCount: Int,
    val newUniqueCalculatorsCount: Int,
    val totalUniqueCalcSpecs: Int,
    val standaloneInteractiveModules: Int,
    val totalActiveFunctionalTools: Int,
    val uiOnlyPlaceholdersCount: Int,
    val plannedExpansionTargetRemaining: Int
)

/**
 * Step 1 & Step 4 programmatic audit and deduplication guard.
 * Enforces unique IDs, non-duplicate titles, and honest counts (no fake inflation).
 */
object CalculatorAuditRegistry {

    /**
     * Exact pre-expansion baseline IDs (82 CalcToolSpec calculators: 80 initial + 2 Road/Bridge).
     */
    val original82Ids: Set<String> = setOf(
        "basic_area", "basic_volume_surface", "basic_perimeter_rft", "basic_land_converter",
        "basic_length_converter", "basic_volume_converter", "basic_fraction_calc",
        "earth_excavation_pit", "earth_sloped_excavation", "earth_backfill", "earth_cut_fill",
        "earth_embankment_road", "earth_soil_bulking",
        "conc_pcc", "conc_rcc_mix", "conc_rmc", "conc_cement_mortar", "conc_water_cement", "conc_tube_curb",
        "struct_isolated_footing", "struct_rect_column", "struct_circ_column", "struct_pedestal",
        "struct_raft_strip", "struct_pile", "struct_beam", "struct_slab", "struct_stair_straight",
        "struct_stair_doglegged", "struct_retaining_wall", "struct_lintel", "struct_ground_beams",
        "struct_wall_multi", "struct_misc_elements", "struct_roofing", "struct_arch_dome",
        "masonry_bricks", "masonry_blocks", "masonry_stone", "masonry_interlocking_paver", "masonry_boundary_fence",
        "finish_plaster", "finish_paint_putty", "finish_waterproofing", "finish_tiles_flooring",
        "finish_trimix_epoxy", "finish_marble_granite", "finish_false_ceiling", "finish_wood_timber",
        "finish_door_window_glass", "finish_asphalt_road", "finish_anti_termite",
        "steel_rebar_weight", "steel_multi_dia", "steel_member_reinf", "steel_hook_bend_ld",
        "steel_stirrup_cutting", "steel_structural_sections", "steel_bbs_beam_column",
        "steel_footing_stair_rebar", "steel_helical_spiral",
        "util_water_tank", "util_septic_tank", "util_rainwater_harvest", "util_plumbing_pipe", "util_electrical_ac_solar",
        "site_rise_fall", "site_slope_gradient", "site_right_angle_triangle", "site_coord_bearing",
        "site_trig_height", "site_drawing_scale", "site_stair_pitch_check", "site_cost_estimator",
        "infra_road_layers", "infra_culvert_pier",
        "conv_weight_mass", "conv_pressure_stress", "conv_force_load",
        "conv_temperature", "conv_density_speed", "conv_angle_slope"
    )

    /**
     * Functional calculators whose scope partially overlaps multi-shape tools or standalone hubs
     * (retained strictly for backward-compatibility of saved Room history & routes).
     */
    val knownOverlapPairs: Map<String, String> = mapOf(
        "struct_circ_column" to "Overlaps Circular Column mode in struct_rect_column (kept for route/history compatibility)",
        "struct_stair_doglegged" to "Overlaps Dog-Legged mode in struct_stair_straight (kept for route/history compatibility)",
        "basic_fraction_calc" to "Form-based complement to interactive FeetInchCalculatorScreen",
        "basic_land_converter" to "Detailed multi-unit breakdown complement to ConvertersHubScreen",
        "basic_length_converter" to "Detailed multi-unit breakdown complement to ConvertersHubScreen"
    )

    val standaloneModuleIds: List<String> = listOf(
        "feet_inch_calc", "scientific_calc", "converters", "bbs", "peb",
        "boq", "materials", "studio2d", "studio3d", "site_diary",
        "knowledge", "projects", "history", "security", "settings"
    )

    fun findDuplicateIds(): List<String> {
        val seen = HashSet<String>()
        val dups = mutableListOf<String>()
        CalculatorRegistry.allTools.forEach { t ->
            if (!seen.add(t.id)) dups += t.id
        }
        return dups
    }

    fun findDuplicateTitles(): List<String> {
        val seen = HashSet<String>()
        val dups = mutableListOf<String>()
        CalculatorRegistry.allTools.forEach { t ->
            val key = t.title.trim().lowercase()
            if (!seen.add(key)) dups += t.title
        }
        return dups
    }

    fun summary(): CalculatorAuditSummary {
        val all = CalculatorRegistry.allTools
        val newUnique = all.count { it.id !in original82Ids }
        return CalculatorAuditSummary(
            originalCatalogCount = original82Ids.size,
            originalFunctionalCount = original82Ids.size,
            duplicateOrOverlapCount = knownOverlapPairs.size,
            newUniqueCalculatorsCount = newUnique,
            totalUniqueCalcSpecs = all.size,
            standaloneInteractiveModules = standaloneModuleIds.size,
            totalActiveFunctionalTools = all.size + standaloneModuleIds.size,
            uiOnlyPlaceholdersCount = 0,
            plannedExpansionTargetRemaining = (500 - all.size).coerceAtLeast(0)
        )
    }
}

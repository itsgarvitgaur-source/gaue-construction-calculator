package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.ceil
import kotlin.math.sqrt

object PhaseCElectricalHighRiseCostCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        cableVoltageDropCalculator(),
        roomLightingLumenCalculator(),
        areaFsiFarCalculator(),
        liftCoreShearWallCalculator(),
        rateAnalysisBuilderCalculator(),
        costPerSqFtStagesCalculator()
    )

    private fun cableVoltageDropCalculator() = CalcToolSpec(
        id = "util_voltage_drop_wire",
        title = "Cable Current, Voltage Drop & Conduit",
        titleHi = "केबल करंट, वोल्टेज ड्रॉप और कंड्यूट पाइप",
        subtitle = "1-Phase / 3-Phase Load Amps, % Voltage Drop Check & Conduit Pipes",
        category = CalcCategory.UTILITIES,
        keywords = listOf("cable", "wire", "voltage drop", "conduit", "electrical", "amp", "phase"),
        fields = listOf(
            CalcFieldSpec("loadKw", "Connected Load (kW)", "12.0", FieldUnitKind.NONE),
            CalcFieldSpec("phase", "Supply System", "3-Phase 415V", options = listOf("1-Phase 230V", "3-Phase 415V")),
            CalcFieldSpec("runM", "One-Way Cable Run Length", "45.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("coreMm2", "Cable Cross-Section (mm²)", "10.0", FieldUnitKind.NONE),
            CalcFieldSpec("conductor", "Conductor Material", "Copper (Cu)", options = listOf("Copper (Cu)", "Aluminium (Al)"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val kw = ctx.doubleOrNull("loadKw") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter kW load."))
            val is3Ph = ctx.raw("phase").startsWith("3-")
            val runM = ctx.lengthMeters("runM") ?: 45.0
            val mm2 = ctx.doubleOrNull("coreMm2") ?: 10.0
            val isCu = ctx.raw("conductor").startsWith("Copper")
            if (kw <= 0 || runM <= 0 || mm2 <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("All inputs must be positive."))

            val v = if (is3Ph) 415.0 else 230.0
            val pf = 0.85
            val amps = if (is3Ph) (kw * 1000.0) / (sqrt(3.0) * v * pf) else (kw * 1000.0) / (v * pf)
            val rho = if (isCu) 0.0178 else 0.0285 // ohm·mm²/m at ~30-40°C
            val vDrop = if (is3Ph) sqrt(3.0) * amps * (rho * runM / mm2) else 2.0 * amps * (rho * runM / mm2)
            val dropPct = (vDrop / v) * 100.0
            val conduitPipes = ceil((runM * 1.05) / 3.0).toInt()
            val status = if (dropPct <= 3.0) "OK (≤ 3% Drop)" else if (dropPct <= 5.0) "MARGINAL (3–5%)" else "HIGH DROP (> 5%) — Upsize Cable"
            val warnings = mutableListOf("Preliminary estimation only; verify IS 732 / IEC 60364 short-circuit, derating & breaker sizing with a licensed electrical engineer.")
            if (dropPct > 5.0) warnings += "Voltage drop ${UnitConverter.fmt(dropPct, 2)}% exceeds 5% limit."

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Design Load Current (PF 0.85)", UnitConverter.fmt(amps, p), "Amps", isPrimary = true),
                        CalcResultItem("Voltage Drop Check", "${UnitConverter.fmt(vDrop, p)} V (${UnitConverter.fmt(dropPct, 2)}%)", status, isPrimary = true),
                        CalcResultItem("3m PVC/GI Conduit Pipes (+5%)", "$conduitPipes", "pipes (${UnitConverter.fmt(runM * 1.05, 1)} m)")
                    ),
                    formula = "I = P / (√3·V·PF) [3Φ] or P / (V·PF) [1Φ]; ΔV = k·I·(ρ·L / A)",
                    steps = listOf("I=${UnitConverter.fmt(amps, 1)}A, ρ=$rho Ω·mm²/m, ΔV=${UnitConverter.fmt(vDrop, 2)}V (${UnitConverter.fmt(dropPct, 2)}%)"),
                    assumptions = "Power factor 0.85, resistive voltage drop check at ambient operating temperature.",
                    warnings = warnings
                )
            )
        }
    )

    private fun roomLightingLumenCalculator() = CalcToolSpec(
        id = "util_room_lighting",
        title = "Room Lighting (Lumen Method) Estimator",
        titleHi = "कमरे की लाइटिंग (ल्यूमेन और LED संख्या)",
        subtitle = "Required LED Fixtures & Total Lighting Watts from Target Lux",
        category = CalcCategory.UTILITIES,
        keywords = listOf("lighting", "lumen", "lux", "led", "watt", "room", "electrical"),
        fields = listOf(
            CalcFieldSpec("l", "Room Length", "6.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Room Width", "4.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("lux", "Target Illumination (Lux)", "250", FieldUnitKind.NONE),
            CalcFieldSpec("lumensPerFix", "Lumens per LED Fixture", "1800", FieldUnitKind.NONE),
            CalcFieldSpec("wattsPerFix", "Wattage per Fixture (W)", "18", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val lux = ctx.doubleOrNull("lux") ?: 250.0
            val lpf = ctx.doubleOrNull("lumensPerFix") ?: 1800.0
            val wpf = ctx.doubleOrNull("wattsPerFix") ?: 18.0
            if (l <= 0 || w <= 0 || lux <= 0 || lpf <= 0 || wpf <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All inputs must be positive."))
            }
            val area = l * w
            val uf = 0.65
            val mf = 0.80
            val rawN = (lux * area) / (lpf * uf * mf)
            val fixtures = ceil(rawN).toInt().coerceAtLeast(1)
            val totalW = fixtures * wpf

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("LED Fixtures Required", "$fixtures", "nos", isPrimary = true),
                        CalcResultItem("Total Lighting Load", UnitConverter.fmt(totalW, 0), "Watts (${UnitConverter.fmt(totalW / area, 1)} W/m²)", isPrimary = true),
                        CalcResultItem("Room Floor Area", UnitConverter.fmt(area, p), "m²")
                    ),
                    formula = "N = (Lux × Area) / (FixtureLumens × UF × MF); UF=0.65, MF=0.80",
                    steps = listOf("Required total lumens = ${(lux * area / (uf * mf)).toInt()} lm → $fixtures fixtures"),
                    assumptions = "Standard office/residential utilization factor UF=0.65 & maintenance factor MF=0.80."
                )
            )
        }
    )

    private fun areaFsiFarCalculator() = CalcToolSpec(
        id = "highrise_area_fsi",
        title = "Carpet, Built-Up, Super Built-Up & FSI/FAR",
        titleHi = "कार्पेट एरिया, बिल्ट-अप, सुपर बिल्ट-अप और FSI",
        subtitle = "Real Estate Area Breakdown & Permissible Floor Space Index Check",
        category = CalcCategory.STRUCTURAL,
        keywords = listOf("carpet", "built-up", "super built-up", "fsi", "far", "high-rise", "building"),
        fields = listOf(
            CalcFieldSpec("plotArea", "Total Plot Area (sq.ft)", "4000", FieldUnitKind.NONE),
            CalcFieldSpec("carpetPerFloor", "Carpet Area per Floor (sq.ft)", "1800", FieldUnitKind.NONE),
            CalcFieldSpec("floors", "Proposed Floors", "4", FieldUnitKind.COUNT),
            CalcFieldSpec("wallPct", "Walls & Balcony Add-on (%)", "15", FieldUnitKind.PERCENT),
            CalcFieldSpec("loadingPct", "Common Lobby/Stair Loading (%)", "25", FieldUnitKind.PERCENT),
            CalcFieldSpec("maxFsi", "Permissible Local FSI / FAR", "2.0", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val plot = ctx.doubleOrNull("plotArea") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter plot area."))
            val carpetFloor = ctx.doubleOrNull("carpetPerFloor") ?: 1800.0
            val floors = ctx.doubleOrNull("floors") ?: 4.0
            val wallPct = (ctx.doubleOrNull("wallPct") ?: 15.0).coerceAtLeast(0.0)
            val loadPct = (ctx.doubleOrNull("loadingPct") ?: 25.0).coerceAtLeast(0.0)
            val maxFsi = ctx.doubleOrNull("maxFsi") ?: 2.0
            if (plot <= 0 || carpetFloor <= 0 || floors <= 0 || maxFsi <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Plot, carpet, floors & FSI must be positive."))
            }
            val builtUpFloor = carpetFloor * (1.0 + wallPct / 100.0)
            val sbaFloor = builtUpFloor * (1.0 + loadPct / 100.0)
            val totalBuiltUp = builtUpFloor * floors
            val totalSba = sbaFloor * floors
            val achievedFsi = totalBuiltUp / plot
            val groundCov = (builtUpFloor / plot) * 100.0
            val warnings = if (achievedFsi > maxFsi) listOf("Achieved FSI ${UnitConverter.fmt(achievedFsi, 2)} exceeds permissible FSI $maxFsi.") else emptyList()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Built-Up / Super Built-Up", "${UnitConverter.fmt(totalBuiltUp, 0)} / ${UnitConverter.fmt(totalSba, 0)}", "sq.ft", isPrimary = true),
                        CalcResultItem("Achieved FSI / FAR", UnitConverter.fmt(achievedFsi, p), if (achievedFsi <= maxFsi) "WITHIN LIMIT (≤$maxFsi)" else "EXCEEDS $maxFsi", isPrimary = true),
                        CalcResultItem("Ground Coverage (%)", UnitConverter.fmt(groundCov, 1), "%"),
                        CalcResultItem("Per Floor Built-Up / SBA", "${UnitConverter.fmt(builtUpFloor, 0)} / ${UnitConverter.fmt(sbaFloor, 0)}", "sq.ft")
                    ),
                    formula = "Built-Up = Carpet×(1+Wall%); SBA = Built-Up×(1+Loading%); FSI = TotalBuiltUp / Plot",
                    steps = listOf("FSI = ${UnitConverter.fmt(totalBuiltUp, 0)} / ${UnitConverter.fmt(plot, 0)} = ${UnitConverter.fmt(achievedFsi, 2)}"),
                    assumptions = "Confirm municipal exclusions (staircase/lift/balcony FSI exemptions) per local bye-laws.",
                    warnings = warnings
                )
            )
        }
    )

    private fun liftCoreShearWallCalculator() = CalcToolSpec(
        id = "highrise_lift_core",
        title = "Lift Shaft & Core Shear Wall Estimator",
        titleHi = "लिफ्ट शाफ्ट और कोर शीयर वॉल गणना",
        subtitle = "High-Rise Lift Pit + Shaft Concrete, Formwork & Steel per Tower",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        keywords = listOf("lift", "elevator", "shaft", "core wall", "shear wall", "high-rise"),
        fields = listOf(
            CalcFieldSpec("innerL", "Shaft Inner Length", "2.1", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("innerW", "Shaft Inner Width", "1.9", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("wallT", "Core Wall Thickness (mm)", "250", FieldUnitKind.NONE),
            CalcFieldSpec("floorH", "Typical Floor Height", "3.1", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("floors", "Number of Floors (+Pit Equiv)", "10", FieldUnitKind.COUNT),
            CalcFieldSpec("doorDedPct", "Lift Door Openings Deduction (%)", "16", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val il = ctx.lengthMeters("innerL") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val iw = ctx.lengthMeters("innerW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val wt = (ctx.doubleOrNull("wallT") ?: 250.0) / 1000.0
            val fh = ctx.lengthMeters("floorH") ?: 3.1
            val fl = ctx.doubleOrNull("floors") ?: 10.0
            val ded = (ctx.doubleOrNull("doorDedPct") ?: 16.0).coerceIn(0.0, 45.0)
            if (il <= 0 || iw <= 0 || wt <= 0 || fh <= 0 || fl <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val totalH = fh * fl
            val outerA = (il + 2.0 * wt) * (iw + 2.0 * wt)
            val wallCsA = outerA - (il * iw)
            val netVol = wallCsA * totalH * (1.0 - ded / 100.0)
            val innerPerim = 2.0 * (il + iw)
            val outerPerim = 2.0 * (il + 2.0 * wt + iw + 2.0 * wt)
            val shutterM2 = (innerPerim + outerPerim) * totalH * (1.0 - ded / 100.0)
            val steelKg = netVol * 155.0 // heavy boundary element + double curtain core steel

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Lift Core Wall Concrete", UnitConverter.fmt(netVol, p), "m³", isPrimary = true),
                        CalcResultItem("Prelim. Core Rebar (~155 kg/m³)", UnitConverter.fmt(steelKg, 0), "kg", isPrimary = true),
                        CalcResultItem("Inner + Outer Formwork Area", UnitConverter.fmt(shutterM2, p), "m²"),
                        CalcResultItem("Total Shaft Height", UnitConverter.fmt(totalH, p), "m")
                    ),
                    formula = "Wall CS = (L+2t)(W+2t) − L×W; Net Vol = CS × TotalH × (1 − DoorDed%)",
                    steps = listOf("Total H=${UnitConverter.fmt(totalH, p)}m; Wall CS=${UnitConverter.fmt(wallCsA, 3)} m²"),
                    assumptions = "Includes double-curtain shear wall rebar norm (~155 kg/m³); design boundary elements per IS 13920."
                )
            )
        }
    )

    private fun rateAnalysisBuilderCalculator() = CalcToolSpec(
        id = "site_rate_analysis",
        title = "Civil Item Rate Analysis (DAR / CPWD)",
        titleHi = "सिविल आइटम रेट एनालिसिस (CPWD / DAR)",
        subtitle = "Material + Labour + Hire + Water/Elec (1.5%) + Contractor Profit (15%)",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("rate analysis", "dar", "cpwd", "overhead", "profit", "unit rate", "boq"),
        fields = listOf(
            CalcFieldSpec("matCost", "Base Material Cost per Unit", "4200", FieldUnitKind.RATE, allowZero = true),
            CalcFieldSpec("labCost", "Skilled + Unskilled Labour Cost", "1100", FieldUnitKind.RATE, allowZero = true),
            CalcFieldSpec("equipCost", "Plant / Machinery / Tools Cost", "350", FieldUnitKind.RATE, allowZero = true),
            CalcFieldSpec("waterElecPct", "Water, Electricity & Sundries (%)", "1.5", FieldUnitKind.PERCENT, allowZero = true),
            CalcFieldSpec("profitPct", "Contractor Overheads & Profit (%)", "15.0", FieldUnitKind.PERCENT, allowZero = true),
            CalcFieldSpec("gstPct", "GST Add-on (%)", "18.0", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val mat = (ctx.doubleOrNull("matCost") ?: 0.0).coerceAtLeast(0.0)
            val lab = (ctx.doubleOrNull("labCost") ?: 0.0).coerceAtLeast(0.0)
            val eqp = (ctx.doubleOrNull("equipCost") ?: 0.0).coerceAtLeast(0.0)
            val we = (ctx.doubleOrNull("waterElecPct") ?: 1.5).coerceAtLeast(0.0)
            val prof = (ctx.doubleOrNull("profitPct") ?: 15.0).coerceAtLeast(0.0)
            val gst = (ctx.doubleOrNull("gstPct") ?: 18.0).coerceAtLeast(0.0)
            val baseSum = mat + lab + eqp
            if (baseSum <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter at least one base cost."))

            val withSundries = baseSum * (1.0 + we / 100.0)
            val unitRateExclGst = withSundries * (1.0 + prof / 100.0)
            val finalRateInclGst = unitRateExclGst * (1.0 + gst / 100.0)
            val cur = ctx.settings.currencySymbol

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Unit Rate (Excl. GST)", "$cur${UnitConverter.fmt(unitRateExclGst, 2)}", "", isPrimary = true),
                        CalcResultItem("Final Rate (Incl. ${gst.toInt()}% GST)", "$cur${UnitConverter.fmt(finalRateInclGst, 2)}", "", isPrimary = true),
                        CalcResultItem("Direct Cost + Sundries", "$cur${UnitConverter.fmt(withSundries, 2)}", ""),
                        CalcResultItem("Contractor OH & Profit (${prof}%)", "$cur${UnitConverter.fmt(unitRateExclGst - withSundries, 2)}", "")
                    ),
                    formula = "Rate = (Mat + Lab + Equip) × (1 + WaterElec%) × (1 + Profit%) × (1 + GST%)",
                    steps = listOf("Base = $cur${UnitConverter.fmt(baseSum, 2)} → +${we}% = $cur${UnitConverter.fmt(withSundries, 2)} → +${prof}% = $cur${UnitConverter.fmt(unitRateExclGst, 2)}"),
                    assumptions = "Follows standard CPWD Delhi Analysis of Rates (DAR) 1.5% water/sundries + 15% contractor profit structure.",
                    estimatedCost = unitRateExclGst
                )
            )
        }
    )

    private fun costPerSqFtStagesCalculator() = CalcToolSpec(
        id = "site_bar_progress",
        title = "Stage-Wise Project Cashflow & Cost Split",
        titleHi = "निर्माण चरण अनुसार बजट और कैशफ्लो",
        subtitle = "Stage-Wise Allocation: Substructure, RCC Frame, Masonry, MEP & Finish",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("cashflow", "stage", "cost", "budget", "substructure", "finishing", "sqft"),
        fields = listOf(
            CalcFieldSpec("areaSqFt", "Total Built-Up Area (sq.ft)", "2400", FieldUnitKind.NONE),
            CalcFieldSpec("rateSqFt", "Turnkey Rate per sq.ft", "1950", FieldUnitKind.RATE),
            CalcFieldSpec("contPct", "Contingency Reserve (%)", "5", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val area = ctx.doubleOrNull("areaSqFt") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter built-up area."))
            val rate = ctx.doubleOrNull("rateSqFt") ?: 1950.0
            val cont = (ctx.doubleOrNull("contPct") ?: 5.0).coerceAtLeast(0.0)
            if (area <= 0 || rate <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Area and rate must be positive."))

            val baseBudget = area * rate
            val totalBudget = baseBudget * (1.0 + cont / 100.0)
            val cur = ctx.settings.currencySymbol

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Project Budget (incl. ${cont.toInt()}%)", "$cur${UnitConverter.fmt(totalBudget, 0)}", "", isPrimary = true),
                        CalcResultItem("Substructure & Plinth (~14%)", "$cur${UnitConverter.fmt(baseBudget * 0.14, 0)}", "", isPrimary = true),
                        CalcResultItem("RCC Superstructure (~28%)", "$cur${UnitConverter.fmt(baseBudget * 0.28, 0)}", ""),
                        CalcResultItem("Masonry & Plaster (~16%)", "$cur${UnitConverter.fmt(baseBudget * 0.16, 0)}", ""),
                        CalcResultItem("Plumbing & Electrical MEP (~14%)", "$cur${UnitConverter.fmt(baseBudget * 0.14, 0)}", ""),
                        CalcResultItem("Flooring, Paint, Joinery (~28%)", "$cur${UnitConverter.fmt(baseBudget * 0.28, 0)}", "")
                    ),
                    formula = "Base = BuiltUp × Rate/sq.ft; Allocated by standard Indian residential turn-key split",
                    steps = listOf("Base = $cur${UnitConverter.fmt(baseBudget, 0)}; +${cont}% contingency = $cur${UnitConverter.fmt(totalBudget, 0)}"),
                    assumptions = "Preliminary S-curve cost split for residential/commercial RCC framed buildings.",
                    estimatedCost = totalBudget
                )
            )
        }
    )
}

package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.core.preferences.ThemeModePref

@Immutable
data class GaurEngineeringPalette(
    val orange: Color = ConstructionOrange,
    val orangeDark: Color = ConstructionOrangeDark,
    val orangeSoft: Color = ConstructionOrangeLight,
    val skyBlue: Color = SkyGlassBlue,
    val skyBlueBright: Color = SkyGlassBlueBright,
    val skyGlassTint: Color = SkyGlassTint,
    val skyGlassBorder: Color = SkyGlassBorder,
    val metallicSilver: Color = MetallicSilver,
    val metallicBorder: Color = MetallicSilverMid,
    val metallicDark: Color = MetallicSilverDark,
    val concreteBg: Color = ConcreteBackground,
    val concreteCard: Color = ConcreteWhite,
    val concreteSurfaceAlt: Color = ConcreteSurfaceAlt,
    val inkPrimary: Color = EngineeringInk,
    val inkSecondary: Color = EngineeringInkSecondary,
    val inkMuted: Color = EngineeringInkMuted,
    val success: Color = StatusSuccess,
    val successBg: Color = StatusSuccessBg,
    val warning: Color = StatusWarning,
    val warningBg: Color = StatusWarningBg,
    val error: Color = StatusError,
    val errorBg: Color = StatusErrorBg,
    val isDark: Boolean = false
)

val LocalEngineeringPalette = staticCompositionLocalOf { GaurEngineeringPalette() }

private val GaurDarkEngineeringPalette = GaurEngineeringPalette(
    orange = ConstructionOrange,
    orangeDark = DarkOrangeBright,
    orangeSoft = DarkOrangeSoft,
    skyBlue = SkyGlassBlueBright,
    skyBlueBright = SkyGlassBlueBright,
    skyGlassTint = DarkSkyGlassTint,
    skyGlassBorder = DarkSkyGlassBorder,
    metallicSilver = DarkGraphiteSurfaceAlt,
    metallicBorder = DarkGraphiteBorder,
    metallicDark = DarkInkMuted,
    concreteBg = DarkGraphiteBg,
    concreteCard = DarkGraphiteCard,
    concreteSurfaceAlt = DarkGraphiteSurfaceAlt,
    inkPrimary = DarkInkPrimary,
    inkSecondary = DarkInkSecondary,
    inkMuted = DarkInkMuted,
    success = Color(0xFF4ADE80),
    successBg = DarkSuccessBg,
    warning = Color(0xFFFBBF24),
    warningBg = DarkWarningBg,
    error = Color(0xFFF87171),
    errorBg = DarkErrorBg,
    isDark = true
)

private val GaurLightColorScheme = lightColorScheme(
    primary = ConstructionOrange,
    onPrimary = ConcreteWhite,
    primaryContainer = ConstructionOrangeLight,
    onPrimaryContainer = ConstructionOrangeDark,
    secondary = SkyGlassBlue,
    onSecondary = ConcreteWhite,
    secondaryContainer = SkyGlassTint,
    onSecondaryContainer = SkyGlassBlue,
    tertiary = MetallicSteel,
    onTertiary = ConcreteWhite,
    tertiaryContainer = MetallicSilver,
    onTertiaryContainer = EngineeringInk,
    background = ConcreteBackground,
    onBackground = EngineeringInk,
    surface = ConcreteWhite,
    onSurface = EngineeringInk,
    surfaceVariant = ConcreteSurfaceAlt,
    onSurfaceVariant = EngineeringInkSecondary,
    outline = MetallicSilverMid,
    outlineVariant = ConcreteBorder,
    error = StatusError,
    onError = ConcreteWhite,
    errorContainer = StatusErrorBg,
    onErrorContainer = StatusError
)

private val GaurDarkColorScheme = darkColorScheme(
    primary = ConstructionOrange,
    onPrimary = ConcreteWhite,
    primaryContainer = DarkOrangeSoft,
    onPrimaryContainer = DarkOrangeBright,
    secondary = SkyGlassBlueBright,
    onSecondary = DarkGraphiteBg,
    secondaryContainer = DarkSkyGlassTint,
    onSecondaryContainer = SkyGlassBlueBright,
    tertiary = DarkInkMuted,
    onTertiary = DarkGraphiteBg,
    tertiaryContainer = DarkGraphiteSurfaceAlt,
    onTertiaryContainer = DarkInkPrimary,
    background = DarkGraphiteBg,
    onBackground = DarkInkPrimary,
    surface = DarkGraphiteCard,
    onSurface = DarkInkPrimary,
    surfaceVariant = DarkGraphiteSurfaceAlt,
    onSurfaceVariant = DarkInkSecondary,
    outline = DarkGraphiteBorder,
    outlineVariant = DarkGraphiteBorder,
    error = Color(0xFFF87171),
    onError = DarkGraphiteBg,
    errorContainer = DarkErrorBg,
    onErrorContainer = Color(0xFFFCA5A5)
)

private val GaurShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp)
)

@Composable
fun GaurConstructionTheme(
    themeMode: ThemeModePref = ThemeModePref.SYSTEM,
    content: @Composable () -> Unit
) {
    val useDark = when (themeMode) {
        ThemeModePref.SYSTEM -> isSystemInDarkTheme()
        ThemeModePref.LIGHT -> false
        ThemeModePref.DARK -> true
    }
    val engineeringPalette = if (useDark) GaurDarkEngineeringPalette else GaurEngineeringPalette()
    val colorScheme = if (useDark) GaurDarkColorScheme else GaurLightColorScheme
    CompositionLocalProvider(LocalEngineeringPalette provides engineeringPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = GaurTypography,
            shapes = GaurShapes,
            content = content
        )
    }
}

package com.example.features.projects

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Archive
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.core.i18n.LocalAppStrings
import com.example.data.local.ProjectEntity
import com.example.domain.units.UnitConverter
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProjectsListScreen(
    viewModel: MainViewModel,
    onOpenProject: (Long) -> Unit,
    onBack: (() -> Unit)? = null
) {
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val projects by viewModel.projects.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var editingProject by remember { mutableStateOf<ProjectEntity?>(null) }

    Scaffold(
        containerColor = palette.concreteBg,
        topBar = {
            EngineeringTopBar(
                title = strings.projects,
                subtitle = "${projects.size} Saved Site Workspaces",
                onBack = onBack
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { editingProject = null; showCreateDialog = true },
                containerColor = palette.orange,
                contentColor = palette.concreteCard,
                modifier = Modifier.testTag("create_project_fab")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = strings.createProject)
            }
        }
    ) { inner ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(inner),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (projects.isEmpty()) {
                item {
                    EngineeringCard(accentColor = palette.skyBlue) {
                        Text("No Site Projects Yet", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Tap + to create a project workspace for drawings, BOQs, BBS schedules, attached documents, and site calculations.",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.inkMuted
                        )
                    }
                }
            }
            items(projects, key = { it.id }) { proj ->
                EngineeringCard(
                    accentColor = if (proj.status == "Archived") palette.metallicDark else palette.orange,
                    onClick = { onOpenProject(proj.id) },
                    modifier = Modifier.testTag("project_card_${proj.id}")
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(proj.name, style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                            Text("${proj.clientName} • ${proj.siteLocation}", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            Text("${proj.projectType} • Started ${proj.startDate}", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                        }
                        GlassBluePill(text = proj.status)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        IconButton(onClick = { editingProject = proj; showCreateDialog = true }) {
                            Icon(Icons.Rounded.Edit, contentDescription = "Edit Project", tint = palette.skyBlue)
                        }
                        IconButton(onClick = { viewModel.duplicateProject(proj) }) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Duplicate", tint = palette.orangeDark)
                        }
                        IconButton(onClick = {
                            viewModel.saveProject(proj.copy(status = if (proj.status == "Archived") "In Progress" else "Archived"))
                        }) {
                            Icon(Icons.Rounded.Archive, contentDescription = "Archive", tint = palette.inkMuted)
                        }
                        IconButton(onClick = { viewModel.deleteProject(proj) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = palette.error)
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        ProjectEditorDialog(
            initial = editingProject,
            onDismiss = { showCreateDialog = false },
            onSave = { proj ->
                viewModel.saveProject(proj)
                showCreateDialog = false
            }
        )
    }
}

@Composable
fun ProjectDetailScreen(
    projectId: Long,
    viewModel: MainViewModel,
    onOpenCalculator: (String) -> Unit,
    onOpenStudio2D: () -> Unit,
    onOpenStudio3D: () -> Unit,
    onOpenBoq: () -> Unit,
    onOpenBbs: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val project by viewModel.repository.observeProject(projectId).collectAsStateWithLifecycle(initialValue = null)
    val history by viewModel.repository.observeProjectHistory(projectId).collectAsStateWithLifecycle(initialValue = emptyList())
    val boqs by viewModel.repository.observeProjectBoqs(projectId).collectAsStateWithLifecycle(initialValue = emptyList())
    val bbs by viewModel.repository.observeProjectBbs(projectId).collectAsStateWithLifecycle(initialValue = emptyList())
    val drawings by viewModel.repository.observeProjectDrawings(projectId).collectAsStateWithLifecycle(initialValue = emptyList())
    val models by viewModel.repository.observeProjectModels3D(projectId).collectAsStateWithLifecycle(initialValue = emptyList())

    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val p = project ?: return@rememberLauncherForActivityResult
        if (uri != null) {
            val arr = runCatching { JSONArray(p.attachedDocsJson) }.getOrDefault(JSONArray())
            arr.put(uri.lastPathSegment ?: uri.toString())
            viewModel.saveProject(p.copy(attachedDocsJson = arr.toString()))
            Toast.makeText(context, "Document reference attached", Toast.LENGTH_SHORT).show()
        }
    }

    val p = project
    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = p?.name ?: "Project Workspace",
            subtitle = p?.let { "${it.clientName} • ${it.siteLocation}" },
            onBack = onBack,
            actions = {
                if (p != null) {
                    IconButton(onClick = {
                        val totalCalcCost = history.mapNotNull { it.totalCost }.sum()
                        val report = EngineeringReportData(
                            title = "Project Summary — ${p.name}",
                            projectName = p.name,
                            clientName = p.clientName,
                            companyName = settings.companyName,
                            engineerName = settings.engineerName,
                            sections = listOf(
                                ReportSection(
                                    "Project Details",
                                    rows = listOf(
                                        "Site Location" to p.siteLocation,
                                        "Type" to p.projectType,
                                        "Status" to p.status,
                                        "Start Date" to p.startDate,
                                        "Saved Calculations" to "${history.size}",
                                        "BOQ / BBS / 2D / 3D" to "${boqs.size} / ${bbs.size} / ${drawings.size} / ${models.size}",
                                        "Est. Calc Cost Sum" to "${settings.currencySymbol}${UnitConverter.fmt(totalCalcCost, 0)}"
                                    ),
                                    paragraphs = listOf("Notes: ${p.notes}")
                                )
                            )
                        )
                        val file = ReportExportEngine.generatePdfFile(context, report)
                        ReportExportEngine.shareFile(context, file, "application/pdf", p.name)
                    }) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = "Export Project PDF", tint = palette.error)
                    }
                }
            }
        )

        if (p == null) {
            Text("Project not found.", modifier = Modifier.padding(16.dp), color = palette.inkMuted)
            return
        }

        val attachedDocs = remember(p.attachedDocsJson) {
            val arr = runCatching { JSONArray(p.attachedDocsJson) }.getOrDefault(JSONArray())
            List(arr.length()) { arr.optString(it) }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                EngineeringCard(accentColor = palette.orange) {
                    Text("${p.projectType} • ${p.status}", style = MaterialTheme.typography.titleSmall, color = palette.orangeDark)
                    Spacer(Modifier.height(4.dp))
                    Text(p.notes.ifBlank { "No site notes recorded." }, style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenBoq, modifier = Modifier.weight(1f)) { Text("BOQ (${boqs.size})") }
                        OutlinedButton(onClick = onOpenBbs, modifier = Modifier.weight(1f)) { Text("BBS (${bbs.size})") }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onOpenStudio2D, modifier = Modifier.weight(1f)) { Text("2D (${drawings.size})") }
                        OutlinedButton(onClick = onOpenStudio3D, modifier = Modifier.weight(1f)) { Text("3D (${models.size})") }
                    }
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = { docPicker.launch(arrayOf("*/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Rounded.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Attach Site Document (${attachedDocs.size})")
                    }
                    attachedDocs.forEach { doc ->
                        Text("• $doc", style = MaterialTheme.typography.bodySmall, color = palette.skyBlue, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }

            item {
                Text("Project Calculations (${history.size})", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
            }
            items(history, key = { it.id }) { h ->
                EngineeringCard(onClick = { onOpenCalculator(h.toolId) }) {
                    Text(h.customName.ifBlank { h.toolName }, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Text(h.category, style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProjectEditorDialog(
    initial: ProjectEntity?,
    onDismiss: () -> Unit,
    onSave: (ProjectEntity) -> Unit
) {
    val today = remember { SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date()) }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var client by remember { mutableStateOf(initial?.clientName ?: "") }
    var location by remember { mutableStateOf(initial?.siteLocation ?: "") }
    var type by remember { mutableStateOf(initial?.projectType ?: "Residential") }
    var status by remember { mutableStateOf(initial?.status ?: "In Progress") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Create Site Project" else "Edit Project") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Project Name") }, singleLine = true)
                OutlinedTextField(value = client, onValueChange = { client = it }, label = { Text("Client Name") }, singleLine = true)
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Site Location") }, singleLine = true)
                var typeOpen by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = typeOpen, onExpandedChange = { typeOpen = !typeOpen }) {
                    OutlinedTextField(
                        value = type, onValueChange = {}, readOnly = true, label = { Text("Project Type") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeOpen) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = typeOpen, onDismissRequest = { typeOpen = false }) {
                        listOf("Residential", "Commercial", "Industrial", "PEB Warehouse", "Roadwork", "Renovation").forEach { t ->
                            DropdownMenuItem(text = { Text(t) }, onClick = { type = t; typeOpen = false })
                        }
                    }
                }
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Engineering Notes") })
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    onSave(
                        ProjectEntity(
                            id = initial?.id ?: 0L,
                            name = name.trim(),
                            clientName = client.trim().ifBlank { "Private Client" },
                            siteLocation = location.trim().ifBlank { "Site" },
                            projectType = type,
                            startDate = initial?.startDate ?: today,
                            status = status,
                            notes = notes.trim(),
                            attachedDocsJson = initial?.attachedDocsJson ?: "[]"
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

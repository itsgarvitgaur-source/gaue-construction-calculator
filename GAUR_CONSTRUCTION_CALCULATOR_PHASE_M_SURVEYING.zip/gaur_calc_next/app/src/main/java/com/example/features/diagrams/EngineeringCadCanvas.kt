package com.example.features.diagrams

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

object CadColors {
    val ConcreteFill = Color(0xFFCBD5E1)
    val ConcreteDarkFill = Color(0xFF94A3B8)
    val ConcreteStroke = Color(0xFF1E293B)
    val MasonryFill = Color(0xFFFED7AA)
    val MasonryStroke = Color(0xFFC2410C)
    val SteelBar = Color(0xFFDC2626)
    val StirrupColor = Color(0xFFEA580C)
    val SoilFill = Color(0xFFE7D8C9)
    val SoilStroke = Color(0xFF78350F)
    val DimBlue = Color(0xFF0288D1)
    val DimOrange = Color(0xFFE65100)
    val GlassFill = Color(0xFFBAE6FD)
    val GridLine = Color(0xFFE2E8F0)
    val LabelBg = Color(0xFFFFFFFF)
}

data class Vec3D(val x: Float, val y: Float, val z: Float)

fun DrawScope.drawEngineeringGrid(spacingPx: Float = 36f) {
    var x = 0f
    while (x <= size.width) {
        drawLine(CadColors.GridLine, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
        x += spacingPx
    }
    var y = 0f
    while (y <= size.height) {
        drawLine(CadColors.GridLine, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
        y += spacingPx
    }
}

fun DrawScope.drawCadTextPill(
    text: String,
    center: Offset,
    textColor: Color = CadColors.DimBlue,
    bgColor: Color = CadColors.LabelBg,
    borderColor: Color = textColor.copy(alpha = 0.45f),
    textSizePx: Float = 26f
) {
    if (text.isBlank()) return
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textColor.toArgb()
        textSize = textSizePx
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    val textW = paint.measureText(text)
    val padX = 10f
    val padY = 6f
    val boxW = textW + padX * 2f
    val boxH = textSizePx + padY * 2f
    val topLeft = Offset(
        (center.x - boxW / 2f).coerceIn(4f, (size.width - boxW - 4f).coerceAtLeast(4f)),
        (center.y - boxH / 2f).coerceIn(4f, (size.height - boxH - 4f).coerceAtLeast(4f))
    )
    drawRoundRect(
        color = bgColor.copy(alpha = 0.94f),
        topLeft = topLeft,
        size = Size(boxW, boxH),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
    )
    drawRoundRect(
        color = borderColor,
        topLeft = topLeft,
        size = Size(boxW, boxH),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f),
        style = Stroke(width = 1.5f)
    )
    val baseline = topLeft.y + boxH / 2f + textSizePx * 0.34f
    drawContext.canvas.nativeCanvas.drawText(
        text,
        topLeft.x + boxW / 2f,
        baseline,
        paint
    )
}

/**
 * Draws a CAD dimension line with perpendicular extension lines, arrowheads, and non-overlapping label pill.
 * [offsetPx] shifts the dimension line along the left-hand normal of (p1 -> p2).
 */
fun DrawScope.drawDimensionLine(
    p1: Offset,
    p2: Offset,
    offsetPx: Float,
    label: String,
    color: Color = CadColors.DimBlue,
    arrowLen: Float = 11f
) {
    val dx = p2.x - p1.x
    val dy = p2.y - p1.y
    val len = hypot(dx, dy)
    if (len < 4f) return
    val ux = dx / len
    val uy = dy / len
    // Normal vector
    val nx = -uy
    val ny = ux
    val sign = if (offsetPx >= 0f) 1f else -1f

    val d1 = Offset(p1.x + nx * offsetPx, p1.y + ny * offsetPx)
    val d2 = Offset(p2.x + nx * offsetPx, p2.y + ny * offsetPx)

    // Extension lines (with small gap from object & slight overshoot)
    val extPaintColor = color.copy(alpha = 0.65f)
    val e1Start = Offset(p1.x + nx * sign * 4f, p1.y + ny * sign * 4f)
    val e1End = Offset(d1.x + nx * sign * 6f, d1.y + ny * sign * 6f)
    val e2Start = Offset(p2.x + nx * sign * 4f, p2.y + ny * sign * 4f)
    val e2End = Offset(d2.x + nx * sign * 6f, d2.y + ny * sign * 6f)
    drawLine(extPaintColor, e1Start, e1End, strokeWidth = 1.5f)
    drawLine(extPaintColor, e2Start, e2End, strokeWidth = 1.5f)

    // Main dimension line
    drawLine(color, d1, d2, strokeWidth = 2.2f)

    // Arrowheads at d1 and d2
    val arrowHalfW = 4.5f
    val a1 = Path().apply {
        moveTo(d1.x, d1.y)
        lineTo(d1.x + ux * arrowLen + nx * arrowHalfW, d1.y + uy * arrowLen + ny * arrowHalfW)
        lineTo(d1.x + ux * arrowLen - nx * arrowHalfW, d1.y + uy * arrowLen - ny * arrowHalfW)
        close()
    }
    val a2 = Path().apply {
        moveTo(d2.x, d2.y)
        lineTo(d2.x - ux * arrowLen + nx * arrowHalfW, d2.y - uy * arrowLen + ny * arrowHalfW)
        lineTo(d2.x - ux * arrowLen - nx * arrowHalfW, d2.y - uy * arrowLen - ny * arrowHalfW)
        close()
    }
    drawPath(a1, color)
    drawPath(a2, color)

    val mid = Offset((d1.x + d2.x) / 2f, (d1.y + d2.y) / 2f)
    drawCadTextPill(text = label, center = mid, textColor = color)
}

fun DrawScope.drawLeaderCallout(
    anchor: Offset,
    elbow: Offset,
    label: String,
    color: Color = CadColors.DimOrange
) {
    drawCircle(color, radius = 4f, center = anchor)
    drawLine(color, anchor, elbow, strokeWidth = 2f)
    val dir = if (elbow.x >= anchor.x) 1f else -1f
    val tip = Offset(elbow.x + dir * 24f, elbow.y)
    drawLine(color, elbow, tip, strokeWidth = 2f)
    drawCadTextPill(
        text = label,
        center = Offset(tip.x + dir * 48f, tip.y),
        textColor = color
    )
}

fun DrawScope.drawAngularArc(
    vertex: Offset,
    radiusPx: Float,
    startAngleDeg: Float,
    sweepAngleDeg: Float,
    label: String,
    color: Color = CadColors.DimOrange
) {
    drawArc(
        color = color,
        startAngle = startAngleDeg,
        sweepAngle = sweepAngleDeg,
        useCenter = false,
        topLeft = Offset(vertex.x - radiusPx, vertex.y - radiusPx),
        size = Size(radiusPx * 2f, radiusPx * 2f),
        style = Stroke(width = 2.4f)
    )
    val midRad = Math.toRadians((startAngleDeg + sweepAngleDeg / 2f).toDouble())
    val labelPos = Offset(
        vertex.x + ((radiusPx + 24f) * cos(midRad)).toFloat(),
        vertex.y + ((radiusPx + 24f) * sin(midRad)).toFloat()
    )
    drawCadTextPill(text = label, center = labelPos, textColor = color, textSizePx = 24f)
}

fun DrawScope.drawDiagonalHatch(
    topLeft: Offset,
    rectSize: Size,
    color: Color = Color(0xFF94A3B8).copy(alpha = 0.35f),
    stepPx: Float = 14f
) {
    val x0 = topLeft.x
    val y0 = topLeft.y
    val x1 = x0 + rectSize.width
    val y1 = y0 + rectSize.height
    var offset = -rectSize.height
    while (offset < rectSize.width + rectSize.height) {
        val sx = (x0 + offset).coerceIn(x0, x1)
        val sy = if (offset < 0) y0 - offset else y0
        val ex = (x0 + offset + rectSize.height).coerceIn(x0, x1)
        val ey = (y0 + rectSize.height - (ex - (x0 + offset))).coerceIn(y0, y1)
        if (sy <= y1 && ey >= y0 && (sx != ex || sy != ey)) {
            drawLine(color, Offset(sx, sy.coerceIn(y0, y1)), Offset(ex, ey), strokeWidth = 1.2f)
        }
        offset += stepPx
    }
}

fun project3DPoint(
    p: Vec3D,
    originCenter: Vec3D,
    canvasCenter: Offset,
    scalePx: Float,
    yawDeg: Float,
    pitchDeg: Float
): Pair<Offset, Float> {
    val yr = Math.toRadians(yawDeg.toDouble())
    val pr = Math.toRadians(pitchDeg.toDouble())
    val dx = (p.x - originCenter.x).toDouble()
    val dy = (p.y - originCenter.y).toDouble()
    val dz = (p.z - originCenter.z).toDouble()

    val rx = dx * cos(yr) - dy * sin(yr)
    val ry = dx * sin(yr) + dy * cos(yr)
    val py = ry * cos(pr) - dz * sin(pr)
    val pz = ry * sin(pr) + dz * cos(pr)

    val persp = (26.0 / (26.0 - py * 0.35)).coerceIn(0.45, 2.2)
    return Offset(
        canvasCenter.x + (rx * scalePx * persp).toFloat(),
        canvasCenter.y - (pz * scalePx * persp).toFloat()
    ) to py.toFloat()
}

fun DrawScope.draw3DPrism(
    minPt: Vec3D,
    maxPt: Vec3D,
    centerRef: Vec3D,
    canvasCenter: Offset,
    scalePx: Float,
    yawDeg: Float,
    pitchDeg: Float,
    baseColor: Color,
    strokeColor: Color = CadColors.ConcreteStroke,
    alpha: Float = 0.88f
): List<Offset> {
    val verts = listOf(
        Vec3D(minPt.x, minPt.y, minPt.z),
        Vec3D(maxPt.x, minPt.y, minPt.z),
        Vec3D(maxPt.x, maxPt.y, minPt.z),
        Vec3D(minPt.x, maxPt.y, minPt.z),
        Vec3D(minPt.x, minPt.y, maxPt.z),
        Vec3D(maxPt.x, minPt.y, maxPt.z),
        Vec3D(maxPt.x, maxPt.y, maxPt.z),
        Vec3D(minPt.x, maxPt.y, maxPt.z)
    ).map { project3DPoint(it, centerRef, canvasCenter, scalePx, yawDeg, pitchDeg) }

    val pts = verts.map { it.first }
    val faces = listOf(
        listOf(0, 1, 2, 3) to 0.72f,
        listOf(4, 5, 6, 7) to 1.0f,
        listOf(0, 1, 5, 4) to 0.88f,
        listOf(1, 2, 6, 5) to 0.78f,
        listOf(2, 3, 7, 6) to 0.75f,
        listOf(3, 0, 4, 7) to 0.84f
    ).sortedBy { (idxs, _) -> idxs.map { verts[it].second }.average() }

    faces.forEach { (idxs, shade) ->
        val path = Path().apply {
            moveTo(pts[idxs[0]].x, pts[idxs[0]].y)
            lineTo(pts[idxs[1]].x, pts[idxs[1]].y)
            lineTo(pts[idxs[2]].x, pts[idxs[2]].y)
            lineTo(pts[idxs[3]].x, pts[idxs[3]].y)
            close()
        }
        drawPath(
            path = path,
            color = Color(
                red = (baseColor.red * shade).coerceIn(0f, 1f),
                green = (baseColor.green * shade).coerceIn(0f, 1f),
                blue = (baseColor.blue * shade).coerceIn(0f, 1f),
                alpha = alpha
            )
        )
        drawPath(path = path, color = strokeColor, style = Stroke(width = 2.0f, join = StrokeJoin.Round))
    }
    return pts
}

fun DrawScope.draw3DCylinder(
    centerXY: Offset,
    zBottom: Float,
    zTop: Float,
    radius: Float,
    centerRef: Vec3D,
    canvasCenter: Offset,
    scalePx: Float,
    yawDeg: Float,
    pitchDeg: Float,
    baseColor: Color,
    strokeColor: Color = CadColors.ConcreteStroke,
    segments: Int = 20
): Pair<List<Offset>, List<Offset>> {
    val botPts = mutableListOf<Offset>()
    val topPts = mutableListOf<Offset>()
    for (i in 0 until segments) {
        val a = 2.0 * PI * i / segments
        val x = centerXY.x + (radius * cos(a)).toFloat()
        val y = centerXY.y + (radius * sin(a)).toFloat()
        botPts += project3DPoint(Vec3D(x, y, zBottom), centerRef, canvasCenter, scalePx, yawDeg, pitchDeg).first
        topPts += project3DPoint(Vec3D(x, y, zTop), centerRef, canvasCenter, scalePx, yawDeg, pitchDeg).first
    }
    // Side body quad strips
    for (i in 0 until segments) {
        val next = (i + 1) % segments
        val sidePath = Path().apply {
            moveTo(botPts[i].x, botPts[i].y)
            lineTo(botPts[next].x, botPts[next].y)
            lineTo(topPts[next].x, topPts[next].y)
            lineTo(topPts[i].x, topPts[i].y)
            close()
        }
        val shade = 0.78f + 0.14f * sin((i.toFloat() / segments) * PI.toFloat())
        drawPath(
            sidePath,
            Color(baseColor.red * shade, baseColor.green * shade, baseColor.blue * shade, 0.88f)
        )
    }
    // Top cap
    val topPath = Path().apply {
        moveTo(topPts[0].x, topPts[0].y)
        for (i in 1 until segments) lineTo(topPts[i].x, topPts[i].y)
        close()
    }
    drawPath(topPath, baseColor.copy(alpha = 0.94f))
    drawPath(topPath, strokeColor, style = Stroke(2f))
    val botPath = Path().apply {
        moveTo(botPts[0].x, botPts[0].y)
        for (i in 1 until segments) lineTo(botPts[i].x, botPts[i].y)
        close()
    }
    drawPath(botPath, strokeColor.copy(alpha = 0.75f), style = Stroke(1.8f))
    return botPts to topPts
}

fun DrawScope.drawDashedLine(p1: Offset, p2: Offset, color: Color, width: Float = 2f) {
    drawLine(
        color = color,
        start = p1,
        end = p2,
        strokeWidth = width,
        cap = StrokeCap.Round,
        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 7f))
    )
}

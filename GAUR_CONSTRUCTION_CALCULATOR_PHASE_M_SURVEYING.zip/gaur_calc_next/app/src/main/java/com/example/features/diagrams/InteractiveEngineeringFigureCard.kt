package com.example.features.diagrams

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.EngineeringCard
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette

@Composable
fun InteractiveEngineeringFigureCard(
    snapshot: DiagramInputSnapshot,
    modifier: Modifier = Modifier
) {
    val palette = LocalEngineeringPalette.current
    val availableModes = remember(snapshot.toolId) { availableViewsForTool(snapshot.toolId) }
    var selectedMode by remember(snapshot.toolId) { mutableStateOf(availableModes.first()) }
    var zoom by remember(snapshot.toolId) { mutableFloatStateOf(1f) }
    var panX by remember(snapshot.toolId) { mutableFloatStateOf(0f) }
    var panY by remember(snapshot.toolId) { mutableFloatStateOf(0f) }
    var yawDeg by remember(snapshot.toolId) { mutableFloatStateOf(38f) }
    var pitchDeg by remember(snapshot.toolId) { mutableFloatStateOf(26f) }

    fun fitToScreen() {
        zoom = 1f
        panX = 0f
        panY = 0f
    }

    fun resetView() {
        zoom = 1f
        panX = 0f
        panY = 0f
        yawDeg = 38f
        pitchDeg = 26f
    }

    EngineeringCard(
        accentColor = palette.skyBlue,
        modifier = modifier.testTag("engineering_figure_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.skyGlassTint)
                        .border(1.dp, palette.skyGlassBorder, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Straighten,
                        contentDescription = null,
                        tint = palette.skyBlue,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Construction Diagram & Dimensions",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = palette.inkPrimary
                    )
                    Text(
                        text = "Live dimension figure • Zoom ${(zoom * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.inkMuted
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // View Mode Selector Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(availableModes) { mode ->
                FilterChip(
                    selected = selectedMode == mode,
                    onClick = {
                        selectedMode = mode
                        fitToScreen()
                    },
                    label = { Text(mode.label, style = MaterialTheme.typography.labelMedium) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = palette.skyGlassTint,
                        selectedLabelColor = palette.skyBlue
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (selectedMode == mode) palette.skyBlue else palette.metallicBorder
                    ),
                    modifier = Modifier.testTag("figure_mode_${mode.name.lowercase()}")
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        // Zoom, Fit & Reset Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(palette.concreteSurfaceAlt)
                .border(1.dp, palette.metallicBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassBluePill(
                text = diagramCaptionForTool(snapshot),
                modifier = Modifier.weight(1f, fill = false)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { zoom = (zoom * 1.22f).coerceAtMost(2.8f) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("figure_zoom_in")
                ) {
                    Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom In", tint = palette.skyBlue)
                }
                IconButton(
                    onClick = { zoom = (zoom / 1.22f).coerceAtLeast(0.6f) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("figure_zoom_out")
                ) {
                    Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom Out", tint = palette.skyBlue)
                }
                IconButton(
                    onClick = { fitToScreen() },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("figure_fit")
                ) {
                    Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "Fit to Screen", tint = palette.inkPrimary)
                }
                IconButton(
                    onClick = { resetView() },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("figure_reset")
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Reset View", tint = palette.orangeDark)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        // Interactive CAD Drawing Canvas
        Surface(
            color = Color(0xFFFAFBFD),
            border = BorderStroke(1.5.dp, palette.skyGlassBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clipToBounds()
                    .testTag("figure_canvas")
                    .pointerInput(selectedMode) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            if (selectedMode == DiagramViewMode.VIEW_3D) {
                                yawDeg = (yawDeg + dragAmount.x * 0.45f) % 360f
                                pitchDeg = (pitchDeg + dragAmount.y * 0.35f).coerceIn(8f, 80f)
                            } else {
                                panX = (panX + dragAmount.x).coerceIn(-320f, 320f)
                                panY = (panY + dragAmount.y).coerceIn(-240f, 240f)
                            }
                        }
                    }
            ) {
                drawEngineeringGrid(spacingPx = 32f)
                withTransform({
                    translate(left = panX, top = panY)
                    scale(scaleX = zoom, scaleY = zoom, pivot = Offset(size.width / 2f, size.height / 2f))
                }) {
                    val handled = drawStructuralOrConcreteDiagram(snapshot, selectedMode, yawDeg, pitchDeg) ||
                        drawMasonrySteelOrSiteDiagram(snapshot, selectedMode, yawDeg, pitchDeg) ||
                        drawExpandedGeometryOrUtilityDiagram(snapshot, selectedMode, yawDeg, pitchDeg) ||
                        drawPhaseCEngineeringDiagram(snapshot, selectedMode)
                    if (!handled) {
                        drawPhaseCEngineeringDiagram(snapshot, selectedMode)
                    }
                }
            }
        }
    }
}

package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.ceil

object PhaseCConcreteCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        pourPlanningCalculator(),
        curingWaterCalculator(),
        buildingConcreteCalculator(),
        constructionJointCalculator(),
        cubeStrengthTestCalculator(),
        freshConcreteYieldCalculator(),
        groutMicroConcreteCalculator(),
        screedingSlopeCalculator(),
        shutteringFormworkCalculator(),
        admixtureFiberCalculator()
    )

    private fun pourPlanningCalculator() = CalcToolSpec(
        id = "conc_pour_planning",
        title = "Concrete Pour Planning & Transit Mixers",
        titleHi = "कंक्रीट पोर प्लानिंग और मिक्सर चक्र",
        subtitle = "Pour Duration, Pump Rate, Mixer Interval & Vibrators Needed",
        category = CalcCategory.CONCRETE,
        keywords = listOf("pour", "planning", "pump", "transit mixer", "cycle", "vibrator", "concrete"),
        fields = listOf(
            CalcFieldSpec("vol", "Total Pour Volume (m³)", "48.0", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("pumpRate", "Pump / Crew Rate (m³/hr)", "12.0", FieldUnitKind.NONE),
            CalcFieldSpec("tmCap", "Transit Mixer Capacity (m³)", "6.0", FieldUnitKind.NONE),
            CalcFieldSpec("roundTripMin", "Plant Round-Trip Time (min)", "75", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val vol = ctx.doubleOrNull("vol") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter pour volume."))
            val rate = ctx.doubleOrNull("pumpRate") ?: 12.0
            val cap = ctx.doubleOrNull("tmCap") ?: 6.0
            val rt = ctx.doubleOrNull("roundTripMin") ?: 75.0
            if (vol <= 0 || rate <= 0 || cap <= 0 || rt <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All values must be positive."))
            }
            val hrs = vol / rate
            val loads = ceil(vol / cap).toInt()
            val dispatchIntervalMin = (cap / rate) * 60.0
            val cycleTrucks = ceil(rt / dispatchIntervalMin).toInt().coerceAtLeast(1)
            val vibrators = ceil(rate / 10.0).toInt().coerceAtLeast(1) + 1 // +1 standby

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Estimated Pour Duration", UnitConverter.fmt(hrs, p), "hours", isPrimary = true),
                        CalcResultItem("Transit Mixer Loads", "$loads", "trips (${UnitConverter.fmt(cap, 1)} m³)", isPrimary = true),
                        CalcResultItem("Active Mixers Needed in Loop", "$cycleTrucks", "trucks"),
                        CalcResultItem("Dispatch Interval", UnitConverter.fmt(dispatchIntervalMin, 1), "min"),
                        CalcResultItem("Needle Vibrators (+1 Standby)", "$vibrators", "nos")
                    ),
                    formula = "Hrs = Vol / Rate; Dispatch = (TM Cap / Rate)×60; Mixers = ceil(RoundTrip / Dispatch)",
                    steps = listOf(
                        "Duration = ${UnitConverter.fmt(vol, p)} / ${UnitConverter.fmt(rate, 1)} = ${UnitConverter.fmt(hrs, p)} hrs",
                        "Dispatch interval = ${UnitConverter.fmt(dispatchIntervalMin, 1)} min; Trucks = ceil($rt / ${UnitConverter.fmt(dispatchIntervalMin, 1)}) = $cycleTrucks"
                    ),
                    assumptions = "Includes 1 standby needle vibrator per IS 456 continuous placement practice."
                )
            )
        }
    )

    private fun curingWaterCalculator() = CalcToolSpec(
        id = "conc_curing_water",
        title = "Concrete Curing Water & Duration",
        titleHi = "कंक्रीट क्योरिंग पानी और समय अनुमान",
        subtitle = "IS 456 Minimum Curing Days, Daily Liters & Tanker Loads",
        category = CalcCategory.CONCRETE,
        keywords = listOf("curing", "water", "ponding", "hessian", "is 456", "days"),
        fields = listOf(
            CalcFieldSpec("area", "Exposed Concrete Surface Area (m²)", "120.0", FieldUnitKind.AREA_SQ_M),
            CalcFieldSpec("days", "Curing Duration (Days)", "10", FieldUnitKind.COUNT),
            CalcFieldSpec("method", "Curing Method", "Ponding (Slab)", options = listOf("Ponding (Slab)", "Wet Hessian / Gunny", "Periodic Sprinkling")),
            CalcFieldSpec("tankerL", "Water Tanker Capacity (Liters)", "5000", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter surface area."))
            val days = ctx.doubleOrNull("days") ?: 10.0
            val tankerL = ctx.doubleOrNull("tankerL") ?: 5000.0
            if (area <= 0 || days <= 0 || tankerL <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be positive."))
            }
            val lPerM2PerDay = when (ctx.raw("method")) {
                "Ponding (Slab)" -> 6.5
                "Wet Hessian / Gunny" -> 4.5
                else -> 5.5
            }
            val dailyL = area * lPerM2PerDay
            val totalL = dailyL * days
            val tankers = totalL / tankerL

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Curing Water Required", UnitConverter.fmt(totalL, 0), "Liters", isPrimary = true),
                        CalcResultItem("Daily Water Requirement", UnitConverter.fmt(dailyL, 0), "L/day", isPrimary = true),
                        CalcResultItem("Water Tankers Needed", UnitConverter.fmt(tankers, p), "tankers"),
                        CalcResultItem("IS 456 Min. Curing (OPC/PPC)", "7 / 10", "days")
                    ),
                    formula = "Total Water = Surface Area × Evaporation Allowance (L/m²/day) × Days",
                    steps = listOf("Rate = $lPerM2PerDay L/m²/day × ${UnitConverter.fmt(area, p)} m² × ${days.toInt()} days = ${UnitConverter.fmt(totalL, 0)} L"),
                    assumptions = "IS 456 Clause 13.5: min 7 days for OPC, 10 days for PPC/PSC/mineral admixtures, 14 days in hot dry weather."
                )
            )
        }
    )

    private fun buildingConcreteCalculator() = CalcToolSpec(
        id = "conc_floor_building",
        title = "Floor & Building Concrete Estimator",
        titleHi = "मंजिल और पूरे भवन कंक्रीट अनुमान",
        subtitle = "Preliminary RCC Concrete, Cement Bags & Steel per Floor",
        category = CalcCategory.CONCRETE,
        isPreliminaryStructural = true,
        keywords = listOf("building", "floor", "rcc", "cement", "steel", "multi-storey", "concrete"),
        fields = listOf(
            CalcFieldSpec("floorArea", "Built-Up Area per Floor (sq.ft)", "1200", FieldUnitKind.NONE),
            CalcFieldSpec("floors", "Number of Floors (incl. Ground)", "3", FieldUnitKind.COUNT),
            CalcFieldSpec("bldgType", "Structure Framing", "Residential G+1 to G+4", options = listOf("Residential G+1 to G+4", "Commercial / Mid-Rise", "Heavy Industrial Frame"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val areaSqFt = ctx.doubleOrNull("floorArea") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter floor area."))
            val floors = ctx.doubleOrNull("floors") ?: 1.0
            if (areaSqFt <= 0 || floors <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Area and floors must be positive."))
            }
            val factorM3PerSqFt = when (ctx.raw("bldgType")) {
                "Commercial / Mid-Rise" -> 0.044
                "Heavy Industrial Frame" -> 0.052
                else -> 0.038
            }
            val steelKgPerM3 = when (ctx.raw("bldgType")) {
                "Commercial / Mid-Rise" -> 125.0
                "Heavy Industrial Frame" -> 140.0
                else -> 105.0
            }
            val perFloorVol = areaSqFt * factorM3PerSqFt
            val totalVol = perFloorVol * floors
            val cementBags = totalVol * 8.2 // M20-M25 blended ~8.2 bags/m³
            val steelMt = (totalVol * steelKgPerM3) / 1000.0

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Building Concrete", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Concrete per Floor", UnitConverter.fmt(perFloorVol, p), "m³/floor", isPrimary = true),
                        CalcResultItem("Est. Cement Bags (M20/M25)", UnitConverter.fmt(cementBags, 0), "bags"),
                        CalcResultItem("Prelim. Reinforcement Steel", UnitConverter.fmt(steelMt, p), "MT")
                    ),
                    formula = "Floor Concrete = Area(sq.ft) × RCC Thumb Factor; Total = Floor × N",
                    steps = listOf("Factor = $factorM3PerSqFt m³/sq.ft × ${UnitConverter.fmt(areaSqFt, 0)} = ${UnitConverter.fmt(perFloorVol, p)} m³/floor"),
                    assumptions = "Preliminary budgeting thumb rules only; actual quantities must be taken from approved structural drawings."
                )
            )
        }
    )

    private fun constructionJointCalculator() = CalcToolSpec(
        id = "conc_construction_joint",
        title = "Construction Joint, Waterstop & Dowels",
        titleHi = "कंस्ट्रक्शन जॉइंट, वाटरस्टॉप और डॉवेल बार",
        subtitle = "PVC Waterstop Roll, Bonding Epoxy & Dowel Bar Estimator",
        category = CalcCategory.CONCRETE,
        keywords = listOf("joint", "construction joint", "waterstop", "dowel", "expansion", "epoxy"),
        fields = listOf(
            CalcFieldSpec("jointLen", "Total Joint Length", "30.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("memberT", "Slab / Wall Thickness (mm)", "250", FieldUnitKind.NONE),
            CalcFieldSpec("dowelDia", "Dowel Bar Dia (mm)", "16", FieldUnitKind.NONE),
            CalcFieldSpec("dowelLen", "Dowel Bar Length (mm)", "600", FieldUnitKind.NONE),
            CalcFieldSpec("dowelSpace", "Dowel Spacing (mm c/c)", "300", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val jl = ctx.lengthMeters("jointLen") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter joint length."))
            val tMm = ctx.doubleOrNull("memberT") ?: 250.0
            val dia = ctx.doubleOrNull("dowelDia") ?: 16.0
            val dLen = ctx.doubleOrNull("dowelLen") ?: 600.0
            val dSp = ctx.doubleOrNull("dowelSpace") ?: 300.0
            if (jl <= 0 || tMm <= 0 || dia <= 0 || dLen <= 0 || dSp <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val waterstopM = jl * 1.05
            val epoxyAreaM2 = jl * (tMm / 1000.0)
            val epoxyKg = epoxyAreaM2 * 0.65
            val dowels = ceil((jl * 1000.0) / dSp).toInt() + 1
            val dowelWtKg = dowels * (dLen / 1000.0) * (dia * dia / 162.2)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("PVC Waterstop (+5% Lap)", UnitConverter.fmt(waterstopM, p), "m", isPrimary = true),
                        CalcResultItem("Dowel Bars Required", "$dowels", "nos (${UnitConverter.fmt(dowelWtKg, p)} kg)", isPrimary = true),
                        CalcResultItem("Joint Interface Area", UnitConverter.fmt(epoxyAreaM2, p), "m²"),
                        CalcResultItem("Bonding Agent / Polysulfide", UnitConverter.fmt(epoxyKg, p), "kg")
                    ),
                    formula = "Waterstop = 1.05×L; Dowels = ceil(L/Spacing)+1; Epoxy ≈ Area × 0.65 kg/m²",
                    steps = listOf("Joint area = ${UnitConverter.fmt(jl, p)} × ${UnitConverter.fmt(tMm / 1000.0, 3)} = ${UnitConverter.fmt(epoxyAreaM2, p)} m²"),
                    assumptions = "Includes 5% overlap allowance for PVC waterstop thermal welding."
                )
            )
        }
    )

    private fun cubeStrengthTestCalculator() = CalcToolSpec(
        id = "conc_cube_strength",
        title = "Concrete Cube Test (IS 516 / IS 456)",
        titleHi = "कंक्रीट क्यूब टेस्ट (IS 516) स्ट्रेंथ जांच",
        subtitle = "3-Cube Load (kN) to MPa, Mean Strength & Individual Limits",
        category = CalcCategory.CONCRETE,
        keywords = listOf("cube", "test", "is 516", "is 456", "mpa", "compressive strength", "qc"),
        fields = listOf(
            CalcFieldSpec("grade", "Target Grade (fck)", "M25 (25 MPa)", options = listOf("M15 (15 MPa)", "M20 (20 MPa)", "M25 (25 MPa)", "M30 (30 MPa)", "M35 (35 MPa)", "M40 (40 MPa)")),
            CalcFieldSpec("cubeSize", "Cube Mold Size", "150 mm", options = listOf("150 mm", "100 mm")),
            CalcFieldSpec("load1", "Cube 1 Failure Load (kN)", "610", FieldUnitKind.NONE),
            CalcFieldSpec("load2", "Cube 2 Failure Load (kN)", "635", FieldUnitKind.NONE),
            CalcFieldSpec("load3", "Cube 3 Failure Load (kN)", "595", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val fck = ctx.raw("grade").substringAfter("M").substringBefore(" ").toDoubleOrNull() ?: 25.0
            val sideMm = if (ctx.raw("cubeSize").startsWith("100")) 100.0 else 150.0
            val areaMm2 = sideMm * sideMm
            val l1 = ctx.doubleOrNull("load1") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Cube 1 load."))
            val l2 = ctx.doubleOrNull("load2") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Cube 2 load."))
            val l3 = ctx.doubleOrNull("load3") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Cube 3 load."))
            if (l1 <= 0 || l2 <= 0 || l3 <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Failure loads must be positive."))
            }
            val s1 = (l1 * 1000.0) / areaMm2
            val s2 = (l2 * 1000.0) / areaMm2
            val s3 = (l3 * 1000.0) / areaMm2
            val avg = (s1 + s2 + s3) / 3.0
            val spreadOk = listOf(s1, s2, s3).all { kotlin.math.abs(it - avg) <= 0.15 * avg }
            val minIndOk = listOf(s1, s2, s3).all { it >= fck - 3.0 }
            val meanPass = avg >= fck + 3.0
            val status = when {
                !spreadOk -> "RETEST (Spread > ±15% of mean)"
                meanPass && minIndOk -> "PASS (28-day IS 456 Table 11)"
                else -> "BELOW TARGET fck+3 MPa"
            }
            val warnings = mutableListOf<String>()
            if (!spreadOk) warnings += "IS 516: Individual cube varies by more than ±15% from average; sample batch invalid."
            if (!minIndOk) warnings += "IS 456: Individual cube strength below fck - 3 MPa."

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Average Cube Strength", UnitConverter.fmt(avg, p), "MPa (N/mm²)", isPrimary = true),
                        CalcResultItem("IS 456 Acceptance Status", status, "", isPrimary = true),
                        CalcResultItem("Individual Cubes (1 / 2 / 3)", "${UnitConverter.fmt(s1, 1)} / ${UnitConverter.fmt(s2, 1)} / ${UnitConverter.fmt(s3, 1)}", "MPa"),
                        CalcResultItem("Required Mean (fck + 3)", UnitConverter.fmt(fck + 3.0, 1), "MPa")
                    ),
                    formula = "Stress (MPa) = (Load_kN × 1000) / Area_mm²; IS 456 28-day Mean ≥ fck + 3 MPa",
                    steps = listOf("Cube Area = ${sideMm.toInt()}×${sideMm.toInt()} = ${areaMm2.toInt()} mm²; Avg = ${UnitConverter.fmt(avg, 2)} MPa"),
                    assumptions = "Compares 28-day crushed strengths against IS 456 Table 11 acceptance criteria.",
                    warnings = warnings
                )
            )
        }
    )

    private fun freshConcreteYieldCalculator() = CalcToolSpec(
        id = "conc_slump_yield",
        title = "Concrete Yield & Wet Density Check",
        titleHi = "ताजा कंक्रीट यील्ड और घनत्व जांच",
        subtitle = "Verify Batcher Yield (ASTM C138 / IS 1199) vs Target Volume",
        category = CalcCategory.CONCRETE,
        keywords = listOf("yield", "density", "rmc", "batch", "slump", "is 1199", "qc"),
        fields = listOf(
            CalcFieldSpec("batchWtKg", "Total Batch Material Weight (kg)", "2410", FieldUnitKind.NONE),
            CalcFieldSpec("targetVol", "Ordered / Target Batch Vol (m³)", "1.0", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("potWtKg", "Sample Concrete Weight in Bucket (kg)", "16.8", FieldUnitKind.NONE),
            CalcFieldSpec("potVolL", "Measuring Bucket Volume (Liters)", "7.0", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val batchWt = ctx.doubleOrNull("batchWtKg") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter batch weight."))
            val targetVol = ctx.doubleOrNull("targetVol") ?: 1.0
            val potWt = ctx.doubleOrNull("potWtKg") ?: 16.8
            val potL = ctx.doubleOrNull("potVolL") ?: 7.0
            if (batchWt <= 0 || targetVol <= 0 || potWt <= 0 || potL <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All values must be positive."))
            }
            val wetDensity = (potWt / (potL / 1000.0)) // kg/m³
            val actualYield = batchWt / wetDensity
            val relYield = (actualYield / targetVol) * 100.0
            val warnings = if (relYield < 98.0 || relYield > 102.0) {
                listOf("Relative yield outside 98%–102% tolerance; inspect batch scale or air content.")
            } else emptyList()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Measured Wet Density", UnitConverter.fmt(wetDensity, 1), "kg/m³", isPrimary = true),
                        CalcResultItem("Actual Batch Yield", UnitConverter.fmt(actualYield, 3), "m³", isPrimary = true),
                        CalcResultItem("Relative Yield (%)", UnitConverter.fmt(relYield, p), "%"),
                        CalcResultItem("Short / Excess Volume", UnitConverter.fmt(actualYield - targetVol, 3), "m³")
                    ),
                    formula = "Wet Density = Sample kg / (Bucket L / 1000); Yield = Batch Weight / Wet Density",
                    steps = listOf("Density = $potWt / ${potL / 1000.0} = ${UnitConverter.fmt(wetDensity, 1)} kg/m³; Yield = ${UnitConverter.fmt(actualYield, 3)} m³"),
                    assumptions = "Net concrete mass in calibrated unit-weight container (excluding tare weight).",
                    warnings = warnings
                )
            )
        }
    )

    private fun groutMicroConcreteCalculator() = CalcToolSpec(
        id = "conc_grout_micro",
        title = "Non-Shrink Grout & Micro-Concrete",
        titleHi = "नॉन-श्रिंक ग्राउट और माइक्रो-कंक्रीट",
        subtitle = "Baseplate Grout & Column Jacketing Bag Yield Estimator",
        category = CalcCategory.CONCRETE,
        keywords = listOf("grout", "non-shrink", "micro-concrete", "jacketing", "baseplate", "gp2"),
        fields = listOf(
            CalcFieldSpec("l", "Pocket / Patch Length", "0.8", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Pocket / Patch Width", "0.8", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("t", "Grout Thickness (mm)", "50", FieldUnitKind.NONE),
            CalcFieldSpec("count", "Number of Pockets / Plates", "12", FieldUnitKind.COUNT),
            CalcFieldSpec("bagYieldL", "Yield per 25 kg Bag (Liters)", "13.2", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val tMm = ctx.doubleOrNull("t") ?: 50.0
            val count = ctx.doubleOrNull("count") ?: 1.0
            val yieldL = ctx.doubleOrNull("bagYieldL") ?: 13.2
            if (l <= 0 || w <= 0 || tMm <= 0 || count <= 0 || yieldL <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val liters = l * w * (tMm / 1000.0) * count * 1000.0 * 1.05 // 5% spillage
            val bags = ceil(liters / yieldL).toInt()
            val mixingWaterL = bags * 4.2

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("25 kg Grout Bags (+5% Wastage)", "$bags", "bags (${bags * 25} kg)", isPrimary = true),
                        CalcResultItem("Total Grout Volume", UnitConverter.fmt(liters, 1), "Liters", isPrimary = true),
                        CalcResultItem("Approx. Mixing Water (~4.2L/bag)", UnitConverter.fmt(mixingWaterL, 1), "Liters")
                    ),
                    formula = "Liters = L × W × (t/1000) × Count × 1000 × 1.05; Bags = ceil(Liters / BagYield)",
                    steps = listOf("Vol = ${UnitConverter.fmt(liters, 1)} L → ceil(${UnitConverter.fmt(liters, 1)} / $yieldL) = $bags bags"),
                    assumptions = "Typical free-flow GP2 grout yield ~13.2 L per 25 kg bag; verify manufacturer TDS."
                )
            )
        }
    )

    private fun screedingSlopeCalculator() = CalcToolSpec(
        id = "conc_screeding",
        title = "Floor & Terrace Screed (IPS / Slope)",
        titleHi = "छत और फर्श स्क्रीड (ढलान मसाला) अनुमान",
        subtitle = "Cement, Coarse Sand & Integral Waterproofing for Slope Screed",
        category = CalcCategory.CONCRETE,
        keywords = listOf("screed", "ips", "terrace", "slope", "brickbat", "cement", "sand"),
        fields = listOf(
            CalcFieldSpec("area", "Terrace / Floor Area (m²)", "100.0", FieldUnitKind.AREA_SQ_M),
            CalcFieldSpec("minT", "Minimum Thickness at Drain (mm)", "35", FieldUnitKind.NONE),
            CalcFieldSpec("maxT", "Maximum Thickness at Ridge (mm)", "85", FieldUnitKind.NONE),
            CalcFieldSpec("mix", "Screed Mix Ratio", "1:4 (Cement:Sand)", options = listOf("1:3 (Cement:Sand)", "1:4 (Cement:Sand)", "1:5 (Cement:Sand)", "1:2:4 (PCC Screed)"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter area."))
            val minT = ctx.doubleOrNull("minT") ?: 35.0
            val maxT = ctx.doubleOrNull("maxT") ?: 85.0
            if (area <= 0 || minT <= 0 || maxT < minT) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Verify positive area and thickness."))
            }
            val avgT = (minT + maxT) / 2.0
            val wetVol = area * (avgT / 1000.0)
            val dryFactor = if (ctx.raw("mix").startsWith("1:2:4")) 1.54 else 1.33
            val dryVol = wetVol * dryFactor
            val partsSum = when {
                ctx.raw("mix").startsWith("1:3") -> 4.0
                ctx.raw("mix").startsWith("1:5") -> 6.0
                ctx.raw("mix").startsWith("1:2:4") -> 7.0
                else -> 5.0
            }
            val cementBags = (dryVol / partsSum) / 0.0347
            val sandRatio = if (ctx.raw("mix").startsWith("1:2:4")) 2.0 else (partsSum - 1.0)
            val sandM3 = (dryVol / partsSum) * sandRatio
            val waterProofL = cementBags * 0.2 // 200 ml per bag

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Cement Bags (50 kg)", UnitConverter.fmt(cementBags, 1), "bags", isPrimary = true),
                        CalcResultItem("Coarse Sand Quantity", UnitConverter.fmt(sandM3, p), "m³ (${UnitConverter.fmt(sandM3 * 35.3147, 0)} cft)", isPrimary = true),
                        CalcResultItem("Avg. Screed Thickness & Vol", "${UnitConverter.fmt(avgT, 1)} mm • ${UnitConverter.fmt(wetVol, p)} m³", ""),
                        CalcResultItem("Liquid Waterproofing (200ml/bag)", UnitConverter.fmt(waterProofL, 1), "Liters")
                    ),
                    formula = "Avg t = (t_min + t_max)/2; Wet Vol = Area × Avg t; Dry Vol = Wet × $dryFactor",
                    steps = listOf("Avg thickness = $avgT mm → Wet Vol = ${UnitConverter.fmt(wetVol, p)} m³"),
                    assumptions = "Uses 1.33 dry factor for mortar screed and 1.54 for 1:2:4 PCC screed."
                )
            )
        }
    )

    private fun shutteringFormworkCalculator() = CalcToolSpec(
        id = "conc_shuttering_area",
        title = "Shuttering, Ply Sheets & Props",
        titleHi = "शटरिंग क्षेत्रफल, प्लाई बोर्ड और प्रॉप्स",
        subtitle = "Formwork Area, 8×4 ft Plywood Sheets, Battens & Jack Props",
        category = CalcCategory.CONCRETE,
        keywords = listOf("shuttering", "formwork", "plywood", "props", "jacks", "centering"),
        fields = listOf(
            CalcFieldSpec("member", "Member Type", "RCC Slab Centering", options = listOf("RCC Slab Centering", "Rectangular Columns", "Beams (3-Side)", "Retaining / Lift Wall")),
            CalcFieldSpec("l", "Length / Span", "10.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Width / Depth", "6.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Height / Drop (if Col/Beam/Wall)", "0.45", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("count", "Quantity (Nos)", "1", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val h = ctx.lengthMeters("h") ?: 0.45
            val count = ctx.doubleOrNull("count") ?: 1.0
            if (l <= 0 || w <= 0 || h <= 0 || count <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            }
            val areaM2 = when (ctx.raw("member")) {
                "Rectangular Columns" -> 2.0 * (l + w) * h * count
                "Beams (3-Side)" -> (w + 2.0 * h) * l * count
                "Retaining / Lift Wall" -> 2.0 * l * h * count
                else -> l * w * count
            }
            val areaSqFt = areaM2 * 10.7639
            val plySheets = ceil((areaSqFt * 1.08) / 32.0).toInt() // 8x4 = 32 sq.ft + 8% cut
            val props = if (ctx.raw("member") == "RCC Slab Centering") ceil(areaM2 / 1.2).toInt() else ceil(l * count / 0.9).toInt() * 2

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Shuttering Area", UnitConverter.fmt(areaM2, p), "m² (${UnitConverter.fmt(areaSqFt, 0)} sq.ft)", isPrimary = true),
                        CalcResultItem("12mm Ply Sheets (8×4 ft, +8%)", "$plySheets", "sheets", isPrimary = true),
                        CalcResultItem("Telescopic Props / Ties", "$props", "nos")
                    ),
                    formula = "Slab=L×W; Beam=(B+2D)×L; Col=2(B+D)×H; Ply = ceil(AreaSqFt×1.08 / 32)",
                    steps = listOf("Shuttering Area = ${UnitConverter.fmt(areaM2, p)} m² (${UnitConverter.fmt(areaSqFt, 0)} sq.ft)"),
                    assumptions = "Single-use ply coverage (before reuse cycles); 1 prop per ~1.2 m² slab centering."
                )
            )
        }
    )

    private fun admixtureFiberCalculator() = CalcToolSpec(
        id = "conc_admixture_dosage",
        title = "Admixture, Plasticizer & Poly-Fiber",
        titleHi = "एडमिक्सचर, सुपर-प्लास्टिसाइज़र और फाइबर",
        subtitle = "Superplasticizer Liters & Polypropylene Fiber Dosage Estimator",
        category = CalcCategory.CONCRETE,
        keywords = listOf("admixture", "superplasticizer", "pce", "fiber", "recron", "chemical"),
        fields = listOf(
            CalcFieldSpec("concVol", "Concrete Volume (m³)", "25.0", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("cementKgM3", "Cement Content (kg/m³)", "360", FieldUnitKind.NONE),
            CalcFieldSpec("dosagePct", "Plasticizer Dosage (% by Cement Wt)", "0.8", FieldUnitKind.PERCENT),
            CalcFieldSpec("fiberKgM3", "Poly-Fiber Dosage (kg/m³)", "0.9", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val vol = ctx.doubleOrNull("concVol") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter concrete volume."))
            val cem = ctx.doubleOrNull("cementKgM3") ?: 360.0
            val dos = ctx.doubleOrNull("dosagePct") ?: 0.8
            val fib = (ctx.doubleOrNull("fiberKgM3") ?: 0.9).coerceAtLeast(0.0)
            if (vol <= 0 || cem <= 0 || dos < 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid positive concrete and cement values."))
            }
            val totalCementKg = vol * cem
            val admixKg = totalCementKg * (dos / 100.0)
            val admixLiters = admixKg / 1.12 // typical SP sg ~1.12
            val fiberKg = vol * fib
            val drums20L = ceil(admixLiters / 20.0).toInt()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Liquid Admixture Quantity", UnitConverter.fmt(admixLiters, p), "Liters (${UnitConverter.fmt(admixKg, 1)} kg)", isPrimary = true),
                        CalcResultItem("20L Containers / Jerry Cans", "$drums20L", "cans", isPrimary = true),
                        CalcResultItem("PP Micro-Fiber Needed", UnitConverter.fmt(fiberKg, p), "kg (${ceil(fiberKg / 0.9).toInt()}×900g packs)"),
                        CalcResultItem("Total Cement Weight", UnitConverter.fmt(totalCementKg, 0), "kg")
                    ),
                    formula = "Admix kg = (Vol × Cement kg/m³) × (Dosage%/100); Liters = kg / 1.12",
                    steps = listOf("Cement = ${UnitConverter.fmt(totalCementKg, 0)} kg × $dos% = ${UnitConverter.fmt(admixKg, 1)} kg"),
                    assumptions = "Assumes admixture specific gravity ~1.12; verify dosage range per IS 9103 & supplier TDS."
                )
            )
        }
    )
}

package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.pow
import kotlin.math.sqrt

/** Phase K: additional plumbing, water supply, drainage and pump estimators. */
object PhaseKPlumbingWaterCalculators {
    private fun dim(k:String,l:String,v:String)=CalcFieldSpec(k,l,v,FieldUnitKind.LENGTH,LengthUnit.M)
    private fun num(k:String,l:String,v:String)=CalcFieldSpec(k,l,v,FieldUnitKind.NONE)
    private fun pct(k:String,l:String,v:String)=CalcFieldSpec(k,l,v,FieldUnitKind.PERCENT)
    private fun fmt(v:Double,p:Int)=UnitConverter.fmt(v,p)
    private fun tool(id:String,t:String,s:String,f:List<CalcFieldSpec>,keys:List<String>,fn:(CalcContext)->Result<CalcOutcome>) =
        CalcToolSpec(id,t,t,s,CalcCategory.UTILITIES,keys,fields=f,compute=fn)

    fun all():List<CalcToolSpec> = listOf(
        tool("phase_k_pipe_diameter_velocity","Pipe Diameter from Flow & Velocity","Estimate internal diameter for target water velocity",listOf(num("q","Design flow (L/s)","2.5"),num("v","Target velocity (m/s)","1.2"),pct("a","Diameter allowance (%)","0")),listOf("pipe sizing","diameter","flow","velocity")){c->
            val q=c.doubleOrNull("q")?:0.0; val v=c.doubleOrNull("v")?:0.0; val a=c.doubleOrNull("a")?:0.0; val p=c.settings.decimalPrecision
            if(q<=0||v<=0||a<0)return@tool Result.failure(IllegalArgumentException("Flow and velocity must be positive; allowance non-negative."))
            val d=sqrt(4*(q/1000)/ (PI*v))*1000*(1+a/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Required internal diameter",fmt(d,p),"mm",true),CalcResultItem("Flow",fmt(q,p),"L/s"),CalcResultItem("Target velocity",fmt(v,p),"m/s")),"D = √(4Q/πV)",listOf("Q converted from L/s to m³/s."),"Preliminary sizing only. Select actual commercial pipe internal diameter and recheck velocity, pressure class and code."))
        },
        tool("phase_k_hazen_williams_loss","Hazen–Williams Pipe Head Loss","Friction head loss in a full pressurised water pipe",listOf(dim("d","Internal diameter (m)","0.05"),dim("l","Pipe length (m)","100"),num("q","Flow (L/s)","2"),num("c","Hazen–Williams C","140")),listOf("hazen williams","head loss","friction loss")){c->
            val d=c.lengthMeters("d")?:0.0; val l=c.lengthMeters("l")?:0.0; val q=c.doubleOrNull("q")?:0.0; val hw=c.doubleOrNull("c")?:0.0; val p=c.settings.decimalPrecision
            if(d<=0||l<=0||q<=0||hw<=0)return@tool Result.failure(IllegalArgumentException("All inputs must be positive."))
            val hf=10.67*l*(q/1000).pow(1.852)/(hw.pow(1.852)*d.pow(4.8704)); val vel=4*(q/1000)/(PI*d*d)
            Result.success(CalcOutcome(listOf(CalcResultItem("Friction head loss",fmt(hf,p),"m",true),CalcResultItem("Velocity",fmt(vel,p),"m/s"),CalcResultItem("Loss per 100 m",fmt(hf/l*100,p),"m/100 m")),"hf=10.67 L Q^1.852/(C^1.852 d^4.8704)",listOf("Q in m³/s; d and L in metres."),"Hazen–Williams approximation; excludes fittings, elevation, transient effects and minor losses."))
        },
        tool("phase_k_pump_power","Water Pump Power & Energy","Hydraulic power, estimated input power and daily energy",listOf(num("q","Flow (L/s)","5"),dim("h","Total dynamic head (m)","25"),num("e","Overall efficiency (%)","65"),num("t","Daily running hours","6")),listOf("pump","motor power","energy","dynamic head")){c->
            val q=c.doubleOrNull("q")?:0.0; val h=c.lengthMeters("h")?:0.0; val e=c.doubleOrNull("e")?:0.0; val t=c.doubleOrNull("t")?:0.0; val p=c.settings.decimalPrecision
            if(q<=0||h<=0||e<=0||e>100||t<0)return@tool Result.failure(IllegalArgumentException("Flow/head positive, efficiency 0–100%, hours non-negative."))
            val ph=1000*9.81*(q/1000)*h/1000; val pin=ph/(e/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Hydraulic power",fmt(ph,p),"kW"),CalcResultItem("Estimated input power",fmt(pin,p),"kW",true),CalcResultItem("Daily energy",fmt(pin*t,p),"kWh/day")),"Ph=ρgQH; Pin=Ph/η",listOf("Water density 1000 kg/m³ assumed."),"Preliminary estimate only; verify pump curve, NPSH, system losses and motor selection."))
        },
        tool("phase_k_rectangular_tank","Rectangular Tank Capacity","Gross and usable storage capacity with freeboard",listOf(dim("l","Internal length (m)","4"),dim("w","Internal width (m)","3"),dim("h","Internal water depth (m)","2"),pct("f","Freeboard deduction (%)","10")),listOf("tank","sump","capacity","storage")){c->
            val l=c.lengthMeters("l")?:0.0; val w=c.lengthMeters("w")?:0.0; val h=c.lengthMeters("h")?:0.0; val f=c.doubleOrNull("f")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||w<=0||h<=0||f<0||f>=100)return@tool Result.failure(IllegalArgumentException("Dimensions positive; freeboard 0 to below 100%."))
            val gross=l*w*h; val use=gross*(1-f/100); val area=l*w+2*h*(l+w)
            Result.success(CalcOutcome(listOf(CalcResultItem("Gross capacity",fmt(gross,p),"m³"),CalcResultItem("Usable capacity",fmt(use,p),"m³",true),CalcResultItem("Usable water",fmt(use*1000,p),"litres"),CalcResultItem("Floor + wall area",fmt(area,p),"m²")),"Vusable=L×W×H×(1−freeboard%)",listOf("Freeboard deducted as percentage of entered water depth."),"Geometric estimate; excludes dead storage, baffles, slab thickness, leakage and structural design."))
        },
        tool("phase_k_cylindrical_tank","Cylindrical Tank Capacity","Vertical circular tank volume and litre capacity",listOf(dim("d","Internal diameter (m)","2.5"),dim("h","Usable water height (m)","2.2"),num("n","Number of tanks","1")),listOf("cylindrical tank","circular tank","water capacity")){c->
            val d=c.lengthMeters("d")?:0.0; val h=c.lengthMeters("h")?:0.0; val n=c.doubleOrNull("n")?:0.0; val p=c.settings.decimalPrecision
            if(d<=0||h<=0||n<=0||n%1.0!=0.0)return@tool Result.failure(IllegalArgumentException("Dimensions and whole tank count must be positive."))
            val v=PI*d*d/4*h*n
            Result.success(CalcOutcome(listOf(CalcResultItem("Total capacity",fmt(v*1000,p),"litres",true),CalcResultItem("Total volume",fmt(v,p),"m³")),"V=πD²H/4 × number of tanks",listOf("Internal diameter and usable water height used."),"Vertical cylindrical tank geometry; tank structural design is excluded."))
        },
        tool("phase_k_water_demand","Building Daily Water Demand","Estimate daily consumption and storage autonomy",listOf(num("n","Occupants","50"),num("r","Demand per person (L/day)","135"),num("d","Storage days","1"),pct("a","Reserve allowance (%)","10")),listOf("water demand","occupancy","daily consumption","storage")){c->
            val n=c.doubleOrNull("n")?:0.0; val r=c.doubleOrNull("r")?:0.0; val d=c.doubleOrNull("d")?:0.0; val a=c.doubleOrNull("a")?:0.0; val p=c.settings.decimalPrecision
            if(n<=0||n%1.0!=0.0||r<=0||d<=0||a<0)return@tool Result.failure(IllegalArgumentException("Occupants whole and positive; demand/days positive; reserve non-negative."))
            val daily=n*r; val store=daily*d*(1+a/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Daily demand",fmt(daily,p),"litres/day",true),CalcResultItem("Required storage",fmt(store,p),"litres"),CalcResultItem("Storage volume",fmt(store/1000,p),"m³")),"Daily=n×L/person/day; storage=daily×days×(1+reserve%)",listOf("Demand rate is user-entered."),"Planning estimate; apply occupancy type, local code, peak demand and fire reserve requirements."))
        },
        tool("phase_k_manning_drain","Circular Drain Pipe Capacity","Full-flow gravity discharge using Manning equation",listOf(dim("d","Internal diameter (m)","0.15"),num("s","Slope (m/m)","0.01"),num("n","Manning roughness","0.013")),listOf("drain","manning","gravity flow","sewer")){c->
            val d=c.lengthMeters("d")?:0.0; val s=c.doubleOrNull("s")?:0.0; val n=c.doubleOrNull("n")?:0.0; val p=c.settings.decimalPrecision
            if(d<=0||s<=0||n<=0)return@tool Result.failure(IllegalArgumentException("Diameter, slope and roughness must be positive."))
            val area=PI*d*d/4; val rh=d/4; val v=(1/n)*rh.pow(2.0/3.0)*sqrt(s); val q=area*v
            Result.success(CalcOutcome(listOf(CalcResultItem("Full-flow discharge",fmt(q*1000,p),"L/s",true),CalcResultItem("Velocity",fmt(v,p),"m/s"),CalcResultItem("Hydraulic radius",fmt(rh,p),"m")),"Q=(1/n) A R^(2/3) S^(1/2); full circular R=D/4",listOf("Steady uniform full flow assumed."),"Full-flow capacity only; sewer design also checks partial-depth flow, self-cleansing velocity and surcharge."))
        },
        tool("phase_k_roof_runoff_downpipes","Roof Runoff & Downpipe Count","Rational-method peak runoff and assumed downpipe count",listOf(CalcFieldSpec("a","Roof catchment area (m²)","250",FieldUnitKind.AREA_SQ_M),num("i","Rainfall intensity (mm/hour)","75"),num("c","Runoff coefficient","0.9"),num("cap","Assumed downpipe capacity (L/s)","2.5")),listOf("rainwater","roof runoff","downpipe","stormwater")){c->
            val a=c.doubleOrNull("a")?:0.0; val i=c.doubleOrNull("i")?:0.0; val cf=c.doubleOrNull("c")?:0.0; val cap=c.doubleOrNull("cap")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||i<=0||cf<=0||cf>1||cap<=0)return@tool Result.failure(IllegalArgumentException("Area/intensity/capacity positive; runoff coefficient >0 and ≤1."))
            val q=a*i*cf/3600; val count=ceil(q/cap).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Peak runoff",fmt(q,p),"L/s",true),CalcResultItem("Downpipes required",count.toString(),"nos")),"Q(L/s)=A×rainfall intensity×C/3600",listOf("Count=ceiling(runoff/assumed capacity)."),"Simplified rational method; verify local design storm, gutter capacity, blockage allowance and actual pipe capacity."))
        },
        tool("phase_k_pipe_internal_volume","Pipe Internal Volume & Flush Water","Water volume held within a pipe length",listOf(dim("d","Internal diameter (m)","0.05"),dim("l","Pipe length (m)","60"),pct("f","Fill percentage","100")),listOf("pipe volume","flush water","pipe capacity")){c->
            val d=c.lengthMeters("d")?:0.0; val l=c.lengthMeters("l")?:0.0; val f=c.doubleOrNull("f")?:0.0; val p=c.settings.decimalPrecision
            if(d<=0||l<=0||f<=0||f>100)return@tool Result.failure(IllegalArgumentException("Dimensions positive and fill must be >0 to 100%."))
            val v=PI*d*d/4*l*f/100
            Result.success(CalcOutcome(listOf(CalcResultItem("Water volume",fmt(v,p),"m³",true),CalcResultItem("Water quantity",fmt(v*1000,p),"litres")),"V=πD²/4 × L × fill%",listOf("Use actual internal diameter, not nominal size."),"Geometric content only; excludes flushing velocity and pressure-test requirements."))
        },
        tool("phase_k_water_hammer_screen","Water Hammer Pressure Rise Screening","Idealised Joukowsky pressure rise from rapid velocity change",listOf(num("a","Pressure wave speed (m/s)","1000"),num("v","Velocity change (m/s)","1"),num("r","Water density (kg/m³)","1000")),listOf("water hammer","surge pressure","transient pressure")){c->
            val a=c.doubleOrNull("a")?:0.0; val v=c.doubleOrNull("v")?:0.0; val r=c.doubleOrNull("r")?:1000.0; val p=c.settings.decimalPrecision
            if(a<=0||v<0||r<=0)return@tool Result.failure(IllegalArgumentException("Wave speed and density positive; velocity change non-negative."))
            val dp=r*a*v
            Result.success(CalcOutcome(listOf(CalcResultItem("Ideal pressure rise",fmt(dp/1000,p),"kPa",true),CalcResultItem("Pressure rise",fmt(dp/100000,p),"bar")),"ΔP=ρaΔV",listOf("Pressure converted to kPa and bar."),"Screening only; transient analysis needs boundary conditions, closure profile, pipe restraint and surge protection design."))
        }
    )
}

package com.example.features.tools

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.units.UnitConverter
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.LocalEngineeringPalette
import com.example.ui.theme.MonoFontFamily
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

internal object SciExprEvaluator {
    fun evaluate(expr: String, degMode: Boolean): Double {
        val tokens = expr.replace("×", "*").replace("÷", "/").replace("π", PI.toString())
        val parser = Parser(tokens, degMode)
        val v = parser.parseExpr()
        parser.skipWs()
        return if (parser.isAtEnd()) v else Double.NaN
    }

    private class Parser(
        private val tokens: String,
        private val degMode: Boolean
    ) {
        private var pos = 0

        private fun peek(): Char? = if (pos < tokens.length) tokens[pos] else null
        fun skipWs() { while (pos < tokens.length && tokens[pos].isWhitespace()) pos++ }
        fun isAtEnd(): Boolean = pos == tokens.length

        fun parseExpr(): Double {
            var x = parseTerm()
            while (true) {
                skipWs()
                when (peek()) {
                    '+' -> { pos++; x += parseTerm() }
                    '-' -> { pos++; x -= parseTerm() }
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parsePower()
            while (true) {
                skipWs()
                when (peek()) {
                    '*' -> { pos++; x *= parsePower() }
                    '/' -> {
                        pos++
                        val d = parsePower()
                        x = if (abs(d) > 1e-15) x / d else Double.NaN
                    }
                    '%' -> { pos++; x /= 100.0 }
                    else -> return x
                }
            }
        }

        private fun parsePower(): Double {
            var x = parseFactor()
            skipWs()
            if (peek() == '^') {
                pos++
                x = x.pow(parsePower())
            }
            return x
        }

        private fun parseFactor(): Double {
            skipWs()
            if (peek() == '+') { pos++; return parseFactor() }
            if (peek() == '-') { pos++; return -parseFactor() }
            if (peek() == '(') {
                pos++
                val v = parseExpr()
                skipWs()
                if (peek() == ')') pos++
                return v
            }
            val start = pos
            val ch = peek() ?: return Double.NaN
            if (ch.isDigit() || ch == '.') {
                while (pos < tokens.length && (tokens[pos].isDigit() || tokens[pos] == '.')) pos++
                return tokens.substring(start, pos).toDoubleOrNull() ?: Double.NaN
            }
            if (ch.isLetter()) {
                while (pos < tokens.length && tokens[pos].isLetter()) pos++
                val fn = tokens.substring(start, pos).lowercase()
                if (fn == "pi") return PI
                if (fn == "e") return Math.E
                skipWs()
                val arg = parseFactor()
                val toRad = if (degMode) PI / 180.0 else 1.0
                val fromRad = if (degMode) 180.0 / PI else 1.0
                return when (fn) {
                    "sin" -> sin(arg * toRad)
                    "cos" -> cos(arg * toRad)
                    "tan" -> tan(arg * toRad)
                    "asin" -> asin(arg.coerceIn(-1.0, 1.0)) * fromRad
                    "acos" -> acos(arg.coerceIn(-1.0, 1.0)) * fromRad
                    "atan" -> atan(arg) * fromRad
                    "sqrt" -> if (arg >= 0) sqrt(arg) else Double.NaN
                    "log" -> if (arg > 0) log10(arg) else Double.NaN
                    "ln" -> if (arg > 0) ln(arg) else Double.NaN
                    "abs" -> abs(arg)
                    else -> Double.NaN
                }
            }
            return Double.NaN
        }
    }
}

@Composable
fun ScientificCalculatorScreen(
    onBack: () -> Unit
) {
    val palette = LocalEngineeringPalette.current
    var expr by remember { mutableStateOf("10*cos(30)") }
    var degMode by remember { mutableStateOf(true) }
    var memory by remember { mutableDoubleStateOf(0.0) }
    var dmsOutput by remember { mutableStateOf("") }
    val tape = remember { mutableStateListOf<String>() }

    val evalValue = remember(expr, degMode) {
        if (expr.isBlank()) 0.0 else SciExprEvaluator.evaluate(expr, degMode)
    }

    fun formatDms(degVal: Double): String {
        if (degVal.isNaN() || degVal.isInfinite()) return "Invalid angle"
        val sign = if (degVal < 0) "-" else ""
        val a = abs(degVal)
        val d = floor(a).toInt()
        val mFull = (a - d) * 60.0
        val m = floor(mFull).toInt()
        val sec = (mFull - m) * 60.0
        return "$sign$d° ${m}' ${UnitConverter.fmt(sec, 1)}\""
    }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = "Scientific & Trig Calculator",
            subtitle = "Trig, Inverse Trig, DMS (° ' \"), Log, Power & Tape",
            onBack = onBack,
            actions = {
                if (tape.isNotEmpty()) {
                    IconButton(onClick = { tape.clear() }) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = "Clear Tape", tint = palette.inkMuted)
                    }
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                EngineeringCard(accentColor = palette.skyBlue) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = degMode, onClick = { degMode = true }, label = { Text("DEG") })
                            FilterChip(selected = !degMode, onClick = { degMode = false }, label = { Text("RAD") })
                        }
                        if (abs(memory) > 1e-9) {
                            Text("MEM = ${UnitConverter.fmt(memory, 3)}", style = MaterialTheme.typography.labelSmall, color = palette.orangeDark)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        color = palette.concreteSurfaceAlt,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, palette.metallicBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                            Text(
                                text = expr.ifEmpty { "0" },
                                fontFamily = MonoFontFamily,
                                fontSize = 20.sp,
                                color = palette.inkPrimary,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "= ${if (evalValue.isNaN()) "Syntax / Domain Error" else UnitConverter.fmt(evalValue, 6)}",
                                fontFamily = MonoFontFamily,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.orangeDark,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth().testTag("sci_calc_result")
                            )
                            if (dmsOutput.isNotEmpty()) {
                                Text("DMS: $dmsOutput", style = MaterialTheme.typography.labelSmall, color = palette.skyBlue)
                            }
                        }
                    }
                }
            }

            item {
                EngineeringCard {
                    val fnRows = listOf(
                        listOf("sin(" to "sin", "cos(" to "cos", "tan(" to "tan", "sqrt(" to "√", "^" to "xʸ"),
                        listOf("asin(" to "sin⁻¹", "acos(" to "cos⁻¹", "atan(" to "tan⁻¹", "log(" to "log", "ln(" to "ln"),
                        listOf("(" to "(", ")" to ")", "π" to "π", "DMS" to "DMS", "AC" to "AC")
                    )
                    fnRows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            row.forEach { (tok, lbl) ->
                                OutlinedButton(
                                    onClick = {
                                        when (tok) {
                                            "AC" -> { expr = ""; dmsOutput = "" }
                                            "DMS" -> if (!evalValue.isNaN()) dmsOutput = formatDms(evalValue)
                                            else -> expr += tok
                                        }
                                    },
                                    contentPadding = PaddingValues(0.dp),
                                    shape = RoundedCornerShape(9.dp),
                                    modifier = Modifier.weight(1f).height(40.dp)
                                ) {
                                    Text(
                                        text = lbl,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (tok == "AC") palette.error else palette.skyBlue
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    val memRow = listOf("MC", "MR", "M+", "M-", "⌫")
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        memRow.forEach { k ->
                            OutlinedButton(
                                onClick = {
                                    when (k) {
                                        "MC" -> memory = 0.0
                                        "MR" -> expr += UnitConverter.fmt(memory, 4)
                                        "M+" -> if (!evalValue.isNaN()) memory += evalValue
                                        "M-" -> if (!evalValue.isNaN()) memory -= evalValue
                                        "⌫" -> if (expr.isNotEmpty()) expr = expr.dropLast(1)
                                    }
                                },
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(9.dp),
                                modifier = Modifier.weight(1f).height(42.dp)
                            ) {
                                if (k == "⌫") Icon(Icons.Rounded.Backspace, contentDescription = "Backspace")
                                else Text(k, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val numRows = listOf(
                        listOf("7", "8", "9", "÷"),
                        listOf("4", "5", "6", "×"),
                        listOf("1", "2", "3", "-"),
                        listOf("0", ".", "=", "+")
                    )
                    numRows.forEach { r ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            r.forEach { btn ->
                                Button(
                                    onClick = {
                                        if (btn == "=") {
                                            if (!evalValue.isNaN()) {
                                                val resStr = UnitConverter.fmt(evalValue, 6).trimEnd('0').trimEnd('.')
                                                tape.add(0, "$expr = $resStr (${if (degMode) "DEG" else "RAD"})")
                                                expr = resStr
                                            }
                                        } else {
                                            expr += btn
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when (btn) {
                                            "=" -> palette.orange
                                            in setOf("÷", "×", "-", "+") -> palette.skyGlassTint
                                            else -> palette.concreteSurfaceAlt
                                        },
                                        contentColor = when (btn) {
                                            "=" -> MaterialTheme.colorScheme.onPrimary
                                            in setOf("÷", "×", "-", "+") -> palette.skyBlue
                                            else -> palette.inkPrimary
                                        }
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.weight(1f).height(48.dp)
                                ) {
                                    Text(btn, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            if (tape.isNotEmpty()) {
                item {
                    Text("Calculation Tape (${tape.size})", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                }
                items(tape) { entry ->
                    Surface(
                        color = palette.concreteCard,
                        border = BorderStroke(1.dp, palette.metallicBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(entry, fontFamily = MonoFontFamily, style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary, modifier = Modifier.padding(10.dp))
                    }
                }
            }
        }
    }
}

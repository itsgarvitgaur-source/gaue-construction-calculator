package com.example.features.boq

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.core.i18n.LocalAppStrings
import com.example.data.local.MaterialRateEntity
import com.example.domain.units.UnitConverter
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.LocalEngineeringPalette

@Composable
fun MaterialEstimatorScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val rates by viewModel.materialRates.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0 = Cost Estimator, 1 = Rate Master & Custom Materials
    val quantities = remember { mutableStateMapOf<Long, String>() }
    var wastagePctStr by remember { mutableStateOf(settings.defaultWastagePercent.toString()) }
    var transportCostStr by remember { mutableStateOf("4500") }
    var taxGstPctStr by remember { mutableStateOf("18") }
    var snapshotA by remember { mutableStateOf<Triple<Double, Double, Double>?>(null) } // material, labour, total

    var showRateDialog by remember { mutableStateOf(false) }
    var editingRate by remember { mutableStateOf<MaterialRateEntity?>(null) }

    val wastagePct = (wastagePctStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 30.0)
    val transportCost = (transportCostStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val gstPct = (taxGstPctStr.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 30.0)

    val lineCalculations = rates.map { r ->
        val q = (quantities[r.id]?.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
        val effQty = q * (1.0 + wastagePct / 100.0)
        val matCost = effQty * r.materialRate
        val labCost = effQty * r.labourRate
        Triple(r, q, matCost to labCost)
    }
    val totalMaterial = lineCalculations.sumOf { it.third.first }
    val totalLabour = lineCalculations.sumOf { it.third.second }
    val subtotal = totalMaterial + totalLabour + transportCost
    val gstAmount = subtotal * (gstPct / 100.0)
    val grandTotal = subtotal + gstAmount

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = strings.materialEstimator,
            subtitle = "Material, Labour, Transport, Wastage & Rate Master",
            onBack = onBack
        )

        TabRow(selectedTabIndex = activeTab, containerColor = palette.concreteCard) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Project Costing") })
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Rate Master (${rates.size})") })
        }

        if (activeTab == 0) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    EngineeringCard(accentColor = palette.orange) {
                        Text("Cost Summary", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Material Cost (+${UnitConverter.fmt(wastagePct, 1)}% wastage)", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                            Text("${settings.currencySymbol}${UnitConverter.fmt(totalMaterial, 0)}", fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Labour Cost", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                            Text("${settings.currencySymbol}${UnitConverter.fmt(totalLabour, 0)}", fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Transportation + GST (${UnitConverter.fmt(gstPct, 1)}%)", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                            Text("${settings.currencySymbol}${UnitConverter.fmt(transportCost + gstAmount, 0)}", fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(6.dp))
                        Surface(color = palette.skyGlassTint, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Final Project Total", style = MaterialTheme.typography.titleSmall, color = palette.skyBlue)
                                Text("${settings.currencySymbol}${UnitConverter.fmt(grandTotal, 0)}", style = MaterialTheme.typography.titleMedium, color = palette.skyBlue, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(value = wastagePctStr, onValueChange = { wastagePctStr = it }, label = { Text("Wastage %") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = transportCostStr, onValueChange = { transportCostStr = it }, label = { Text("Transport") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(value = taxGstPctStr, onValueChange = { taxGstPctStr = it }, label = { Text("Tax/GST %") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { snapshotA = Triple(totalMaterial, totalLabour, grandTotal) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.CompareArrows, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (snapshotA == null) "Pin Estimate A" else "Update Pin A")
                            }
                            OutlinedButton(
                                onClick = {
                                    val rows = lineCalculations.filter { it.second > 0 }.map { (r, q, costs) ->
                                        listOf(r.name, r.unit, UnitConverter.fmt(q, 2), UnitConverter.fmt(r.materialRate, 2), UnitConverter.fmt(r.labourRate, 2), UnitConverter.fmt(costs.first + costs.second, 2))
                                    }
                                    val report = EngineeringReportData(
                                        title = "Material & Labour Cost Estimate",
                                        projectName = "Material Costing",
                                        companyName = settings.companyName,
                                        engineerName = settings.engineerName,
                                        sections = listOf(
                                            ReportSection("Summary", rows = listOf("Material" to "${settings.currencySymbol}${UnitConverter.fmt(totalMaterial, 0)}", "Labour" to "${settings.currencySymbol}${UnitConverter.fmt(totalLabour, 0)}", "Transport" to "${settings.currencySymbol}${UnitConverter.fmt(transportCost, 0)}", "GST" to "${settings.currencySymbol}${UnitConverter.fmt(gstAmount, 0)}", "GRAND TOTAL" to "${settings.currencySymbol}${UnitConverter.fmt(grandTotal, 0)}")),
                                            ReportSection("Material Breakdown", tableHeaders = listOf("Material", "Unit", "Qty", "Mat.Rate", "Lab.Rate", "Amount"), tableRows = rows)
                                        )
                                    )
                                    val file = ReportExportEngine.generatePdfFile(context, report)
                                    ReportExportEngine.shareFile(context, file, "application/pdf", "Material_Estimate")
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.error)
                                Spacer(Modifier.width(4.dp))
                                Text("PDF")
                            }
                        }
                        snapshotA?.let { (aMat, aLab, aTot) ->
                            val diff = grandTotal - aTot
                            Spacer(Modifier.height(6.dp))
                            Surface(color = palette.orangeSoft, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    "Comparison vs Pinned A (${settings.currencySymbol}${UnitConverter.fmt(aTot, 0)}): Difference = ${if (diff >= 0) "+" else ""}${settings.currencySymbol}${UnitConverter.fmt(diff, 0)} (Mat Δ ${UnitConverter.fmt(totalMaterial - aMat, 0)}, Lab Δ ${UnitConverter.fmt(totalLabour - aLab, 0)})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.orangeDark,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }
                }

                items(rates, key = { it.id }) { rate ->
                    val qStr = quantities[rate.id] ?: ""
                    val q = qStr.toDoubleOrNull() ?: 0.0
                    val lineAmt = q * (1.0 + wastagePct / 100.0) * (rate.materialRate + rate.labourRate)
                    EngineeringCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(rate.name, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                Text(
                                    "Mat: ${settings.currencySymbol}${UnitConverter.fmt(rate.materialRate, 1)} | Lab: ${settings.currencySymbol}${UnitConverter.fmt(rate.labourRate, 1)} / ${rate.unit}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.inkMuted
                                )
                                if (lineAmt > 0) {
                                    Text(
                                        "Line Total: ${settings.currencySymbol}${UnitConverter.fmt(lineAmt, 0)}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = palette.orangeDark
                                    )
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            OutlinedTextField(
                                value = qStr,
                                onValueChange = { quantities[rate.id] = it },
                                label = { Text(rate.unit) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.width(105.dp)
                            )
                        }
                    }
                }
            }
        } else {
            // Rate Master & Custom Materials
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                editingRate = null
                                showRateDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.orange),
                            modifier = Modifier.weight(1f).testTag("add_custom_material_btn")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add Custom Material")
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel.resetRates()
                                Toast.makeText(context, "Default rates restored", Toast.LENGTH_SHORT).show()
                            },
                            border = BorderStroke(1.dp, palette.metallicBorder)
                        ) {
                            Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reset")
                        }
                    }
                }
                items(rates, key = { it.id }) { r ->
                    EngineeringCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(r.name, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                Text("${r.category} • Unit: ${r.unit}", style = MaterialTheme.typography.bodySmall, color = palette.skyBlue)
                                Text(
                                    "Material: ${settings.currencySymbol}${UnitConverter.fmt(r.materialRate, 2)}  |  Labour: ${settings.currencySymbol}${UnitConverter.fmt(r.labourRate, 2)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = palette.inkSecondary
                                )
                            }
                            IconButton(onClick = {
                                editingRate = r
                                showRateDialog = true
                            }) {
                                Icon(Icons.Rounded.Edit, contentDescription = "Edit Rate", tint = palette.skyBlue)
                            }
                            if (r.isCustom) {
                                IconButton(onClick = { viewModel.deleteMaterialRate(r.id) }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "Delete Custom", tint = palette.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showRateDialog) {
        var name by remember { mutableStateOf(editingRate?.name ?: "") }
        var category by remember { mutableStateOf(editingRate?.category ?: "Custom") }
        var unit by remember { mutableStateOf(editingRate?.unit ?: "Nos") }
        var matRate by remember { mutableStateOf((editingRate?.materialRate ?: 100.0).toString()) }
        var labRate by remember { mutableStateOf((editingRate?.labourRate ?: 20.0).toString()) }

        AlertDialog(
            onDismissRequest = { showRateDialog = false },
            title = { Text(if (editingRate == null) "Add Custom Material & Unit" else "Edit Rate") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Material Name") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Custom Unit") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = matRate, onValueChange = { matRate = it }, label = { Text("Material Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = labRate, onValueChange = { labRate = it }, label = { Text("Labour Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        viewModel.saveMaterialRate(
                            MaterialRateEntity(
                                id = editingRate?.id ?: 0L,
                                name = name.trim(),
                                category = category.ifBlank { "Custom" },
                                unit = unit.ifBlank { "Nos" },
                                materialRate = (matRate.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                                labourRate = (labRate.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                                isCustom = editingRate?.isCustom ?: true
                            )
                        )
                        showRateDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showRateDialog = false }) { Text("Cancel") } }
        )
    }
}

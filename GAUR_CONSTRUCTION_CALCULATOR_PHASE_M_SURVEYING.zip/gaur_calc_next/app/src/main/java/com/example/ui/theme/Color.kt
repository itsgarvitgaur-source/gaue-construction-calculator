package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Official Gaur Construction Calculator Bright Engineering Palette
// Derived from Logo: Construction Orange, Metallic Silver, White, Sky/Glass Blue, Light Concrete Grey

val ConstructionOrange = Color(0xFF008C89)
val ConstructionOrangeDark = Color(0xFF006466)
val ConstructionOrangeLight = Color(0xFFDDF4F3)
val ConstructionOrangeGlow = Color(0xFF56B9B5)

val SkyGlassBlue = Color(0xFF007F7D)
val SkyGlassBlueBright = Color(0xFF00A3A0)
val SkyGlassTint = Color(0xFFE0F4F3)
val SkyGlassBorder = Color(0xFF77C8C5)

val MetallicSilver = Color(0xFFE2E8F0)
val MetallicSilverMid = Color(0xFFCBD5E1)
val MetallicSilverDark = Color(0xFF64748B)
val MetallicSteel = Color(0xFF475569)

val ConcreteWhite = Color(0xFFFFFFFF)
val ConcreteBackground = Color(0xFFF4F6F9)
val ConcreteSurfaceAlt = Color(0xFFEBF0F5)
val ConcreteBorder = Color(0xFFD5DCE4)

val EngineeringInk = Color(0xFF0F172A)
val EngineeringInkSecondary = Color(0xFF334155)
val EngineeringInkMuted = Color(0xFF64748B)

val StatusSuccess = Color(0xFF16A34A)
val StatusSuccessBg = Color(0xFFDCFCE7)
val StatusWarning = Color(0xFFD97706)
val StatusWarningBg = Color(0xFFFEF3C7)
val StatusError = Color(0xFFDC2626)
val StatusErrorBg = Color(0xFFFEE2E2)

// Blueprint CAD canvas colors (engineering drafting mode)
val BlueprintNavy = Color(0xFF0B3B68)
val BlueprintGrid = Color(0xFF1E5B94)
val BlueprintPaper = Color(0xFFFAFBFD)
val BlueprintPaperGrid = Color(0xFFDCE5EF)

// Dark Graphite Engineering Theme tokens
val DarkGraphiteBg = Color(0xFF0E131B)
val DarkGraphiteCard = Color(0xFF171E29)
val DarkGraphiteSurfaceAlt = Color(0xFF212B3A)
val DarkGraphiteBorder = Color(0xFF334155)
val DarkInkPrimary = Color(0xFFF1F5F9)
val DarkInkSecondary = Color(0xFFCBD5E1)
val DarkInkMuted = Color(0xFF94A3B8)
val DarkOrangeSoft = Color(0xFF123A39)
val DarkOrangeBright = Color(0xFF4CC7C2)
val DarkSkyGlassTint = Color(0xFF0F2940)
val DarkSkyGlassBorder = Color(0xFF0284C7)
val DarkSuccessBg = Color(0xFF0F2F1F)
val DarkWarningBg = Color(0xFF332209)
val DarkErrorBg = Color(0xFF3B1219)


package com.example.features.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Debug
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.security.KeyStore
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

enum class ShieldCheckStatus {
    PASS,
    WARNING,
    INFO
}

data class SecurityCheckItem(
    val id: String,
    val title: String,
    val status: ShieldCheckStatus,
    val summary: String,
    val explanation: String
)

data class SecurityDiagnosticReport(
    val overallStatusLabel: String,
    val hasWarnings: Boolean,
    val apkSha256: String,
    val keystoreActive: Boolean,
    val declaredPermissions: List<String>,
    val checks: List<SecurityCheckItem>,
    val scannedAt: Long = System.currentTimeMillis()
)

object SecurityShieldEngine {
    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val KEY_ALIAS = "gaur_shield_aes256_key"

    fun runDiagnosticScan(context: Context): SecurityDiagnosticReport {
        val checks = mutableListOf<SecurityCheckItem>()

        // 1. APK Signature SHA-256 verification
        val sha256 = readApkSignatureSha256(context)
        checks += SecurityCheckItem(
            id = "apk_sig",
            title = "APK Signing Certificate",
            status = if (sha256 != "Unavailable") ShieldCheckStatus.PASS else ShieldCheckStatus.WARNING,
            summary = if (sha256 != "Unavailable") "SHA-256: ${sha256.take(23)}…" else "Could not read certificate",
            explanation = "Verifies the running APK's X.509 signing certificate digest via Android PackageManager."
        )

        // 2. Debuggable & Debugger check
        val isDebuggableFlag = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val debuggerAttached = Debug.isDebuggerConnected() || Debug.waitingForDebugger()
        checks += SecurityCheckItem(
            id = "debug_check",
            title = "Debugging & Attachment Check",
            status = if (!debuggerAttached && !isDebuggableFlag) ShieldCheckStatus.PASS else ShieldCheckStatus.INFO,
            summary = when {
                debuggerAttached -> "Active debugger attached"
                isDebuggableFlag -> "Debug build configuration (normal for dev/preview)"
                else -> "Release non-debuggable configuration"
            },
            explanation = "Inspects ApplicationInfo.FLAG_DEBUGGABLE and android.os.Debug.isDebuggerConnected()."
        )

        // 3. Root / Test-Keys Environment Indicators
        val rootIndicators = detectRootIndicators()
        checks += SecurityCheckItem(
            id = "root_env",
            title = "Environment & Root Risk Indicators",
            status = if (rootIndicators.isEmpty()) ShieldCheckStatus.PASS else ShieldCheckStatus.WARNING,
            summary = if (rootIndicators.isEmpty()) "No standard su/test-keys indicators found" else rootIndicators.joinToString(", "),
            explanation = "Checks Build.TAGS (test-keys) and standard su binary paths. Rooted environments may allow external memory inspection; core calculators remain available."
        )

        // 4. AndroidKeyStore AES-256-GCM Storage Protection
        val keystoreOk = ensureAndVerifyAesKey()
        checks += SecurityCheckItem(
            id = "keystore_aes",
            title = "Project Data Encryption (AES-256-GCM)",
            status = if (keystoreOk) ShieldCheckStatus.PASS else ShieldCheckStatus.WARNING,
            summary = if (keystoreOk) "AndroidKeyStore AES-256-GCM key verified" else "Hardware/Keystore unavailable",
            explanation = "Uses AndroidKeyStore KeyGenParameterSpec to protect project backup integrity and encrypted payloads without storing raw keys in code."
        )

        // 5. Permission Minimization Audit
        val permissions = readDeclaredPermissions(context)
        val invasive = permissions.filter {
            it.contains("READ_EXTERNAL_STORAGE") ||
                it.contains("CAMERA") ||
                it.contains("ACCESS_FINE_LOCATION") ||
                it.contains("READ_CONTACTS")
        }
        checks += SecurityCheckItem(
            id = "perm_audit",
            title = "Permission Minimization Audit",
            status = if (invasive.isEmpty()) ShieldCheckStatus.PASS else ShieldCheckStatus.WARNING,
            summary = if (permissions.isEmpty()) "Zero dangerous permissions requested" else "${permissions.size} permissions declared (${invasive.size} sensitive)",
            explanation = "Gaur Construction Calculator operates 100% offline using zero-permission SAF & FileProvider APIs."
        )

        val hasWarnings = checks.any { it.status == ShieldCheckStatus.WARNING }
        val label = if (!hasWarnings) "Shield Active — Integrity & Encryption Verified"
        else "Attention Recommended — Review Environment Indicators"

        return SecurityDiagnosticReport(
            overallStatusLabel = label,
            hasWarnings = hasWarnings,
            apkSha256 = sha256,
            keystoreActive = keystoreOk,
            declaredPermissions = permissions,
            checks = checks
        )
    }

    @Suppress("DEPRECATION")
    private fun readApkSignatureSha256(context: Context): String = runCatching {
        val pm = context.packageManager
        val sigBytes: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            info.signingInfo?.apkContentsSigners?.firstOrNull()?.toByteArray()
        } else {
            val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES)
            info.signatures?.firstOrNull()?.toByteArray()
        }
        if (sigBytes == null) return@runCatching "Unavailable"
        val digest = MessageDigest.getInstance("SHA-256").digest(sigBytes)
        digest.joinToString(":") { "%02X".format(it) }
    }.getOrDefault("Unavailable")

    private fun detectRootIndicators(): List<String> {
        val found = mutableListOf<String>()
        if (Build.TAGS?.contains("test-keys") == true) {
            found += "test-keys build tag"
        }
        val suPaths = listOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/su/bin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su"
        )
        if (suPaths.any { runCatching { File(it).exists() }.getOrDefault(false) }) {
            found += "su binary detected"
        }
        return found
    }

    private fun readDeclaredPermissions(context: Context): List<String> = runCatching {
        val info = context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS)
        info.requestedPermissions?.toList() ?: emptyList()
    }.getOrDefault(emptyList())

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = ks.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val keyGen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGen.init(spec)
        return keyGen.generateKey()
    }

    private fun ensureAndVerifyAesKey(): Boolean = runCatching {
        val key = getOrCreateKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val ct = cipher.doFinal("GAUR_INTEGRITY_PING".toByteArray(Charsets.UTF_8))
        val dec = Cipher.getInstance("AES/GCM/NoPadding")
        dec.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        val plain = String(dec.doFinal(ct), Charsets.UTF_8)
        plain == "GAUR_INTEGRITY_PING"
    }.getOrDefault(false)

    fun encryptPayload(plainText: String): Result<String> = runCatching {
        val key = getOrCreateKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = Base64.encodeToString(cipher.iv, Base64.NO_WRAP)
        val ct = Base64.encodeToString(cipher.doFinal(plainText.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        "GAUR_ENC_V1:$iv:$ct"
    }

    fun decryptPayload(token: String): Result<String> = runCatching {
        val parts = token.split(":")
        require(parts.size == 3 && parts[0] == "GAUR_ENC_V1") { "Invalid encrypted envelope." }
        val iv = Base64.decode(parts[1], Base64.NO_WRAP)
        val ct = Base64.decode(parts[2], Base64.NO_WRAP)
        val key = getOrCreateKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        String(cipher.doFinal(ct), Charsets.UTF_8)
    }

    fun sha256Checksum(text: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

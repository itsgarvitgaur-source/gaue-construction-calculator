package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil

object MasonryWoodRoadCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        stoneMasonryCalculator(),
        interlockingPaverCalculator(),
        boundaryFenceCalculator(),
        marbleGraniteCalculator(),
        falseCeilingCalculator(),
        woodTimberCalculator(),
        doorWindowGlassCalculator(),
        asphaltRoadCalculator(),
        antiTermiteCalculator()
    )

    private fun stoneMasonryCalculator() = CalcToolSpec(
        id = "masonry_stone",
        title = "Stone / Rubble Masonry Wall",
        titleHi = "पत्थर की चिनाई (स्टोन मेसनरी)",
        subtitle = "Random Rubble / Coursed Stone Volume, Mortar, Cement & Sand",
        category = CalcCategory.MASONRY,
        keywords = listOf("stone", "rubble", "masonry", "wall", "mortar", "foundation"),
        fields = listOf(
            CalcFieldSpec("l", "Wall Length (L)", "10.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Wall Height (H)", "2.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("t", "Wall Thickness (T)", "0.45", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("ratio", "Mortar Ratio", "1:6", options = listOf("1:4", "1:5", "1:6"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val t = ctx.lengthMeters("t") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter thickness."))
            if (l <= 0 || h <= 0 || t <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val grossVol = l * h * t
            val stoneReqM3 = grossVol * 1.25 // 25% dressing/wastage
            val dryMortar = grossVol * 0.42 // ~42% dry mortar for rubble masonry
            val sandPart = ctx.raw("ratio").substringAfter(":").toDoubleOrNull() ?: 6.0
            val bags = (dryMortar / (1.0 + sandPart)) / 0.0347
            val sandCft = dryMortar * (sandPart / (1.0 + sandPart)) * UnitConverter.CU_FT_IN_CU_M
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Masonry Volume", UnitConverter.fmt(grossVol, p), "m³", isPrimary = true),
                        CalcResultItem("Undressed Stone Needed", "${UnitConverter.fmt(stoneReqM3, p)} m³ (${UnitConverter.fmt(stoneReqM3 * UnitConverter.CU_FT_IN_CU_M, p)} CFT)", "", isPrimary = true),
                        CalcResultItem("Cement for Mortar", UnitConverter.fmt(bags, p), "Bags"),
                        CalcResultItem("Sand for Mortar", UnitConverter.fmt(sandCft, p), "CFT")
                    ),
                    formula = "Stone = 1.25 × V_wall; Dry Mortar = 0.42 × V_wall",
                    steps = listOf("Wall Vol = ${UnitConverter.fmt(grossVol, p)} m³"),
                    assumptions = "Random rubble stone masonry (CPWD norm ~1.25 m³ stone & 0.42 m³ dry mortar per m³)."
                )
            )
        }
    )

    private fun interlockingPaverCalculator() = CalcToolSpec(
        id = "masonry_interlocking_paver",
        title = "Interlocking Paver Block Estimator",
        titleHi = "इंटरलॉकिंग पेवर ब्लॉक कैलकुलेटर",
        subtitle = "Zigzag / I-Shape / Square Pavers, Bedding Sand & Edge Wastage",
        category = CalcCategory.MASONRY,
        keywords = listOf("paver", "interlocking", "zigzag", "cobble", "driveway", "parking"),
        fields = listOf(
            CalcFieldSpec("l", "Paving Area Length", "15.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Paving Area Width", "6.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("paverType", "Paver Block Density", "I-Shape / Zigzag (38 pcs/m²)", options = listOf("I-Shape / Zigzag (38 pcs/m²)", "Square 200×200 (25 pcs/m²)", "Uni-Paver (42 pcs/m²)")),
            CalcFieldSpec("sandMm", "Sand Bedding Thickness (mm)", "40", FieldUnitKind.NONE),
            CalcFieldSpec("wastage", "Cutting Wastage (%)", "5", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val sandMm = ctx.doubleOrNull("sandMm") ?: 40.0
            val wast = ctx.doubleOrNull("wastage") ?: 5.0
            if (l <= 0 || w <= 0 || sandMm < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val areaM2 = l * w
            val perM2 = when {
                ctx.raw("paverType").contains("25") -> 25.0
                ctx.raw("paverType").contains("42") -> 42.0
                else -> 38.0
            }
            val pcs = ceil(areaM2 * perM2 * (1.0 + wast / 100.0)).toLong()
            val sandCft = (areaM2 * (sandMm / 1000.0) * 1.15) * UnitConverter.CU_FT_IN_CU_M
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Paver Blocks Required", "$pcs", "Blocks", isPrimary = true),
                        CalcResultItem("Paving Area", "${UnitConverter.fmt(areaM2, p)} m² (${UnitConverter.fmt(areaM2 * UnitConverter.SQ_FT_IN_SQ_M, 0)} sq.ft)", "", isPrimary = true),
                        CalcResultItem("Bedding Sand (Loose)", UnitConverter.fmt(sandCft, p), "CFT")
                    ),
                    formula = "Blocks = Area × Density × (1 + Wastage%)",
                    steps = listOf("${UnitConverter.fmt(areaM2, p)} m² × $perM2 × (1 + $wast%) = $pcs blocks"),
                    assumptions = "Includes 15% compaction allowance on river/stone-dust bedding sand."
                )
            )
        }
    )

    private fun boundaryFenceCalculator() = CalcToolSpec(
        id = "masonry_boundary_fence",
        title = "Boundary Fencing & Barbed Wire",
        titleHi = "बाउंड्री फेंसिंग और कांटेदार तार",
        subtitle = "Fence Posts, Post Footing Concrete & Barbed Wire Strands",
        category = CalcCategory.MASONRY,
        keywords = listOf("fence", "fencing", "barbed wire", "post", "boundary", "chain link"),
        fields = listOf(
            CalcFieldSpec("perim", "Total Fence Perimeter", "120", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("spacing", "Post Spacing (c/c)", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("strands", "Horizontal Wire Strands", "6", FieldUnitKind.COUNT),
            CalcFieldSpec("wtPerM", "Wire Weight (kg per m)", "0.11", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val perim = ctx.lengthMeters("perim") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter perimeter."))
            val sp = ctx.lengthMeters("spacing") ?: 3.0
            val strands = (ctx.doubleOrNull("strands") ?: 6.0).toInt().coerceAtLeast(1)
            val wtM = ctx.doubleOrNull("wtPerM") ?: 0.11
            if (perim <= 0 || sp <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val posts = ceil(perim / sp).toInt() + 1
            val wireLenM = perim * strands * 1.05 // 5% tie/overlap
            val wireKg = wireLenM * wtM
            val postConcM3 = posts * (0.3 * 0.3 * 0.45)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Fence Posts Required", "$posts", "Posts", isPrimary = true),
                        CalcResultItem("Total Barbed Wire Length", UnitConverter.fmt(wireLenM, p), "m", isPrimary = true),
                        CalcResultItem("Barbed Wire Weight", UnitConverter.fmt(wireKg, p), "kg"),
                        CalcResultItem("Post Footing PCC (0.3×0.3×0.45)", UnitConverter.fmt(postConcM3, p), "m³")
                    ),
                    formula = "Posts = ⌈Perimeter / Spacing⌉ + 1; Wire = Perimeter × Strands × 1.05",
                    steps = listOf("Posts = $posts; Wire = ${UnitConverter.fmt(wireLenM, p)} m"),
                    assumptions = "Assumes 5% extra wire for post wrapping/straining and 0.3×0.3×0.45 m PCC per post."
                )
            )
        }
    )

    private fun marbleGraniteCalculator() = CalcToolSpec(
        id = "finish_marble_granite",
        title = "Marble, Granite & Stair Stone Slabs",
        titleHi = "मार्बल, ग्रेनाइट और सीढ़ी पत्थर",
        subtitle = "Flooring Stone Slabs, Stair Treads/Risers, Wastage & Cement Bedding",
        category = CalcCategory.FINISHING,
        keywords = listOf("marble", "granite", "kota", "stone", "flooring", "stair", "tread"),
        fields = listOf(
            CalcFieldSpec("area", "Total Area (sq.ft)", "650", FieldUnitKind.NONE),
            CalcFieldSpec("slabL", "Slab Length (ft)", "6.0", FieldUnitKind.NONE),
            CalcFieldSpec("slabW", "Slab Width (ft)", "3.0", FieldUnitKind.NONE),
            CalcFieldSpec("wastage", "Cutting Wastage (%)", "10", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter area."))
            val sl = ctx.doubleOrNull("slabL") ?: 6.0
            val sw = ctx.doubleOrNull("slabW") ?: 3.0
            val wast = ctx.doubleOrNull("wastage") ?: 10.0
            if (area <= 0 || sl <= 0 || sw <= 0 || wast < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val grossSqFt = area * (1.0 + wast / 100.0)
            val slabs = ceil(grossSqFt / (sl * sw)).toInt()
            val areaM2 = area / UnitConverter.SQ_FT_IN_SQ_M
            val bedDry = areaM2 * 0.025 * 1.33
            val cementBags = (bedDry / 5.0) / 0.0347
            val sandCft = bedDry * (4.0 / 5.0) * UnitConverter.CU_FT_IN_CU_M
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Gross Stone Required", UnitConverter.fmt(grossSqFt, p), "sq.ft", isPrimary = true),
                        CalcResultItem("Full Slabs (${sl}×${sw} ft)", "$slabs", "Slabs", isPrimary = true),
                        CalcResultItem("Bedding Cement (1:4)", UnitConverter.fmt(cementBags, p), "Bags"),
                        CalcResultItem("Bedding Sand", UnitConverter.fmt(sandCft, p), "CFT")
                    ),
                    formula = "Gross = Net Area × (1 + Wastage%); Slabs = ⌈Gross / (L_slab × W_slab)⌉",
                    steps = listOf("${UnitConverter.fmt(area, p)} × (1 + $wast%) = ${UnitConverter.fmt(grossSqFt, p)} sq.ft"),
                    assumptions = "Includes 25 mm 1:4 cement-sand mortar bedding; natural stone cutting wastage ~8–12%."
                )
            )
        }
    )

    private fun falseCeilingCalculator() = CalcToolSpec(
        id = "finish_false_ceiling",
        title = "Gypsum / POP False Ceiling & Grid",
        titleHi = "फॉल्स सीलिंग (जिप्सम / POP) गणना",
        subtitle = "Gypsum Boards (6×4 ft), Perimeter/Intermediate/Ceiling GI Channels & Screws",
        category = CalcCategory.FINISHING,
        keywords = listOf("false ceiling", "gypsum", "pop", "grid", "channel", "ceiling"),
        fields = listOf(
            CalcFieldSpec("l", "Room Length", "6.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Room Width", "4.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("wastage", "Board Wastage (%)", "8", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val wast = ctx.doubleOrNull("wastage") ?: 8.0
            if (l <= 0 || w <= 0 || wast < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val areaM2 = l * w
            val areaSqFt = areaM2 * UnitConverter.SQ_FT_IN_SQ_M
            val boards = ceil((areaSqFt / 24.0) * (1.0 + wast / 100.0)).toInt() // 6x4 = 24 sq.ft
            val perimChannelM = 2.0 * (l + w)
            val mainChannelM = areaM2 * 1.15
            val crossSectionM = areaM2 * 2.2
            val screws = ceil(areaSqFt * 1.4).toInt()
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Gypsum Boards (6×4 ft)", "$boards", "Sheets", isPrimary = true),
                        CalcResultItem("Ceiling Area", "${UnitConverter.fmt(areaSqFt, p)} sq.ft (${UnitConverter.fmt(areaM2, p)} m²)", "", isPrimary = true),
                        CalcResultItem("Perimeter L-Channel", UnitConverter.fmt(perimChannelM, p), "m"),
                        CalcResultItem("Intermediate + Ceiling Channels", UnitConverter.fmt(mainChannelM + crossSectionM, p), "m"),
                        CalcResultItem("Drywall Screws (25mm)", "$screws", "Nos")
                    ),
                    formula = "Boards = ⌈Area(sq.ft) / 24 × (1 + Wastage%)⌉",
                    steps = listOf("Area = ${UnitConverter.fmt(areaSqFt, p)} sq.ft → $boards sheets"),
                    assumptions = "Standard 12.5mm gypsum board (1830×1220 mm = 24 sq.ft); GI channels at 600×1200 mm grid."
                )
            )
        }
    )

    private fun woodTimberCalculator() = CalcToolSpec(
        id = "finish_wood_timber",
        title = "Wood / Timber CFT & Hoppus Log",
        titleHi = "लकड़ी / टिम्बर (CFT और गोल लट्ठा) गणना",
        subtitle = "Sawn Plank / Chowkhat CFT & Round Log Hoppus (G/4)² × L Formula",
        category = CalcCategory.FINISHING,
        typeFieldKey = "woodType",
        keywords = listOf("wood", "timber", "cft", "log", "plank", "hoppus", "chowkhat", "lumber"),
        fields = listOf(
            CalcFieldSpec("woodType", "Timber Form", "Sawn Plank / Beam (L×W×T)", options = listOf("Sawn Plank / Beam (L×W×T)", "Round Wood Log (Hoppus)")),
            CalcFieldSpec("lenFt", "Length (feet)", "8.0", FieldUnitKind.NONE),
            CalcFieldSpec("wIn", "Width (inches)", "5.0", FieldUnitKind.NONE, visibleWhen = { it["woodType"] != "Round Wood Log (Hoppus)" }),
            CalcFieldSpec("tIn", "Thickness (inches)", "3.0", FieldUnitKind.NONE, visibleWhen = { it["woodType"] != "Round Wood Log (Hoppus)" }),
            CalcFieldSpec("girthIn", "Mid Girth / Circumference (inches)", "36.0", FieldUnitKind.NONE, visibleWhen = { it["woodType"] == "Round Wood Log (Hoppus)" }),
            CalcFieldSpec("count", "Number of Pieces", "4", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val lenFt = ctx.doubleOrNull("lenFt") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length in ft."))
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (lenFt <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be positive."))
            val cftSingle: Double
            val formula: String
            if (ctx.raw("woodType") == "Round Wood Log (Hoppus)") {
                val gIn = ctx.doubleOrNull("girthIn") ?: 36.0
                if (gIn <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive girth."))
                cftSingle = (gIn / 4.0) * (gIn / 4.0) * lenFt / 144.0
                formula = "Hoppus CFT = (Girth_in / 4)² × Length_ft / 144"
            } else {
                val wIn = ctx.doubleOrNull("wIn") ?: 5.0
                val tIn = ctx.doubleOrNull("tIn") ?: 3.0
                if (wIn <= 0 || tIn <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive width and thickness."))
                cftSingle = (lenFt * wIn * tIn) / 144.0
                formula = "Sawn CFT = (Length_ft × Width_in × Thick_in) / 144"
            }
            val totalCft = cftSingle * n
            val cum = totalCft / UnitConverter.CU_FT_IN_CU_M
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Timber Volume", UnitConverter.fmt(totalCft, p + 1), "CFT", isPrimary = true),
                        CalcResultItem("Cubic Meters", UnitConverter.fmt(cum, p + 2), "m³", isPrimary = true),
                        CalcResultItem("Single Piece CFT", UnitConverter.fmt(cftSingle, p + 1), "CFT")
                    ),
                    formula = formula,
                    steps = listOf("Single = ${UnitConverter.fmt(cftSingle, p + 1)} CFT × ${n.toInt()} = ${UnitConverter.fmt(totalCft, p + 1)} CFT"),
                    assumptions = "Standard Indian timber trade Hoppus quarter-girth rule for round logs."
                )
            )
        }
    )

    private fun doorWindowGlassCalculator() = CalcToolSpec(
        id = "finish_door_window_glass",
        title = "Door, Window & Glass Glazing",
        titleHi = "दरवाज़ा, खिड़की और ग्लास कैलकुलेटर",
        subtitle = "Frame RFT, Shutter Area, Toughened Glass Sq.ft & Laminate Sheets",
        category = CalcCategory.FINISHING,
        keywords = listOf("door", "window", "glass", "glazing", "shutter", "laminate", "frame"),
        fields = listOf(
            CalcFieldSpec("w", "Opening Width", "1.2", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Opening Height", "2.1", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("sides", "Frame Type", "3-Sided (Door Frame)", options = listOf("3-Sided (Door Frame)", "4-Sided (Window Frame)")),
            CalcFieldSpec("count", "Quantity (Nos)", "4", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (w <= 0 || h <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be positive."))
            val frameM = (if (ctx.raw("sides").startsWith("4-Sided")) 2.0 * (w + h) else w + 2.0 * h) * n
            val frameRft = UnitConverter.fromMeters(frameM, LengthUnit.FT)
            val areaM2 = w * h * n
            val areaSqFt = areaM2 * UnitConverter.SQ_FT_IN_SQ_M
            val lamSheets = ceil(areaSqFt * 2.0 / 32.0).toInt() // 8x4 sheet both sides
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Shutter / Glass Area", "${UnitConverter.fmt(areaSqFt, p)} sq.ft (${UnitConverter.fmt(areaM2, p)} m²)", "", isPrimary = true),
                        CalcResultItem("Total Frame Run (RFT)", "${UnitConverter.fmt(frameRft, p)} RFT (${UnitConverter.fmt(frameM, p)} m)", "", isPrimary = true),
                        CalcResultItem("Laminate Sheets (8×4 both sides)", "$lamSheets", "Sheets")
                    ),
                    formula = "Area = W × H × N; Frame = (2H + W or 2H + 2W) × N",
                    steps = listOf("Area = ${UnitConverter.fmt(areaM2, p)} m²; Frame = ${UnitConverter.fmt(frameM, p)} m"),
                    assumptions = "Laminate sheet = 8×4 ft (32 sq.ft) assuming 2-face lamination."
                )
            )
        }
    )

    private fun asphaltRoadCalculator() = CalcToolSpec(
        id = "finish_asphalt_road",
        title = "Asphalt / Bitumen Road & WBM",
        titleHi = "डामर (एस्फाल्ट) और WBM रोड कैलकुलेटर",
        subtitle = "Hot-Mix Asphalt Tonnage, Sub-Base Volume & Tack Coat Emulsion",
        category = CalcCategory.FINISHING,
        keywords = listOf("asphalt", "bitumen", "road", "wbm", "gsb", "paving", "tack coat"),
        fields = listOf(
            CalcFieldSpec("l", "Road Length", "100.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Carriageway Width", "7.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("thickMm", "Asphalt / Layer Thickness (mm)", "50", FieldUnitKind.NONE),
            CalcFieldSpec("density", "Compacted Density (kg/m³)", "2350", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val tMm = ctx.doubleOrNull("thickMm") ?: 50.0
            val dens = ctx.doubleOrNull("density") ?: 2350.0
            if (l <= 0 || w <= 0 || tMm <= 0 || dens <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val areaM2 = l * w
            val volM3 = areaM2 * (tMm / 1000.0)
            val tonnageMt = (volM3 * dens) / 1000.0
            val bitumenMt = tonnageMt * 0.052 // ~5.2% binder content
            val tackCoatKg = areaM2 * 0.25
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Hot-Mix Asphalt Required", UnitConverter.fmt(tonnageMt, p), "Metric Tons", isPrimary = true),
                        CalcResultItem("Compacted Layer Volume", UnitConverter.fmt(volM3, p), "m³", isPrimary = true),
                        CalcResultItem("Binder Bitumen (~5.2%)", UnitConverter.fmt(bitumenMt, p + 1), "MT"),
                        CalcResultItem("Tack Coat Emulsion", UnitConverter.fmt(tackCoatKg, 0), "kg"),
                        CalcResultItem("Paving Surface Area", UnitConverter.fmt(areaM2, p), "m²")
                    ),
                    formula = "Weight (MT) = Area × Thickness(m) × Density(kg/m³) / 1000",
                    steps = listOf("Vol = ${UnitConverter.fmt(areaM2, p)} × ${tMm / 1000.0} = ${UnitConverter.fmt(volM3, p)} m³"),
                    assumptions = "Compacted dense bituminous macadam / BC density ~2350 kg/m³; tack coat 0.25 kg/m²."
                )
            )
        }
    )

    private fun antiTermiteCalculator() = CalcToolSpec(
        id = "finish_anti_termite",
        title = "Anti-Termite Soil Treatment",
        titleHi = "दीमक-रोधी (एंटी-टरमाइट) उपचार",
        subtitle = "IS 6313 Emulsion Liters & Chemical Concentrate for Plinth & Perimeter",
        category = CalcCategory.FINISHING,
        keywords = listOf("termite", "anti termite", "chemical", "soil", "plinth", "is 6313"),
        fields = listOf(
            CalcFieldSpec("l", "Building Plinth Length", "15.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Building Plinth Width", "10.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("dilution", "Dilution Ratio (Chem : Water)", "1:19", options = listOf("1:19", "1:49"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            if (l <= 0 || w <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val areaM2 = l * w
            val perimM = 2.0 * (l + w)
            val floorEmulsion = areaM2 * 5.0 // 5 L/m² top surface
            val perimEmulsion = perimM * 7.5 // 7.5 L per linear m wall-floor junction
            val totalEmulsion = floorEmulsion + perimEmulsion
            val ratioParts = if (ctx.raw("dilution") == "1:49") 50.0 else 20.0
            val concL = totalEmulsion / ratioParts
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Emulsion Solution", UnitConverter.fmt(totalEmulsion, 0), "Liters", isPrimary = true),
                        CalcResultItem("Chemical Concentrate", UnitConverter.fmt(concL, p), "Liters", isPrimary = true),
                        CalcResultItem("Floor Surface (@ 5 L/m²)", UnitConverter.fmt(floorEmulsion, 0), "Liters"),
                        CalcResultItem("Perimeter Trench (@ 7.5 L/m)", UnitConverter.fmt(perimEmulsion, 0), "Liters")
                    ),
                    formula = "Emulsion = 5 × Floor Area + 7.5 × Perimeter; Concentrate = Emulsion / Dilution",
                    steps = listOf("Floor=${UnitConverter.fmt(floorEmulsion, 0)} L + Perimeter=${UnitConverter.fmt(perimEmulsion, 0)} L"),
                    assumptions = "Dosage per IS 6313 Part 2 pre-construction anti-termite specification."
                )
            )
        }
    )
}

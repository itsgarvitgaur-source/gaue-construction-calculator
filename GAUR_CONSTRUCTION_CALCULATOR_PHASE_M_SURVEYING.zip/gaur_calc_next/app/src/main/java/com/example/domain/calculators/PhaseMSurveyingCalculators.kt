package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.*

/** Phase M: field surveying, levelling, traverse and setting-out estimators. */
object PhaseMSurveyingCalculators {
    private fun len(k:String,l:String,v:String)=CalcFieldSpec(k,l,v,FieldUnitKind.LENGTH,LengthUnit.M)
    private fun num(k:String,l:String,v:String)=CalcFieldSpec(k,l,v,FieldUnitKind.NONE)
    private fun fmt(v:Double,p:Int)=UnitConverter.fmt(v,p)
    private fun tool(id:String,title:String,sub:String,fields:List<CalcFieldSpec>,keys:List<String>,calc:(CalcContext)->Result<CalcOutcome>) =
        CalcToolSpec(id,title,title,sub,CalcCategory.SITE_TOOLKIT,keys,fields=fields,compute=calc)

    fun all():List<CalcToolSpec> = listOf(
        tool("phase_m_level_hi", "Auto Level – Height of Instrument", "Calculate instrument height and point reduced levels from staff readings",
            listOf(num("bm","Benchmark RL (m)","100.000"),num("bs","Backsight (m)","1.245"),num("is","Intermediate sight (m)","1.860"),num("fs","Foresight (m)","2.115")),
            listOf("auto level","height of instrument","HI method","reduced level","survey")) { c ->
            val bm=c.doubleOrNull("bm")?:0.0; val bs=c.doubleOrNull("bs")?:0.0; val isr=c.doubleOrNull("is")?:0.0; val fs=c.doubleOrNull("fs")?:0.0; val p=c.settings.decimalPrecision
            if(bs<=0||isr<0||fs<0) return@tool Result.failure(IllegalArgumentException("Backsight must be positive; intermediate and foresight readings cannot be negative."))
            val hi=bm+bs; val rlI=hi-isr; val rlF=hi-fs
            Result.success(CalcOutcome(listOf(CalcResultItem("Height of instrument (HI)",fmt(hi,p),"m",true),CalcResultItem("Intermediate point RL",fmt(rlI,p),"m"),CalcResultItem("Foresight point RL",fmt(rlF,p),"m")),"HI = BM RL + BS; Point RL = HI − staff reading",listOf("All staff readings are in metres.","Use the foresight RL as the next change-point RL when shifting instrument."),"Single instrument setup only. Apply booking, arithmetic checks and change-point conventions in the field book.")) },
        tool("phase_m_rise_fall", "Levelling – Rise & Fall Method", "Compute RL difference and classify rise or fall between two staff readings",
            listOf(num("rl","Previous point RL (m)","100.000"),num("prev","Previous staff reading (m)","1.650"),num("next","Next staff reading (m)","1.325")),
            listOf("rise and fall","levelling","staff reading","reduced level")) { c ->
            val rl=c.doubleOrNull("rl")?:0.0; val a=c.doubleOrNull("prev")?:0.0; val b=c.doubleOrNull("next")?:0.0; val p=c.settings.decimalPrecision
            if(a<0||b<0) return@tool Result.failure(IllegalArgumentException("Staff readings cannot be negative."))
            val delta=a-b; val newRl=rl+delta
            Result.success(CalcOutcome(listOf(CalcResultItem(if(delta>=0)"Rise" else "Fall",fmt(abs(delta),p),"m",true),CalcResultItem("New point RL",fmt(newRl,p),"m"),CalcResultItem("RL change",fmt(delta,p),"m")),"RL₂ = RL₁ + (previous staff reading − next staff reading)",listOf("A smaller next reading indicates rise; a larger next reading indicates fall."),"Two-point calculation only; full level-book arithmetic checks require all intermediate and change-point readings.")) },
        tool("phase_m_slope_distance", "Slope, Gradient & Vertical Difference", "Calculate slope percentage, ratio and level difference",
            listOf(len("run","Horizontal distance","100"),len("rise","Vertical difference (m)","2.5")),
            listOf("slope","gradient","level difference","survey level")) { c ->
            val run=c.lengthMeters("run")?:0.0; val rise=c.lengthMeters("rise")?:0.0; val p=c.settings.decimalPrecision
            if(run<=0||rise<0) return@tool Result.failure(IllegalArgumentException("Horizontal distance must be positive and vertical difference non-negative."))
            val g=rise/run*100; val sl=sqrt(run*run+rise*rise)
            Result.success(CalcOutcome(listOf(CalcResultItem("Gradient",fmt(g,p),"%",true),CalcResultItem("Gradient ratio",if(rise==0.0)"Level" else "1 in ${fmt(run/rise,p)}",""),CalcResultItem("Slope length",fmt(sl,p),"m")),"Gradient = rise / horizontal run × 100; slope length = √(run²+rise²)",listOf("Enter vertical difference as a positive magnitude."),"Sign/direction is not inferred; record whether the line rises or falls.")) },
        tool("phase_m_traverse_lat_depart", "Traverse – Latitude & Departure", "Resolve a survey line into northing/easting components",
            listOf(len("d","Line length","100"),num("bearing","Bearing angle from north (degrees)","35"),num("quadrant","Quadrant: 1 NE, 2 SE, 3 SW, 4 NW","1")),
            listOf("traverse","latitude","departure","bearing","northing","easting")) { c ->
            val d=c.lengthMeters("d")?:0.0; val b=c.doubleOrNull("bearing")?:0.0; val q=c.doubleOrNull("quadrant")?:0.0; val p=c.settings.decimalPrecision
            if(d<=0||b<0||b>90||q !in listOf(1.0,2.0,3.0,4.0)) return@tool Result.failure(IllegalArgumentException("Length positive, bearing angle 0–90°, quadrant 1–4."))
            val rad=b*PI/180; val ns=if(q==1.0||q==4.0)1 else -1; val es=if(q==1.0||q==2.0)1 else -1
            val lat=ns*d*cos(rad); val dep=es*d*sin(rad)
            Result.success(CalcOutcome(listOf(CalcResultItem("Latitude / Northing",fmt(lat,p),"m",true),CalcResultItem("Departure / Easting",fmt(dep,p),"m"),CalcResultItem("Line length",fmt(d,p),"m")),"Latitude = ±L cos θ; Departure = ±L sin θ",listOf("Bearing angle is the acute angle from north/south meridian; quadrant supplies signs."),"For whole-circle bearings use the corresponding quadrant and reduced bearing. Traverse adjustment is not included.")) },
        tool("phase_m_coordinate_bearing", "Coordinate Distance & Bearing", "Compute distance, bearing and azimuth between two coordinate points",
            listOf(num("e1","Start Easting (m)","500.000"),num("n1","Start Northing (m)","1000.000"),num("e2","End Easting (m)","560.000"),num("n2","End Northing (m)","1080.000")),
            listOf("coordinate bearing","azimuth","distance between coordinates","survey coordinates")) { c ->
            val e1=c.doubleOrNull("e1")?:0.0; val n1=c.doubleOrNull("n1")?:0.0; val e2=c.doubleOrNull("e2")?:0.0; val n2=c.doubleOrNull("n2")?:0.0; val p=c.settings.decimalPrecision
            val de=e2-e1; val dn=n2-n1; val d=hypot(de,dn)
            if(d==0.0) return@tool Result.failure(IllegalArgumentException("Start and end coordinates must be different."))
            val az=(atan2(de,dn)*180/PI+360)%360
            Result.success(CalcOutcome(listOf(CalcResultItem("Horizontal distance",fmt(d,p),"m",true),CalcResultItem("Whole-circle azimuth",fmt(az,p),"°"),CalcResultItem("ΔE / Departure",fmt(de,p),"m"),CalcResultItem("ΔN / Latitude",fmt(dn,p),"m")),"Distance = √(ΔE²+ΔN²); Azimuth = atan2(ΔE, ΔN)",listOf("Azimuth measured clockwise from north, 0°–360°."),"Assumes a consistent projected coordinate system and units; grid-to-ground and convergence corrections are excluded.")) },
        tool("phase_m_coordinate_point", "Coordinate Point from Distance & Bearing", "Set out a point using start coordinates, distance and azimuth",
            listOf(num("e","Start Easting (m)","500.000"),num("n","Start Northing (m)","1000.000"),len("d","Horizontal distance","75"),num("az","Azimuth clockwise from north (degrees)","125")),
            listOf("setting out","coordinate point","stakeout","azimuth","survey")) { c ->
            val e=c.doubleOrNull("e")?:0.0; val n=c.doubleOrNull("n")?:0.0; val d=c.lengthMeters("d")?:0.0; val az=c.doubleOrNull("az")?:0.0; val p=c.settings.decimalPrecision
            if(d<0||az<0||az>=360) return@tool Result.failure(IllegalArgumentException("Distance cannot be negative; azimuth must be 0° to less than 360°."))
            val r=az*PI/180; val ee=e+d*sin(r); val nn=n+d*cos(r)
            Result.success(CalcOutcome(listOf(CalcResultItem("Target Easting",fmt(ee,p),"m",true),CalcResultItem("Target Northing",fmt(nn,p),"m"),CalcResultItem("ΔE",fmt(d*sin(r),p),"m"),CalcResultItem("ΔN",fmt(d*cos(r),p),"m")),"E₂=E₁+D sin(Az); N₂=N₁+D cos(Az)",listOf("Azimuth measured clockwise from north."),"Coordinate setting-out estimate; verify datum, projection, instrument orientation and control points before construction.")) },
        tool("phase_m_three_four_five", "3–4–5 Right Angle Setting Out", "Calculate scaled triangle sides for a perpendicular layout",
            listOf(len("a","First leg / scale length","3"),len("b","Second leg / scale length","4"),len("scale","Scale multiplier","10")),
            listOf("3 4 5","right angle","perpendicular","setting out","squaring")) { c ->
            val a=c.lengthMeters("a")?:0.0; val b=c.lengthMeters("b")?:0.0; val s=c.lengthMeters("scale")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||b<=0||s<=0) return@tool Result.failure(IllegalArgumentException("Both legs and scale multiplier must be positive."))
            val h=hypot(a,b)*s
            Result.success(CalcOutcome(listOf(CalcResultItem("First leg",fmt(a*s,p),"m"),CalcResultItem("Second leg",fmt(b*s,p),"m"),CalcResultItem("Diagonal",fmt(h,p),"m",true)),"Diagonal = scale × √(a²+b²)",listOf("For a 3:4:5 triangle, enter leg values 3 and 4 and scale 10 for 30, 40 and 50 units."),"The method checks a right angle geometrically; longer baselines improve field accuracy. Check both diagonals for rectangular layouts.")) },
        tool("phase_m_contour_interpolation", "Contour Point Interpolation", "Find the point location between two spot levels for a target contour RL",
            listOf(len("d","Horizontal distance between points","20"),num("rl1","First point RL (m)","100.0"),num("rl2","Second point RL (m)","104.0"),num("target","Target contour RL (m)","102.0")),
            listOf("contour","interpolation","contour level","survey mapping")) { c ->
            val d=c.lengthMeters("d")?:0.0; val a=c.doubleOrNull("rl1")?:0.0; val b=c.doubleOrNull("rl2")?:0.0; val t=c.doubleOrNull("target")?:0.0; val p=c.settings.decimalPrecision
            if(d<=0||a==b||t<min(a,b)||t>max(a,b)) return@tool Result.failure(IllegalArgumentException("Distance positive, endpoint RLs different, target RL must lie between them."))
            val x=d*(t-a)/(b-a)
            Result.success(CalcOutcome(listOf(CalcResultItem("Distance from first point",fmt(x,p),"m",true),CalcResultItem("Distance from second point",fmt(d-x,p),"m"),CalcResultItem("Target contour RL",fmt(t,p),"m")),"x = D × (RLtarget − RL₁) / (RL₂ − RL₁)",listOf("Assumes a linear ground slope between the two surveyed points."),"Linear interpolation only; contour accuracy depends on survey point density and terrain variation.")) },
        tool("phase_m_offset_point", "Offset Point from Survey Baseline", "Calculate left/right offset coordinates from a baseline and chainage",
            listOf(num("e0","Baseline start Easting (m)","500.000"),num("n0","Baseline start Northing (m)","1000.000"),len("chain","Chainage along baseline","25"),num("az","Baseline azimuth clockwise from north (degrees)","90"),num("off","Offset: positive right, negative left (m)","3")),
            listOf("offset point","baseline offset","chainage","left right offset","setting out")) { c ->
            val e0=c.doubleOrNull("e0")?:0.0; val n0=c.doubleOrNull("n0")?:0.0; val chain=c.lengthMeters("chain")?:0.0; val az=c.doubleOrNull("az")?:0.0; val off=c.doubleOrNull("off")?:0.0; val p=c.settings.decimalPrecision
            if(chain<0||az<0||az>=360) return@tool Result.failure(IllegalArgumentException("Chainage cannot be negative; azimuth must be 0° to less than 360°."))
            val r=az*PI/180; val eBase=e0+chain*sin(r); val nBase=n0+chain*cos(r)
            val e=eBase+off*cos(r); val n=nBase-off*sin(r)
            Result.success(CalcOutcome(listOf(CalcResultItem("Offset point Easting",fmt(e,p),"m",true),CalcResultItem("Offset point Northing",fmt(n,p),"m"),CalcResultItem("Baseline point Easting",fmt(eBase,p),"m"),CalcResultItem("Baseline point Northing",fmt(nBase,p),"m")),"E=E₀+C sin(Az)+O cos(Az); N=N₀+C cos(Az)−O sin(Az)",listOf("Positive offset is to the right when looking along the baseline azimuth; negative is left."),"Plan-coordinate setting-out only. Confirm baseline orientation, chainage origin, coordinate datum and field sign convention before use.")) },
        tool("phase_m_traverse_closure", "Traverse Misclosure & Relative Precision", "Compare calculated closing coordinate with known closing control",
            listOf(num("de","Easting misclosure (m)","0.025"),num("dn","Northing misclosure (m)","0.018"),len("perim","Total traverse length","1200")),
            listOf("traverse closure","misclosure","relative precision","survey adjustment")) { c ->
            val de=c.doubleOrNull("de")?:0.0; val dn=c.doubleOrNull("dn")?:0.0; val l=c.lengthMeters("perim")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0) return@tool Result.failure(IllegalArgumentException("Total traverse length must be positive."))
            val e=hypot(de,dn); val ratio=if(e==0.0) Double.POSITIVE_INFINITY else l/e
            Result.success(CalcOutcome(listOf(CalcResultItem("Linear misclosure",fmt(e,p),"m",true),CalcResultItem("Relative precision",if(e==0.0)"Perfect closure" else "1 : ${fmt(ratio,0)}",""),CalcResultItem("Easting misclosure",fmt(de,p),"m"),CalcResultItem("Northing misclosure",fmt(dn,p),"m")),"Misclosure = √(ΔE² + ΔN²); relative precision = perimeter / misclosure",listOf("Misclosure components are signed coordinate differences."),"Reports closure only; no Bowditch/transit adjustment applied. Compare with survey specification before accepting observations.")) }
    )
}

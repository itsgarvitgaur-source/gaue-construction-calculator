package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil

object PhaseCSteelCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        cuttingStockOptimizationCalculator(),
        steelTonnageDensityCalculator(),
        columnTiesIs13920Calculator(),
        beamReinforcementBarsCalculator(),
        slabTwoWaySteelCalculator(),
        weldedWireMeshCalculator(),
        steelPlateBoltWeightCalculator(),
        coverBlockChairCalculator(),
        mechanicalCouplerVsLapCalculator(),
        staircaseBbsCalculator()
    )

    private fun cuttingStockOptimizationCalculator() = CalcToolSpec(
        id = "steel_cutting_opt",
        title = "12m Bar Cutting Stock Optimization",
        titleHi = "12m सरिया कटिंग वेस्टेज ऑप्टिमाइज़र",
        subtitle = "First-Fit Decreasing Packing for Up to 3 Cut Lengths vs 12m Stock",
        category = CalcCategory.STEEL,
        keywords = listOf("cutting", "optimization", "12m", "scrap", "wastage", "bbs", "stock"),
        fields = listOf(
            CalcFieldSpec("dia", "Bar Diameter (mm)", "16", FieldUnitKind.NONE),
            CalcFieldSpec("len1", "Cut Length A (m)", "5.2", FieldUnitKind.NONE),
            CalcFieldSpec("qty1", "Count A (Nos)", "18", FieldUnitKind.COUNT),
            CalcFieldSpec("len2", "Cut Length B (m)", "3.8", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("qty2", "Count B (Nos)", "24", FieldUnitKind.COUNT, allowZero = true),
            CalcFieldSpec("len3", "Cut Length C (m)", "2.4", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("qty3", "Count C (Nos)", "16", FieldUnitKind.COUNT, allowZero = true),
            CalcFieldSpec("stockLen", "Standard Bar Length (m)", "12.0", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val dia = ctx.doubleOrNull("dia") ?: 16.0
            val stock = ctx.doubleOrNull("stockLen") ?: 12.0
            if (dia <= 0 || stock <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dia and stock length must be positive."))

            val cuts = mutableListOf<Double>()
            listOf("len1" to "qty1", "len2" to "qty2", "len3" to "qty3").forEach { (lk, qk) ->
                val l = (ctx.doubleOrNull(lk) ?: 0.0)
                val q = (ctx.doubleOrNull(qk) ?: 0.0).toInt()
                if (l > stock) return@CalcToolSpec Result.failure(IllegalArgumentException("Cut length $l m exceeds stock bar $stock m."))
                if (l > 0 && q > 0) repeat(q) { cuts += l }
            }
            if (cuts.isEmpty()) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter at least one cut length and count."))

            cuts.sortDescending()
            val bins = mutableListOf<Double>() // remaining length in each 12m bar
            for (c in cuts) {
                var placed = false
                for (i in bins.indices) {
                    if (bins[i] + 1e-6 >= c) {
                        bins[i] -= c
                        placed = true
                        break
                    }
                }
                if (!placed) bins += (stock - c)
            }
            val totalCutM = cuts.sum()
            val stockBars = bins.size
            val totalPurchasedM = stockBars * stock
            val offcutM = totalPurchasedM - totalCutM
            val scrapPct = (offcutM / totalPurchasedM) * 100.0
            val unitWt = dia * dia / 162.2
            val purchasedKg = totalPurchasedM * unitWt

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Full ${UnitConverter.fmt(stock, 0)}m Bars Required", "$stockBars", "bars (${UnitConverter.fmt(purchasedKg, 1)} kg)", isPrimary = true),
                        CalcResultItem("Offcut / Scrap Percentage", "${UnitConverter.fmt(scrapPct, 2)}%", "(${UnitConverter.fmt(offcutM, 2)} m leftover)", isPrimary = true),
                        CalcResultItem("Net Cut Steel Length", UnitConverter.fmt(totalCutM, 2), "m (${UnitConverter.fmt(totalCutM * unitWt, 1)} kg)"),
                        CalcResultItem("Leftover End Pieces", "${bins.count { it > 0.05 }}", "remnants")
                    ),
                    formula = "First-Fit Decreasing (FFD) 1D Bin Packing on ${UnitConverter.fmt(stock, 0)}m bars",
                    steps = listOf("Sorted ${cuts.size} pieces → Packed into $stockBars bars → Scrap = ${UnitConverter.fmt(offcutM, 2)} m"),
                    assumptions = "Uses FFD heuristic assuming single-bar cuts (no coupler splicing within pieces)."
                )
            )
        }
    )

    private fun steelTonnageDensityCalculator() = CalcToolSpec(
        id = "steel_tonnage_density",
        title = "Steel Tonnage by m³ / Sq.Ft Norm",
        titleHi = "स्टील खपत (kg/m³ और kg/sq.ft) अनुमान",
        subtitle = "Member-Wise & Building Steel Weight Estimator from Norms",
        category = CalcCategory.STEEL,
        isPreliminaryStructural = true,
        keywords = listOf("tonnage", "steel per m3", "steel per sqft", "thumb rule", "budget"),
        fields = listOf(
            CalcFieldSpec("member", "Element / Building Type", "RCC Slab (80 kg/m³)", options = listOf("Footing (65 kg/m³)", "RCC Slab (80 kg/m³)", "RCC Beam (135 kg/m³)", "RCC Column (185 kg/m³)", "Staircase (95 kg/m³)", "Retaining Wall (105 kg/m³)", "Full Building (4.2 kg/sq.ft)")),
            CalcFieldSpec("qty", "Concrete Vol (m³) OR Area (sq.ft)", "25.0", FieldUnitKind.NONE),
            CalcFieldSpec("customNorm", "Custom Norm Override (0 = Default)", "0", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val qty = ctx.doubleOrNull("qty") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter quantity."))
            val override = ctx.doubleOrNull("customNorm") ?: 0.0
            if (qty <= 0 || override < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be valid."))
            val defaultNorm = when (ctx.raw("member")) {
                "Footing (65 kg/m³)" -> 65.0
                "RCC Beam (135 kg/m³)" -> 135.0
                "RCC Column (185 kg/m³)" -> 185.0
                "Staircase (95 kg/m³)" -> 95.0
                "Retaining Wall (105 kg/m³)" -> 105.0
                "Full Building (4.2 kg/sq.ft)" -> 4.2
                else -> 80.0
            }
            val norm = if (override > 0) override else defaultNorm
            val totalKg = qty * norm * 1.03 // +3% rolling/lap allowance
            val mt = totalKg / 1000.0

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Steel Weight (+3%)", UnitConverter.fmt(totalKg, 1), "kg (${UnitConverter.fmt(mt, p)} MT)", isPrimary = true),
                        CalcResultItem("Applied Steel Ratio", UnitConverter.fmt(norm, 1), if (ctx.raw("member").contains("sq.ft")) "kg/sq.ft" else "kg/m³", isPrimary = true),
                        CalcResultItem("Approx. 12m Bar Bundle Equiv (12mm)", "${ceil(totalKg / 10.65).toInt()}", "bars (ref)")
                    ),
                    formula = "Steel (kg) = Quantity × Norm × 1.03; MT = kg / 1000",
                    steps = listOf("${UnitConverter.fmt(qty, p)} × $norm × 1.03 = ${UnitConverter.fmt(totalKg, 1)} kg"),
                    assumptions = "Preliminary estimating thumb norms only; final steel MUST come from structural BBS drawings."
                )
            )
        }
    )

    private fun columnTiesIs13920Calculator() = CalcToolSpec(
        id = "steel_column_ties",
        title = "Column Rebar & Confining Ties (IS 13920)",
        titleHi = "कॉलम सरिया और IS 13920 कन्फाइनिंग रिंग",
        subtitle = "Longitudinal Bars + Lo End Confining Zone vs Mid-Height Ties",
        category = CalcCategory.STEEL,
        isPreliminaryStructural = true,
        keywords = listOf("column", "ties", "is 13920", "confining", "stirrup", "lap"),
        fields = listOf(
            CalcFieldSpec("b", "Column Width (mm)", "300", FieldUnitKind.NONE),
            CalcFieldSpec("d", "Column Depth (mm)", "450", FieldUnitKind.NONE),
            CalcFieldSpec("h", "Floor-to-Floor Height", "3.2", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("mainDia", "Main Bar Dia (mm)", "16", FieldUnitKind.NONE),
            CalcFieldSpec("mainCount", "Main Bar Count", "8", FieldUnitKind.COUNT),
            CalcFieldSpec("tieDia", "Tie Dia (mm)", "8", FieldUnitKind.NONE),
            CalcFieldSpec("endSpace", "End Zone Lo Spacing (mm)", "100", FieldUnitKind.NONE),
            CalcFieldSpec("midSpace", "Mid Zone Spacing (mm)", "175", FieldUnitKind.NONE),
            CalcFieldSpec("cols", "No. of Columns", "6", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val b = ctx.doubleOrNull("b") ?: 300.0
            val d = ctx.doubleOrNull("d") ?: 450.0
            val hM = ctx.lengthMeters("h") ?: 3.2
            val mainDia = ctx.doubleOrNull("mainDia") ?: 16.0
            val mainN = ctx.doubleOrNull("mainCount") ?: 8.0
            val tieDia = ctx.doubleOrNull("tieDia") ?: 8.0
            val endSp = ctx.doubleOrNull("endSpace") ?: 100.0
            val midSp = ctx.doubleOrNull("midSpace") ?: 175.0
            val cols = ctx.doubleOrNull("cols") ?: 6.0
            if (b <= 100 || d <= 100 || hM <= 0 || endSp <= 0 || midSp <= 0 || cols <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid positive column dimensions."))
            }
            val loMm = maxOf(d, hM * 1000.0 / 6.0, 450.0)
            val midMm = (hM * 1000.0 - 2.0 * loMm).coerceAtLeast(0.0)
            val endTies = (ceil((2.0 * loMm) / endSp).toInt() + 2)
            val midTies = if (midMm > 0) ceil(midMm / midSp).toInt() else 0
            val totalTiesPerCol = endTies + midTies

            val cover = 40.0
            val tieCutM = (2.0 * ((b - 2 * cover) + (d - 2 * cover)) + 20.0 * tieDia - 6.0 * tieDia) / 1000.0
            val lapM = 50.0 * mainDia / 1000.0
            val mainLenPerCol = (hM + lapM) * mainN

            val mainKg = mainLenPerCol * (mainDia * mainDia / 162.2) * cols
            val tieKg = totalTiesPerCol * tieCutM * (tieDia * tieDia / 162.2) * cols

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Column Steel", UnitConverter.fmt(mainKg + tieKg, 1), "kg", isPrimary = true),
                        CalcResultItem("Ties per Column ($endTies end + $midTies mid)", "$totalTiesPerCol", "ties (Lo=${loMm.toInt()}mm)", isPrimary = true),
                        CalcResultItem("Main Bar Weight (${mainN.toInt()}×Ø${mainDia.toInt()})", UnitConverter.fmt(mainKg, 1), "kg"),
                        CalcResultItem("Tie Ring Weight (Cut ${UnitConverter.fmt(tieCutM, 2)}m)", UnitConverter.fmt(tieKg, 1), "kg")
                    ),
                    formula = "IS 13920 Lo = max(D, H/6, 450mm); Tie Cut = 2(a+b)+20d-6d; Lap = 50d",
                    steps = listOf("Lo = ${loMm.toInt()} mm each end → $endTies confining + $midTies mid ties/col"),
                    assumptions = "40mm cover, 135° seismic hooks (10d each), 50d main bar lap allowance."
                )
            )
        }
    )

    private fun beamReinforcementBarsCalculator() = CalcToolSpec(
        id = "steel_beam_bars",
        title = "Beam Top, Bottom & Stirrup Steel",
        titleHi = "बीम टॉप, बॉटम और रिंग सरिया",
        subtitle = "Detailed Beam Main, Top, Extra Bars & Stirrups BBS Estimator",
        category = CalcCategory.STEEL,
        isPreliminaryStructural = true,
        keywords = listOf("beam", "rebar", "top", "bottom", "curtailment", "stirrup", "bbs"),
        fields = listOf(
            CalcFieldSpec("span", "Beam Clear Span", "5.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("b", "Beam Width (mm)", "250", FieldUnitKind.NONE),
            CalcFieldSpec("d", "Beam Depth (mm)", "450", FieldUnitKind.NONE),
            CalcFieldSpec("botDia", "Bottom Main Dia (mm)", "16", FieldUnitKind.NONE),
            CalcFieldSpec("botN", "Bottom Bars Count", "3", FieldUnitKind.COUNT),
            CalcFieldSpec("topDia", "Top Anchor Dia (mm)", "12", FieldUnitKind.NONE),
            CalcFieldSpec("topN", "Top Bars Count", "3", FieldUnitKind.COUNT),
            CalcFieldSpec("stirDia", "Stirrup Dia (mm)", "8", FieldUnitKind.NONE),
            CalcFieldSpec("stirSpace", "Stirrup Spacing (mm c/c)", "150", FieldUnitKind.NONE),
            CalcFieldSpec("beams", "Number of Beams", "4", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val span = ctx.lengthMeters("span") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter span."))
            val b = ctx.doubleOrNull("b") ?: 250.0
            val d = ctx.doubleOrNull("d") ?: 450.0
            val botDia = ctx.doubleOrNull("botDia") ?: 16.0
            val botN = ctx.doubleOrNull("botN") ?: 3.0
            val topDia = ctx.doubleOrNull("topDia") ?: 12.0
            val topN = ctx.doubleOrNull("topN") ?: 3.0
            val stirDia = ctx.doubleOrNull("stirDia") ?: 8.0
            val stirSp = ctx.doubleOrNull("stirSpace") ?: 150.0
            val nBeams = ctx.doubleOrNull("beams") ?: 4.0
            if (span <= 0 || b <= 80 || d <= 100 || stirSp <= 0 || nBeams <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid beam dimensions."))
            }
            val anchorM = 50.0 * maxOf(botDia, topDia) / 1000.0
            val botLen = span + anchorM
            val topLen = span + anchorM
            val stirN = ceil((span * 1000.0) / stirSp).toInt() + 1
            val cover = 25.0
            val stirCutM = (2.0 * ((b - 2 * cover) + (d - 2 * cover)) + 20.0 * stirDia - 6.0 * stirDia) / 1000.0

            val botKg = botLen * botN * (botDia * botDia / 162.2) * nBeams
            val topKg = topLen * topN * (topDia * topDia / 162.2) * nBeams
            val stirKg = stirN * stirCutM * (stirDia * stirDia / 162.2) * nBeams

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Beam Steel Weight", UnitConverter.fmt(botKg + topKg + stirKg, 1), "kg", isPrimary = true),
                        CalcResultItem("Stirrups (${stirN}/beam × ${nBeams.toInt()})", UnitConverter.fmt(stirKg, 1), "kg (Cut ${UnitConverter.fmt(stirCutM, 2)}m)", isPrimary = true),
                        CalcResultItem("Bottom Bars (${botN.toInt()}×Ø${botDia.toInt()})", UnitConverter.fmt(botKg, 1), "kg"),
                        CalcResultItem("Top Bars (${topN.toInt()}×Ø${topDia.toInt()})", UnitConverter.fmt(topKg, 1), "kg")
                    ),
                    formula = "Main Cut ≈ Span + 50d anchorage; Stirrup Cut = 2(a+b)+14d",
                    steps = listOf("Bot=${UnitConverter.fmt(botKg, 1)}kg, Top=${UnitConverter.fmt(topKg, 1)}kg, Stir=${UnitConverter.fmt(stirKg, 1)}kg"),
                    assumptions = "25mm clear cover, 50d total anchorage/dev length at supports."
                )
            )
        }
    )

    private fun slabTwoWaySteelCalculator() = CalcToolSpec(
        id = "steel_slab_two_way",
        title = "Two-Way Slab Cranked & Dist. Rebar",
        titleHi = "टू-वे स्लैब क्रैंक और डिस्ट्रीब्यूशन सरिया",
        subtitle = "Short-Span Main, Long-Span Dist., Top Extra & Chair Bars",
        category = CalcCategory.STEEL,
        isPreliminaryStructural = true,
        keywords = listOf("slab", "two-way", "crank", "bent-up", "main bar", "distribution", "chair"),
        fields = listOf(
            CalcFieldSpec("lx", "Short Span Lx", "4.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("ly", "Long Span Ly", "5.2", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("t", "Slab Thickness (mm)", "125", FieldUnitKind.NONE),
            CalcFieldSpec("mainDia", "Main / Dist Bar Dia (mm)", "10", FieldUnitKind.NONE),
            CalcFieldSpec("mainSp", "Main Bar Spacing (mm c/c)", "150", FieldUnitKind.NONE),
            CalcFieldSpec("distSp", "Dist. Bar Spacing (mm c/c)", "175", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val lx = ctx.lengthMeters("lx") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Lx."))
            val ly = ctx.lengthMeters("ly") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Ly."))
            val t = ctx.doubleOrNull("t") ?: 125.0
            val dia = ctx.doubleOrNull("mainDia") ?: 10.0
            val mSp = ctx.doubleOrNull("mainSp") ?: 150.0
            val dSp = ctx.doubleOrNull("distSp") ?: 175.0
            if (lx <= 0 || ly <= 0 || t <= 50 || dia <= 0 || mSp <= 0 || dSp <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val effD = (t - 40.0 - dia).coerceAtLeast(40.0) / 1000.0
            val crankExtra = 0.42 * effD
            val mainCount = ceil((ly * 1000.0) / mSp).toInt() + 1
            val distCount = ceil((lx * 1000.0) / dSp).toInt() + 1
            val mainLen = lx + 0.25 + crankExtra
            val distLen = ly + 0.25 + crankExtra
            val unitWt = dia * dia / 162.2
            val mainKg = mainCount * mainLen * unitWt
            val distKg = distCount * distLen * unitWt
            val topDistKg = (mainKg + distKg) * 0.22 // crank zone top distribution
            val totalKg = mainKg + distKg + topDistKg

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Two-Way Slab Steel", UnitConverter.fmt(totalKg, 1), "kg", isPrimary = true),
                        CalcResultItem("Main Bars (Along Lx) + Dist (Ly)", "$mainCount + $distCount", "bars", isPrimary = true),
                        CalcResultItem("Main + Dist Mesh Weight", UnitConverter.fmt(mainKg + distKg, 1), "kg"),
                        CalcResultItem("Top Extra / Torsion Mesh (~22%)", UnitConverter.fmt(topDistKg, 1), "kg")
                    ),
                    formula = "N = ceil(Span/Spacing)+1; Cut = Span + 2×Bearing + 0.42×d (45° crank)",
                    steps = listOf("d ≈ ${UnitConverter.fmt(effD * 1000, 0)}mm, crank extra = ${UnitConverter.fmt(crankExtra * 1000, 1)}mm"),
                    assumptions = "20mm top/bottom cover, 125mm beam bearing each end, single crank per alternate bar."
                )
            )
        }
    )

    private fun weldedWireMeshCalculator() = CalcToolSpec(
        id = "steel_welded_mesh",
        title = "Welded Wire Mesh (BRC) & Chicken Mesh",
        titleHi = "वेल्डेड वायर मेश (BRC) और चिकन मेश",
        subtitle = "Mesh Sheets / Rolls Count, Overlap Allowance & Steel Weight",
        category = CalcCategory.STEEL,
        keywords = listOf("mesh", "brc", "welded wire", "chicken mesh", "slab", "plaster"),
        fields = listOf(
            CalcFieldSpec("area", "Area to Cover (m²)", "180.0", FieldUnitKind.AREA_SQ_M),
            CalcFieldSpec("meshType", "Mesh Type", "BRC Slab Mesh (2.4×4.8m)", options = listOf("BRC Slab Mesh (2.4×4.8m)", "Plaster Chicken Mesh Roll (1×30m)", "GI Weld Mesh Roll (1.2×15m)")),
            CalcFieldSpec("lapPct", "Overlap & Cut Wastage (%)", "12", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter area."))
            val lap = (ctx.doubleOrNull("lapPct") ?: 12.0).coerceAtLeast(0.0)
            if (area <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Area must be positive."))

            val (unitArea, kgPerUnit, unitName) = when (ctx.raw("meshType")) {
                "Plaster Chicken Mesh Roll (1×30m)" -> Triple(30.0, 11.0, "rolls")
                "GI Weld Mesh Roll (1.2×15m)" -> Triple(18.0, 24.0, "rolls")
                else -> Triple(11.52, 42.0, "sheets") // 2.4x4.8m A142-equivalent
            }
            val grossArea = area * (1.0 + lap / 100.0)
            val units = ceil(grossArea / unitArea).toInt()
            val wtKg = units * kgPerUnit

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Required Quantity", "$units", unitName, isPrimary = true),
                        CalcResultItem("Gross Area (incl. ${lap.toInt()}% lap)", UnitConverter.fmt(grossArea, p), "m²", isPrimary = true),
                        CalcResultItem("Approx. Mesh Weight", UnitConverter.fmt(wtKg, 1), "kg")
                    ),
                    formula = "Qty = ceil(Area × (1 + Lap%) / Sheet_or_Roll_Area)",
                    steps = listOf("${UnitConverter.fmt(grossArea, p)} m² / $unitArea m² = $units $unitName"),
                    assumptions = "Typical A142/standard roll weights used as reference; verify wire gauge with vendor."
                )
            )
        }
    )

    private fun steelPlateBoltWeightCalculator() = CalcToolSpec(
        id = "steel_plate_bolt",
        title = "MS Steel Plate, Gusset & Bolt Weight",
        titleHi = "MS स्टील प्लेट, गसेट और नट-बोल्ट वजन",
        subtitle = "Baseplate Steel Weight minus Bolt Holes + High-Strength Bolts",
        category = CalcCategory.STEEL,
        keywords = listOf("plate", "gusset", "baseplate", "bolt", "anchor", "nut", "washer", "structural"),
        fields = listOf(
            CalcFieldSpec("plL", "Plate Length (mm)", "450", FieldUnitKind.NONE),
            CalcFieldSpec("plW", "Plate Width (mm)", "350", FieldUnitKind.NONE),
            CalcFieldSpec("plT", "Plate Thickness (mm)", "20", FieldUnitKind.NONE),
            CalcFieldSpec("plCount", "Number of Plates", "12", FieldUnitKind.COUNT),
            CalcFieldSpec("boltDia", "Bolt Diameter (mm)", "20", FieldUnitKind.NONE),
            CalcFieldSpec("boltLen", "Bolt Length (mm)", "100", FieldUnitKind.NONE),
            CalcFieldSpec("boltsPerPl", "Bolts per Plate", "4", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.doubleOrNull("plL") ?: 450.0
            val w = ctx.doubleOrNull("plW") ?: 350.0
            val t = ctx.doubleOrNull("plT") ?: 20.0
            val plN = ctx.doubleOrNull("plCount") ?: 12.0
            val bDia = ctx.doubleOrNull("boltDia") ?: 20.0
            val bLen = ctx.doubleOrNull("boltLen") ?: 100.0
            val bPerPl = ctx.doubleOrNull("boltsPerPl") ?: 4.0
            if (l <= 0 || w <= 0 || t <= 0 || plN <= 0 || bDia <= 0 || bLen <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val grossVolM3 = (l / 1000.0) * (w / 1000.0) * (t / 1000.0) * plN
            val holeDiaM = (bDia + 2.0) / 1000.0
            val holeVolM3 = PI * (holeDiaM / 2.0) * (holeDiaM / 2.0) * (t / 1000.0) * bPerPl * plN
            val netPlateKg = (grossVolM3 - holeVolM3).coerceAtLeast(0.0) * 7850.0
            val totalBolts = (bPerPl * plN).toInt()
            // Bolt shank + hex head + nut + 2 washers (~1.35x shank length equivalent)
            val oneBoltKg = (PI * (bDia / 2000.0) * (bDia / 2000.0) * ((bLen + 2.2 * bDia) / 1000.0)) * 7850.0
            val boltsKg = oneBoltKg * totalBolts

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Net MS Plates Weight", UnitConverter.fmt(netPlateKg, p), "kg", isPrimary = true),
                        CalcResultItem("Total Bolts + Nuts + Washers ($totalBolts)", UnitConverter.fmt(boltsKg, p), "kg", isPrimary = true),
                        CalcResultItem("Total Steel Assembly Weight", UnitConverter.fmt(netPlateKg + boltsKg, p), "kg")
                    ),
                    formula = "Plate Wt = Net Vol × 7850 kg/m³; Bolt Wt = Shank + Head + Nut/Washer equiv.",
                    steps = listOf("Gross plate vol = ${UnitConverter.fmt(grossVolM3, 4)} m³; Net = ${UnitConverter.fmt(netPlateKg, 1)} kg"),
                    assumptions = "Steel density 7850 kg/m³; bolt hole clearance +2mm."
                )
            )
        }
    )

    private fun coverBlockChairCalculator() = CalcToolSpec(
        id = "steel_cover_chair",
        title = "Cover Block & Rebar Chair Spacers",
        titleHi = "कवर ब्लॉक और स्लैब चेयर बार संख्या",
        subtitle = "Concrete Cover Blocks & 12mm Chair Bars Quantity + Weight",
        category = CalcCategory.STEEL,
        keywords = listOf("cover block", "chair", "spacer", "slab", "footing", "rebar"),
        fields = listOf(
            CalcFieldSpec("area", "Slab / Raft Plan Area (m²)", "150.0", FieldUnitKind.AREA_SQ_M),
            CalcFieldSpec("slabT", "Slab / Raft Thickness (mm)", "150", FieldUnitKind.NONE),
            CalcFieldSpec("coverSp", "Cover Block Spacing (m)", "0.9", FieldUnitKind.NONE),
            CalcFieldSpec("chairSp", "Chair Bar Spacing (m)", "1.0", FieldUnitKind.NONE),
            CalcFieldSpec("chairDia", "Chair Bar Dia (mm)", "12", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter area."))
            val slabT = ctx.doubleOrNull("slabT") ?: 150.0
            val cSp = ctx.doubleOrNull("coverSp") ?: 0.9
            val chSp = ctx.doubleOrNull("chairSp") ?: 1.0
            val chDia = ctx.doubleOrNull("chairDia") ?: 12.0
            if (area <= 0 || slabT <= 50 || cSp <= 0 || chSp <= 0 || chDia <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All values must be positive."))
            }
            val coverQty = ceil(area / (cSp * cSp)).toInt()
            val chairQty = ceil(area / (chSp * chSp)).toInt()
            val chairH = ((slabT - 55.0).coerceAtLeast(50.0)) / 1000.0
            val chairCutM = 0.25 + 2.0 * chairH + 2.0 * 0.15 // top + 2 legs + 2 feet
            val chairKg = chairQty * chairCutM * (chDia * chDia / 162.2)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Cover Blocks Needed", "$coverQty", "nos", isPrimary = true),
                        CalcResultItem("Chair Bars (${chairQty} Nos)", UnitConverter.fmt(chairKg, p), "kg (Cut ${UnitConverter.fmt(chairCutM, 2)}m)", isPrimary = true),
                        CalcResultItem("Chair Clear Height", UnitConverter.fmt(chairH * 1000.0, 0), "mm")
                    ),
                    formula = "Qty = ceil(Area / Spacing²); Chair Cut = Top(250mm) + 2×LegH + 2×Foot(150mm)",
                    steps = listOf("Cover qty = ceil($area / (${cSp}²)) = $coverQty; Chairs = $chairQty nos"),
                    assumptions = "Uses 250mm top support and two 150mm bottom feet per chair bar."
                )
            )
        }
    )

    private fun mechanicalCouplerVsLapCalculator() = CalcToolSpec(
        id = "steel_couplers",
        title = "Rebar Coupler vs Lap Splice Comparison",
        titleHi = "रीबार कपलर बनाम लैप जॉइंट तुलना",
        subtitle = "Compare 50d Lap Steel Weight Cost vs Mechanical Rebar Couplers",
        category = CalcCategory.STEEL,
        keywords = listOf("coupler", "lap", "splice", "rebar", "comparison", "savings"),
        fields = listOf(
            CalcFieldSpec("dia", "Bar Diameter (mm)", "25", FieldUnitKind.NONE),
            CalcFieldSpec("joints", "Number of Bar Splices", "120", FieldUnitKind.COUNT),
            CalcFieldSpec("lapMult", "Lap Length Factor (× d)", "50", FieldUnitKind.NONE),
            CalcFieldSpec("steelRate", "Steel Price per kg (incl. Bending)", "75", FieldUnitKind.RATE),
            CalcFieldSpec("couplerRate", "Coupler Unit Price + Threading", "180", FieldUnitKind.RATE)
        ),
        compute = { ctx ->
            val dia = ctx.doubleOrNull("dia") ?: 25.0
            val joints = ctx.doubleOrNull("joints") ?: 120.0
            val mult = ctx.doubleOrNull("lapMult") ?: 50.0
            val sRate = ctx.doubleOrNull("steelRate") ?: 75.0
            val cRate = ctx.doubleOrNull("couplerRate") ?: 180.0
            if (dia <= 0 || joints <= 0 || mult <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Dia, joints & lap factor must be positive."))
            }
            val lapLenM = (mult * dia) / 1000.0
            val savedSteelKg = joints * lapLenM * (dia * dia / 162.2)
            val lapCost = savedSteelKg * sRate
            val couplerCost = joints * cRate
            val cur = ctx.settings.currencySymbol
            val netSavings = lapCost - couplerCost

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Lap Steel Saved", UnitConverter.fmt(savedSteelKg, 1), "kg (${UnitConverter.fmt(lapLenM, 2)}m/splice)", isPrimary = true),
                        CalcResultItem(if (netSavings >= 0) "Net Savings with Couplers" else "Extra Cost for Couplers", "$cur${UnitConverter.fmt(kotlin.math.abs(netSavings), 0)}", "", isPrimary = true),
                        CalcResultItem("50d Lap Steel Cost", "$cur${UnitConverter.fmt(lapCost, 0)}", ""),
                        CalcResultItem("Mechanical Coupler Cost", "$cur${UnitConverter.fmt(couplerCost, 0)}", "")
                    ),
                    formula = "Saved Steel = Joints × (Lap×d/1000) × (d²/162.2); Net = LapCost − CouplerCost",
                    steps = listOf("IS 456 recommends couplers for Ø32mm & Ø36mm instead of lapping."),
                    assumptions = "Pure material+labour cost comparison; couplers also reduce bar congestion in columns."
                )
            )
        }
    )

    private fun staircaseBbsCalculator() = CalcToolSpec(
        id = "steel_stair_bbs",
        title = "Staircase Waist Slab & Step Rebar",
        titleHi = "सीढ़ी वेस्ट स्लैब और स्टेप्स सरिया",
        subtitle = "Main Sloped Bars, Distribution Steel & Step Ties Weight",
        category = CalcCategory.STEEL,
        isPreliminaryStructural = true,
        keywords = listOf("staircase", "waist slab", "rebar", "bbs", "steps", "nosing"),
        fields = listOf(
            CalcFieldSpec("waistLen", "Inclined Flight Length", "3.8", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("flightW", "Stair Flight Width", "1.2", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("flights", "Number of Flights", "2", FieldUnitKind.COUNT),
            CalcFieldSpec("mainDia", "Main Sloped Bar Dia (mm)", "12", FieldUnitKind.NONE),
            CalcFieldSpec("mainSp", "Main Bar Spacing (mm)", "150", FieldUnitKind.NONE),
            CalcFieldSpec("distDia", "Distribution Bar Dia (mm)", "8", FieldUnitKind.NONE),
            CalcFieldSpec("distSp", "Distribution Spacing (mm)", "200", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val wl = ctx.lengthMeters("waistLen") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter flight length."))
            val fw = ctx.lengthMeters("flightW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter flight width."))
            val fl = ctx.doubleOrNull("flights") ?: 2.0
            val mDia = ctx.doubleOrNull("mainDia") ?: 12.0
            val mSp = ctx.doubleOrNull("mainSp") ?: 150.0
            val dDia = ctx.doubleOrNull("distDia") ?: 8.0
            val dSp = ctx.doubleOrNull("distSp") ?: 200.0
            if (wl <= 0 || fw <= 0 || fl <= 0 || mSp <= 0 || dSp <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All values must be positive."))
            }
            val mainN = ceil((fw * 1000.0) / mSp).toInt() + 1
            val mainLen = wl + 0.6 // +600mm landing anchorage
            val distN = ceil((wl * 1000.0) / dSp).toInt() + 1
            val distLen = fw + 0.1
            val mainKg = mainN * mainLen * (mDia * mDia / 162.2) * fl * 1.35 // top + bottom end laps
            val distKg = distN * distLen * (dDia * dDia / 162.2) * fl

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Staircase Steel", UnitConverter.fmt(mainKg + distKg, 1), "kg", isPrimary = true),
                        CalcResultItem("Main Sloped Bars (${mainN}/flight)", UnitConverter.fmt(mainKg, 1), "kg", isPrimary = true),
                        CalcResultItem("Distribution Bars (${distN}/flight)", UnitConverter.fmt(distKg, 1), "kg")
                    ),
                    formula = "Main N = ceil(W/Spacing)+1; Cut = WaistLen + Anchorage; Top mesh +35% approx.",
                    steps = listOf("${fl.toInt()} flights × (${UnitConverter.fmt(mainKg / fl, 1)} + ${UnitConverter.fmt(distKg / fl, 1)}) kg"),
                    assumptions = "Includes 600mm anchorage into landing beams & 35% allowance for top negative steel."
                )
            )
        }
    )
}

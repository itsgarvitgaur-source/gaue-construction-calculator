package com.example.features.diagrams

import com.example.core.preferences.UserSettings
import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

enum class DiagramViewMode(val label: String) {
    VIEW_3D("Isometric"),
    PLAN_2D("2D Plan"),
    ELEVATION("Elevation"),
    SECTION("Section"),
    REINFORCEMENT("Rebar View"),
    DIMENSION_2D("Dimensions")
}

data class DiagramInputSnapshot(
    val toolId: String,
    val inputs: Map<String, String>,
    val lengthUnits: Map<String, LengthUnit>,
    val settings: UserSettings
) {
    val p: Int get() = settings.decimalPrecision

    fun raw(key: String, fallback: String = ""): String =
        inputs[key]?.trim()?.takeIf { it.isNotEmpty() } ?: fallback

    fun dbl(key: String, fallback: Double): Double =
        inputs[key]?.trim()?.toDoubleOrNull()?.takeIf { !it.isNaN() && !it.isInfinite() } ?: fallback

    fun lenMeters(key: String, fallbackMeters: Double): Double {
        val v = inputs[key]?.trim()?.toDoubleOrNull() ?: return fallbackMeters
        val u = lengthUnits[key] ?: LengthUnit.M
        return (v * u.toMeters).coerceAtLeast(0.0)
    }

    fun lenLabel(key: String, fallbackMeters: Double): String {
        val u = lengthUnits[key] ?: LengthUnit.M
        val v = inputs[key]?.trim()?.toDoubleOrNull()
        return if (v != null && v >= 0.0) {
            "${UnitConverter.fmt(v, p)} ${u.symbol}"
        } else {
            val conv = UnitConverter.fromMeters(fallbackMeters, u)
            "${UnitConverter.fmt(conv, p)} ${u.symbol}"
        }
    }

    fun mmLabel(key: String, fallbackMm: Double): String {
        val v = dbl(key, fallbackMm).coerceAtLeast(0.0)
        return "${UnitConverter.fmt(v, 0)} mm"
    }
}

fun availableViewsForTool(toolId: String): List<DiagramViewMode> = when (toolId) {
    "struct_slab" -> listOf(DiagramViewMode.VIEW_3D, DiagramViewMode.PLAN_2D, DiagramViewMode.SECTION, DiagramViewMode.REINFORCEMENT)
    "struct_beam", "struct_lintel", "struct_ground_beams" -> listOf(DiagramViewMode.ELEVATION, DiagramViewMode.SECTION, DiagramViewMode.REINFORCEMENT, DiagramViewMode.VIEW_3D)
    "struct_rect_column", "struct_circ_column", "struct_pedestal" -> listOf(DiagramViewMode.VIEW_3D, DiagramViewMode.ELEVATION, DiagramViewMode.SECTION, DiagramViewMode.REINFORCEMENT)
    "struct_isolated_footing", "struct_raft_strip", "struct_pile" -> listOf(DiagramViewMode.VIEW_3D, DiagramViewMode.PLAN_2D, DiagramViewMode.SECTION, DiagramViewMode.REINFORCEMENT)
    "struct_stair_straight", "struct_stair_doglegged" -> listOf(DiagramViewMode.ELEVATION, DiagramViewMode.PLAN_2D, DiagramViewMode.VIEW_3D)
    "struct_retaining_wall", "struct_arch_dome" -> listOf(DiagramViewMode.SECTION, DiagramViewMode.ELEVATION)
    "struct_wall_multi", "masonry_bricks", "masonry_blocks", "masonry_stone", "masonry_boundary_fence" -> listOf(DiagramViewMode.ELEVATION, DiagramViewMode.PLAN_2D, DiagramViewMode.VIEW_3D)
    "struct_misc_elements", "struct_roofing" -> listOf(DiagramViewMode.ELEVATION, DiagramViewMode.PLAN_2D, DiagramViewMode.VIEW_3D)
    "conc_pcc", "conc_rcc_mix", "conc_rmc", "conc_tube_curb", "util_water_tank" -> listOf(DiagramViewMode.VIEW_3D, DiagramViewMode.SECTION, DiagramViewMode.DIMENSION_2D)
    "finish_plaster", "finish_paint_putty", "finish_waterproofing", "finish_tiles_flooring", "finish_trimix_epoxy",
    "finish_marble_granite", "finish_false_ceiling", "finish_door_window_glass", "finish_asphalt_road", "finish_anti_termite", "masonry_interlocking_paver" ->
        listOf(DiagramViewMode.PLAN_2D, DiagramViewMode.SECTION, DiagramViewMode.DIMENSION_2D)
    "earth_excavation_pit", "earth_sloped_excavation", "earth_backfill", "earth_cut_fill", "earth_embankment_road" ->
        listOf(DiagramViewMode.SECTION, DiagramViewMode.VIEW_3D, DiagramViewMode.PLAN_2D)
    "steel_rebar_weight", "steel_multi_dia", "steel_member_reinf", "steel_hook_bend_ld", "steel_stirrup_cutting",
    "steel_structural_sections", "steel_bbs_beam_column", "steel_footing_stair_rebar", "steel_helical_spiral" ->
        listOf(DiagramViewMode.REINFORCEMENT, DiagramViewMode.DIMENSION_2D)
    "infra_road_layers", "infra_culvert_pier" -> listOf(DiagramViewMode.SECTION, DiagramViewMode.PLAN_2D)
    "conc_cube_strength", "conc_pour_planning", "conc_curing_water", "conc_slump_yield",
    "conc_construction_joint", "conc_screeding", "conc_shuttering_area" -> listOf(DiagramViewMode.SECTION, DiagramViewMode.DIMENSION_2D)
    "steel_cutting_opt", "steel_tonnage_density", "steel_column_ties", "steel_beam_bars",
    "steel_slab_two_way", "steel_welded_mesh", "steel_plate_bolt", "steel_cover_chair",
    "steel_couplers", "steel_stair_bbs" -> listOf(DiagramViewMode.REINFORCEMENT, DiagramViewMode.DIMENSION_2D)
    "soil_bearing_pressure", "soil_pile_cap_qty", "soil_gabion_retaining", "soil_compaction_layers" ->
        listOf(DiagramViewMode.SECTION, DiagramViewMode.PLAN_2D)
    "masonry_opening_deduct", "masonry_parapet_boundary", "masonry_arch_lintel",
    "finish_road_kerb_drain", "highrise_lift_core", "util_room_lighting" ->
        listOf(DiagramViewMode.PLAN_2D, DiagramViewMode.SECTION)
    "basic_volume_surface" -> listOf(DiagramViewMode.VIEW_3D, DiagramViewMode.DIMENSION_2D)
    else -> listOf(DiagramViewMode.DIMENSION_2D, DiagramViewMode.PLAN_2D)
}

fun diagramCaptionForTool(s: DiagramInputSnapshot): String {
    return when (s.toolId) {
        "basic_area" -> "${s.raw("shape", "Rectangle")}  •  Primary=${s.lenLabel("a", 10.0)}"
        "basic_volume_surface" -> "${s.raw("shape", "Cuboid / Box")}  •  ${s.lenLabel("l", 5.0)} × H=${s.lenLabel("h", 3.0)}"
        "struct_slab" -> {
            val type = s.raw("slabType", "Two-Way Slab")
            val lx = s.lenMeters("lx", 4.0).coerceAtLeast(0.1)
            val ly = if (type == "Square Slab") lx else s.lenMeters("ly", 5.2).coerceAtLeast(0.1)
            val t = s.lenMeters("t", 0.125).coerceAtLeast(0.02)
            val vol = if (type == "Circular Slab") PI * (lx / 2.0) * (lx / 2.0) * t else lx * ly * t
            "$type  •  Slab Vol ≈ ${UnitConverter.fmt(vol, s.p)} m³"
        }
        "struct_beam", "struct_lintel", "struct_ground_beams" -> {
            val isL = s.toolId == "struct_lintel"
            val isG = s.toolId == "struct_ground_beams"
            val type = when {
                isL -> s.raw("lintelType", "Lintel + Chajja Sunshade")
                isG -> s.raw("gBeamType", "Plinth Beam")
                else -> s.raw("beamType", "Rectangular Beam")
            }
            val l = when {
                isL -> s.lenMeters("openW", 1.5) + 2.0 * s.lenMeters("bearing", 0.15)
                isG -> s.lenMeters("len", 45.0)
                type == "Circular / Ring Beam" -> PI * s.lenMeters("ringDia", 6.0)
                else -> s.lenMeters("l", 5.0)
            }
            val b = s.lenMeters(if (isL) "lW" else "b", 0.23)
            val d = if (type == "Square Beam") b else s.lenMeters(if (isL) "lD" else "d", 0.45)
            "$type  •  Run=${UnitConverter.fmt(l, s.p)}m  •  ${UnitConverter.fmt(b * 1000, 0)}×${UnitConverter.fmt(d * 1000, 0)}mm"
        }
        "struct_rect_column", "struct_circ_column", "struct_pedestal" -> {
            val isPed = s.toolId == "struct_pedestal"
            val type = if (isPed) s.raw("pedType", "Rectangular Pedestal")
            else if (s.toolId == "struct_circ_column") "Circular / Round Column"
            else s.raw("colType", "Rectangular Column")
            val h = s.lenMeters("h", if (isPed) 0.9 else 3.2)
            val n = s.dbl("count", 1.0).coerceAtLeast(1.0)
            "$type (${n.roundToInt()} Nos)  •  H=${UnitConverter.fmt(h, s.p)}m"
        }
        "struct_isolated_footing" -> {
            val type = s.raw("footingType", "Sloped Footing")
            val bl = s.lenMeters("bl", 2.2)
            val bw = s.lenMeters("bw", 1.8)
            val d1 = s.lenMeters("d1", 0.25)
            val d2 = s.lenMeters("d2", 0.35)
            val dimTxt = when (type) {
                "Circular Footing" -> "Ø${s.lenLabel("dia", 2.2)}"
                "Square Footing" -> "${s.lenLabel("bw", 1.8)} × ${s.lenLabel("bw", 1.8)}"
                else -> "${UnitConverter.fmt(bl, s.p)}×${UnitConverter.fmt(bw, s.p)}m"
            }
            "$type  •  $dimTxt  •  D=${UnitConverter.fmt(d1 + if (type in setOf("Sloped Footing", "Tapered Footing", "Stepped Footing")) d2 else 0.0, s.p)}m"
        }
        "struct_raft_strip" -> {
            val type = s.raw("type", "Raft / Mat Foundation")
            val l = s.lenMeters("l", 12.0)
            val w = s.lenMeters("w", 9.0)
            val t = s.lenMeters("t", 0.45)
            "$type  •  ${UnitConverter.fmt(l, s.p)}×${UnitConverter.fmt(w, s.p)}×${UnitConverter.fmt(t, s.p)}m"
        }
        "struct_pile" -> {
            val type = s.raw("pileType", "Bored Cast-in-Situ Pile")
            "$type  •  ${s.lenLabel("dia", 0.5)} × L=${s.lenLabel("depth", 12.0)}"
        }
        "struct_stair_straight", "struct_stair_doglegged" -> {
            val type = if (s.toolId == "struct_stair_doglegged") "Dog-Legged Staircase" else s.raw("stairType", "Straight Staircase")
            val fh = s.lenMeters("floorH", 3.0)
            val r = s.lenMeters("riser", 0.15).coerceAtLeast(0.05)
            val risers = max(2, (fh / r).roundToInt())
            "$type  •  $risers Risers  •  H=${UnitConverter.fmt(fh, s.p)}m"
        }
        "struct_retaining_wall" -> "${s.raw("retType", "Cantilever T-Wall")}  •  H=${s.lenLabel("h", 3.5)}  •  Base=${s.lenLabel("baseW", 2.4)}"
        "struct_wall_multi" -> "${s.raw("wallType", "Shear Wall")}  •  H=${s.lenLabel("h", 3.5)}  •  T=${s.lenLabel("t", 0.25)}"
        "struct_misc_elements" -> "${s.raw("elemType", "Concrete Ramp")}  •  ${s.lenLabel("l", 6.0)} × ${s.lenLabel("w", 3.0)}"
        "struct_roofing" -> "${s.raw("roofType", "Double-Slope / Gable Roof")}  •  Span ${s.lenLabel("span", 18.0)}"
        "struct_arch_dome" -> "${s.raw("archType", "Semicircular Arch")}  •  Span ${s.lenLabel("span", 4.0)}"
        "conc_pcc", "conc_rcc_mix", "conc_rmc" -> {
            val vol = if (s.toolId == "conc_pcc") {
                s.lenMeters("l", 10.0) * s.lenMeters("w", 5.0) * s.lenMeters("t", 0.1)
            } else s.dbl("vol", 10.0)
            "Wet Vol = ${UnitConverter.fmt(vol, s.p)} m³  •  Mix ${s.raw("mix", "M20")}"
        }
        "masonry_bricks", "masonry_blocks" -> {
            val shape = s.raw("wallShape", "Straight Wall")
            val l = if (shape == "Curved / Circular Wall") PI * s.lenMeters("dia", 5.0) else s.lenMeters("wallL", 10.0)
            val h = s.lenMeters("wallH", 3.0)
            val ded = s.dbl("deductArea", 2.5)
            "$shape  •  Net Area ≈ ${UnitConverter.fmt((l * h - ded).coerceAtLeast(0.0), s.p)} m²"
        }
        "finish_plaster" -> {
            val net = (s.lenMeters("l", 10.0) * s.lenMeters("h", 3.0) - s.dbl("deduct", 0.0)).coerceAtLeast(0.0)
            "Net Plaster Area = ${UnitConverter.fmt(net, s.p)} m² (${s.raw("ratio", "1:4")})"
        }
        "finish_tiles_flooring" -> {
            val rl = s.lenMeters("roomL", 5.0); val rw = s.lenMeters("roomW", 4.0)
            "Floor Area = ${UnitConverter.fmt(rl * rw, s.p)} m² (${UnitConverter.fmt(rl * rw * 10.7639, 0)} sq.ft)"
        }
        "earth_excavation_pit", "earth_sloped_excavation" -> {
            val l = s.lenMeters("l", 2.5); val w = s.lenMeters("w", 2.0); val d = s.lenMeters("d", 1.8)
            val n = s.dbl("count", 6.0).coerceAtLeast(1.0)
            "Excavation = ${UnitConverter.fmt(l * w * d * n, s.p)} m³"
        }
        "steel_rebar_weight" -> {
            val d = s.dbl("dia", 12.0); val l = s.lenMeters("len", 12.0); val n = s.dbl("count", 1.0).coerceAtLeast(1.0)
            "Weight = ${UnitConverter.fmt((d * d / 162.2) * l * n, s.p)} kg (Ø${d.roundToInt()}mm)"
        }
        "util_water_tank" -> "${s.raw("tankShape", "Rectangular Tank")} • H=${s.lenLabel("h", 2.5)}"
        "util_septic_tank" -> "Septic Tank (${s.raw("users", "15")} Users)"
        "util_rainwater_harvest" -> "Roof ${s.raw("area", "150")} m² • Rain ${s.raw("rain", "850")} mm"
        "util_electrical_ac_solar" -> "${s.raw("mode", "Room AC")} • ${s.lenLabel("l", 5.0)}×${s.lenLabel("w", 4.0)}"
        "masonry_stone" -> "Stone Wall ${s.lenLabel("l", 10.0)}×${s.lenLabel("h", 2.0)}×${s.lenLabel("t", 0.45)}"
        "masonry_interlocking_paver" -> "Paving ${s.lenLabel("l", 15.0)}×${s.lenLabel("w", 6.0)}"
        "finish_marble_granite" -> "Stone Area ${s.raw("area", "650")} sq.ft (${s.raw("slabL", "6")}×${s.raw("slabW", "3")} ft)"
        "finish_false_ceiling" -> "Ceiling ${s.lenLabel("l", 6.0)}×${s.lenLabel("w", 4.5)}"
        "finish_wood_timber" -> "${s.raw("woodType", "Timber")} • L=${s.raw("lenFt", "8")} ft"
        "finish_asphalt_road" -> "Road ${s.lenLabel("l", 100.0)}×${s.lenLabel("w", 7.0)} (${s.raw("thickMm", "50")}mm)"
        "finish_anti_termite" -> "Plinth ${s.lenLabel("l", 15.0)}×${s.lenLabel("w", 10.0)}"
        "steel_bbs_beam_column" -> "${s.raw("memberType", "RCC Beam BBS")} • ${s.lenLabel("span", 4.5)}"
        "steel_footing_stair_rebar" -> "${s.raw("mode", "Footing Mat")} • ${s.lenLabel("lx", 2.0)}×${s.lenLabel("ly", 2.0)}"
        "steel_helical_spiral" -> "Helix Ø${s.raw("dia", "500")}mm • H=${s.lenLabel("h", 10.0)}"
        "earth_soil_bulking" -> "h₁=${s.raw("hDamp", "200")}mm → h₂=${s.raw("hSat", "162")}mm"
        "site_stair_pitch_check" -> "R=${s.raw("riserMm", "150")}mm • G=${s.raw("treadMm", "300")}mm"
        "site_cost_estimator" -> "Area ${s.raw("areaSqFt", "1200")} sq.ft @ ${s.raw("ratePerSqFt", "1850")}"
        "infra_road_layers" -> "Road ${s.lenLabel("len", 500.0)}×${s.lenLabel("width", 7.0)} • GSB ${s.raw("gsbMm", "200")}+WMM ${s.raw("wmmMm", "250")}mm"
        "infra_culvert_pier" -> "${s.raw("infraType", "Box Culvert")} • Span ${s.lenLabel("span", 4.0)} × H=${s.lenLabel("height", 3.0)}"
        "conc_pour_planning" -> "Pour ${s.raw("vol", "48")} m³ @ ${s.raw("pumpRate", "12")} m³/hr"
        "conc_curing_water" -> "Curing ${s.raw("area", "120")} m² • ${s.raw("days", "10")} Days (${s.raw("method", "Ponding")})"
        "conc_floor_building" -> "Area ${s.raw("floorArea", "1200")} sq.ft × ${s.raw("floors", "3")} Floors"
        "conc_slump_yield" -> "Batch ${s.raw("batchWtKg", "2410")} kg • Bucket ${s.raw("potWtKg", "16.8")} kg"
        "conc_grout_micro" -> "Pocket ${s.lenLabel("l", 0.8)}×${s.lenLabel("w", 0.8)} × ${s.raw("t", "50")}mm"
        "conc_shuttering_area" -> "${s.raw("member", "Slab")} • ${s.lenLabel("l", 10.0)}×${s.lenLabel("w", 6.0)}"
        "conc_admixture_dosage" -> "${s.raw("concVol", "25")} m³ @ ${s.raw("dosagePct", "0.8")}% Admix"
        "steel_cutting_opt" -> "Ø${s.raw("dia", "16")}mm • ${s.raw("stockLen", "12")}m Stock Optimization"
        "steel_tonnage_density" -> "${s.raw("member", "Slab")} • Qty=${s.raw("qty", "25")}"
        "steel_column_ties" -> "Col ${s.raw("b", "300")}×${s.raw("d", "450")}mm • H=${s.lenLabel("h", 3.2)}"
        "steel_beam_bars" -> "Beam ${s.lenLabel("span", 5.0)} • ${s.raw("b", "250")}×${s.raw("d", "450")}mm"
        "steel_slab_two_way" -> "2-Way Slab ${s.lenLabel("lx", 4.0)}×${s.lenLabel("ly", 5.2)} • Ø${s.raw("mainDia", "10")}mm"
        "steel_welded_mesh" -> "${s.raw("meshType", "BRC Mesh")} • ${s.raw("area", "180")} m²"
        "steel_cover_chair" -> "Area ${s.raw("area", "150")} m² • Slab ${s.raw("slabT", "150")}mm"
        "steel_couplers" -> "Ø${s.raw("dia", "25")}mm • ${s.raw("joints", "120")} Splices (${s.raw("lapMult", "50")}d)"
        "steel_stair_bbs" -> "Stair ${s.lenLabel("waistLen", 3.8)}×${s.lenLabel("flightW", 1.2)} (${s.raw("flights", "2")} Flights)"
        "soil_swell_shrink" -> "Bank ${s.raw("bankVol", "500")} m³ (+${s.raw("swellPct", "25")}% Swell)"
        "soil_dewatering" -> "Pit ${s.lenLabel("pitL", 18.0)}×${s.lenLabel("pitW", 12.0)} • Pump ${s.raw("pumpLpm", "500")} LPM"
        "soil_compaction_layers" -> "Fill ${s.raw("area", "1500")} m² × ${s.lenLabel("fillDepth", 0.9)}"
        "soil_sand_fill" -> "Plinth ${s.raw("area", "1000")} sq.ft × ${s.raw("depthMm", "300")}mm"
        "soil_fdt_check" -> "Core ${s.raw("wetMassG", "1980")}g / ${s.raw("holeVolCc", "1000")}cc vs MDD ${s.raw("labMdd", "1.82")}"
        "masonry_parapet_boundary" -> "Wall L=${s.lenLabel("perim", 60.0)} × H=${s.lenLabel("h", 1.8)}"
        "masonry_arch_lintel" -> "Arch Span ${s.lenLabel("span", 2.4)} × Rise ${s.lenLabel("rise", 0.6)}"
        "finish_tile_adhesive" -> "Area ${s.raw("area", "600")} sq.ft • Bed ${s.raw("bedMm", "5")}mm"
        "finish_gypsum_plaster" -> "Gypsum ${s.raw("area", "1200")} sq.ft @ ${s.raw("thickMm", "12")}mm"
        "finish_drywall_partition" -> "Drywall ${s.lenLabel("len", 8.0)}×${s.lenLabel("h", 3.0)}"
        "finish_plywood_laminate" -> "Carpentry ${s.raw("areaSqFt", "320")} sq.ft (8×4 Sheets)"
        "finish_skirting_dado" -> "Room ${s.lenLabel("l", 4.5)}×${s.lenLabel("w", 3.6)} • H=${s.raw("skirtingH", "100")}mm"
        "finish_stone_cladding" -> "Cladding ${s.raw("area", "450")} sq.ft"
        "util_voltage_drop_wire" -> "${s.raw("loadKw", "12")} kW (${s.raw("phase", "3-Ph")}) • ${s.lenLabel("runM", 45.0)}"
        "highrise_area_fsi" -> "Plot ${s.raw("plotArea", "4000")} sq.ft • ${s.raw("floors", "4")} Floors"
        "site_rate_analysis" -> "Mat ${s.raw("matCost", "4200")} + Lab ${s.raw("labCost", "1100")} (+${s.raw("profitPct", "15")}%)"
        "site_bar_progress" -> "Area ${s.raw("areaSqFt", "2400")} sq.ft @ ${s.raw("rateSqFt", "1950")}/sq.ft"
        else -> "Live Dimensioned Construction Diagram"
    }
}



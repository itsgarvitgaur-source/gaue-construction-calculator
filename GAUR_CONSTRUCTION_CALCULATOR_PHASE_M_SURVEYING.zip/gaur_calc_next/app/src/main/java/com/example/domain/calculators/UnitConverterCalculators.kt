package com.example.domain.calculators

import com.example.domain.units.EngineeringUnitConverter
import com.example.domain.units.ForceUnit
import com.example.domain.units.PressureUnit
import com.example.domain.units.SpeedUnit
import com.example.domain.units.TempUnit
import com.example.domain.units.UnitConverter
import com.example.domain.units.WeightUnit
import kotlin.math.PI
import kotlin.math.atan
import kotlin.math.tan

object UnitConverterCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        weightMassConverter(),
        pressureStressConverter(),
        forceLoadConverter(),
        temperatureConverter(),
        densitySpeedConverter(),
        angleSlopeConverter()
    )

    private fun weightMassConverter() = CalcToolSpec(
        id = "conv_weight_mass",
        title = "Weight & Mass Converter",
        titleHi = "वजन और द्रव्यमान कनवर्टर",
        subtitle = "kg, Quintal, Metric Ton (MT), Gram, Pound (lb), Ounce & US Ton",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("weight", "mass", "kg", "ton", "quintal", "pound", "lb", "ounce", "converter"),
        fields = listOf(
            CalcFieldSpec("val", "Weight Value", "100", FieldUnitKind.NONE),
            CalcFieldSpec("unit", "From Unit", WeightUnit.KG.symbol, options = WeightUnit.entries.map { it.symbol })
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid weight."))
            if (v < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Weight cannot be negative."))
            val from = WeightUnit.entries.firstOrNull { it.symbol == ctx.raw("unit") } ?: WeightUnit.KG
            val kg = EngineeringUnitConverter.convertWeight(v, from, WeightUnit.KG)
            val mt = EngineeringUnitConverter.convertWeight(v, from, WeightUnit.MT)
            val quintal = EngineeringUnitConverter.convertWeight(v, from, WeightUnit.QUINTAL)
            val lb = EngineeringUnitConverter.convertWeight(v, from, WeightUnit.LB)
            val g = EngineeringUnitConverter.convertWeight(v, from, WeightUnit.G)
            val usTon = EngineeringUnitConverter.convertWeight(v, from, WeightUnit.SHORT_TON)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Kilograms", UnitConverter.fmt(kg, p), "kg", isPrimary = true),
                        CalcResultItem("Metric Tons", UnitConverter.fmt(mt, p + 2), "MT", isPrimary = true),
                        CalcResultItem("Quintal (100 kg)", UnitConverter.fmt(quintal, p + 1), "Qtl"),
                        CalcResultItem("Pounds", UnitConverter.fmt(lb, p), "lb"),
                        CalcResultItem("Grams", UnitConverter.fmt(g, 1), "g"),
                        CalcResultItem("US Short Tons", UnitConverter.fmt(usTon, p + 2), "ton")
                    ),
                    formula = "1 Metric Ton = 10 Quintal = 1000 kg = 2204.62 lb",
                    steps = listOf("${UnitConverter.fmt(v, p)} ${from.symbol} = ${UnitConverter.fmt(kg, p + 1)} kg"),
                    assumptions = "Exact avoirdupois pound (1 lb = 0.45359237 kg)."
                )
            )
        }
    )

    private fun pressureStressConverter() = CalcToolSpec(
        id = "conv_pressure_stress",
        title = "Pressure & Concrete Stress Converter",
        titleHi = "दबाव और कंक्रीट स्ट्रेंथ कनवर्टर",
        subtitle = "MPa (N/mm²), PSI, kg/cm², kPa (kN/m²), Bar & Pa",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("pressure", "stress", "mpa", "psi", "bar", "kpa", "kg/cm2", "strength", "sbc"),
        fields = listOf(
            CalcFieldSpec("val", "Pressure / Stress Value", "25", FieldUnitKind.NONE),
            CalcFieldSpec("unit", "From Unit", PressureUnit.MPA.symbol, options = PressureUnit.entries.map { it.symbol })
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid pressure."))
            val from = PressureUnit.entries.firstOrNull { it.symbol == ctx.raw("unit") } ?: PressureUnit.MPA
            val mpa = EngineeringUnitConverter.convertPressure(v, from, PressureUnit.MPA)
            val psi = EngineeringUnitConverter.convertPressure(v, from, PressureUnit.PSI)
            val kpa = EngineeringUnitConverter.convertPressure(v, from, PressureUnit.KPA)
            val kgcm2 = EngineeringUnitConverter.convertPressure(v, from, PressureUnit.KG_CM2)
            val bar = EngineeringUnitConverter.convertPressure(v, from, PressureUnit.BAR)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("MPa (N/mm²)", UnitConverter.fmt(mpa, p + 1), "MPa", isPrimary = true),
                        CalcResultItem("PSI (lb/in²)", UnitConverter.fmt(psi, p), "PSI", isPrimary = true),
                        CalcResultItem("kPa (kN/m²)", UnitConverter.fmt(kpa, p), "kPa"),
                        CalcResultItem("kg/cm²", UnitConverter.fmt(kgcm2, p + 1), "kg/cm²"),
                        CalcResultItem("Bar", UnitConverter.fmt(bar, p + 1), "Bar")
                    ),
                    formula = "1 MPa = 1 N/mm² = 1000 kN/m² = 145.038 PSI = 10.197 kg/cm²",
                    steps = listOf("${UnitConverter.fmt(v, p)} ${from.symbol} = ${UnitConverter.fmt(kpa, p)} kPa"),
                    assumptions = "Ideal for cube compressive strength (MPa ↔ PSI) and soil bearing capacity (kN/m²)."
                )
            )
        }
    )

    private fun forceLoadConverter() = CalcToolSpec(
        id = "conv_force_load",
        title = "Force & Structural Load Converter",
        titleHi = "बल और लोड कनवर्टर",
        subtitle = "kN, Newton (N), kgf, Ton-force (tf), lbf & kip",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("force", "load", "kn", "newton", "kgf", "kip", "lbf", "ton"),
        fields = listOf(
            CalcFieldSpec("val", "Force / Load Value", "100", FieldUnitKind.NONE),
            CalcFieldSpec("unit", "From Unit", ForceUnit.KN.symbol, options = ForceUnit.entries.map { it.symbol })
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid force."))
            val from = ForceUnit.entries.firstOrNull { it.symbol == ctx.raw("unit") } ?: ForceUnit.KN
            val kn = EngineeringUnitConverter.convertForce(v, from, ForceUnit.KN)
            val n = EngineeringUnitConverter.convertForce(v, from, ForceUnit.N)
            val kgf = EngineeringUnitConverter.convertForce(v, from, ForceUnit.KGF)
            val tf = EngineeringUnitConverter.convertForce(v, from, ForceUnit.TON_F)
            val kip = EngineeringUnitConverter.convertForce(v, from, ForceUnit.KIP)
            val lbf = EngineeringUnitConverter.convertForce(v, from, ForceUnit.LBF)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Kilonewton", UnitConverter.fmt(kn, p), "kN", isPrimary = true),
                        CalcResultItem("Kilogram-force", UnitConverter.fmt(kgf, p), "kgf", isPrimary = true),
                        CalcResultItem("Metric Ton-force", UnitConverter.fmt(tf, p + 1), "tf"),
                        CalcResultItem("Kips (1000 lbf)", UnitConverter.fmt(kip, p + 1), "kip"),
                        CalcResultItem("Pound-force", UnitConverter.fmt(lbf, p), "lbf"),
                        CalcResultItem("Newtons", UnitConverter.fmt(n, 0), "N")
                    ),
                    formula = "1 kN = 1000 N = 101.97 kgf = 0.2248 kip",
                    steps = listOf("${UnitConverter.fmt(v, p)} ${from.symbol} = ${UnitConverter.fmt(n, 1)} N"),
                    assumptions = "Standard gravity g = 9.80665 m/s²."
                )
            )
        }
    )

    private fun temperatureConverter() = CalcToolSpec(
        id = "conv_temperature",
        title = "Temperature Converter (°C / °F / K)",
        titleHi = "तापमान कनवर्टर",
        subtitle = "Concrete Curing, Bitumen Heating & Weather Temperature Conversion",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("temperature", "celsius", "fahrenheit", "kelvin", "curing", "bitumen"),
        fields = listOf(
            CalcFieldSpec("val", "Temperature", "27", FieldUnitKind.NONE),
            CalcFieldSpec("unit", "From Unit", TempUnit.CELSIUS.symbol, options = TempUnit.entries.map { it.symbol })
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid temperature."))
            val from = TempUnit.entries.firstOrNull { it.symbol == ctx.raw("unit") } ?: TempUnit.CELSIUS
            val c = EngineeringUnitConverter.convertTemperature(v, from, TempUnit.CELSIUS)
            val f = EngineeringUnitConverter.convertTemperature(v, from, TempUnit.FAHRENHEIT)
            val k = EngineeringUnitConverter.convertTemperature(v, from, TempUnit.KELVIN)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Celsius", UnitConverter.fmt(c, p), "°C", isPrimary = true),
                        CalcResultItem("Fahrenheit", UnitConverter.fmt(f, p), "°F", isPrimary = true),
                        CalcResultItem("Kelvin", UnitConverter.fmt(k, p), "K")
                    ),
                    formula = "°F = (°C × 9/5) + 32; K = °C + 273.15",
                    steps = listOf("${UnitConverter.fmt(v, p)} ${from.symbol} → ${UnitConverter.fmt(c, p)} °C / ${UnitConverter.fmt(f, p)} °F"),
                    assumptions = "Recommended fresh concrete pouring temperature per IS 456 / ACI: 5°C–35°C."
                )
            )
        }
    )

    private fun densitySpeedConverter() = CalcToolSpec(
        id = "conv_density_speed",
        title = "Material Density & Speed Converter",
        titleHi = "घनत्व और गति कनवर्टर",
        subtitle = "Unit Weight (kg/m³ ↔ lb/ft³) Reference + Speed (m/s, km/h, mph)",
        category = CalcCategory.CONVERTERS,
        typeFieldKey = "mode",
        keywords = listOf("density", "unit weight", "speed", "kg/m3", "pcf", "km/h", "mph", "material"),
        fields = listOf(
            CalcFieldSpec("mode", "Converter Mode", "Density / Unit Weight", options = listOf("Density / Unit Weight", "Speed / Velocity")),
            CalcFieldSpec("val", "Value", "2400", FieldUnitKind.NONE),
            CalcFieldSpec(
                key = "densityUnit", label = "From Density Unit", defaultValue = "kg/m³",
                options = listOf("kg/m³", "g/cm³", "lb/ft³ (pcf)", "kN/m³"),
                visibleWhen = { it["mode"] != "Speed / Velocity" }
            ),
            CalcFieldSpec(
                key = "speedUnit", label = "From Speed Unit", defaultValue = SpeedUnit.KMPH.symbol,
                options = SpeedUnit.entries.map { it.symbol },
                visibleWhen = { it["mode"] == "Speed / Velocity" }
            )
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid value."))
            if (ctx.raw("mode") == "Speed / Velocity") {
                val from = SpeedUnit.entries.firstOrNull { it.symbol == ctx.raw("speedUnit") } ?: SpeedUnit.KMPH
                val kmph = EngineeringUnitConverter.convertSpeed(v, from, SpeedUnit.KMPH)
                val mps = EngineeringUnitConverter.convertSpeed(v, from, SpeedUnit.MPS)
                val mph = EngineeringUnitConverter.convertSpeed(v, from, SpeedUnit.MPH)
                val ftps = EngineeringUnitConverter.convertSpeed(v, from, SpeedUnit.FTPS)
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("km/h", UnitConverter.fmt(kmph, p), "km/h", isPrimary = true),
                            CalcResultItem("m/s", UnitConverter.fmt(mps, p + 1), "m/s", isPrimary = true),
                            CalcResultItem("mph", UnitConverter.fmt(mph, p), "mph"),
                            CalcResultItem("ft/s", UnitConverter.fmt(ftps, p), "ft/s")
                        ),
                        formula = "1 m/s = 3.6 km/h = 2.2369 mph",
                        steps = listOf("${UnitConverter.fmt(v, p)} ${from.symbol} = ${UnitConverter.fmt(mps, p + 1)} m/s"),
                        assumptions = "Standard velocity conversion."
                    )
                )
            } else {
                val kgM3 = when (ctx.raw("densityUnit")) {
                    "g/cm³" -> v * 1000.0
                    "lb/ft³ (pcf)" -> v * 16.018463
                    "kN/m³" -> v * 101.9716
                    else -> v
                }
                val gCm3 = kgM3 / 1000.0
                val pcf = kgM3 / 16.018463
                val knM3 = kgM3 / 101.9716
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("kg/m³", UnitConverter.fmt(kgM3, p), "kg/m³", isPrimary = true),
                            CalcResultItem("kN/m³ (Unit Wt)", UnitConverter.fmt(knM3, p), "kN/m³", isPrimary = true),
                            CalcResultItem("lb/ft³ (PCF)", UnitConverter.fmt(pcf, p), "lb/ft³"),
                            CalcResultItem("g/cm³ (Sp.Gr.)", UnitConverter.fmt(gCm3, 3), "g/cm³")
                        ),
                        formula = "1 g/cm³ = 1000 kg/m³ = 9.80665 kN/m³ = 62.428 lb/ft³",
                        steps = listOf("${UnitConverter.fmt(v, p)} ${ctx.raw("densityUnit")} = ${UnitConverter.fmt(kgM3, p)} kg/m³"),
                        assumptions = "Ref IS 875: Steel 7850, RCC 2500, PCC 2400, Brick 1920, Water 1000 kg/m³."
                    )
                )
            }
        }
    )

    private fun angleSlopeConverter() = CalcToolSpec(
        id = "conv_angle_slope",
        title = "Angle, Radian & Roof Pitch Converter",
        titleHi = "कोण, रेडियन और ढलान कनवर्टर",
        subtitle = "Degrees (°), Radians, Gradians, Slope (%), Ratio (1:N) & Pitch (X/12)",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("angle", "degree", "radian", "grad", "pitch", "slope", "1:N"),
        fields = listOf(
            CalcFieldSpec("val", "Input Value", "30", FieldUnitKind.NONE),
            CalcFieldSpec("unit", "From Format", "Degrees (°)", options = listOf("Degrees (°)", "Radians (rad)", "Gradians (gon)", "Slope (%)", "Roof Pitch (X / 12)"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid value."))
            val deg = when (ctx.raw("unit")) {
                "Radians (rad)" -> Math.toDegrees(v)
                "Gradians (gon)" -> v * 0.9
                "Slope (%)" -> Math.toDegrees(atan(v / 100.0))
                "Roof Pitch (X / 12)" -> Math.toDegrees(atan(v / 12.0))
                else -> v
            }
            val rad = Math.toRadians(deg)
            val grad = deg / 0.9
            val pct = tan(rad) * 100.0
            val pitch12 = tan(rad) * 12.0
            val ratioN = if (kotlin.math.abs(pct) > 1e-6) 100.0 / pct else Double.POSITIVE_INFINITY
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Degrees", "${UnitConverter.fmt(deg, p)}°", "", isPrimary = true),
                        CalcResultItem("Slope Percentage", "${UnitConverter.fmt(pct, p)} %", "", isPrimary = true),
                        CalcResultItem("Roof Pitch", "${UnitConverter.fmt(pitch12, p)} / 12", ""),
                        CalcResultItem("Gradient Ratio", if (ratioN.isInfinite()) "Flat" else "1 : ${UnitConverter.fmt(ratioN, p)}", ""),
                        CalcResultItem("Radians", UnitConverter.fmt(rad, 4), "rad"),
                        CalcResultItem("Gradians", UnitConverter.fmt(grad, p), "gon")
                    ),
                    formula = "Slope% = 100×tan(θ); Pitch = 12×tan(θ); Rad = θ×π/180",
                    steps = listOf("${UnitConverter.fmt(v, p)} ${ctx.raw("unit")} → θ = ${UnitConverter.fmt(deg, p)}°"),
                    assumptions = "Pitch X/12 represents vertical rise in inches per 12 inches horizontal run."
                )
            )
        }
    )
}

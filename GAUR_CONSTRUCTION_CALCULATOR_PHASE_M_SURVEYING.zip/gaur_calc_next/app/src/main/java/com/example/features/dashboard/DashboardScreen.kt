package com.example.features.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.OfflineBolt
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.core.preferences.ThemeModePref
import com.example.domain.calculators.CalculatorAuditRegistry
import com.example.domain.calculators.CalculatorRegistry
import com.example.features.knowledge.CivilKnowledgeCatalog
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.GlassBluePill
import com.example.ui.components.SectionHeader
import com.example.ui.theme.LocalEngineeringPalette

/**
 * LEVEL 1 — Clean 18-Folder Nested Dashboard
 * Displays ONLY branding header, compact Global Search, optional compact Favorites/Recent chips,
 * and a spacious 2-column (3-4 col tablet) grid of the 18 Major Engineering Category Folders.
 */
@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onOpenFolder: (String) -> Unit,
    onOpenSubcategory: (String, String) -> Unit,
    onOpenCalculator: (String) -> Unit,
    onOpenProject: (Long) -> Unit,
    onNavigateRoute: (String) -> Unit
) {
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteToolIds.collectAsStateWithLifecycle()
    val recentIds by viewModel.recentToolIds.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    val shieldReport by viewModel.shieldReport.collectAsStateWithLifecycle()

    val folders = remember { NestedCategoryCatalog.categories }
    val auditSummary = remember { CalculatorAuditRegistry.summary() }
    val isHindi = settings.language == AppLanguage.HINDI

    var searchQuery by remember { mutableStateOf("") }
    val trimmedQuery = searchQuery.trim()

    val matchingFolders = remember(trimmedQuery, folders) {
        if (trimmedQuery.isEmpty()) emptyList()
        else {
            val q = trimmedQuery.lowercase()
            folders.filter {
                it.titleEn.lowercase().contains(q) ||
                    it.titleHi.lowercase().contains(q) ||
                    it.subtitleEn.lowercase().contains(q) ||
                    it.keywords.any { kw -> kw.contains(q) }
            }.take(5)
        }
    }
    val matchingSubfolders = remember(trimmedQuery) {
        if (trimmedQuery.isEmpty()) emptyList()
        else NestedCategoryCatalog.searchSubcategories(trimmedQuery).take(6)
    }
    val searchTools = remember(trimmedQuery) {
        if (trimmedQuery.isEmpty()) emptyList() else CalculatorRegistry.search(trimmedQuery).take(16)
    }
    val matchingArticles = remember(trimmedQuery) {
        if (trimmedQuery.isEmpty()) emptyList()
        else {
            val q = trimmedQuery.lowercase()
            CivilKnowledgeCatalog.articles.filter {
                it.titleEn.lowercase().contains(q) ||
                    it.titleHi.lowercase().contains(q) ||
                    it.topic.lowercase().contains(q) ||
                    it.standardRef.lowercase().contains(q)
            }.take(4)
        }
    }
    val matchingProjects = remember(trimmedQuery, projects) {
        if (trimmedQuery.isEmpty()) emptyList()
        else {
            val q = trimmedQuery.lowercase()
            projects.filter {
                it.name.lowercase().contains(q) ||
                    it.siteLocation.lowercase().contains(q) ||
                    it.clientName.lowercase().contains(q)
            }.take(4)
        }
    }

    val quickChips = remember(favoriteIds, recentIds) {
        val favSet = favoriteIds.toSet()
        val combinedIds = (favoriteIds.take(4) + recentIds.filter { it !in favSet }.take(4)).distinct()
        combinedIds.mapNotNull { id ->
            CalculatorRegistry.byId(id)?.let { tool -> tool to (id in favSet) }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        // Reference-inspired teal brand header: compact, bold, and engineering focused.
        Surface(
            color = androidx.compose.ui.graphics.Color(0xFF007F7D),
            shape = RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp),
            shadowElevation = 3.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(androidx.compose.ui.graphics.Color.White), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Construction, contentDescription = null, tint = androidx.compose.ui.graphics.Color(0xFF007F7D), modifier = Modifier.size(25.dp))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text("GAUR CONSTRUCTION", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        Text(if (settings.engineerName.isNotBlank()) "Welcome, ${settings.engineerName}" else "Construction Calculator", color = androidx.compose.ui.graphics.Color(0xFFD8FFFF), style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                    IconButton(onClick = { viewModel.setThemeMode(if (palette.isDark) ThemeModePref.LIGHT else ThemeModePref.DARK) }, modifier = Modifier.minimumInteractiveComponentSize().testTag("dash_theme_toggle")) {
                        Icon(if (palette.isDark) Icons.Rounded.LightMode else Icons.Rounded.DarkMode, contentDescription = "Toggle Dark/Light Theme", tint = androidx.compose.ui.graphics.Color.White)
                    }
                    IconButton(onClick = { onNavigateRoute("security") }, modifier = Modifier.minimumInteractiveComponentSize().testTag("dash_security_btn")) {
                        Icon(Icons.Rounded.VerifiedUser, contentDescription = strings.securityShield, tint = if (shieldReport?.hasWarnings == true) palette.warning else androidx.compose.ui.graphics.Color.White)
                    }
                    IconButton(onClick = { onNavigateRoute("settings") }, modifier = Modifier.minimumInteractiveComponentSize().testTag("dash_settings_btn")) {
                        Icon(Icons.Rounded.Settings, contentDescription = strings.settingsTitle, tint = androidx.compose.ui.graphics.Color.White)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Every Shape You Need", color = androidx.compose.ui.graphics.Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Slabs • Columns • Beams • Footings & More", color = androidx.compose.ui.graphics.Color(0xFFD8FFFF), style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    items(listOf("Quantity", "Load Calc", "Mix Design", "Conversion", "History")) { shortcut ->
                        AssistChip(onClick = { when (shortcut) { "History" -> onNavigateRoute("history"); "Conversion" -> onNavigateRoute("converters"); else -> onNavigateRoute("calculators") } }, label = { Text(shortcut, maxLines = 1) }, colors = AssistChipDefaults.assistChipColors(containerColor = androidx.compose.ui.graphics.Color(0xFF006466), labelColor = androidx.compose.ui.graphics.Color.White), border = BorderStroke(1.dp, androidx.compose.ui.graphics.Color(0xFF58B9B5)))
                    }
                }
            }
        }

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val columns = when {
                maxWidth >= 900.dp -> 4
                maxWidth >= 600.dp -> 3
                else -> 3
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Status Strip + Global Search
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GlassBluePill(
                                text = "${strings.offlineReady} • ${auditSummary.totalActiveFunctionalTools} Tools",
                                icon = Icons.Rounded.OfflineBolt
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = palette.orangeSoft,
                                border = BorderStroke(1.dp, palette.orange.copy(alpha = 0.4f)),
                                onClick = { onNavigateRoute("calculators") },
                                modifier = Modifier.testTag("dash_all_calcs_pill")
                            ) {
                                Text(
                                    text = "All ${auditSummary.totalUniqueCalcSpecs} Calcs",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = palette.orangeDark,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("dashboard_search_input"),
                            placeholder = {
                                Text(
                                    text = if (isHindi) "फ़ोल्डर, कैलकुलेटर, बीम, सरिया, FSI या प्रोजेक्ट खोजें..." else "Search folders, calculators, IS codes & projects...",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Rounded.Search, contentDescription = "Search", tint = androidx.compose.ui.graphics.Color(0xFF007F7D))
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Rounded.Close, contentDescription = "Clear")
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = palette.concreteCard,
                                unfocusedContainerColor = palette.concreteCard,
                                focusedBorderColor = androidx.compose.ui.graphics.Color(0xFF007F7D),
                                unfocusedBorderColor = androidx.compose.ui.graphics.Color(0xFFB8D5D4)
                            )
                        )
                    }
                }

                if (trimmedQuery.isNotEmpty()) {
                    val totalFound = matchingFolders.size + matchingSubfolders.size + searchTools.size + matchingArticles.size + matchingProjects.size
                    item {
                        SectionHeader(title = "Search Results ($totalFound)", icon = Icons.Rounded.Search)
                    }
                    if (totalFound == 0) {
                        item {
                            EngineeringCard {
                                Text(strings.noResults, color = palette.inkMuted)
                            }
                        }
                    } else {
                        if (matchingFolders.isNotEmpty()) {
                            items(matchingFolders, key = { "fld_${it.id}" }) { cat ->
                                EngineeringCard(
                                    accentColor = cat.accent,
                                    onClick = { onOpenFolder(cat.id) }
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Icon(cat.icon, contentDescription = null, tint = cat.accent, modifier = Modifier.size(22.dp))
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                                Text(if (isHindi) cat.titleHi else cat.titleEn, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                                Text("Folder • ${cat.subcategories.size} Subfolders", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted, maxLines = 1)
                                            }
                                        }
                                        GlassBluePill(text = "${cat.uniqueToolCount()} Tools")
                                    }
                                }
                            }
                        }
                        if (matchingSubfolders.isNotEmpty()) {
                            items(matchingSubfolders, key = { "sub_${it.first.id}_${it.second.id}" }) { (cat, sub) ->
                                EngineeringCard(
                                    accentColor = cat.accent,
                                    onClick = {
                                        if (sub.toolIds.isEmpty() && sub.directRoute != null) {
                                            onNavigateRoute(sub.directRoute)
                                        } else {
                                            onOpenSubcategory(cat.id, sub.id)
                                        }
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Rounded.FolderOpen, contentDescription = null, tint = cat.accent, modifier = Modifier.size(20.dp))
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                                Text(if (isHindi) sub.titleHi else sub.titleEn, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                                Text("${cat.titleEn} > ${sub.subtitleEn}", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                        Text(strings.openTool, style = MaterialTheme.typography.labelMedium, color = cat.accent)
                                    }
                                }
                            }
                        }
                        items(searchTools, key = { "tool_${it.id}" }) { tool ->
                            EngineeringCard(
                                accentColor = palette.orange,
                                onClick = {
                                    viewModel.onToolOpened(tool.id)
                                    onOpenCalculator(tool.id)
                                },
                                modifier = Modifier.testTag("search_result_${tool.id}")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isHindi) tool.titleHi else tool.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = palette.inkPrimary
                                        )
                                        Text(
                                            text = "${tool.category.titleEn} • ${tool.subtitle}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = palette.inkMuted,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    Text(strings.openTool, style = MaterialTheme.typography.labelLarge, color = palette.orangeDark)
                                }
                            }
                        }
                        items(matchingArticles, key = { "art_${it.id}" }) { art ->
                            EngineeringCard(
                                accentColor = palette.skyBlue,
                                onClick = { onNavigateRoute("knowledge/${art.topic}") }
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.MenuBook, contentDescription = null, tint = palette.skyBlue, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(if (isHindi) art.titleHi else art.titleEn, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                        Text("${art.topic} • ${art.standardRef}", style = MaterialTheme.typography.bodySmall, color = palette.skyBlue)
                                    }
                                }
                            }
                        }
                        items(matchingProjects, key = { "proj_${it.id}" }) { proj ->
                            EngineeringCard(
                                accentColor = palette.success,
                                onClick = { onOpenProject(proj.id) }
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Folder, contentDescription = null, tint = palette.success, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(proj.name, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                        Text("Project • ${proj.siteLocation}", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Compact Favorites & Recently Used Chips (keeps Home clean and breathable)
                    if (quickChips.isNotEmpty()) {
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(quickChips, key = { it.first.id }) { (tool, isFav) ->
                                    AssistChip(
                                        onClick = {
                                            viewModel.onToolOpened(tool.id)
                                            onOpenCalculator(tool.id)
                                        },
                                        label = {
                                            Text(
                                                text = if (isHindi) tool.titleHi else tool.title,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                fontWeight = FontWeight.Medium
                                            )
                                        },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = if (isFav) Icons.Rounded.Star else Icons.Rounded.History,
                                                contentDescription = null,
                                                modifier = Modifier.size(15.dp),
                                                tint = if (isFav) palette.orange else palette.skyBlue
                                            )
                                        },
                                        colors = AssistChipDefaults.assistChipColors(
                                            containerColor = palette.concreteCard,
                                            labelColor = palette.inkPrimary
                                        ),
                                        border = BorderStroke(1.dp, palette.metallicBorder),
                                        modifier = Modifier.testTag("quick_chip_${tool.id}")
                                    )
                                }
                            }
                        }
                    }

                    // Level 1: 18 Main Category Folders Grid
                    item {
                        SectionHeader(
                            title = if (isHindi) "इंजीनियरिंग कैटेगरी फ़ोल्डर" else "Engineering Folders",
                            icon = Icons.Rounded.Construction,
                            trailingActionText = "${folders.size} Folders",
                            onTrailingClick = { onNavigateRoute("calculators") }
                        )
                    }

                    items(folders.chunked(columns), key = { row -> row.joinToString("_") { it.id } }) { rowFolders ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            rowFolders.forEach { folder ->
                                Surface(
                                    modifier = Modifier.weight(1f).height(108.dp).clip(RoundedCornerShape(14.dp)).testTag("folder_tile_${folder.id}"),
                                    color = androidx.compose.ui.graphics.Color(0xFF008C89),
                                    shape = RoundedCornerShape(14.dp),
                                    shadowElevation = 2.dp,
                                    onClick = { onOpenFolder(folder.id) }
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                            Icon(folder.icon, contentDescription = folder.titleEn, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(32.dp))
                                        }
                                        Text(
                                            text = if (isHindi) folder.titleHi else folder.titleEn,
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.SemiBold,
                                            color = androidx.compose.ui.graphics.Color.White,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                            repeat(columns - rowFolders.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

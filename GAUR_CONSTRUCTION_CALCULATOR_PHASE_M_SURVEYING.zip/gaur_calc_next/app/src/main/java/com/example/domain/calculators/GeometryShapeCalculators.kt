package com.example.domain.calculators

import com.example.domain.units.AreaUnit
import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import com.example.domain.units.VolumeUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

object GeometryShapeCalculators {

    fun areaCalculator(): CalcToolSpec {
        val shapes = listOf(
            "Rectangle",
            "Square",
            "Triangle (Base & Height)",
            "Triangle (3 Sides Heron)",
            "Right Triangle",
            "Circle",
            "Semicircle",
            "Circular Sector",
            "Ring / Annulus",
            "Ellipse / Oval",
            "Trapezoid",
            "Parallelogram",
            "Rhombus",
            "Regular Polygon (N-Sides)",
            "Irregular 4-Side Plot"
        )
        return CalcToolSpec(
            id = "basic_area",
            title = "Area Calculator (All 15 2D Shapes)",
            titleHi = "क्षेत्रफल कैलकुलेटर (सभी 15 आकार)",
            subtitle = "Rectangle, Square, Triangles, Circle, Sector, Ring, Ellipse, Trapezoid, Polygon & Plot",
            category = CalcCategory.BASIC,
            typeFieldKey = "shape",
            keywords = listOf("area", "plot", "rectangle", "square", "triangle", "trapezoid", "circle", "sector", "ellipse", "polygon", "rhombus", "parallelogram", "annulus"),
            fields = listOf(
                CalcFieldSpec("shape", "2D Shape", "Rectangle", options = shapes),
                CalcFieldSpec(
                    key = "a", label = "Length / Side A / Radius", defaultValue = "10",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                    dynamicLabel = { m ->
                        when (m["shape"]) {
                            "Square" -> "Side Length (a)"
                            "Circle", "Semicircle", "Circular Sector" -> "Radius (r)"
                            "Ring / Annulus" -> "Outer Radius (R)"
                            "Ellipse / Oval" -> "Semi-Major Axis (a)"
                            "Triangle (Base & Height)", "Parallelogram" -> "Base (b)"
                            "Right Triangle" -> "Base (a)"
                            "Trapezoid" -> "Bottom Base (a)"
                            "Rhombus" -> "Diagonal 1 (d₁)"
                            "Regular Polygon (N-Sides)" -> "Side Length (s)"
                            "Triangle (3 Sides Heron)", "Irregular 4-Side Plot" -> "Side A"
                            else -> "Length (L)"
                        }
                    }
                ),
                CalcFieldSpec(
                    key = "b", label = "Width / Side B / Height", defaultValue = "8",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M, allowZero = true,
                    visibleWhen = { m -> m["shape"] !in setOf("Square", "Circle", "Semicircle", "Circular Sector", "Regular Polygon (N-Sides)") },
                    dynamicLabel = { m ->
                        when (m["shape"]) {
                            "Ring / Annulus" -> "Inner Radius (r)"
                            "Ellipse / Oval" -> "Semi-Minor Axis (b)"
                            "Triangle (Base & Height)", "Parallelogram", "Right Triangle" -> "Height (h)"
                            "Trapezoid" -> "Top Base (b)"
                            "Rhombus" -> "Diagonal 2 (d₂)"
                            "Triangle (3 Sides Heron)", "Irregular 4-Side Plot" -> "Side B"
                            else -> "Width (W)"
                        }
                    }
                ),
                CalcFieldSpec(
                    key = "c", label = "Side C", defaultValue = "7",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M, allowZero = true,
                    visibleWhen = { m -> m["shape"] in setOf("Triangle (3 Sides Heron)", "Irregular 4-Side Plot") }
                ),
                CalcFieldSpec(
                    key = "d", label = "Side D", defaultValue = "9",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M, allowZero = true,
                    visibleWhen = { m -> m["shape"] == "Irregular 4-Side Plot" }
                ),
                CalcFieldSpec(
                    key = "h", label = "Height / Diagonal", defaultValue = "6",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M, allowZero = true,
                    visibleWhen = { m -> m["shape"] in setOf("Trapezoid", "Irregular 4-Side Plot") },
                    dynamicLabel = { m ->
                        if (m["shape"] == "Irregular 4-Side Plot") "Diagonal (AC) between A-B & C-D" else "Vertical Height (h)"
                    }
                ),
                CalcFieldSpec(
                    key = "angle", label = "Sector Angle θ (deg)", defaultValue = "90",
                    unitKind = FieldUnitKind.ANGLE_DEG,
                    visibleWhen = { m -> m["shape"] == "Circular Sector" }
                ),
                CalcFieldSpec(
                    key = "nSides", label = "Number of Sides (N)", defaultValue = "6",
                    unitKind = FieldUnitKind.COUNT,
                    visibleWhen = { m -> m["shape"] == "Regular Polygon (N-Sides)" }
                )
            ),
            compute = { ctx ->
                val p = ctx.settings.decimalPrecision
                val shape = ctx.raw("shape").ifBlank { "Rectangle" }
                val a = ctx.lengthMeters("a") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter primary dimension."))
                if (a <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Primary dimension must be positive."))
                val b = ctx.lengthMeters("b") ?: 0.0
                val c = ctx.lengthMeters("c") ?: 0.0
                val d = ctx.lengthMeters("d") ?: 0.0
                val h = ctx.lengthMeters("h") ?: 0.0
                val ang = ctx.doubleOrNull("angle") ?: 90.0
                val nSides = (ctx.doubleOrNull("nSides") ?: 6.0).toInt().coerceAtLeast(3)

                var perimM = 0.0
                val areaM2: Double
                val formula: String
                val step1: String

                when (shape) {
                    "Square" -> {
                        areaM2 = a * a; perimM = 4 * a
                        formula = "Area = a²; Perimeter = 4a"
                        step1 = "${UnitConverter.fmt(a, p)}² = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Triangle (Base & Height)", "Parallelogram" -> {
                        if (b <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive height."))
                        val isPara = shape == "Parallelogram"
                        areaM2 = if (isPara) a * b else 0.5 * a * b
                        perimM = if (isPara) 2.0 * (a + b) else a + b + sqrt(a * a + b * b)
                        formula = if (isPara) "Area = Base × Height" else "Area = 0.5 × Base × Height"
                        step1 = "${if (isPara) "" else "0.5 × "}${UnitConverter.fmt(a, p)} × ${UnitConverter.fmt(b, p)} = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Right Triangle" -> {
                        if (b <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive height."))
                        val hyp = sqrt(a * a + b * b)
                        areaM2 = 0.5 * a * b; perimM = a + b + hyp
                        formula = "Area = 0.5 × a × h; c = √(a² + h²)"
                        step1 = "Hypotenuse = ${UnitConverter.fmt(hyp, p)} m; Area = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Triangle (3 Sides Heron)" -> {
                        if (b <= 0 || c <= 0 || a + b <= c || a + c <= b || b + c <= a) {
                            return@CalcToolSpec Result.failure(IllegalArgumentException("Sides violate triangle inequality."))
                        }
                        val s = (a + b + c) / 2.0
                        areaM2 = sqrt(s * (s - a) * (s - b) * (s - c)); perimM = a + b + c
                        formula = "s = (A+B+C)/2; Area = √[s(s-A)(s-B)(s-C)]"
                        step1 = "s = ${UnitConverter.fmt(s, p)} m; Area = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Circle" -> {
                        areaM2 = PI * a * a; perimM = 2.0 * PI * a
                        formula = "Area = πr²; Circumference = 2πr"
                        step1 = "π × ${UnitConverter.fmt(a, p)}² = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Semicircle" -> {
                        areaM2 = 0.5 * PI * a * a; perimM = PI * a + 2.0 * a
                        formula = "Area = 0.5 × πr²; Perimeter = πr + 2r"
                        step1 = "0.5 × π × ${UnitConverter.fmt(a, p)}² = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Circular Sector" -> {
                        if (ang <= 0 || ang > 360) return@CalcToolSpec Result.failure(IllegalArgumentException("Angle must be 1°–360°."))
                        areaM2 = PI * a * a * (ang / 360.0)
                        perimM = 2.0 * a + 2.0 * PI * a * (ang / 360.0)
                        formula = "Area = πr² × (θ / 360°)"
                        step1 = "π × ${UnitConverter.fmt(a, p)}² × (${ang}/360) = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Ring / Annulus" -> {
                        if (b < 0 || b >= a) return@CalcToolSpec Result.failure(IllegalArgumentException("Inner radius r must be < outer radius R."))
                        areaM2 = PI * (a * a - b * b); perimM = 2.0 * PI * (a + b)
                        formula = "Area = π(R² - r²)"
                        step1 = "π × (${UnitConverter.fmt(a, p)}² - ${UnitConverter.fmt(b, p)}²) = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Ellipse / Oval" -> {
                        if (b <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive semi-minor axis b."))
                        areaM2 = PI * a * b
                        perimM = PI * (3 * (a + b) - sqrt((3 * a + b) * (a + 3 * b)))
                        formula = "Area = π × a × b"
                        step1 = "π × ${UnitConverter.fmt(a, p)} × ${UnitConverter.fmt(b, p)} = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Trapezoid" -> {
                        if (b <= 0 || h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive Base 2 and Height."))
                        areaM2 = 0.5 * (a + b) * h
                        val leg = sqrt(h * h + ((a - b) / 2.0) * ((a - b) / 2.0))
                        perimM = a + b + 2.0 * leg
                        formula = "Area = 0.5 × (Base1 + Base2) × Height"
                        step1 = "0.5 × (${UnitConverter.fmt(a, p)} + ${UnitConverter.fmt(b, p)}) × ${UnitConverter.fmt(h, p)} = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Rhombus" -> {
                        if (b <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive second diagonal."))
                        areaM2 = 0.5 * a * b
                        val side = 0.5 * sqrt(a * a + b * b)
                        perimM = 4.0 * side
                        formula = "Area = 0.5 × d₁ × d₂; Side = 0.5√(d₁² + d₂²)"
                        step1 = "0.5 × ${UnitConverter.fmt(a, p)} × ${UnitConverter.fmt(b, p)} = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Regular Polygon (N-Sides)" -> {
                        areaM2 = (nSides * a * a) / (4.0 * tan(PI / nSides))
                        perimM = nSides * a
                        formula = "Area = (N × s²) / (4 × tan(π / N))"
                        step1 = "$nSides-sided polygon of side ${UnitConverter.fmt(a, p)} m = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    "Irregular 4-Side Plot" -> {
                        if (b <= 0 || c <= 0 || d <= 0 || h <= 0 ||
                            a + b <= h || a + h <= b || b + h <= a ||
                            c + d <= h || c + h <= d || d + h <= c
                        ) {
                            return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid sides or diagonal for two triangles."))
                        }
                        val s1 = (a + b + h) / 2.0
                        val s2 = (c + d + h) / 2.0
                        val a1 = sqrt(s1 * (s1 - a) * (s1 - b) * (s1 - h))
                        val a2 = sqrt(s2 * (s2 - c) * (s2 - d) * (s2 - h))
                        areaM2 = a1 + a2; perimM = a + b + c + d
                        formula = "Plot Area = Area(△A,B,Diag) + Area(△C,D,Diag) via Heron"
                        step1 = "△1=${UnitConverter.fmt(a1, p)} m² + △2=${UnitConverter.fmt(a2, p)} m² = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                    else -> {
                        if (b <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive width."))
                        areaM2 = a * b; perimM = 2.0 * (a + b)
                        formula = "Area = L × W; Perimeter = 2(L + W)"
                        step1 = "${UnitConverter.fmt(a, p)} × ${UnitConverter.fmt(b, p)} = ${UnitConverter.fmt(areaM2, p)} m²"
                    }
                }
                val sqFt = UnitConverter.sqMetersToArea(areaM2, AreaUnit.SQ_FT)
                val sqYd = UnitConverter.sqMetersToArea(areaM2, AreaUnit.SQ_YD)
                val bigha = UnitConverter.sqMetersToArea(areaM2, AreaUnit.BIGHA, ctx.settings.bighaSqFt)
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Area (Metric)", UnitConverter.fmt(areaM2, p), "m²", isPrimary = true),
                            CalcResultItem("Area (Imperial)", UnitConverter.fmt(sqFt, p), "sq.ft", isPrimary = true),
                            CalcResultItem("Perimeter / Boundary", UnitConverter.fmt(perimM, p), "m"),
                            CalcResultItem("Area in Gaj / Sq.Yd", UnitConverter.fmt(sqYd, p), "sq.yd"),
                            CalcResultItem("Area in Bigha", UnitConverter.fmt(bigha, 4), "Bigha")
                        ),
                        formula = formula,
                        steps = listOf(step1, "sq.ft = m² × 10.7639 = ${UnitConverter.fmt(sqFt, p)} sq.ft"),
                        assumptions = "Uses configured regional Bigha (${UnitConverter.fmt(ctx.settings.bighaSqFt, 0)} sq.ft)."
                    )
                )
            }
        )
    }

    fun volumeAndSurfaceAreaCalculator(): CalcToolSpec {
        val shapes = listOf(
            "Cuboid / Box",
            "Cube",
            "Cylinder",
            "Hollow Cylinder / Pipe",
            "Cone",
            "Frustum of Cone",
            "Sphere",
            "Hemisphere",
            "Triangular Prism",
            "Square Pyramid",
            "Frustum of Pyramid",
            "Trapezoidal Hopper"
        )
        return CalcToolSpec(
            id = "basic_volume_surface",
            title = "Volume & Surface Area (All 12 3D Shapes)",
            titleHi = "आयतन और सतह क्षेत्रफल (12 ठोस आकार)",
            subtitle = "Cube, Cuboid, Cylinder, Pipe, Cone, Frustum, Sphere, Hemisphere, Prism, Pyramid & Hopper",
            category = CalcCategory.BASIC,
            typeFieldKey = "shape",
            keywords = listOf("volume", "surface", "cube", "cuboid", "cylinder", "pipe", "cone", "frustum", "sphere", "hemisphere", "pyramid", "prism", "cft", "cum"),
            fields = listOf(
                CalcFieldSpec("shape", "3D Solid Shape", "Cuboid / Box", options = shapes),
                CalcFieldSpec(
                    key = "l", label = "Length / Outer Dia / Base L", defaultValue = "5",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                    dynamicLabel = { m ->
                        when (m["shape"]) {
                            "Cube" -> "Side Length (a)"
                            "Cylinder", "Cone" -> "Diameter (Ø)"
                            "Hollow Cylinder / Pipe" -> "Outer Diameter (OD)"
                            "Frustum of Cone" -> "Bottom Diameter (D₁)"
                            "Sphere", "Hemisphere" -> "Diameter (Ø)"
                            "Triangular Prism" -> "Triangle Base (b)"
                            "Square Pyramid" -> "Base Side (a)"
                            "Frustum of Pyramid", "Trapezoidal Hopper" -> "Bottom Length / Side (L₁)"
                            else -> "Length (L)"
                        }
                    }
                ),
                CalcFieldSpec(
                    key = "w", label = "Width / Inner Dia / Top Side", defaultValue = "4",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M, allowZero = true,
                    visibleWhen = { m -> m["shape"] !in setOf("Cube", "Cylinder", "Cone", "Sphere", "Hemisphere", "Square Pyramid") },
                    dynamicLabel = { m ->
                        when (m["shape"]) {
                            "Hollow Cylinder / Pipe" -> "Inner Diameter (ID)"
                            "Frustum of Cone" -> "Top Diameter (D₂)"
                            "Triangular Prism" -> "Triangle Height (h_t)"
                            "Frustum of Pyramid" -> "Top Side (L₂)"
                            "Trapezoidal Hopper" -> "Bottom Width (W₁)"
                            else -> "Width (W)"
                        }
                    }
                ),
                CalcFieldSpec(
                    key = "w2", label = "Top Width / Length (Hopper)", defaultValue = "2.5",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M, allowZero = true,
                    visibleWhen = { m -> m["shape"] == "Trapezoidal Hopper" }
                ),
                CalcFieldSpec(
                    key = "h", label = "Height / Length", defaultValue = "3",
                    unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                    visibleWhen = { m -> m["shape"] !in setOf("Cube", "Sphere", "Hemisphere") },
                    dynamicLabel = { m ->
                        if (m["shape"] in setOf("Hollow Cylinder / Pipe", "Triangular Prism")) "Length (L)" else "Vertical Height (H)"
                    }
                )
            ),
            compute = { ctx ->
                val p = ctx.settings.decimalPrecision
                val shape = ctx.raw("shape").ifBlank { "Cuboid / Box" }
                val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter primary dimension."))
                val w = ctx.lengthMeters("w") ?: 0.0
                val w2 = ctx.lengthMeters("w2") ?: 0.0
                val h = ctx.lengthMeters("h") ?: 1.0
                if (l <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Primary dimension must be positive."))

                val volM3: Double
                val surfaceM2: Double
                val formula: String
                val step: String

                when (shape) {
                    "Cube" -> {
                        volM3 = l * l * l; surfaceM2 = 6.0 * l * l
                        formula = "V = a³; TSA = 6a²"
                        step = "${UnitConverter.fmt(l, p)}³ = ${UnitConverter.fmt(volM3, p)} m³"
                    }
                    "Cylinder" -> {
                        if (h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive height."))
                        val r = l / 2.0
                        volM3 = PI * r * r * h; surfaceM2 = 2 * PI * r * (r + h)
                        formula = "V = πr²h; TSA = 2πr(r + h)"
                        step = "r=${UnitConverter.fmt(r, p)} m, H=${UnitConverter.fmt(h, p)} m"
                    }
                    "Hollow Cylinder / Pipe" -> {
                        if (h <= 0 || w < 0 || w >= l) return@CalcToolSpec Result.failure(IllegalArgumentException("Inner dia must be < Outer dia, Length > 0."))
                        val rOut = l / 2.0; val rIn = w / 2.0
                        volM3 = PI * (rOut * rOut - rIn * rIn) * h
                        surfaceM2 = 2.0 * PI * (rOut + rIn) * h + 2.0 * PI * (rOut * rOut - rIn * rIn)
                        formula = "V = π(R² - r²) × L"
                        step = "R=${UnitConverter.fmt(rOut, p)} m, r=${UnitConverter.fmt(rIn, p)} m, L=${UnitConverter.fmt(h, p)} m"
                    }
                    "Cone" -> {
                        if (h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive height."))
                        val r = l / 2.0; val slant = sqrt(r * r + h * h)
                        volM3 = (1.0 / 3.0) * PI * r * r * h; surfaceM2 = PI * r * (r + slant)
                        formula = "V = (1/3)πr²h; TSA = πr(r + √(r²+h²))"
                        step = "r=${UnitConverter.fmt(r, p)} m, slant=${UnitConverter.fmt(slant, p)} m"
                    }
                    "Frustum of Cone" -> {
                        if (h <= 0 || w <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive top dia and height."))
                        val r1 = l / 2.0; val r2 = w / 2.0
                        val slant = sqrt(h * h + (r1 - r2) * (r1 - r2))
                        volM3 = (PI * h / 3.0) * (r1 * r1 + r1 * r2 + r2 * r2)
                        surfaceM2 = PI * (r1 + r2) * slant + PI * (r1 * r1 + r2 * r2)
                        formula = "V = (πh/3)(R² + Rr + r²)"
                        step = "R=${UnitConverter.fmt(r1, p)} m, r=${UnitConverter.fmt(r2, p)} m, slant=${UnitConverter.fmt(slant, p)} m"
                    }
                    "Sphere" -> {
                        val r = l / 2.0
                        volM3 = (4.0 / 3.0) * PI * r * r * r; surfaceM2 = 4.0 * PI * r * r
                        formula = "V = (4/3)πr³; TSA = 4πr²"
                        step = "r=${UnitConverter.fmt(r, p)} m"
                    }
                    "Hemisphere" -> {
                        val r = l / 2.0
                        volM3 = (2.0 / 3.0) * PI * r * r * r; surfaceM2 = 3.0 * PI * r * r
                        formula = "V = (2/3)πr³; TSA = 3πr²"
                        step = "r=${UnitConverter.fmt(r, p)} m"
                    }
                    "Triangular Prism" -> {
                        if (w <= 0 || h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive triangle height and length."))
                        val triArea = 0.5 * l * w
                        volM3 = triArea * h
                        val side = sqrt((l / 2.0) * (l / 2.0) + w * w)
                        surfaceM2 = 2.0 * triArea + (l + 2.0 * side) * h
                        formula = "V = (0.5 × b × h_t) × L"
                        step = "Triangle Area = ${UnitConverter.fmt(triArea, p)} m² × L=${UnitConverter.fmt(h, p)} m"
                    }
                    "Square Pyramid" -> {
                        if (h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive height."))
                        volM3 = (1.0 / 3.0) * l * l * h
                        val slant = sqrt(h * h + (l / 2.0) * (l / 2.0))
                        surfaceM2 = l * l + 2.0 * l * slant
                        formula = "V = (1/3)a²h; TSA = a² + 2a·slant"
                        step = "Base = ${UnitConverter.fmt(l * l, p)} m², slant = ${UnitConverter.fmt(slant, p)} m"
                    }
                    "Frustum of Pyramid" -> {
                        if (w <= 0 || h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive top side and height."))
                        val a1 = l * l; val a2 = w * w
                        volM3 = (h / 3.0) * (a1 + a2 + sqrt(a1 * a2))
                        val slant = sqrt(h * h + ((l - w) / 2.0) * ((l - w) / 2.0))
                        surfaceM2 = a1 + a2 + 2.0 * (l + w) * slant
                        formula = "V = (H/3)(A₁ + A₂ + √(A₁A₂))"
                        step = "A₁=${UnitConverter.fmt(a1, p)} m², A₂=${UnitConverter.fmt(a2, p)} m²"
                    }
                    "Trapezoidal Hopper" -> {
                        if (w <= 0 || w2 <= 0 || h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive dimensions."))
                        val a1 = l * w; val a2 = w2 * w2
                        volM3 = (h / 3.0) * (a1 + a2 + sqrt(a1 * a2))
                        surfaceM2 = a1 + a2 + 2.0 * ((l + w2) / 2.0 + (w + w2) / 2.0) * h
                        formula = "V = (H/3)(A_bot + A_top + √(A_bot·A_top))"
                        step = "A_bot=${UnitConverter.fmt(a1, p)} m², A_top=${UnitConverter.fmt(a2, p)} m²"
                    }
                    else -> {
                        if (w <= 0 || h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive width and height."))
                        volM3 = l * w * h; surfaceM2 = 2.0 * (l * w + w * h + h * l)
                        formula = "V = L × W × H; TSA = 2(LW + WH + HL)"
                        step = "${UnitConverter.fmt(l, p)}×${UnitConverter.fmt(w, p)}×${UnitConverter.fmt(h, p)} = ${UnitConverter.fmt(volM3, p)} m³"
                    }
                }
                val cft = UnitConverter.convertVolume(volM3, VolumeUnit.CU_M, VolumeUnit.CU_FT)
                val brass = UnitConverter.convertVolume(volM3, VolumeUnit.CU_M, VolumeUnit.BRASS)
                val liters = volM3 * 1000.0
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Volume (m³)", UnitConverter.fmt(volM3, p), "m³", isPrimary = true),
                            CalcResultItem("Volume (CFT)", UnitConverter.fmt(cft, p), "ft³", isPrimary = true),
                            CalcResultItem("Surface Area", UnitConverter.fmt(surfaceM2, p), "m²"),
                            CalcResultItem("Brass (100 CFT)", UnitConverter.fmt(brass, p), "Brass"),
                            CalcResultItem("Capacity (Liters)", UnitConverter.fmt(liters, p), "L")
                        ),
                        formula = formula,
                        steps = listOf(step, "CFT = m³ × 35.3147 = ${UnitConverter.fmt(cft, p)} ft³"),
                        assumptions = "1 Brass = 100 CFT = 2.8317 m³; 1 m³ = 1000 Liters."
                    )
                )
            }
        )
    }
}

package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.sqrt

/**
 * Phase G: practical geometry and idealised cross-section property estimators.
 * Dimensions are entered using the app's length-unit controls and converted to metres.
 */
object PhaseGStructuralGeometryCalculators {
    private fun dim(key: String, label: String, value: String = "200") =
        CalcFieldSpec(key, label, value, FieldUnitKind.LENGTH, LengthUnit.MM)

    private fun tool(
        id: String, title: String, subtitle: String, fields: List<CalcFieldSpec>,
        keywords: List<String>, calc: (CalcContext) -> Result<CalcOutcome>
    ) = CalcToolSpec(
        id = id, title = title, titleHi = title, subtitle = subtitle,
        category = CalcCategory.STEEL, keywords = keywords,
        fields = fields, compute = calc
    )

    private fun fmt(v: Double, p: Int) = UnitConverter.fmt(v, p)

    fun all(): List<CalcToolSpec> = listOf(
        tool("phase_g_ellipse_geometry", "Ellipse Geometry", "Area, perimeter approximation and axes", listOf(dim("a","Semi-major axis a"),dim("b","Semi-minor axis b")), listOf("ellipse","oval","area","perimeter")) { c ->
            val a=c.lengthMeters("a") ?: 0.0; val b=c.lengthMeters("b") ?: 0.0; val p=c.settings.decimalPrecision
            if(a<=0||b<=0) return@tool Result.failure(IllegalArgumentException("Both semi-axes must be positive."))
            val area=PI*a*b
            val perimeter=PI*(3*(a+b)-sqrt((3*a+b)*(a+3*b)))
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(area,p),"m²",true),CalcResultItem("Approx. perimeter",fmt(perimeter,p),"m"),CalcResultItem("Major diameter",fmt(2*a,p),"m"),CalcResultItem("Minor diameter",fmt(2*b,p),"m")), "A = πab; Ramanujan perimeter approximation", listOf("A = π × $a × $b = ${fmt(area,p)} m²"), "a and b are semi-axes; perimeter is an approximation."))
        },
        tool("phase_g_regular_polygon", "Regular Polygon Geometry", "Area, perimeter and apothem", listOf(dim("s","Side length","100"),CalcFieldSpec("n","Number of sides","6",FieldUnitKind.COUNT)), listOf("polygon","regular","apothem","area")) { c ->
            val s=c.lengthMeters("s") ?: 0.0; val n=(c.doubleOrNull("n") ?: 0.0).toInt(); val p=c.settings.decimalPrecision
            if(s<=0||n<3||n>10000) return@tool Result.failure(IllegalArgumentException("Side must be positive and sides count at least 3."))
            val perimeter=n*s; val ap=s/(2*kotlin.math.tan(PI/n)); val area=0.5*perimeter*ap
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(area,p),"m²",true),CalcResultItem("Perimeter",fmt(perimeter,p),"m"),CalcResultItem("Apothem",fmt(ap,p),"m")), "P = ns; apothem = s/[2tan(π/n)]; A = P×apothem/2", listOf("n=$n, P=${fmt(perimeter,p)} m, apothem=${fmt(ap,p)} m"), "Assumes a regular, convex polygon."))
        },
        tool("phase_g_composite_two_rectangles", "Composite Area – Two Rectangles", "Area and centroid for two non-overlapping rectangles", listOf(dim("w1","Rectangle 1 width"),dim("h1","Rectangle 1 height"),dim("x1","Rectangle 1 centroid X","0"),dim("y1","Rectangle 1 centroid Y","0"),dim("w2","Rectangle 2 width"),dim("h2","Rectangle 2 height"),dim("x2","Rectangle 2 centroid X","300"),dim("y2","Rectangle 2 centroid Y","0")), listOf("composite","area","centroid","rectangle")) { c ->
            val w1=c.lengthMeters("w1")?:0.0; val h1=c.lengthMeters("h1")?:0.0; val x1=c.lengthMeters("x1")?:0.0; val y1=c.lengthMeters("y1")?:0.0
            val w2=c.lengthMeters("w2")?:0.0; val h2=c.lengthMeters("h2")?:0.0; val x2=c.lengthMeters("x2")?:0.0; val y2=c.lengthMeters("y2")?:0.0; val p=c.settings.decimalPrecision
            if(listOf(w1,h1,w2,h2).any{it<=0}) return@tool Result.failure(IllegalArgumentException("Rectangle widths and heights must be positive."))
            val a1=w1*h1; val a2=w2*h2; val a=a1+a2; val x=(a1*x1+a2*x2)/a; val y=(a1*y1+a2*y2)/a
            Result.success(CalcOutcome(listOf(CalcResultItem("Total area",fmt(a,p),"m²",true),CalcResultItem("Centroid X",fmt(x,p),"m"),CalcResultItem("Centroid Y",fmt(y,p),"m")), "A=ΣAi; x̄=Σ(Aixi)/ΣAi; ȳ=Σ(Aiyi)/ΣAi", listOf("A1=${fmt(a1,p)} m²; A2=${fmt(a2,p)} m²"), "Enter each rectangle centroid in the same global coordinate system. Rectangles must not overlap; subtract holes separately."))
        },
        tool("phase_g_i_section", "I-Section Properties", "Area, centroidal Ix/Iy and elastic section modulus", listOf(dim("bf","Flange width"),dim("tf","Flange thickness"),dim("tw","Web thickness"),dim("h","Overall depth")), listOf("i section","ibeam","moment of inertia","section modulus")) { c ->
            val bf=c.lengthMeters("bf")?:0.0; val tf=c.lengthMeters("tf")?:0.0; val tw=c.lengthMeters("tw")?:0.0; val h=c.lengthMeters("h")?:0.0; val p=c.settings.decimalPrecision
            if(bf<=0||tf<=0||tw<=0||h<=2*tf||tw>=bf) return@tool Result.failure(IllegalArgumentException("Require positive dimensions, h > 2tf and bf > tw."))
            val hw=h-2*tf; val area=2*bf*tf+tw*hw
            val ix=2*(bf*tf.pow3()/12+bf*tf*((h-tf)/2).pow2())+tw*hw.pow2()/12
            val iy=2*(tf*bf.pow3()/12)+hw*tw.pow3()/12
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(area,p),"m²",true),CalcResultItem("Ix",fmt(ix,p),"m⁴"),CalcResultItem("Iy",fmt(iy,p),"m⁴"),CalcResultItem("Zx",fmt(ix/(h/2),p),"m³"),CalcResultItem("Zy",fmt(iy/(bf/2),p),"m³")), "Parallel-axis theorem for two flanges + web", listOf("Web clear depth = h − 2tf = ${fmt(hw,p)} m"), "Ideal sharp-corner I-section; ignores fillets, taper and local buckling."))
        },
        tool("phase_g_t_section", "T-Section Properties", "Area, centroid from bottom, Ix and section modulus", listOf(dim("bf","Flange width"),dim("tf","Flange thickness"),dim("tw","Web thickness"),dim("h","Overall depth")), listOf("t section","tee","centroid","inertia")) { c ->
            val b=c.lengthMeters("bf")?:0.0; val tf=c.lengthMeters("tf")?:0.0; val tw=c.lengthMeters("tw")?:0.0; val h=c.lengthMeters("h")?:0.0; val p=c.settings.decimalPrecision
            if(b<=0||tf<=0||tw<=0||h<=tf||tw>b) return@tool Result.failure(IllegalArgumentException("Require h > tf and flange width >= web thickness."))
            val hw=h-tf; val af=b*tf; val aw=tw*hw; val y=(af*(h-tf/2)+aw*(hw/2))/(af+aw)
            val ix=b*tf.pow3()/12+af*(h-tf/2-y).pow2()+tw*hw.pow3()/12+aw*(y-hw/2).pow2()
            val iy=tf*b.pow3()/12+hw*tw.pow3()/12; val area=af+aw
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(area,p),"m²",true),CalcResultItem("Centroid from bottom",fmt(y,p),"m"),CalcResultItem("Ix",fmt(ix,p),"m⁴"),CalcResultItem("Iy",fmt(iy,p),"m⁴"),CalcResultItem("Top Zx",fmt(ix/(h-y),p),"m³")), "Composite rectangles + parallel-axis theorem", listOf("Flange area=$af m²; web area=$aw m²"), "Ideal sharp-corner T-section; Ix and Iy are centroidal."))
        },
        tool("phase_g_l_section", "Equal/Unequal L-Section Properties", "Area, centroid and centroidal moments of inertia", listOf(dim("b","Horizontal leg width"),dim("h","Vertical leg height"),dim("t","Uniform thickness")), listOf("angle","l section","centroid","inertia")) { c ->
            val b=c.lengthMeters("b")?:0.0; val h=c.lengthMeters("h")?:0.0; val t=c.lengthMeters("t")?:0.0; val p=c.settings.decimalPrecision
            if(b<=0||h<=0||t<=0||t>=b||t>=h) return@tool Result.failure(IllegalArgumentException("Thickness must be positive and smaller than both legs."))
            val a1=b*t; val a2=t*(h-t); val x1=b/2; val y1=t/2; val x2=t/2; val y2=t+(h-t)/2; val a=a1+a2
            val x=(a1*x1+a2*x2)/a; val y=(a1*y1+a2*y2)/a
            val ix=b*t.pow2()/12+a1*(y1-y).pow2()+t*(h-t).pow2()/12+a2*(y2-y).pow2()
            val iy=t*b.pow2()/12+a1*(x1-x).pow2()+(h-t)*t.pow2()/12+a2*(x2-x).pow2()
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(a,p),"m²",true),CalcResultItem("Centroid X",fmt(x,p),"m"),CalcResultItem("Centroid Y",fmt(y,p),"m"),CalcResultItem("Ix",fmt(ix,p),"m⁴"),CalcResultItem("Iy",fmt(iy,p),"m⁴")), "L = horizontal rectangle + non-overlapping vertical rectangle", listOf("Overlap t×t counted once; centroid by area-weighted average."), "Uniform-thickness ideal L-section; centroid axes are parallel to the legs."))
        },
        tool("phase_g_c_channel", "C-Channel Section Properties", "Area, centroid and centroidal Ix/Iy", listOf(dim("h","Overall depth"),dim("bf","Flange width"),dim("tf","Flange thickness"),dim("tw","Web thickness")), listOf("channel","c section","centroid","inertia")) { c ->
            val h=c.lengthMeters("h")?:0.0; val b=c.lengthMeters("bf")?:0.0; val tf=c.lengthMeters("tf")?:0.0; val tw=c.lengthMeters("tw")?:0.0; val p=c.settings.decimalPrecision
            if(h<=0||b<=0||tf<=0||tw<=0||h<=2*tf||tw>=b) return@tool Result.failure(IllegalArgumentException("Require h > 2tf and flange width > web thickness."))
            val parts=listOf(Triple(tw*(h-2*tf),tw/2,(h/2)),Triple(b*tf,b/2,(h-tf/2)),Triple(b*tf,b/2,(tf/2)))
            val a=parts.sumOf{it.first}; val x=parts.sumOf{it.first*it.second}/a; val y=parts.sumOf{it.first*it.third}/a
            val ix=parts.sumOf{(ar,xx,yy)->(if(yy==h/2) tw*(h-2*tf).pow3()/12 else b*tf.pow3()/12) + ar*(yy-y).pow2()}
            val iy=parts.sumOf{(ar,xx,yy)->(if(xx==tw/2) (h-2*tf)*tw.pow3()/12 else tf*b.pow3()/12) + ar*(xx-x).pow2()}
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(a,p),"m²",true),CalcResultItem("Centroid X from back",fmt(x,p),"m"),CalcResultItem("Centroid Y",fmt(y,p),"m"),CalcResultItem("Ix",fmt(ix,p),"m⁴"),CalcResultItem("Iy",fmt(iy,p),"m⁴")), "Three non-overlapping rectangles; parallel-axis theorem", listOf("Web + top flange + bottom flange"), "Ideal sharp-corner channel; centroid and inertia are for the stated orientation."))
        },
        tool("phase_g_hollow_rect_section", "Rectangular Hollow Section Properties", "Area, Ix/Iy, section modulus and radii of gyration", listOf(dim("b","Outside width"),dim("h","Outside depth"),dim("tw","Uniform wall thickness")), listOf("rhs","box section","hollow rectangle","inertia")) { c ->
            val b=c.lengthMeters("b")?:0.0; val h=c.lengthMeters("h")?:0.0; val t=c.lengthMeters("tw")?:0.0; val p=c.settings.decimalPrecision
            if(b<=0||h<=0||t<=0||2*t>=b||2*t>=h) return@tool Result.failure(IllegalArgumentException("Wall thickness must leave positive internal dimensions."))
            val bi=b-2*t; val hi=h-2*t; val a=b*h-bi*hi; val ix=(b*h.pow3()-bi*hi.pow3())/12; val iy=(h*b.pow3()-hi*bi.pow3())/12
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(a,p),"m²",true),CalcResultItem("Ix",fmt(ix,p),"m⁴"),CalcResultItem("Iy",fmt(iy,p),"m⁴"),CalcResultItem("Zx",fmt(ix/(h/2),p),"m³"),CalcResultItem("Zy",fmt(iy/(b/2),p),"m³"),CalcResultItem("rx",fmt(sqrt(ix/a),p),"m"),CalcResultItem("ry",fmt(sqrt(iy/a),p),"m")), "Hollow section = outer rectangle − inner rectangle", listOf("Internal size = ${fmt(bi,p)} × ${fmt(hi,p)} m"), "Uniform wall thickness and sharp corners assumed; actual rolled RHS corner radii change properties."))
        },
        tool("phase_g_quadrilateral_centroid", "Quadrilateral Area & Centroid", "Area and centroid from four ordered vertex coordinates", listOf(dim("x1","Vertex 1 X","0"),dim("y1","Vertex 1 Y","0"),dim("x2","Vertex 2 X","400"),dim("y2","Vertex 2 Y","0"),dim("x3","Vertex 3 X","350"),dim("y3","Vertex 3 Y","300"),dim("x4","Vertex 4 X","50"),dim("y4","Vertex 4 Y","250")), listOf("quadrilateral","polygon","shoelace","centroid","plot area")) { c ->
            val xs=(1..4).map { c.lengthMeters("x$it") ?: 0.0 }; val ys=(1..4).map { c.lengthMeters("y$it") ?: 0.0 }; val p=c.settings.decimalPrecision
            var crossSum=0.0; var cxSum=0.0; var cySum=0.0
            for(i in 0..3) { val j=(i+1)%4; val cross=xs[i]*ys[j]-xs[j]*ys[i]; crossSum+=cross; cxSum+=(xs[i]+xs[j])*cross; cySum+=(ys[i]+ys[j])*cross }
            if(kotlin.math.abs(crossSum)<1e-12) return@tool Result.failure(IllegalArgumentException("Points form a zero-area or degenerate polygon."))
            val signedArea=crossSum/2.0; val area=kotlin.math.abs(signedArea); val cx=cxSum/(3*crossSum); val cy=cySum/(3*crossSum)
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(area,p),"m²",true),CalcResultItem("Centroid X",fmt(cx,p),"m"),CalcResultItem("Centroid Y",fmt(cy,p),"m")), "Shoelace: A=½Σ(xᵢyᵢ₊₁−xᵢ₊₁yᵢ); centroid by polygon coordinate formula", listOf("Four vertices processed in the entered order; signed area = ${fmt(signedArea,p)} m²"), "Vertices must be entered sequentially around a simple, non-self-intersecting quadrilateral."))
        },
        tool("phase_g_rectangle_section_properties", "Rectangle Section Properties", "Centroidal inertia, section modulus and radius of gyration", listOf(dim("b","Section width"),dim("h","Section depth")), listOf("rectangle","section properties","inertia","modulus","radius gyration")) { c ->
            val b=c.lengthMeters("b")?:0.0; val h=c.lengthMeters("h")?:0.0; val p=c.settings.decimalPrecision
            if(b<=0||h<=0) return@tool Result.failure(IllegalArgumentException("Width and depth must be positive."))
            val a=b*h; val ix=b*h.pow3()/12; val iy=h*b.pow3()/12
            Result.success(CalcOutcome(listOf(CalcResultItem("Area",fmt(a,p),"m²",true),CalcResultItem("Ix",fmt(ix,p),"m⁴"),CalcResultItem("Iy",fmt(iy,p),"m⁴"),CalcResultItem("Zx",fmt(ix/(h/2),p),"m³"),CalcResultItem("Zy",fmt(iy/(b/2),p),"m³"),CalcResultItem("rx",fmt(sqrt(ix/a),p),"m"),CalcResultItem("ry",fmt(sqrt(iy/a),p),"m")), "Ix=bh³/12; Iy=hb³/12; Z=I/c; r=√(I/A)", listOf("A = b × h = ${fmt(a,p)} m²"), "Ideal solid rectangle; these are geometric properties, not a member capacity check."))
        }
    )

    private fun Double.pow2() = this * this
    private fun Double.pow3() = this * this * this
}

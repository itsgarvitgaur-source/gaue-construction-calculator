package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.math.tan

object ExpandedFootingAndColumnCalculators {

    internal data class MixRatio(val c: Double, val s: Double, val a: Double, val name: String)

    internal fun mixRatioFor(grade: String): MixRatio = when {
        grade.startsWith("M15") -> MixRatio(1.0, 2.0, 4.0, "M15")
        grade.startsWith("M25") -> MixRatio(1.0, 1.0, 2.0, "M25")
        grade.startsWith("M30") -> MixRatio(1.0, 0.85, 1.75, "M30")
        else -> MixRatio(1.0, 1.5, 3.0, "M20")
    }

    internal fun concreteBatch(wetVolM3: Double, mix: MixRatio, wastagePct: Double): Triple<Double, Double, Double> {
        val dryVol = wetVolM3 * (1.0 + wastagePct / 100.0) * 1.54
        val sum = mix.c + mix.s + mix.a
        val bags = (dryVol * (mix.c / sum)) / 0.0347
        val sandCft = dryVol * (mix.s / sum) * UnitConverter.CU_FT_IN_CU_M
        val aggCft = dryVol * (mix.a / sum) * UnitConverter.CU_FT_IN_CU_M
        return Triple(bags, sandCft, aggCft)
    }

    val footingTypes = listOf(
        "Isolated / Pad Footing",
        "Square Footing",
        "Rectangular Footing",
        "Circular Footing",
        "Stepped Footing",
        "Sloped Footing",
        "Tapered Footing",
        "Combined Footing (Rectangular)",
        "Trapezoidal Combined Footing",
        "Strap Footing",
        "Strip Footing",
        "Continuous Wall Footing"
    )

    fun isolatedMultiTypeFooting() = CalcToolSpec(
        id = "struct_isolated_footing",
        title = "Footing Calculator (All Shapes)",
        titleHi = "फुटिंग कैलकुलेटर (सभी प्रकार)",
        subtitle = "Isolated, Square, Circular, Stepped, Sloped, Tapered, Combined, Strap & Strip",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "footingType",
        keywords = listOf(
            "footing", "isolated", "square", "rectangular", "circular", "stepped",
            "sloped", "tapered", "combined", "trapezoidal", "strap", "strip", "wall footing", "pad"
        ),
        fields = listOf(
            CalcFieldSpec("footingType", "Footing Type", "Sloped Footing", options = footingTypes),
            CalcFieldSpec(
                key = "bl",
                label = "Base Length (L)",
                defaultValue = "2.2",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m -> m["footingType"] != "Circular Footing" && m["footingType"] != "Square Footing" },
                dynamicLabel = { m ->
                    when (m["footingType"]) {
                        "Strap Footing" -> "Footing 1 Length (L1)"
                        "Strip Footing", "Continuous Wall Footing" -> "Running Length (L)"
                        "Combined Footing (Rectangular)", "Trapezoidal Combined Footing" -> "Combined Length (L)"
                        else -> "Base Length (L)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "bw",
                label = "Base Width (B)",
                defaultValue = "1.8",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m -> m["footingType"] != "Circular Footing" },
                dynamicLabel = { m ->
                    when (m["footingType"]) {
                        "Square Footing" -> "Square Base Side (B = L)"
                        "Trapezoidal Combined Footing" -> "Narrow End Width (B1)"
                        "Strap Footing" -> "Footing 1 Width (B1)"
                        else -> "Base Width (B)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "b2",
                label = "Wide End / Footing 2 Width (B2)",
                defaultValue = "2.6",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m ->
                    m["footingType"] in setOf("Trapezoidal Combined Footing", "Strap Footing", "Stepped Footing")
                },
                dynamicLabel = { m ->
                    when (m["footingType"]) {
                        "Stepped Footing" -> "Upper Step Width (B2)"
                        "Strap Footing" -> "Footing 2 Width (B2)"
                        else -> "Wide End Width (B2)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "l2",
                label = "Upper Step / Footing 2 Length (L2)",
                defaultValue = "1.4",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m -> m["footingType"] in setOf("Stepped Footing", "Strap Footing") },
                dynamicLabel = { m ->
                    if (m["footingType"] == "Strap Footing") "Footing 2 Length (L2)" else "Upper Step Length (L2)"
                }
            ),
            CalcFieldSpec(
                key = "dia",
                label = "Circular Base Diameter (D)",
                defaultValue = "2.2",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m -> m["footingType"] == "Circular Footing" }
            ),
            CalcFieldSpec(
                key = "d1",
                label = "Bottom Pad Depth (D1)",
                defaultValue = "0.25",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                dynamicLabel = { m ->
                    when (m["footingType"]) {
                        "Stepped Footing" -> "Bottom Step Height (D1)"
                        "Sloped Footing", "Tapered Footing" -> "Edge Vertical Depth (D1)"
                        else -> "Footing Thickness (D1)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "d2",
                label = "Sloped / Upper Depth (D2)",
                defaultValue = "0.35",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                allowZero = true,
                visibleWhen = { m -> m["footingType"] in setOf("Sloped Footing", "Tapered Footing", "Stepped Footing") },
                dynamicLabel = { m ->
                    if (m["footingType"] == "Stepped Footing") "Upper Step Height (D2)" else "Sloped Frustum Rise (D2)"
                }
            ),
            CalcFieldSpec(
                key = "tl",
                label = "Column / Pedestal Length",
                defaultValue = "0.45",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m -> m["footingType"] !in setOf("Strip Footing") },
                dynamicLabel = { m ->
                    if (m["footingType"] == "Continuous Wall Footing") "Wall Stem Width (tw)" else "Column / Pedestal L"
                }
            ),
            CalcFieldSpec(
                key = "tw",
                label = "Column / Pedestal Width",
                defaultValue = "0.35",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m ->
                    m["footingType"] !in setOf("Circular Footing", "Strip Footing", "Continuous Wall Footing")
                }
            ),
            CalcFieldSpec(
                key = "pedH",
                label = "Pedestal Height Above Pad (0 if none)",
                defaultValue = "0.30",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                allowZero = true,
                visibleWhen = { m ->
                    m["footingType"] in setOf(
                        "Isolated / Pad Footing", "Square Footing", "Rectangular Footing",
                        "Circular Footing", "Sloped Footing", "Stepped Footing"
                    )
                }
            ),
            CalcFieldSpec(
                key = "strapClear",
                label = "Strap Clear Span (m)",
                defaultValue = "3.0",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.M,
                visibleWhen = { m -> m["footingType"] == "Strap Footing" }
            ),
            CalcFieldSpec(
                key = "strapW",
                label = "Strap Beam Width × Depth (mm W)",
                defaultValue = "350",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["footingType"] == "Strap Footing" }
            ),
            CalcFieldSpec(
                key = "strapD",
                label = "Strap Beam Depth",
                defaultValue = "550",
                unitKind = FieldUnitKind.LENGTH,
                defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["footingType"] == "Strap Footing" }
            ),
            CalcFieldSpec("excDepth", "Excavation Depth (m)", "1.5", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true),
            CalcFieldSpec("count", "Number of Footings", "4", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("footingType").ifBlank { "Sloped Footing" }
            val bl = ctx.lengthMeters("bl") ?: 2.2
            val bw = ctx.lengthMeters("bw") ?: 1.8
            val b2 = ctx.lengthMeters("b2") ?: 2.6
            val l2 = ctx.lengthMeters("l2") ?: 1.4
            val dia = ctx.lengthMeters("dia") ?: 2.2
            val d1 = ctx.lengthMeters("d1") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter footing depth D1."))
            val d2 = ctx.lengthMeters("d2") ?: 0.0
            val tl = ctx.lengthMeters("tl") ?: 0.45
            val tw = ctx.lengthMeters("tw") ?: 0.35
            val pedH = ctx.lengthMeters("pedH") ?: 0.0
            val excDepth = ctx.lengthMeters("excDepth") ?: 1.5
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (d1 <= 0 || n <= 0 || bw <= 0 || (type != "Circular Footing" && type != "Square Footing" && bl <= 0)) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All footing dimensions must be positive."))
            }

            var unitVol: Double
            var unitFormwork: Double
            var unitPcc: Double
            var unitExc: Double
            val formula: String
            val stepDetail: String

            when (type) {
                "Square Footing" -> {
                    val padVol = bw * bw * d1
                    val pedVol = tl * tw * pedH
                    unitVol = padVol + pedVol
                    unitFormwork = 4.0 * bw * d1 + 2.0 * (tl + tw) * pedH
                    unitPcc = (bw + 0.2) * (bw + 0.2) * 0.10
                    unitExc = (bw + 0.6) * (bw + 0.6) * excDepth
                    formula = "V = B²×D1 + (Col_L×Col_W×H_ped)"
                    stepDetail = "Square Pad ${UnitConverter.fmt(bw, p)}×${UnitConverter.fmt(bw, p)}×${UnitConverter.fmt(d1, p)} = ${UnitConverter.fmt(padVol, p)} m³"
                }
                "Circular Footing" -> {
                    val r = dia / 2.0
                    val rc = tl / 2.0
                    val padVol = PI * r * r * d1
                    val pedVol = PI * rc * rc * pedH
                    unitVol = padVol + pedVol
                    unitFormwork = PI * dia * d1 + PI * tl * pedH
                    unitPcc = PI * (r + 0.1) * (r + 0.1) * 0.10
                    unitExc = PI * (r + 0.3) * (r + 0.3) * excDepth
                    formula = "V = π(D/2)²×D1 + π(d_ped/2)²×H_ped"
                    stepDetail = "Circular Pad Ø${UnitConverter.fmt(dia, p)}m = ${UnitConverter.fmt(padVol, p)} m³"
                }
                "Stepped Footing" -> {
                    val step1 = bl * bw * d1
                    val step2 = l2 * b2 * d2
                    val pedVol = tl * tw * pedH
                    unitVol = step1 + step2 + pedVol
                    unitFormwork = 2.0 * (bl + bw) * d1 + 2.0 * (l2 + b2) * d2 + 2.0 * (tl + tw) * pedH
                    unitPcc = (bl + 0.2) * (bw + 0.2) * 0.10
                    unitExc = (bl + 0.6) * (bw + 0.6) * excDepth
                    formula = "V = (L1×B1×D1) + (L2×B2×D2) + Pedestal"
                    stepDetail = "Step 1=${UnitConverter.fmt(step1, p)} m³, Step 2=${UnitConverter.fmt(step2, p)} m³"
                }
                "Sloped Footing", "Tapered Footing" -> {
                    val a1 = bl * bw
                    val a2 = tl * tw
                    val rectVol = a1 * d1
                    val trapVol = if (d2 > 0) (d2 / 3.0) * (a1 + a2 + sqrt(a1 * a2)) else 0.0
                    val pedVol = a2 * pedH
                    unitVol = rectVol + trapVol + pedVol
                    unitFormwork = 2.0 * (bl + bw) * d1 + 2.0 * (tl + tw) * pedH
                    unitPcc = (bl + 0.2) * (bw + 0.2) * 0.10
                    unitExc = (bl + 0.6) * (bw + 0.6) * excDepth
                    formula = "V = L·B·D1 + (D2/3)(A1+A2+√(A1A2)) + A2·H_ped"
                    stepDetail = "Pad=${UnitConverter.fmt(rectVol, p)} m³, Sloped=${UnitConverter.fmt(trapVol, p)} m³"
                }
                "Trapezoidal Combined Footing" -> {
                    val areaPlan = 0.5 * (bw + b2) * bl
                    unitVol = areaPlan * d1
                    val sideEdge = sqrt(bl * bl + ((b2 - bw) / 2.0) * ((b2 - bw) / 2.0))
                    unitFormwork = (bw + b2 + 2.0 * sideEdge) * d1
                    unitPcc = 0.5 * (bw + b2 + 0.4) * (bl + 0.2) * 0.10
                    unitExc = 0.5 * (bw + b2 + 1.0) * (bl + 0.6) * excDepth
                    formula = "V = 0.5 × (B1 + B2) × L × D1"
                    stepDetail = "Trapezoid Area = ${UnitConverter.fmt(areaPlan, p)} m² × D=${UnitConverter.fmt(d1, p)}m"
                }
                "Strap Footing" -> {
                    val sbLen = ctx.lengthMeters("strapClear") ?: 3.0
                    val sbW = ctx.lengthMeters("strapW") ?: 0.35
                    val sbD = ctx.lengthMeters("strapD") ?: 0.55
                    val f1 = bl * bw * d1
                    val f2 = l2 * b2 * d1
                    val strap = sbLen * sbW * sbD
                    unitVol = f1 + f2 + strap
                    unitFormwork = (2.0 * (bl + bw) + 2.0 * (l2 + b2)) * d1 + sbLen * (sbW + 2.0 * sbD)
                    unitPcc = ((bl + 0.2) * (bw + 0.2) + (l2 + 0.2) * (b2 + 0.2)) * 0.10
                    unitExc = ((bl + 0.6) * (bw + 0.6) + (l2 + 0.6) * (b2 + 0.6) + sbLen * (sbW + 0.4)) * excDepth
                    formula = "V = (L1·B1 + L2·B2)·D1 + (L_strap × W_strap × D_strap)"
                    stepDetail = "Pad1=${UnitConverter.fmt(f1, p)} + Pad2=${UnitConverter.fmt(f2, p)} + Strap=${UnitConverter.fmt(strap, p)} m³"
                }
                "Strip Footing", "Continuous Wall Footing" -> {
                    unitVol = bl * bw * d1
                    unitFormwork = 2.0 * bl * d1
                    unitPcc = bl * (bw + 0.2) * 0.10
                    unitExc = bl * (bw + 0.4) * excDepth
                    formula = "V = L_run × Width × Depth"
                    stepDetail = "Continuous strip ${UnitConverter.fmt(bl, p)}×${UnitConverter.fmt(bw, p)}×${UnitConverter.fmt(d1, p)} m"
                }
                else -> {
                    // Isolated / Rectangular / Combined Rectangular
                    val padVol = bl * bw * d1
                    val pedVol = tl * tw * pedH
                    unitVol = padVol + pedVol
                    unitFormwork = 2.0 * (bl + bw) * d1 + 2.0 * (tl + tw) * pedH
                    unitPcc = (bl + 0.2) * (bw + 0.2) * 0.10
                    unitExc = (bl + 0.6) * (bw + 0.6) * excDepth
                    formula = "V = (L × B × D1) + Pedestal"
                    stepDetail = "Pad = ${UnitConverter.fmt(padVol, p)} m³ + Pedestal = ${UnitConverter.fmt(pedVol, p)} m³"
                }
            }

            val totalVol = unitVol * n
            val totalFormwork = unitFormwork * n
            val totalPcc = unitPcc * n
            val totalExc = unitExc * n
            val mix = mixRatioFor("M20")
            val (bags, sandCft, aggCft) = concreteBatch(totalVol, mix, ctx.settings.defaultWastagePercent)
            val steelPct = if (type.contains("Combined") || type == "Strap Footing") 0.011 else 0.0085
            val steelKg = totalVol * steelPct * 7850.0

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Footing Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Formwork (Shuttering) Area", UnitConverter.fmt(totalFormwork, p), "m²", isPrimary = true),
                        CalcResultItem("Excavation Quantity", UnitConverter.fmt(totalExc, p), "m³"),
                        CalcResultItem("PCC Blinding (100mm)", UnitConverter.fmt(totalPcc, p), "m³"),
                        CalcResultItem("Preliminary Steel Est.", UnitConverter.fmt(steelKg, p), "kg"),
                        CalcResultItem("Cement / Sand / Agg (M20)", "${UnitConverter.fmt(bags, 1)} Bags | ${UnitConverter.fmt(sandCft, 0)}/${UnitConverter.fmt(aggCft, 0)} CFT", "")
                    ),
                    formula = formula,
                    steps = listOf(
                        "Type: $type (${n.roundToInt()} Nos)",
                        stepDetail,
                        "Total Vol = ${UnitConverter.fmt(totalVol, p)} m³ | Formwork = ${UnitConverter.fmt(totalFormwork, p)} m²"
                    ),
                    assumptions = "100 mm PCC offset + 300 mm working pit clearance per side for excavation. Sloped footing top requires self-supporting concrete slump (25–50 mm)."
                )
            )
        }
    )

    fun multiTypeColumnCalculator() = CalcToolSpec(
        id = "struct_rect_column",
        title = "Column Calculator (All Shapes)",
        titleHi = "कॉलम कैलकुलेटर (सभी आकार)",
        subtitle = "Square, Rect, Circular, L, T, Cross, Polygonal, Tapered, Stepped, Pedestal & Capital",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "colType",
        keywords = listOf(
            "column", "square", "rectangular", "circular", "round", "l-shaped", "t-shaped",
            "cross", "polygonal", "tapered", "stepped", "short column", "pedestal", "capital", "base"
        ),
        fields = listOf(
            CalcFieldSpec(
                "colType", "Column Type", "Rectangular Column",
                options = listOf(
                    "Rectangular Column",
                    "Square Column",
                    "Circular / Round Column",
                    "L-Shaped Column",
                    "T-Shaped Column",
                    "Cross-Shaped (+) Column",
                    "Polygonal Column (Hex/Oct)",
                    "Tapered Column",
                    "Stepped Column",
                    "Short Column",
                    "Column with Pedestal",
                    "Column with Capital",
                    "Column with Base"
                )
            ),
            CalcFieldSpec(
                key = "b", label = "Width (B)", defaultValue = "300",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] !in setOf("Circular / Round Column", "Polygonal Column (Hex/Oct)") },
                dynamicLabel = { m ->
                    when (m["colType"]) {
                        "Square Column" -> "Column Side (B = D)"
                        "L-Shaped Column" -> "Leg 1 Length (L1)"
                        "T-Shaped Column" -> "Flange Width (Bf)"
                        "Cross-Shaped (+) Column" -> "Overall Cross Span (A)"
                        "Tapered Column", "Stepped Column" -> "Bottom Width (B1)"
                        else -> "Column Width (B)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "d", label = "Depth (D)", defaultValue = "450",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] !in setOf("Square Column", "Circular / Round Column", "Polygonal Column (Hex/Oct)") },
                dynamicLabel = { m ->
                    when (m["colType"]) {
                        "L-Shaped Column" -> "Leg 2 Length (L2)"
                        "T-Shaped Column" -> "Overall Web Depth (D)"
                        "Cross-Shaped (+) Column" -> "Arm Thickness (t)"
                        "Tapered Column", "Stepped Column" -> "Bottom Depth (D1)"
                        else -> "Column Depth (D)"
                    }
                }
            ),
            CalcFieldSpec(
                key = "armT", label = "Web / Arm Thickness (t)", defaultValue = "230",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] in setOf("L-Shaped Column", "T-Shaped Column") }
            ),
            CalcFieldSpec(
                key = "dia", label = "Column Diameter (D)", defaultValue = "450",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] == "Circular / Round Column" }
            ),
            CalcFieldSpec(
                key = "polySides", label = "Polygon Sides", defaultValue = "6 (Hexagon)",
                options = listOf("6 (Hexagon)", "8 (Octagon)", "5 (Pentagon)"),
                visibleWhen = { m -> m["colType"] == "Polygonal Column (Hex/Oct)" }
            ),
            CalcFieldSpec(
                key = "polySideLen", label = "Polygon Side Length (a)", defaultValue = "220",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] == "Polygonal Column (Hex/Oct)" }
            ),
            CalcFieldSpec(
                key = "topB", label = "Top Width (B2)", defaultValue = "230",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] in setOf("Tapered Column", "Stepped Column") }
            ),
            CalcFieldSpec(
                key = "topD", label = "Top Depth (D2)", defaultValue = "300",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] in setOf("Tapered Column", "Stepped Column") }
            ),
            CalcFieldSpec(
                key = "pedW", label = "Pedestal / Capital / Base Width", defaultValue = "600",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] in setOf("Column with Pedestal", "Column with Capital", "Column with Base") }
            ),
            CalcFieldSpec(
                key = "pedH", label = "Pedestal / Capital / Base Height", defaultValue = "600",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                visibleWhen = { m -> m["colType"] in setOf("Column with Pedestal", "Column with Capital", "Column with Base") }
            ),
            CalcFieldSpec(
                key = "h", label = "Column Height (H)", defaultValue = "3.2",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                dynamicLabel = { m -> if (m["colType"] == "Short Column") "Short Column Height (H)" else "Column Height (H)" }
            ),
            CalcFieldSpec("count", "Number of Columns", "6", FieldUnitKind.COUNT),
            CalcFieldSpec("steelPct", "Est. Steel % (Typically 1.5–2.5%)", "2.0", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("colType").ifBlank { "Rectangular Column" }
            val b = ctx.lengthMeters("b") ?: 0.3
            val d = ctx.lengthMeters("d") ?: 0.45
            val armT = ctx.lengthMeters("armT") ?: 0.23
            val dia = ctx.lengthMeters("dia") ?: 0.45
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val n = ctx.doubleOrNull("count") ?: 1.0
            val sp = ctx.doubleOrNull("steelPct") ?: 2.0
            if (h <= 0 || n <= 0 || sp < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid height or count."))

            val areaM2: Double
            val perimM: Double
            val unitVol: Double
            val formula: String

            when (type) {
                "Square Column" -> {
                    areaM2 = b * b
                    perimM = 4.0 * b
                    unitVol = areaM2 * h
                    formula = "A = B²; V = B² × H × N; Formwork = 4·B·H·N"
                }
                "Circular / Round Column" -> {
                    val r = dia / 2.0
                    areaM2 = PI * r * r
                    perimM = PI * dia
                    unitVol = areaM2 * h
                    formula = "A = π(D/2)²; V = A × H × N; Formwork = π·D·H·N"
                }
                "L-Shaped Column" -> {
                    val t = armT.coerceAtMost(minOf(b, d))
                    areaM2 = b * t + (d - t) * t
                    perimM = 2.0 * (b + d)
                    unitVol = areaM2 * h
                    formula = "A = L1·t + (L2 - t)·t; Formwork = 2(L1 + L2)·H"
                }
                "T-Shaped Column" -> {
                    val t = armT.coerceAtMost(minOf(b, d))
                    areaM2 = b * t + (d - t) * t
                    perimM = 2.0 * (b + d)
                    unitVol = areaM2 * h
                    formula = "A = Bf·t + (D - t)·t; Formwork = 2(Bf + D)·H"
                }
                "Cross-Shaped (+) Column" -> {
                    val t = d.coerceAtMost(b)
                    areaM2 = 2.0 * b * t - t * t
                    perimM = 4.0 * b
                    unitVol = areaM2 * h
                    formula = "A = 2·A_span·t - t²; Formwork = 4·A_span·H"
                }
                "Polygonal Column (Hex/Oct)" -> {
                    val sides = ctx.raw("polySides").substringBefore(" ").toIntOrNull() ?: 6
                    val a = ctx.lengthMeters("polySideLen") ?: 0.22
                    areaM2 = (sides * a * a) / (4.0 * tan(PI / sides))
                    perimM = sides * a
                    unitVol = areaM2 * h
                    formula = "A = (n·a²)/(4·tan(π/n)); V = A × H"
                }
                "Tapered Column" -> {
                    val b2 = ctx.lengthMeters("topB") ?: 0.23
                    val d2 = ctx.lengthMeters("topD") ?: 0.30
                    val a1 = b * d
                    val a2 = b2 * d2
                    areaM2 = 0.5 * (a1 + a2)
                    perimM = b + d + b2 + d2
                    unitVol = (h / 3.0) * (a1 + a2 + sqrt(a1 * a2))
                    formula = "V = (H/3)(A_bot + A_top + √(A_bot·A_top))"
                }
                "Stepped Column" -> {
                    val b2 = ctx.lengthMeters("topB") ?: 0.23
                    val d2 = ctx.lengthMeters("topD") ?: 0.30
                    val a1 = b * d
                    val a2 = b2 * d2
                    areaM2 = a1
                    perimM = b + d + b2 + d2
                    unitVol = (a1 + a2) * (h * 0.5)
                    formula = "V = (A1 + A2) × (H / 2)"
                }
                "Column with Pedestal", "Column with Base", "Column with Capital" -> {
                    val pw = ctx.lengthMeters("pedW") ?: 0.6
                    val ph = ctx.lengthMeters("pedH") ?: 0.6
                    areaM2 = b * d
                    val extraArea = pw * pw
                    val extraVol = if (type == "Column with Capital") {
                        (ph / 3.0) * (areaM2 + extraArea + sqrt(areaM2 * extraArea))
                    } else extraArea * ph
                    perimM = 2.0 * (b + d)
                    unitVol = areaM2 * h + extraVol
                    formula = "V = (B·D·H_shaft) + V_${type.substringAfter("with ")}"
                }
                else -> {
                    areaM2 = b * d
                    perimM = 2.0 * (b + d)
                    unitVol = areaM2 * h
                    formula = "V = B × D × H × N; Formwork = 2(B + D)·H·N"
                }
            }

            val totalVol = unitVol * n
            val totalFormwork = perimM * h * n
            val steelKg = totalVol * (sp / 100.0) * 7850.0
            val (bags, sandCft, aggCft) = concreteBatch(totalVol, mixRatioFor("M25"), ctx.settings.defaultWastagePercent)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Formwork Area", UnitConverter.fmt(totalFormwork, p), "m²", isPrimary = true),
                        CalcResultItem("Preliminary Steel Est.", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true),
                        CalcResultItem("Cross-Section Area", UnitConverter.fmt(areaM2, 4), "m²"),
                        CalcResultItem("Cement / Sand / Agg (M25)", "${UnitConverter.fmt(bags, 1)} Bags | ${UnitConverter.fmt(sandCft, 0)}/${UnitConverter.fmt(aggCft, 0)} CFT", "")
                    ),
                    formula = formula,
                    steps = listOf(
                        "Selected Type: $type (${n.roundToInt()} Nos)",
                        "Cross-Section Area = ${UnitConverter.fmt(areaM2, 4)} m², Perimeter = ${UnitConverter.fmt(perimM, 3)} m",
                        "Concrete Volume = ${UnitConverter.fmt(totalVol, p)} m³ | Formwork = ${UnitConverter.fmt(totalFormwork, p)} m²"
                    ),
                    assumptions = "M25 mix, 40 mm clear cover. L/T/Cross/Tapered columns require special lateral tie detailing per IS 13920 / IS 456."
                )
            )
        }
    )

    fun pedestalCalculator() = CalcToolSpec(
        id = "struct_pedestal",
        title = "RCC Pedestal & Column Base",
        titleHi = "पेडेस्टल और कॉलम बेस गणना",
        subtitle = "Rectangular, Square, Circular & Stepped Pedestal Concrete, Formwork & Steel",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "pedType",
        keywords = listOf("pedestal", "column base", "plinth", "starter", "foundation"),
        fields = listOf(
            CalcFieldSpec("pedType", "Pedestal Type", "Rectangular Pedestal", options = listOf("Rectangular Pedestal", "Square Pedestal", "Circular Pedestal", "Stepped Pedestal")),
            CalcFieldSpec("b", "Pedestal Width (B)", "600", FieldUnitKind.LENGTH, LengthUnit.MM, visibleWhen = { it["pedType"] != "Circular Pedestal" }),
            CalcFieldSpec("d", "Pedestal Depth (D)", "600", FieldUnitKind.LENGTH, LengthUnit.MM, visibleWhen = { it["pedType"] in setOf("Rectangular Pedestal", "Stepped Pedestal") }),
            CalcFieldSpec("dia", "Pedestal Diameter", "650", FieldUnitKind.LENGTH, LengthUnit.MM, visibleWhen = { it["pedType"] == "Circular Pedestal" }),
            CalcFieldSpec("h", "Pedestal Height (H)", "0.9", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("count", "Number of Pedestals", "8", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("pedType")
            val b = ctx.lengthMeters("b") ?: 0.6
            val d = ctx.lengthMeters("d") ?: 0.6
            val dia = ctx.lengthMeters("dia") ?: 0.65
            val h = ctx.lengthMeters("h") ?: 0.9
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (h <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val (area, perim) = when (type) {
                "Square Pedestal" -> (b * b) to (4.0 * b)
                "Circular Pedestal" -> (PI * (dia / 2.0) * (dia / 2.0)) to (PI * dia)
                "Stepped Pedestal" -> ((b * d * 0.5) + ((b * 0.7) * (d * 0.7) * 0.5)) to (2.0 * (b + d))
                else -> (b * d) to (2.0 * (b + d))
            }
            val vol = area * h * n
            val fw = perim * h * n
            val steelKg = vol * 0.012 * 7850.0
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Pedestal Concrete", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Formwork Area", UnitConverter.fmt(fw, p), "m²", isPrimary = true),
                        CalcResultItem("Est. Dowel/Cage Steel", UnitConverter.fmt(steelKg, p), "kg")
                    ),
                    formula = "V = Area × H × N; Formwork = Perimeter × H × N",
                    steps = listOf("Type: $type; Unit Vol = ${UnitConverter.fmt(area * h, p)} m³"),
                    assumptions = "Nominal cover 40–50 mm; includes PEB/RCC column pedestal base."
                )
            )
        }
    )
}

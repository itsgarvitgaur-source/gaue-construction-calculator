package com.example.features.bbs

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.core.i18n.LocalAppStrings
import com.example.data.local.BbsScheduleEntity
import com.example.domain.units.UnitConverter
import com.example.features.diagrams.CadColors
import com.example.features.diagrams.drawCadTextPill
import com.example.features.diagrams.drawDashedLine
import com.example.features.diagrams.drawDimensionLine
import com.example.features.diagrams.drawEngineeringGrid
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette
import com.example.ui.theme.MonoFontFamily
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sqrt

enum class BarShapeType(val label: String) {
    STRAIGHT("Straight Bar"),
    L_BEND("L-Bend (90°)"),
    U_BAR("U-Bar (2×90°)"),
    STIRRUP("2-Leg Stirrup"),
    CIRCULAR_RING("Circular Ring"),
    CRANK("Crank / Bent-up"),
    CHAIR("Chair Bar")
}

data class BbsBarEntry(
    val id: Long,
    val mark: String,
    val diaMm: Int,
    val shape: BarShapeType,
    val dimAMm: Double,
    val dimBMm: Double,
    val dimCMm: Double,
    val quantity: Int,
    val hookMm: Double,
    val lapMm: Double,
    val bendDeductionMm: Double,
    val spacingMm: Double = 150.0
) {
    val cuttingLengthM: Double
        get() {
            val d = diaMm.toDouble()
            val rawMm = when (shape) {
                BarShapeType.STRAIGHT -> dimAMm + lapMm + 2 * hookMm
                BarShapeType.L_BEND -> dimAMm + dimBMm + hookMm - bendDeductionMm
                BarShapeType.U_BAR -> dimAMm + 2 * dimBMm + 2 * hookMm - 2 * bendDeductionMm
                BarShapeType.STIRRUP -> 2 * (dimAMm + dimBMm) + 2 * (10 * d) - 3 * (2 * d) - 2 * (3 * d)
                BarShapeType.CIRCULAR_RING -> PI * dimAMm + 2 * (10 * d)
                BarShapeType.CRANK -> dimAMm + 2 * (0.42 * dimBMm) + dimCMm + lapMm
                BarShapeType.CHAIR -> dimAMm + 2 * dimBMm + 2 * dimCMm - 4 * bendDeductionMm
            }.coerceAtLeast(100.0)
            return rawMm / 1000.0
        }

    val totalLengthM: Double get() = cuttingLengthM * quantity
    val unitWeightKgPerM: Double get() = (diaMm * diaMm) / 162.2
    val totalWeightKg: Double get() = totalLengthM * unitWeightKgPerM
}

private fun presetEntriesForMember(memberType: String): List<BbsBarEntry> = when (memberType) {
    "Column BBS" -> listOf(
        BbsBarEntry(1, "C-Main", 16, BarShapeType.L_BEND, 3400.0, 300.0, 0.0, 8, 0.0, 750.0, 32.0),
        BbsBarEntry(2, "C-Tie", 8, BarShapeType.STIRRUP, 220.0, 370.0, 0.0, 22, 80.0, 0.0, 16.0)
    )
    "Slab BBS" -> listOf(
        BbsBarEntry(1, "S-Main", 10, BarShapeType.CRANK, 3950.0, 100.0, 450.0, 28, 0.0, 0.0, 20.0),
        BbsBarEntry(2, "S-Dist", 8, BarShapeType.STRAIGHT, 4950.0, 0.0, 0.0, 21, 72.0, 0.0, 0.0),
        BbsBarEntry(3, "S-Chair", 10, BarShapeType.CHAIR, 300.0, 80.0, 150.0, 16, 0.0, 0.0, 20.0)
    )
    "Footing BBS" -> listOf(
        BbsBarEntry(1, "F-Long", 12, BarShapeType.U_BAR, 1900.0, 200.0, 0.0, 14, 0.0, 0.0, 24.0),
        BbsBarEntry(2, "F-Short", 12, BarShapeType.U_BAR, 1700.0, 200.0, 0.0, 15, 0.0, 0.0, 24.0)
    )
    "Staircase BBS" -> listOf(
        BbsBarEntry(1, "ST-Main", 12, BarShapeType.STRAIGHT, 4600.0, 0.0, 0.0, 9, 108.0, 500.0, 0.0),
        BbsBarEntry(2, "ST-Dist", 8, BarShapeType.STRAIGHT, 1150.0, 0.0, 0.0, 24, 72.0, 0.0, 0.0)
    )
    else -> listOf(
        BbsBarEntry(1, "B-Bot", 16, BarShapeType.L_BEND, 4950.0, 350.0, 0.0, 3, 0.0, 0.0, 32.0),
        BbsBarEntry(2, "B-Top", 12, BarShapeType.L_BEND, 4950.0, 350.0, 0.0, 3, 0.0, 0.0, 24.0),
        BbsBarEntry(3, "B-Stir", 8, BarShapeType.STIRRUP, 180.0, 400.0, 0.0, 34, 80.0, 0.0, 16.0)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BbsStudioScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val savedSchedules by viewModel.bbsList.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()

    val memberTypes = listOf("Beam BBS", "Column BBS", "Slab BBS", "Footing BBS", "Staircase BBS")
    var selectedMember by remember { mutableStateOf("Beam BBS") }
    var scheduleTitle by remember { mutableStateOf("Ground Floor Beam B1") }
    val entries = remember { mutableStateListOf<BbsBarEntry>().apply { addAll(presetEntriesForMember("Beam BBS")) } }
    var selectedBarId by remember { mutableStateOf<Long?>(entries.firstOrNull()?.id) }
    var editingEntry by remember { mutableStateOf<BbsBarEntry?>(null) }
    var showAddEditDialog by remember { mutableStateOf(false) }

    val selectedEntry = entries.firstOrNull { it.id == selectedBarId } ?: entries.firstOrNull()
    val totalWeightKg = entries.sumOf { it.totalWeightKg }
    val diaSummary = entries.groupBy { it.diaMm }.mapValues { (_, list) -> list.sumOf { it.totalWeightKg } }.toSortedMap()

    fun buildBbsReport(): EngineeringReportData {
        val rows = entries.map { e ->
            listOf(
                e.mark,
                "${e.diaMm}mm",
                e.shape.label,
                "${e.quantity}",
                UnitConverter.fmt(e.cuttingLengthM, 3),
                UnitConverter.fmt(e.totalLengthM, 2),
                UnitConverter.fmt(e.totalWeightKg, 2)
            )
        }
        val summaryRows = diaSummary.map { (d, w) -> "${d} mm TMT" to "${UnitConverter.fmt(w, 2)} kg" } +
            ("TOTAL STEEL" to "${UnitConverter.fmt(totalWeightKg, 2)} kg (${UnitConverter.fmt(totalWeightKg / 1000.0, 3)} MT)")

        return EngineeringReportData(
            title = "Bar Bending Schedule — $scheduleTitle",
            projectName = selectedMember,
            companyName = settings.companyName,
            engineerName = settings.engineerName,
            subtitle = "IS 2502 / SP 34 Detailing Summary",
            sections = listOf(
                ReportSection(
                    heading = "Schedule Table",
                    tableHeaders = listOf("Mark", "Dia", "Shape", "Qty", "Cut(m)", "Tot(m)", "Wt(kg)"),
                    tableRows = rows
                ),
                ReportSection("Diameter-Wise Steel Summary", rows = summaryRows)
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = strings.bbsTitle,
            subtitle = "Total: ${UnitConverter.fmt(totalWeightKg, 2)} kg",
            onBack = onBack,
            actions = {
                IconButton(
                    onClick = {
                        val json = JSONArray().apply {
                            entries.forEach { e ->
                                put(JSONObject().apply {
                                    put("mark", e.mark)
                                    put("diaMm", e.diaMm)
                                    put("shape", e.shape.name)
                                    put("dimA", e.dimAMm)
                                    put("dimB", e.dimBMm)
                                    put("dimC", e.dimCMm)
                                    put("qty", e.quantity)
                                    put("hook", e.hookMm)
                                    put("lap", e.lapMm)
                                    put("bend", e.bendDeductionMm)
                                    put("spacing", e.spacingMm)
                                })
                            }
                        }.toString()
                        viewModel.saveBbs(
                            BbsScheduleEntity(
                                projectId = projects.firstOrNull()?.id,
                                title = scheduleTitle.ifBlank { selectedMember },
                                memberType = selectedMember,
                                itemsJson = json,
                                totalWeightKg = totalWeightKg
                            )
                        )
                        Toast.makeText(context, "BBS saved to Project Database", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("bbs_save_btn")
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = "Save BBS", tint = palette.orangeDark)
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Member type presets
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(memberTypes) { m ->
                        FilterChip(
                            selected = selectedMember == m,
                            onClick = {
                                selectedMember = m
                                scheduleTitle = m
                                entries.clear()
                                entries.addAll(presetEntriesForMember(m))
                                selectedBarId = entries.firstOrNull()?.id
                            },
                            label = { Text(m) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = palette.orangeSoft,
                                selectedLabelColor = palette.orangeDark
                            ),
                            border = BorderStroke(1.dp, palette.metallicBorder)
                        )
                    }
                }
            }

            // Title & Summary Card
            item {
                EngineeringCard(accentColor = palette.orange) {
                    OutlinedTextField(
                        value = scheduleTitle,
                        onValueChange = { scheduleTitle = it },
                        label = { Text("BBS Schedule Title / Member ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Steel Weight", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            Text(
                                "${UnitConverter.fmt(totalWeightKg, 2)} kg  (${UnitConverter.fmt(totalWeightKg / 1000.0, 3)} MT)",
                                style = MaterialTheme.typography.titleLarge,
                                color = palette.orangeDark
                            )
                        }
                        Button(
                            onClick = {
                                editingEntry = null
                                showAddEditDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.orange),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("bbs_add_bar_btn")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add Bar")
                        }
                    }

                    if (diaSummary.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(diaSummary.entries.toList()) { (dia, wt) ->
                                GlassBluePill(text = "${dia}mm: ${UnitConverter.fmt(wt, 1)} kg")
                            }
                        }
                    }
                }
            }

            // Detailed Dimensioned BBS Shape Figure Card
            selectedEntry?.let { bar ->
                item {
                    InteractiveBbsDetailDiagramCard(entry = bar)
                }
            }

            // Export Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val file = ReportExportEngine.generatePdfFile(context, buildBbsReport())
                            ReportExportEngine.shareFile(context, file, "application/pdf", scheduleTitle)
                        },
                        modifier = Modifier.weight(1f).testTag("bbs_pdf_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.error)
                        Spacer(Modifier.width(4.dp))
                        Text("PDF")
                    }
                    OutlinedButton(
                        onClick = {
                            val headers = listOf("Bar Mark", "Dia (mm)", "Shape", "Qty", "Cut Length (m)", "Total Length (m)", "Unit Wt (kg/m)", "Total Wt (kg)")
                            val rows = entries.map { e ->
                                listOf(
                                    e.mark,
                                    e.diaMm.toString(),
                                    e.shape.label,
                                    e.quantity.toString(),
                                    UnitConverter.fmt(e.cuttingLengthM, 3),
                                    UnitConverter.fmt(e.totalLengthM, 2),
                                    UnitConverter.fmt(e.unitWeightKgPerM, 3),
                                    UnitConverter.fmt(e.totalWeightKg, 2)
                                )
                            }
                            val file = ReportExportEngine.generateExcelWorkbookFile(context, "BBS_$scheduleTitle", headers, rows)
                            ReportExportEngine.shareFile(context, file, "application/vnd.ms-excel", scheduleTitle)
                        },
                        modifier = Modifier.weight(1f).testTag("bbs_excel_btn"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.success)
                        Spacer(Modifier.width(4.dp))
                        Text("Excel")
                    }
                    OutlinedButton(
                        onClick = {
                            val file = ReportExportEngine.generatePdfFile(context, buildBbsReport())
                            ReportExportEngine.printPdfFile(context, file, scheduleTitle)
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Print")
                    }
                }
            }

            // Bar Entries with Visual Shape Previews
            items(entries, key = { it.id }) { item ->
                val isSelected = selectedEntry?.id == item.id
                EngineeringCard(
                    accentColor = if (isSelected) palette.orange else palette.skyBlue,
                    onClick = { selectedBarId = item.id }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Visual Bar Shape Preview Canvas
                        Surface(
                            color = palette.skyGlassTint,
                            border = BorderStroke(1.dp, if (isSelected) palette.orange else palette.skyGlassBorder),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.size(76.dp)
                        ) {
                            BarShapePreviewCanvas(shape = item.shape, modifier = Modifier.fillMaxSize().padding(8.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${item.mark}  •  Ø${item.diaMm}mm",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = palette.inkPrimary
                                )
                                Text(
                                    text = "${UnitConverter.fmt(item.totalWeightKg, 2)} kg",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = palette.orangeDark,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "${item.shape.label}  × ${item.quantity} Nos  •  @${item.spacingMm.toInt()}mm c/c",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.skyBlue,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Cut: ${UnitConverter.fmt(item.cuttingLengthM, 3)} m  |  Tot: ${UnitConverter.fmt(item.totalLengthM, 2)} m",
                                fontFamily = MonoFontFamily,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkSecondary
                            )
                        }
                        IconButton(onClick = {
                            editingEntry = item
                            showAddEditDialog = true
                        }) {
                            Icon(Icons.Rounded.Edit, contentDescription = "Edit Bar", tint = palette.skyBlue)
                        }
                        IconButton(onClick = {
                            entries.remove(item)
                            if (selectedBarId == item.id) {
                                selectedBarId = entries.firstOrNull()?.id
                            }
                        }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete Bar", tint = palette.error)
                        }
                    }
                }
            }

            if (savedSchedules.isNotEmpty()) {
                item {
                    Text(
                        "Saved Schedules (${savedSchedules.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = palette.inkPrimary,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                items(savedSchedules, key = { it.id }) { saved ->
                    EngineeringCard(onClick = {
                        scheduleTitle = saved.title
                        selectedMember = saved.memberType
                        runCatching {
                            val arr = JSONArray(saved.itemsJson)
                            entries.clear()
                            for (i in 0 until arr.length()) {
                                val o = arr.getJSONObject(i)
                                entries.add(
                                    BbsBarEntry(
                                        id = System.nanoTime() + i,
                                        mark = o.optString("mark", "B${i + 1}"),
                                        diaMm = o.optInt("diaMm", 12),
                                        shape = BarShapeType.entries.firstOrNull { it.name == o.optString("shape") } ?: BarShapeType.STRAIGHT,
                                        dimAMm = o.optDouble("dimA", 3000.0),
                                        dimBMm = o.optDouble("dimB", 300.0),
                                        dimCMm = o.optDouble("dimC", 0.0),
                                        quantity = o.optInt("qty", 4),
                                        hookMm = o.optDouble("hook", 0.0),
                                        lapMm = o.optDouble("lap", 0.0),
                                        bendDeductionMm = o.optDouble("bend", 24.0),
                                        spacingMm = o.optDouble("spacing", 150.0)
                                    )
                                )
                            }
                            selectedBarId = entries.firstOrNull()?.id
                        }
                    }) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(saved.title, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                Text("${saved.memberType} • ${UnitConverter.fmt(saved.totalWeightKg, 2)} kg", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            }
                            IconButton(onClick = { viewModel.deleteBbs(saved.id) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Delete Saved", tint = palette.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddEditDialog) {
        BbsEntryEditorDialog(
            initial = editingEntry,
            onDismiss = { showAddEditDialog = false },
        onSave = { updated ->
            if (editingEntry != null) {
                val idx = entries.indexOfFirst { it.id == editingEntry!!.id }
                if (idx >= 0) entries[idx] = updated
            } else {
                entries.add(updated)
            }
            selectedBarId = updated.id
            showAddEditDialog = false
        }
        )
    }
}

@Composable
private fun InteractiveBbsDetailDiagramCard(entry: BbsBarEntry) {
    val palette = LocalEngineeringPalette.current
    var zoom by remember(entry.id) { mutableFloatStateOf(1f) }
    var panX by remember(entry.id) { mutableFloatStateOf(0f) }
    var panY by remember(entry.id) { mutableFloatStateOf(0f) }

    EngineeringCard(
        accentColor = palette.skyBlue,
        modifier = Modifier.testTag("bbs_detail_diagram_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.skyGlassTint)
                        .border(1.dp, palette.skyGlassBorder, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Straighten, contentDescription = null, tint = palette.skyBlue, modifier = Modifier.size(16.dp))
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        "BBS Bar Detail Drawing — ${entry.mark}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = palette.inkPrimary
                    )
                    Text(
                        "Tap any bar below to inspect • Cut ${UnitConverter.fmt(entry.cuttingLengthM, 3)} m",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.inkMuted
                    )
                }
            }
        }

        Spacer(Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(palette.concreteSurfaceAlt)
                .border(1.dp, palette.metallicBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassBluePill(
                text = "Mark ${entry.mark} • Ø${entry.diaMm}mm • @${entry.spacingMm.toInt()}mm",
                modifier = Modifier.weight(1f, fill = false)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { zoom = (zoom * 1.22f).coerceAtMost(2.8f) }, modifier = Modifier.minimumInteractiveComponentSize().testTag("bbs_zoom_in")) {
                    Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom In", tint = palette.skyBlue)
                }
                IconButton(onClick = { zoom = (zoom / 1.22f).coerceAtLeast(0.6f) }, modifier = Modifier.minimumInteractiveComponentSize().testTag("bbs_zoom_out")) {
                    Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom Out", tint = palette.skyBlue)
                }
                IconButton(onClick = { zoom = 1f; panX = 0f; panY = 0f }, modifier = Modifier.minimumInteractiveComponentSize().testTag("bbs_fit")) {
                    Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "Fit to Screen", tint = palette.inkPrimary)
                }
                IconButton(onClick = { zoom = 1f; panX = 0f; panY = 0f }, modifier = Modifier.minimumInteractiveComponentSize().testTag("bbs_reset")) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Reset View", tint = palette.orangeDark)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Surface(
            color = Color(0xFFFAFBFD),
            border = BorderStroke(1.5.dp, palette.skyGlassBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(235.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clipToBounds()
                    .testTag("bbs_detail_canvas")
                    .pointerInput(entry.id) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            panX = (panX + drag.x).coerceIn(-260f, 260f)
                            panY = (panY + drag.y).coerceIn(-200f, 200f)
                        }
                    }
            ) {
                drawEngineeringGrid(spacingPx = 32f)
                withTransform({
                    translate(left = panX, top = panY)
                    scale(scaleX = zoom, scaleY = zoom, pivot = Offset(size.width / 2f, size.height / 2f))
                }) {
                    val pad = 74f
                    val w = size.width
                    val h = size.height
                    val barStroke = Stroke(width = 8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    val aLbl = "A=${entry.dimAMm.toInt()}mm"
                    val bLbl = "B=${entry.dimBMm.toInt()}mm"
                    val cLbl = "C=${entry.dimCMm.toInt()}mm"

                    when (entry.shape) {
                        BarShapeType.STRAIGHT -> {
                            val y = h * 0.52f
                            drawLine(CadColors.SteelBar, Offset(pad, y), Offset(w - pad, y), 9f, cap = StrokeCap.Round)
                            if (entry.hookMm > 0) {
                                drawLine(CadColors.SteelBar, Offset(pad, y), Offset(pad, y - 34f), 8f, cap = StrokeCap.Round)
                                drawLine(CadColors.SteelBar, Offset(w - pad, y), Offset(w - pad, y - 34f), 8f, cap = StrokeCap.Round)
                                drawDimensionLine(Offset(pad, y - 34f), Offset(pad, y), -44f, "Hook ${entry.hookMm.toInt()}mm", CadColors.DimOrange)
                            }
                            if (entry.lapMm > 0) {
                                drawDashedLine(Offset(w * 0.6f, y - 14f), Offset(w - pad, y - 14f), CadColors.DimOrange, 4f)
                                drawCadTextPill("Lap ${entry.lapMm.toInt()}mm", Offset(w * 0.74f, y - 34f), CadColors.DimOrange, textSizePx = 22f)
                            }
                            drawDimensionLine(Offset(pad, y), Offset(w - pad, y), 34f, aLbl)
                        }
                        BarShapeType.L_BEND -> {
                            val x0 = pad + 20f
                            val yTop = h * 0.25f
                            val yBot = h * 0.72f
                            val xEnd = w - pad
                            val path = Path().apply {
                                moveTo(x0, yTop)
                                lineTo(x0, yBot)
                                lineTo(xEnd, yBot)
                            }
                            drawPath(path, CadColors.SteelBar, style = barStroke)
                            drawDimensionLine(Offset(x0, yBot), Offset(xEnd, yBot), 34f, aLbl)
                            drawDimensionLine(Offset(x0, yTop), Offset(x0, yBot), -48f, bLbl, CadColors.DimOrange)
                            if (entry.lapMm > 0) {
                                drawCadTextPill("Lap=${entry.lapMm.toInt()}mm", Offset(x0 + 90f, yTop + 18f), CadColors.DimOrange, textSizePx = 22f)
                            }
                        }
                        BarShapeType.U_BAR -> {
                            val x0 = pad + 18f
                            val x1 = w - pad - 18f
                            val yTop = h * 0.26f
                            val yBot = h * 0.72f
                            val path = Path().apply {
                                moveTo(x0, yTop)
                                lineTo(x0, yBot)
                                lineTo(x1, yBot)
                                lineTo(x1, yTop)
                            }
                            drawPath(path, CadColors.SteelBar, style = barStroke)
                            drawDimensionLine(Offset(x0, yBot), Offset(x1, yBot), 34f, aLbl)
                            drawDimensionLine(Offset(x1, yTop), Offset(x1, yBot), -46f, bLbl, CadColors.DimOrange)
                        }
                        BarShapeType.STIRRUP -> {
                            val boxW = min(w * 0.44f, 180f)
                            val boxH = h * 0.54f
                            val left = w / 2f - boxW / 2f
                            val top = h * 0.23f
                            drawRect(CadColors.SteelBar, Offset(left, top), androidx.compose.ui.geometry.Size(boxW, boxH), style = Stroke(7f))
                            drawLine(CadColors.SteelBar, Offset(left, top), Offset(left + 32f, top + 30f), 7f, cap = StrokeCap.Round)
                            drawLine(CadColors.SteelBar, Offset(left + 10f, top), Offset(left + 40f, top + 24f), 7f, cap = StrokeCap.Round)
                            drawDimensionLine(Offset(left, top + boxH), Offset(left + boxW, top + boxH), 34f, aLbl)
                            drawDimensionLine(Offset(left, top), Offset(left, top + boxH), -50f, bLbl, CadColors.DimOrange)
                            drawCadTextPill("135° Hook ${(10 * entry.diaMm)}mm", Offset(w * 0.76f, top + 14f), CadColors.DimOrange, textSizePx = 22f)
                        }
                        BarShapeType.CIRCULAR_RING -> {
                            val r = min(w, h) * 0.28f
                            val c = Offset(w / 2f, h / 2f + 6f)
                            drawCircle(CadColors.SteelBar, r, c, style = Stroke(7f))
                            drawDimensionLine(Offset(c.x - r, c.y + r), Offset(c.x + r, c.y + r), 34f, "Dia=$aLbl")
                            drawCadTextPill("Hook=2×10d=${20 * entry.diaMm}mm", Offset(w / 2f, 26f), CadColors.DimOrange, textSizePx = 22f)
                        }
                        BarShapeType.CRANK -> {
                            val yBot = h * 0.72f
                            val yTop = h * 0.34f
                            val x0 = pad
                            val x1 = w * 0.34f
                            val x2 = w * 0.50f
                            val x3 = w - pad
                            val path = Path().apply {
                                moveTo(x0, yBot)
                                lineTo(x1, yBot)
                                lineTo(x2, yTop)
                                lineTo(x3, yTop)
                            }
                            drawPath(path, CadColors.SteelBar, style = barStroke)
                            drawDimensionLine(Offset(x0, yBot), Offset(x3, yBot), 34f, aLbl)
                            drawDimensionLine(Offset(x2, yTop), Offset(x2, yBot), -48f, "D=$bLbl (0.42D)", CadColors.DimOrange)
                            drawCadTextPill("Crank $cLbl", Offset((x2 + x3) / 2f, yTop - 22f), CadColors.DimBlue, textSizePx = 22f)
                        }
                        BarShapeType.CHAIR -> {
                            val yBot = h * 0.72f
                            val yTop = h * 0.32f
                            val p = Path().apply {
                                moveTo(pad, yBot)
                                lineTo(pad + 56f, yBot)
                                lineTo(pad + 56f, yTop)
                                lineTo(w - pad - 56f, yTop)
                                lineTo(w - pad - 56f, yBot)
                                lineTo(w - pad, yBot)
                            }
                            drawPath(p, CadColors.SteelBar, style = barStroke)
                            drawDimensionLine(Offset(pad + 56f, yTop), Offset(w - pad - 56f, yTop), -26f, "Head $aLbl")
                            drawDimensionLine(Offset(pad + 56f, yTop), Offset(pad + 56f, yBot), -52f, "Ht $bLbl", CadColors.DimOrange)
                            drawDimensionLine(Offset(w - pad - 56f, yBot), Offset(w - pad, yBot), 30f, "Leg $cLbl")
                        }
                    }

                    drawCadTextPill(
                        "Mark ${entry.mark}  •  Ø${entry.diaMm}mm  •  Cut L = ${UnitConverter.fmt(entry.cuttingLengthM, 3)} m  •  Bend Ded=${entry.bendDeductionMm.toInt()}mm",
                        Offset(w / 2f, 24f),
                        CadColors.DimBlue,
                        textSizePx = 22f
                    )
                }
            }
        }
    }
}

@Composable
fun BarShapePreviewCanvas(shape: BarShapeType, modifier: Modifier = Modifier) {
    val palette = LocalEngineeringPalette.current
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val barColor = palette.orangeDark
        val path = Path()
        when (shape) {
            BarShapeType.STRAIGHT -> {
                path.moveTo(w * 0.1f, h * 0.55f)
                path.lineTo(w * 0.9f, h * 0.55f)
            }
            BarShapeType.L_BEND -> {
                path.moveTo(w * 0.15f, h * 0.2f)
                path.lineTo(w * 0.15f, h * 0.78f)
                path.lineTo(w * 0.88f, h * 0.78f)
            }
            BarShapeType.U_BAR -> {
                path.moveTo(w * 0.18f, h * 0.22f)
                path.lineTo(w * 0.18f, h * 0.78f)
                path.lineTo(w * 0.82f, h * 0.78f)
                path.lineTo(w * 0.82f, h * 0.22f)
            }
            BarShapeType.STIRRUP -> {
                path.moveTo(w * 0.34f, h * 0.34f)
                path.lineTo(w * 0.22f, h * 0.2f)
                path.lineTo(w * 0.8f, h * 0.2f)
                path.lineTo(w * 0.8f, h * 0.82f)
                path.lineTo(w * 0.2f, h * 0.82f)
                path.lineTo(w * 0.2f, h * 0.2f)
                path.lineTo(w * 0.38f, h * 0.25f)
            }
            BarShapeType.CIRCULAR_RING -> {
                drawCircle(color = barColor, radius = minOf(w, h) * 0.34f, center = Offset(w / 2f, h / 2f), style = stroke)
                drawLine(barColor, Offset(w * 0.5f, h * 0.16f), Offset(w * 0.68f, h * 0.28f), strokeWidth = 4f, cap = StrokeCap.Round)
                return@Canvas
            }
            BarShapeType.CRANK -> {
                path.moveTo(w * 0.08f, h * 0.72f)
                path.lineTo(w * 0.35f, h * 0.72f)
                path.lineTo(w * 0.52f, h * 0.28f)
                path.lineTo(w * 0.92f, h * 0.28f)
            }
            BarShapeType.CHAIR -> {
                path.moveTo(w * 0.1f, h * 0.75f)
                path.lineTo(w * 0.28f, h * 0.75f)
                path.lineTo(w * 0.28f, h * 0.25f)
                path.lineTo(w * 0.72f, h * 0.25f)
                path.lineTo(w * 0.72f, h * 0.75f)
                path.lineTo(w * 0.9f, h * 0.75f)
            }
        }
        drawPath(path, color = barColor, style = stroke)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BbsEntryEditorDialog(
    initial: BbsBarEntry?,
    onDismiss: () -> Unit,
    onSave: (BbsBarEntry) -> Unit
) {
    var mark by remember { mutableStateOf(initial?.mark ?: "B4") }
    var dia by remember { mutableStateOf((initial?.diaMm ?: 12).toString()) }
    var shape by remember { mutableStateOf(initial?.shape ?: BarShapeType.L_BEND) }
    var dimA by remember { mutableStateOf((initial?.dimAMm ?: 4000.0).toInt().toString()) }
    var dimB by remember { mutableStateOf((initial?.dimBMm ?: 300.0).toInt().toString()) }
    var dimC by remember { mutableStateOf((initial?.dimCMm ?: 0.0).toInt().toString()) }
    var qty by remember { mutableStateOf((initial?.quantity ?: 4).toString()) }
    var hook by remember { mutableStateOf((initial?.hookMm ?: 0.0).toInt().toString()) }
    var lap by remember { mutableStateOf((initial?.lapMm ?: 0.0).toInt().toString()) }
    var bend by remember { mutableStateOf((initial?.bendDeductionMm ?: 24.0).toInt().toString()) }
    var spacing by remember { mutableStateOf((initial?.spacingMm ?: 150.0).toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add BBS Bar Entry" else "Edit BBS Bar") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = mark, onValueChange = { mark = it }, label = { Text("Mark") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = dia, onValueChange = { dia = it }, label = { Text("Dia (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                var shapeOpen by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = shapeOpen, onExpandedChange = { shapeOpen = !shapeOpen }) {
                    OutlinedTextField(
                        value = shape.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Bar Shape") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = shapeOpen) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = shapeOpen, onDismissRequest = { shapeOpen = false }) {
                        BarShapeType.entries.forEach { s ->
                            DropdownMenuItem(text = { Text(s.label) }, onClick = { shape = s; shapeOpen = false })
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = dimA, onValueChange = { dimA = it }, label = { Text("Dim A (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = dimB, onValueChange = { dimB = it }, label = { Text("Dim B (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = dimC, onValueChange = { dimC = it }, label = { Text("Dim C (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = hook, onValueChange = { hook = it }, label = { Text("Hook (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = lap, onValueChange = { lap = it }, label = { Text("Lap (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = bend, onValueChange = { bend = it }, label = { Text("Bend Ded.") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = spacing, onValueChange = { spacing = it }, label = { Text("Spacing c/c (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    BbsBarEntry(
                        id = initial?.id ?: System.nanoTime(),
                        mark = mark.ifBlank { "B1" },
                        diaMm = (dia.toIntOrNull() ?: 12).coerceIn(6, 40),
                        shape = shape,
                        dimAMm = (dimA.toDoubleOrNull() ?: 3000.0).coerceAtLeast(50.0),
                        dimBMm = (dimB.toDoubleOrNull() ?: 300.0).coerceAtLeast(0.0),
                        dimCMm = (dimC.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                        quantity = (qty.toIntOrNull() ?: 1).coerceAtLeast(1),
                        hookMm = (hook.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                        lapMm = (lap.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                        bendDeductionMm = (bend.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                        spacingMm = (spacing.toDoubleOrNull() ?: 150.0).coerceAtLeast(50.0)
                    )
                )
            }) { Text("Save Bar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

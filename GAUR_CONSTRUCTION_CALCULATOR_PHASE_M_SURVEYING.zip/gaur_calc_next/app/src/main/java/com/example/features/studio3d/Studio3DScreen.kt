package com.example.features.studio3d

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.GridOn
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.ReportExportEngine
import com.example.core.i18n.LocalAppStrings
import com.example.data.local.StudioModel3DEntity
import com.example.domain.units.UnitConverter
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.LocalEngineeringPalette
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin

enum class Object3DType(val label: String, val colorHex: Long) {
    GROUND("Ground", 0xFF94A3B8),
    FOUNDATION("Foundation", 0xFF64748B),
    FOOTING("Footing", 0xFF78716C),
    PEDESTAL("Pedestal", 0xFF94A3B8),
    COLUMN("Column", 0xFFF57C00),
    BEAM("Beam", 0xFFFB923C),
    SLAB("Slab", 0xFF0288D1),
    STAIRCASE("Staircase", 0xFF38BDF8),
    WALL("Wall", 0xFFE2E8F0),
    DOOR("Door", 0xFF92400E),
    WINDOW("Window", 0xFF7DD3FC),
    ROOF("Roof", 0xFFEA580C),
    PEB_FRAME("PEB Frame", 0xFFF97316),
    PURLINS("Purlins", 0xFFCBD5E1),
    ROOFING_SHEETS("Roofing Sheets", 0xFF0EA5E9),
    REINFORCEMENT_BARS("Reinforcement Bars", 0xFFDC2626)
}

data class Structural3DObject(
    val id: Long,
    val type: Object3DType,
    val label: String,
    val x: Float,
    val y: Float,
    val z: Float, // elevation
    val l: Float, // X size
    val w: Float, // Y size
    val h: Float, // Z height
    val visible: Boolean = true
)

private data class Vec3(val x: Float, val y: Float, val z: Float)

private fun preset3DAssembly(name: String): List<Structural3DObject> = when (name) {
    "Footing + Column + Rebar" -> listOf(
        Structural3DObject(1, Object3DType.GROUND, "Ground", -1.5f, -1.5f, -0.8f, 4f, 4f, 0.1f),
        Structural3DObject(2, Object3DType.FOOTING, "Footing 2×2×0.45m", -1f, -1f, -0.7f, 2f, 2f, 0.45f),
        Structural3DObject(3, Object3DType.PEDESTAL, "Pedestal 0.6×0.6m", -0.3f, -0.3f, -0.25f, 0.6f, 0.6f, 0.55f),
        Structural3DObject(4, Object3DType.COLUMN, "Column 0.35×0.45×3.2m", -0.175f, -0.225f, 0.3f, 0.35f, 0.45f, 3.2f),
        Structural3DObject(5, Object3DType.REINFORCEMENT_BARS, "8-16mm Rebar Cage", -0.12f, -0.17f, -0.55f, 0.24f, 0.34f, 4.1f)
    )
    "PEB Warehouse Bay" -> listOf(
        Structural3DObject(1, Object3DType.SLAB, "Trimix Floor 12×8m", 0f, 0f, 0f, 12f, 8f, 0.2f),
        Structural3DObject(2, Object3DType.PEB_FRAME, "Frame Col 1", 0f, 0f, 0.2f, 0.35f, 0.5f, 6.0f),
        Structural3DObject(3, Object3DType.PEB_FRAME, "Frame Col 2", 0f, 7.5f, 0.2f, 0.35f, 0.5f, 6.0f),
        Structural3DObject(4, Object3DType.PEB_FRAME, "Frame Col 3", 6f, 0f, 0.2f, 0.35f, 0.5f, 6.0f),
        Structural3DObject(5, Object3DType.PEB_FRAME, "Frame Col 4", 6f, 7.5f, 0.2f, 0.35f, 0.5f, 6.0f),
        Structural3DObject(6, Object3DType.PEB_FRAME, "Frame Col 5", 11.6f, 0f, 0.2f, 0.35f, 0.5f, 6.0f),
        Structural3DObject(7, Object3DType.PEB_FRAME, "Frame Col 6", 11.6f, 7.5f, 0.2f, 0.35f, 0.5f, 6.0f),
        Structural3DObject(8, Object3DType.PURLINS, "Purlin Bay", 0f, 3.8f, 6.4f, 12f, 0.4f, 0.25f),
        Structural3DObject(9, Object3DType.ROOFING_SHEETS, "Roof Deck", 0f, 0f, 6.2f, 12f, 8f, 0.15f)
    )
    else -> listOf(
        Structural3DObject(1, Object3DType.GROUND, "Site Ground", -0.5f, -0.5f, -0.5f, 8f, 6f, 0.15f),
        Structural3DObject(2, Object3DType.FOOTING, "F1", 0f, 0f, -0.35f, 1.4f, 1.4f, 0.35f),
        Structural3DObject(3, Object3DType.FOOTING, "F2", 5.6f, 0f, -0.35f, 1.4f, 1.4f, 0.35f),
        Structural3DObject(4, Object3DType.FOOTING, "F3", 0f, 3.6f, -0.35f, 1.4f, 1.4f, 0.35f),
        Structural3DObject(5, Object3DType.FOOTING, "F4", 5.6f, 3.6f, -0.35f, 1.4f, 1.4f, 0.35f),
        Structural3DObject(6, Object3DType.COLUMN, "C1", 0.5f, 0.5f, 0f, 0.4f, 0.4f, 3.2f),
        Structural3DObject(7, Object3DType.COLUMN, "C2", 6.1f, 0.5f, 0f, 0.4f, 0.4f, 3.2f),
        Structural3DObject(8, Object3DType.COLUMN, "C3", 0.5f, 4.1f, 0f, 0.4f, 0.4f, 3.2f),
        Structural3DObject(9, Object3DType.COLUMN, "C4", 6.1f, 4.1f, 0f, 0.4f, 0.4f, 3.2f),
        Structural3DObject(10, Object3DType.BEAM, "Front Beam", 0.5f, 0.5f, 3.0f, 6.0f, 0.35f, 0.45f),
        Structural3DObject(11, Object3DType.BEAM, "Rear Beam", 0.5f, 4.1f, 3.0f, 6.0f, 0.35f, 0.45f),
        Structural3DObject(12, Object3DType.SLAB, "Roof Slab 6×4×0.15m", 0.5f, 0.5f, 3.45f, 6.0f, 4.0f, 0.15f)
    )
}

@Composable
fun Studio3DScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val pending2D by viewModel.pending3DFrom2DJson.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()

    var modelTitle by remember { mutableStateOf("RCC Structural Model") }
    val objects = remember { mutableStateListOf<Structural3DObject>().apply { addAll(preset3DAssembly("RCC Frame")) } }

    LaunchedEffect(pending2D) {
        val raw = pending2D ?: return@LaunchedEffect
        runCatching {
            val arr = JSONArray(raw)
            if (arr.length() > 0) {
                objects.clear()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val t = Object3DType.entries.firstOrNull { it.label == o.optString("type") } ?: Object3DType.COLUMN
                    objects.add(
                        Structural3DObject(
                            id = System.nanoTime() + i,
                            type = t,
                            label = o.optString("label", t.label),
                            x = o.optDouble("x", 0.0).toFloat(),
                            y = o.optDouble("y", 0.0).toFloat(),
                            z = o.optDouble("z", 0.0).toFloat(),
                            l = o.optDouble("l", 1.0).toFloat(),
                            w = o.optDouble("w", 1.0).toFloat(),
                            h = o.optDouble("h", 1.0).toFloat(),
                            visible = o.optBoolean("visible", true)
                        )
                    )
                }
                modelTitle = "Imported from 2D Studio"
            }
        }
        viewModel.setPending3DFrom2D(null)
    }

    var yawDeg by remember { mutableFloatStateOf(38f) }
    var pitchDeg by remember { mutableFloatStateOf(26f) }
    var zoom by remember { mutableFloatStateOf(36f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var isPerspective by remember { mutableStateOf(true) }
    var showGrid by remember { mutableStateOf(true) }
    var sectionCutZ by remember { mutableFloatStateOf(10f) }
    var showDimensions by remember { mutableStateOf(true) }

    var showAddDialog by remember { mutableStateOf(false) }

    fun projectPoint(v: Vec3, cx: Float, cy: Float): Pair<Offset, Float> {
        val yr = Math.toRadians(yawDeg.toDouble())
        val pr = Math.toRadians(pitchDeg.toDouble())
        // Center model roughly around (3, 3, 1.5)
        val dx = v.x - 3.0
        val dy = v.y - 3.0
        val dz = v.z - 1.5

        val rx = dx * cos(yr) - dy * sin(yr)
        val ry = dx * sin(yr) + dy * cos(yr)

        val py = ry * cos(pr) - dz * sin(pr)
        val pz = ry * sin(pr) + dz * cos(pr)

        val perspScale = if (isPerspective) (22.0 / (22.0 - py * 0.45)).coerceIn(0.4, 2.5) else 1.0
        val sx = cx + panX + (rx * zoom * perspScale).toFloat()
        val sy = cy + panY - (pz * zoom * perspScale).toFloat()
        return Offset(sx, sy) to py.toFloat()
    }

    fun export3DImage() {
        val bmp = Bitmap.createBitmap(1200, 900, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        canvas.drawColor(android.graphics.Color.rgb(241, 245, 249))
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val cx = 600f
        val cy = 500f
        objects.filter { it.visible && it.z <= sectionCutZ }.sortedBy { it.x + it.y + it.z }.forEach { obj ->
            val topZ = minOf(obj.z + obj.h, sectionCutZ)
            val corners = listOf(
                Vec3(obj.x, obj.y, obj.z), Vec3(obj.x + obj.l, obj.y, obj.z),
                Vec3(obj.x + obj.l, obj.y + obj.w, obj.z), Vec3(obj.x, obj.y + obj.w, obj.z),
                Vec3(obj.x, obj.y, topZ), Vec3(obj.x + obj.l, obj.y, topZ),
                Vec3(obj.x + obj.l, obj.y + obj.w, topZ), Vec3(obj.x, obj.y + obj.w, topZ)
            ).map { projectPoint(it, cx, cy).first }
            paint.color = android.graphics.Color.rgb(15, 23, 42)
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = 2.5f
            val edges = listOf(0 to 1, 1 to 2, 2 to 3, 3 to 0, 4 to 5, 5 to 6, 6 to 7, 7 to 4, 0 to 4, 1 to 5, 2 to 6, 3 to 7)
            edges.forEach { (a, b) -> canvas.drawLine(corners[a].x, corners[a].y, corners[b].x, corners[b].y, paint) }
        }
        val file = ReportExportEngine.saveBitmapPng(context, "3D_$modelTitle", bmp)
        ReportExportEngine.shareFile(context, file, "image/png", modelTitle)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = strings.studio3D,
            subtitle = "${if (isPerspective) "Perspective" else "Orthographic"} • ${objects.count { it.visible }} active members",
            onBack = onBack,
            actions = {
                IconButton(onClick = { export3DImage() }) {
                    Icon(Icons.Rounded.Image, contentDescription = "Export 3D PNG", tint = palette.skyBlue)
                }
                IconButton(
                    onClick = {
                        val arr = JSONArray().apply {
                            objects.forEach { o ->
                                put(JSONObject().apply {
                                    put("type", o.type.label)
                                    put("label", o.label)
                                    put("x", o.x); put("y", o.y); put("z", o.z)
                                    put("l", o.l); put("w", o.w); put("h", o.h)
                                    put("visible", o.visible)
                                })
                            }
                        }.toString()
                        viewModel.saveModel3D(
                            StudioModel3DEntity(
                                projectId = projects.firstOrNull()?.id,
                                title = modelTitle,
                                objectsJson = arr,
                                cameraYaw = yawDeg,
                                cameraPitch = pitchDeg,
                                isPerspective = isPerspective
                            )
                        )
                        Toast.makeText(context, "3D Structural Model saved", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("studio3d_save_btn")
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = "Save 3D Model", tint = palette.orangeDark)
                }
            }
        )

        // Camera View Presets & Projections
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                FilterChip(
                    selected = isPerspective,
                    onClick = { isPerspective = !isPerspective },
                    label = { Text(if (isPerspective) "Perspective" else "Ortho") }
                )
            }
            item {
                FilterChip(selected = false, onClick = { yawDeg = 38f; pitchDeg = 26f }, label = { Text("Isometric") })
            }
            item {
                FilterChip(selected = false, onClick = { yawDeg = 0f; pitchDeg = 89f }, label = { Text("Top") })
            }
            item {
                FilterChip(selected = false, onClick = { yawDeg = 0f; pitchDeg = 0f }, label = { Text("Front") })
            }
            item {
                FilterChip(selected = false, onClick = { yawDeg = 90f; pitchDeg = 0f }, label = { Text("Side") })
            }
            item {
                FilterChip(
                    selected = showGrid,
                    onClick = { showGrid = !showGrid },
                    leadingIcon = { Icon(Icons.Rounded.GridOn, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Grid") }
                )
            }
            items(listOf("RCC Frame", "Footing + Column + Rebar", "PEB Warehouse Bay")) { preset ->
                FilterChip(
                    selected = false,
                    onClick = {
                        modelTitle = preset
                        objects.clear()
                        objects.addAll(preset3DAssembly(preset))
                    },
                    label = { Text(preset) }
                )
            }
        }

        // Interactive 3D Viewport
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(310.dp)
                .padding(horizontal = 12.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F2942), RoundedCornerShape(16.dp))
                    .pointerInput(Unit) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            yawDeg = (yawDeg + drag.x * 0.45f) % 360f
                            pitchDeg = (pitchDeg + drag.y * 0.45f).coerceIn(-89f, 89f)
                        }
                    }
            ) {
                val cx = size.width / 2f
                val cy = size.height * 0.56f

                // 3D Ground Reference Grid
                if (showGrid) {
                    val gridColor = Color(0xFF1E4976)
                    for (g in -2..12 step 2) {
                        val (a1, _) = projectPoint(Vec3(g.toFloat(), -2f, 0f), cx, cy)
                        val (a2, _) = projectPoint(Vec3(g.toFloat(), 10f, 0f), cx, cy)
                        drawLine(gridColor, a1, a2, 1.5f)
                        val (b1, _) = projectPoint(Vec3(-2f, g.toFloat(), 0f), cx, cy)
                        val (b2, _) = projectPoint(Vec3(12f, g.toFloat(), 0f), cx, cy)
                        drawLine(gridColor, b1, b2, 1.5f)
                    }
                }

                // Depth-sort visible 3D objects (Painter's algorithm)
                val renderList = objects
                    .filter { it.visible && it.z < sectionCutZ }
                    .map { obj ->
                        val center = Vec3(obj.x + obj.l / 2f, obj.y + obj.w / 2f, obj.z + obj.h / 2f)
                        val (_, depth) = projectPoint(center, cx, cy)
                        obj to depth
                    }
                    .sortedBy { it.second }

                renderList.forEach { (obj, _) ->
                    val topZ = minOf(obj.z + obj.h, sectionCutZ)
                    val verts = listOf(
                        Vec3(obj.x, obj.y, obj.z),
                        Vec3(obj.x + obj.l, obj.y, obj.z),
                        Vec3(obj.x + obj.l, obj.y + obj.w, obj.z),
                        Vec3(obj.x, obj.y + obj.w, obj.z),
                        Vec3(obj.x, obj.y, topZ),
                        Vec3(obj.x + obj.l, obj.y, topZ),
                        Vec3(obj.x + obj.l, obj.y + obj.w, topZ),
                        Vec3(obj.x, obj.y + obj.w, topZ)
                    ).map { projectPoint(it, cx, cy) }

                    val pts = verts.map { it.first }
                    val baseColor = Color(obj.type.colorHex)

                    // Six faces of the prism sorted by average depth
                    val faces = listOf(
                        listOf(0, 1, 2, 3) to 0.72f,
                        listOf(4, 5, 6, 7) to 1.0f,
                        listOf(0, 1, 5, 4) to 0.88f,
                        listOf(1, 2, 6, 5) to 0.80f,
                        listOf(2, 3, 7, 6) to 0.76f,
                        listOf(3, 0, 4, 7) to 0.84f
                    ).sortedBy { (idxs, _) -> idxs.map { verts[it].second }.average() }

                    faces.forEach { (idxs, shade) ->
                        val p = Path().apply {
                            moveTo(pts[idxs[0]].x, pts[idxs[0]].y)
                            lineTo(pts[idxs[1]].x, pts[idxs[1]].y)
                            lineTo(pts[idxs[2]].x, pts[idxs[2]].y)
                            lineTo(pts[idxs[3]].x, pts[idxs[3]].y)
                            close()
                        }
                        val shaded = Color(
                            red = (baseColor.red * shade).coerceIn(0f, 1f),
                            green = (baseColor.green * shade).coerceIn(0f, 1f),
                            blue = (baseColor.blue * shade).coerceIn(0f, 1f),
                            alpha = if (obj.type == Object3DType.SLAB || obj.type == Object3DType.WINDOW) 0.55f else 0.86f
                        )
                        drawPath(p, color = shaded)
                        drawPath(p, color = Color.White.copy(alpha = 0.65f), style = Stroke(1.6f))
                    }

                    if (showDimensions && obj.label.isNotBlank()) {
                        val topCenter = pts[6]
                        drawContext.canvas.nativeCanvas.drawText(
                            obj.label,
                            topCenter.x,
                            topCenter.y - 4f,
                            android.graphics.Paint().apply {
                                color = android.graphics.Color.WHITE
                                textSize = 21f
                                isAntiAlias = true
                            }
                        )
                    }
                }
            }

            Surface(
                color = palette.concreteCard.copy(alpha = 0.9f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.align(Alignment.TopStart).padding(10.dp)
            ) {
                Text(
                    "Drag canvas to Orbit • Yaw ${yawDeg.toInt()}° Pitch ${pitchDeg.toInt()}°",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.inkPrimary,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        // Zoom & Section Cut Controls + Objects List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                EngineeringCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Zoom: ${zoom.toInt()}x", style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(84.dp))
                        Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 14f..75f, modifier = Modifier.weight(1f))
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Section Z: ${UnitConverter.fmt(sectionCutZ.toDouble(), 1)}m", style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(96.dp))
                        Slider(value = sectionCutZ, onValueChange = { sectionCutZ = it }, valueRange = 0.2f..10f, modifier = Modifier.weight(1f))
                    }
                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.orange),
                        modifier = Modifier.fillMaxWidth().testTag("studio3d_add_obj_btn")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Add 3D Member (Slab, Column, Beam, Footing, Rebar...)")
                    }
                }
            }

            items(objects, key = { it.id }) { obj ->
                EngineeringCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${obj.type.label}: ${obj.label}", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                            Text(
                                "Pos (${obj.x}, ${obj.y}, ${obj.z})m  •  Dim ${obj.l} × ${obj.w} × ${obj.h} m",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkMuted
                            )
                        }
                        IconButton(onClick = {
                            val idx = objects.indexOfFirst { it.id == obj.id }
                            if (idx >= 0) objects[idx] = obj.copy(visible = !obj.visible)
                        }) {
                            Icon(
                                if (obj.visible) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                contentDescription = "Toggle Visibility",
                                tint = palette.skyBlue
                            )
                        }
                        IconButton(onClick = { objects.removeAll { it.id == obj.id } }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Remove Object", tint = palette.error)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        Add3DObjectDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { newObj ->
                objects.add(newObj)
                showAddDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Add3DObjectDialog(
    onDismiss: () -> Unit,
    onAdd: (Structural3DObject) -> Unit
) {
    var selectedType by remember { mutableStateOf(Object3DType.SLAB) }
    var label by remember { mutableStateOf("Custom Slab") }
    var xStr by remember { mutableStateOf("0") }
    var yStr by remember { mutableStateOf("0") }
    var zStr by remember { mutableStateOf("0") }
    var lStr by remember { mutableStateOf("5.0") }
    var wStr by remember { mutableStateOf("4.0") }
    var hStr by remember { mutableStateOf("0.15") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Generate 3D Structural Member") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                var typeOpen by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = typeOpen, onExpandedChange = { typeOpen = !typeOpen }) {
                    OutlinedTextField(
                        value = selectedType.label,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("3D Object Type") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeOpen) },
                        modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = typeOpen, onDismissRequest = { typeOpen = false }) {
                        Object3DType.entries.forEach { t ->
                            DropdownMenuItem(text = { Text(t.label) }, onClick = {
                                selectedType = t
                                label = t.label
                                when (t) {
                                    Object3DType.COLUMN, Object3DType.PEDESTAL -> { lStr = "0.4"; wStr = "0.4"; hStr = "3.2" }
                                    Object3DType.BEAM -> { lStr = "5.0"; wStr = "0.3"; hStr = "0.45" }
                                    Object3DType.SLAB -> { lStr = "5.0"; wStr = "4.0"; hStr = "0.15" }
                                    Object3DType.FOOTING -> { lStr = "1.8"; wStr = "1.8"; hStr = "0.45" }
                                    else -> {}
                                }
                                typeOpen = false
                            })
                        }
                    }
                }
                OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Member Label") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = lStr, onValueChange = { lStr = it }, label = { Text("Length X (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = wStr, onValueChange = { wStr = it }, label = { Text("Width Y (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = hStr, onValueChange = { hStr = it }, label = { Text("Height Z (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = xStr, onValueChange = { xStr = it }, label = { Text("Pos X") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = yStr, onValueChange = { yStr = it }, label = { Text("Pos Y") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = zStr, onValueChange = { zStr = it }, label = { Text("Elev Z") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onAdd(
                    Structural3DObject(
                        id = System.nanoTime(),
                        type = selectedType,
                        label = label.ifBlank { selectedType.label },
                        x = xStr.toFloatOrNull() ?: 0f,
                        y = yStr.toFloatOrNull() ?: 0f,
                        z = zStr.toFloatOrNull() ?: 0f,
                        l = (lStr.toFloatOrNull() ?: 1f).coerceAtLeast(0.05f),
                        w = (wStr.toFloatOrNull() ?: 1f).coerceAtLeast(0.05f),
                        h = (hStr.toFloatOrNull() ?: 1f).coerceAtLeast(0.05f)
                    )
                )
            }) { Text("Add to 3D Scene") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

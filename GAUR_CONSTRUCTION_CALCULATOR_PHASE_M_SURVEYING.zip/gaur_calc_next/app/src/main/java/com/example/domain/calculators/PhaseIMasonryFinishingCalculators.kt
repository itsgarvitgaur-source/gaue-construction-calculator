package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.ceil
import kotlin.math.max

/** Phase I: supplementary masonry and finishing quantity estimators. */
object PhaseIMasonryFinishingCalculators {
    private fun dim(key: String, label: String, value: String) = CalcFieldSpec(key, label, value, FieldUnitKind.LENGTH, LengthUnit.M)
    private fun pct(key: String, label: String, value: String) = CalcFieldSpec(key, label, value, FieldUnitKind.PERCENT, allowZero = true)
    private fun fmt(v: Double, p: Int) = UnitConverter.fmt(v, p)
    private fun tool(id: String, title: String, subtitle: String, category: CalcCategory, fields: List<CalcFieldSpec>, keywords: List<String>, calc: (CalcContext) -> Result<CalcOutcome>) =
        CalcToolSpec(id, title, title, subtitle, category, keywords, fields = fields, compute = calc)

    fun all(): List<CalcToolSpec> = listOf(
        tool("phase_i_masonry_mortar_split", "Masonry Mortar Material Split", "Wet mortar volume, dry volume and cement/sand bags", CalcCategory.MASONRY,
            listOf(dim("l","Wall length","10"),dim("h","Wall height","3"),dim("t","Wall thickness","0.23"),pct("open","Opening deduction","10"),CalcFieldSpec("cement","Cement ratio part","1"),CalcFieldSpec("sand","Sand ratio part","6"),CalcFieldSpec("dry","Dry volume factor","1.33")), listOf("masonry mortar","brick mortar","cement sand mortar")) { c ->
            val l=c.lengthMeters("l")?:0.0; val h=c.lengthMeters("h")?:0.0; val t=c.lengthMeters("t")?:0.0; val o=c.doubleOrNull("open")?:0.0; val cr=c.doubleOrNull("cement")?:0.0; val sr=c.doubleOrNull("sand")?:0.0; val df=c.doubleOrNull("dry")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||h<=0||t<=0||o<0||o>=100||cr<=0||sr<=0||df<1) return@tool Result.failure(IllegalArgumentException("Dimensions and mix parts must be positive; opening deduction must be 0–99% and dry factor at least 1."))
            val wet=l*h*t*(1-o/100); val dry=wet*df; val sum=cr+sr; val cement=dry*cr/sum; val sand=dry*sr/sum; val bags=cement/0.0347
            Result.success(CalcOutcome(listOf(CalcResultItem("Net wet mortar",fmt(wet,p),"m³",true),CalcResultItem("Dry mortar ingredients",fmt(dry,p),"m³"),CalcResultItem("Cement",fmt(cement,p),"m³"),CalcResultItem("Cement bags (50 kg approx.)",fmt(bags,0),"bags"),CalcResultItem("Sand",fmt(sand,p),"m³")),"Net wall volume × dry factor; split by mix parts",listOf("Net wall volume after openings = ${fmt(wet,p)} m³","Dry volume = ${fmt(wet,p)} × ${fmt(df,p)}"),"Planning estimate only. Mortar joint thickness, actual brick/block dimensions, bulking and site wastage vary."))
        },
        tool("phase_i_block_adhesive_bags", "AAC / Block Adhesive Bag Planner", "Estimate adhesive bags from wall area and coverage", CalcCategory.MASONRY,
            listOf(CalcFieldSpec("area","Net wall area","100",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("rate","Coverage per 20 kg bag (m²)","8"),pct("waste","Wastage","5")), listOf("aac adhesive","block adhesive","thin bed mortar")) { c ->
            val a=c.doubleOrNull("area")?:0.0; val r=c.doubleOrNull("rate")?:0.0; val w=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||r<=0||w<0) return@tool Result.failure(IllegalArgumentException("Area and coverage must be positive; wastage cannot be negative."))
            val req=a*(1+w/100)/r; val bags=ceil(req).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Adhesive bags required",bags.toString(),"20 kg bags",true),CalcResultItem("Adjusted area",fmt(a*(1+w/100),p),"m²"),CalcResultItem("Theoretical bags",fmt(req,p),"bags")),"Bags = ceil(area × (1+wastage%) / coverage per bag)",listOf("Adjusted wall area includes ${fmt(w,p)}% allowance."),"Coverage must be taken from the selected manufacturer's technical data sheet and actual block/bed thickness."))
        },
        tool("phase_i_brick_wall_face_count", "Brick Wall Face Count & Bond Planner", "Estimate bricks from wall face module and courses", CalcCategory.MASONRY,
            listOf(dim("l","Wall length","10"),dim("h","Wall height","3"),CalcFieldSpec("bl","Brick length incl. joint (mm)","240"),CalcFieldSpec("bh","Brick course height incl. joint (mm)","80"),pct("waste","Cutting / breakage allowance","5")), listOf("brick count","brick bond","brick courses")) { c ->
            val l=c.lengthMeters("l")?:0.0; val h=c.lengthMeters("h")?:0.0; val bl=(c.doubleOrNull("bl")?:0.0)/1000; val bh=(c.doubleOrNull("bh")?:0.0)/1000; val w=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||h<=0||bl<=0||bh<=0||w<0) return@tool Result.failure(IllegalArgumentException("Wall dimensions and brick modules must be positive."))
            val perCourse=ceil(l/bl).toInt(); val courses=ceil(h/bh).toInt(); val base=perCourse*courses; val total=ceil(base*(1+w/100)).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Bricks per course",perCourse.toString(),"nos"),CalcResultItem("Number of courses",courses.toString(),"courses"),CalcResultItem("Total bricks incl. allowance",total.toString(),"nos",true),CalcResultItem("Face area",fmt(l*h,p),"m²")),"ceil(L/module length) × ceil(H/course height) × (1+wastage%)",listOf("Course count rounded up to whole courses.","Brick count rounded up to whole units."),"Single-leaf face-count approximation. Openings, bond pattern, returns, piers and half-brick cuts are not modeled."))
        },
        tool("phase_i_tile_box_planner", "Tile Box & Layout Planner", "Tile count, boxes and edge-cut allowance", CalcCategory.FINISHING,
            listOf(CalcFieldSpec("area","Net tiled area","40",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("tl","Tile length (mm)","600"),CalcFieldSpec("tw","Tile width (mm)","600"),CalcFieldSpec("box","Tiles per box","4"),pct("waste","Cutting allowance","8")), listOf("tile boxes","tile layout","floor tile procurement")) { c ->
            val a=c.doubleOrNull("area")?:0.0; val tl=(c.doubleOrNull("tl")?:0.0)/1000; val tw=(c.doubleOrNull("tw")?:0.0)/1000; val box=c.doubleOrNull("box")?:0.0; val w=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||tl<=0||tw<=0||box<=0||w<0) return@tool Result.failure(IllegalArgumentException("Area, tile sizes and tiles per box must be positive."))
            val tileArea=tl*tw; val raw=a/tileArea; val tiles=ceil(raw*(1+w/100)).toInt(); val boxes=ceil(tiles/box).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Tiles to purchase",tiles.toString(),"tiles",true),CalcResultItem("Boxes required",boxes.toString(),"boxes"),CalcResultItem("Coverage per tile",fmt(tileArea,p),"m²"),CalcResultItem("Purchased coverage",fmt(tiles*tileArea,p),"m²")),"Tiles = ceil(area/tile area × (1+wastage%)); boxes = ceil(tiles/box)",listOf("Tile area = ${fmt(tl,p)} × ${fmt(tw,p)} m²"),"Does not optimize room-by-room setting-out, pattern direction, grout width or reuse of offcuts."))
        },
        tool("phase_i_grout_quantity", "Tile Grout Quantity Estimator", "Joint volume converted to grout mass", CalcCategory.FINISHING,
            listOf(CalcFieldSpec("area","Tiled area","30",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("tl","Tile length (mm)","600"),CalcFieldSpec("tw","Tile width (mm)","600"),CalcFieldSpec("joint","Joint width (mm)","3"),CalcFieldSpec("depth","Grout depth (mm)","5"),CalcFieldSpec("density","Grout density (kg/L)","1.6"),pct("waste","Wastage","10")), listOf("grout","tile joint","epoxy grout")) { c ->
            val a=c.doubleOrNull("area")?:0.0; val tl=(c.doubleOrNull("tl")?:0.0)/1000; val tw=(c.doubleOrNull("tw")?:0.0)/1000; val j=(c.doubleOrNull("joint")?:0.0)/1000; val d=(c.doubleOrNull("depth")?:0.0)/1000; val rho=c.doubleOrNull("density")?:0.0; val w=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||tl<=0||tw<=0||j<=0||d<=0||rho<=0||w<0) return@tool Result.failure(IllegalArgumentException("All dimensions, density and area must be positive."))
            val perArea=j*d*(1/tl+1/tw); val kg=a*perArea*1000*rho*(1+w/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Grout required",fmt(kg,p),"kg",true),CalcResultItem("Joint volume",fmt(a*perArea,p),"m³"),CalcResultItem("Consumption",fmt(kg/a,p),"kg/m²")),"Joint volume per area = joint width × depth × (1/tile length + 1/tile width)",listOf("Consumption adjusted by ${fmt(w,p)}% wastage."),"Approximate regular grid joints; perimeter joints, tile lippage, actual grout density and product coverage may change consumption."))
        },
        tool("phase_i_screed_level_planner", "Floor Screed Volume & Material Planner", "Average thickness, volume and mix split", CalcCategory.FINISHING,
            listOf(CalcFieldSpec("area","Floor area","60",FieldUnitKind.AREA_SQ_M),dim("t","Average screed thickness","0.05"),CalcFieldSpec("cement","Cement ratio part","1"),CalcFieldSpec("sand","Sand ratio part","4"),CalcFieldSpec("dry","Dry volume factor","1.30")), listOf("floor screed","leveling screed","screed mortar")) { c ->
            val a=c.doubleOrNull("area")?:0.0; val t=c.lengthMeters("t")?:0.0; val cr=c.doubleOrNull("cement")?:0.0; val sr=c.doubleOrNull("sand")?:0.0; val df=c.doubleOrNull("dry")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||t<=0||cr<=0||sr<=0||df<1) return@tool Result.failure(IllegalArgumentException("Area, thickness and mix parts must be positive; dry factor must be at least 1."))
            val wet=a*t; val dry=wet*df; val cement=dry*cr/(cr+sr); val sand=dry*sr/(cr+sr)
            Result.success(CalcOutcome(listOf(CalcResultItem("Wet screed volume",fmt(wet,p),"m³",true),CalcResultItem("Dry ingredients volume",fmt(dry,p),"m³"),CalcResultItem("Cement volume",fmt(cement,p),"m³"),CalcResultItem("Cement bags (approx.)",fmt(cement/0.0347,0),"50 kg bags"),CalcResultItem("Sand volume",fmt(sand,p),"m³")),"Wet volume=area×thickness; dry ingredients split by mix ratio",listOf("Average thickness = ${fmt(t,p)} m"),"Nominal material estimate only; substrate undulations, compaction and specified screed design affect actual quantities."))
        },
        tool("phase_i_gypsum_board_partition", "Gypsum Board Partition Planner", "Board sheets, studs and tracks for a partition", CalcCategory.FINISHING,
            listOf(dim("l","Partition length","8"),dim("h","Partition height","3"),CalcFieldSpec("sw","Stud spacing (mm)","600"),CalcFieldSpec("bw","Board width (mm)","1200"),CalcFieldSpec("bh","Board height (mm)","2400"),CalcFieldSpec("layers","Board layers per face","1"),pct("waste","Board wastage","8")), listOf("gypsum board","drywall partition","studs","tracks")) { c ->
            val l=c.lengthMeters("l")?:0.0; val h=c.lengthMeters("h")?:0.0; val sp=(c.doubleOrNull("sw")?:0.0)/1000; val bw=(c.doubleOrNull("bw")?:0.0)/1000; val bh=(c.doubleOrNull("bh")?:0.0)/1000; val layers=c.doubleOrNull("layers")?:0.0; val w=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||h<=0||sp<=0||bw<=0||bh<=0||layers<1||layers%1.0!=0.0||w<0) return@tool Result.failure(IllegalArgumentException("Check dimensions, stud spacing, board sizes and whole-number layer count."))
            val studs=ceil(l/sp).toInt()+1; val faceArea=2*l*h*layers; val sheets=ceil(faceArea/(bw*bh)*(1+w/100)).toInt(); val track=2*l
            Result.success(CalcOutcome(listOf(CalcResultItem("Board sheets",sheets.toString(),"sheets",true),CalcResultItem("Studs",studs.toString(),"vertical studs"),CalcResultItem("Top + bottom track",fmt(track,p),"m"),CalcResultItem("Board face area",fmt(faceArea,p),"m²")),"Studs=ceil(L/spacing)+1; sheets=ceil(2LH×layers/board area × allowance)",listOf("Both partition faces included.","Track includes one top and one bottom run."),"Straight non-load-bearing partition estimate. Door openings, noggings, double-stud jambs, board stagger, fire/acoustic layers and framing details are excluded."))
        },
        tool("phase_i_false_ceiling_grid", "False Ceiling Grid & Board Planner", "Ceiling boards, perimeter channel and grid members", CalcCategory.FINISHING,
            listOf(dim("l","Room length","6"),dim("w","Room width","4"),CalcFieldSpec("main","Main channel spacing (mm)","1200"),CalcFieldSpec("cross","Cross channel spacing (mm)","600"),CalcFieldSpec("boardL","Board length (mm)","2400"),CalcFieldSpec("boardW","Board width (mm)","1200"),pct("waste","Board wastage","8")), listOf("false ceiling","gypsum ceiling","ceiling grid")) { c ->
            val l=c.lengthMeters("l")?:0.0; val w=c.lengthMeters("w")?:0.0; val ms=(c.doubleOrNull("main")?:0.0)/1000; val cs=(c.doubleOrNull("cross")?:0.0)/1000; val bl=(c.doubleOrNull("boardL")?:0.0)/1000; val bw=(c.doubleOrNull("boardW")?:0.0)/1000; val waste=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||w<=0||ms<=0||cs<=0||bl<=0||bw<=0||waste<0) return@tool Result.failure(IllegalArgumentException("Room, grid spacing and board dimensions must be positive."))
            val area=l*w; val boards=ceil(area/(bl*bw)*(1+waste/100)).toInt(); val mains=(ceil(w/ms).toInt()+1)*l; val cross=(ceil(l/cs).toInt()+1)*w; val perimeter=2*(l+w)
            Result.success(CalcOutcome(listOf(CalcResultItem("Ceiling boards",boards.toString(),"sheets",true),CalcResultItem("Main channel length",fmt(mains,p),"m"),CalcResultItem("Cross channel length",fmt(cross,p),"m"),CalcResultItem("Perimeter channel",fmt(perimeter,p),"m"),CalcResultItem("Ceiling area",fmt(area,p),"m²")),"Board area plus grid line-count estimates",listOf("Grid member lengths are rounded up to full rows/lines."),"Concept quantity only. Hanger spacing, splice laps, wall angle, edge support, lighting cut-outs and manufacturer's grid system are not included."))
        },
        tool("phase_i_membrane_roll_planner", "Waterproofing Membrane Roll Planner", "Membrane area with side/end laps and roll count", CalcCategory.FINISHING,
            listOf(CalcFieldSpec("area","Net waterproofing area","120",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("roll","Roll length (m)","10"),CalcFieldSpec("width","Roll width (m)","1"),dim("side","Side lap width","0.1"),dim("end","End lap length","0.15"),pct("waste","Extra wastage","5")), listOf("membrane roll","waterproofing sheet","bituminous membrane")) { c ->
            val a=c.doubleOrNull("area")?:0.0; val rl=c.doubleOrNull("roll")?:0.0; val rw=c.doubleOrNull("width")?:0.0; val side=c.lengthMeters("side")?:0.0; val end=c.lengthMeters("end")?:0.0; val waste=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||rl<=0||rw<=0||side<0||end<0||side>=rw||end>=rl||waste<0) return@tool Result.failure(IllegalArgumentException("Check area, roll dimensions and lap sizes."))
            val effW=rw-side; val effL=rl-end; val effArea=effW*effL; val rolls=ceil(a*(1+waste/100)/effArea).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Effective coverage per roll",fmt(effArea,p),"m²",true),CalcResultItem("Rolls required",rolls.toString(),"rolls"),CalcResultItem("Gross roll area",fmt(rl*rw,p),"m²/roll"),CalcResultItem("Adjusted project area",fmt(a*(1+waste/100),p),"m²")),"Effective roll coverage=(roll width−side lap)×(roll length−end lap)",listOf("One lap allowance deducted in each direction per roll."),"Simplified rectangular coverage. Actual layout, perimeter upstands, detailing, overlaps between courses and manufacturer requirements may increase consumption."))
        },
        tool("phase_i_skimming_compound", "Wall Skim Coat / Putty Quantity", "Estimate skim coat bags from area and application rate", CalcCategory.FINISHING,
            listOf(CalcFieldSpec("area","Net wall / ceiling area","150",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("rate","Consumption (kg/m²/mm)","1.2"),CalcFieldSpec("thick","Average coat thickness (mm)","1"),CalcFieldSpec("bag","Bag size (kg)","20"),pct("waste","Wastage","7")), listOf("skim coat","wall putty","putty bags","surface finishing")) { c ->
            val a=c.doubleOrNull("area")?:0.0; val r=c.doubleOrNull("rate")?:0.0; val t=c.doubleOrNull("thick")?:0.0; val b=c.doubleOrNull("bag")?:0.0; val w=c.doubleOrNull("waste")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||r<=0||t<=0||b<=0||w<0) return@tool Result.failure(IllegalArgumentException("Area, rate, thickness and bag size must be positive."))
            val kg=a*r*t*(1+w/100); val bags=ceil(kg/b).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Compound required",fmt(kg,p),"kg",true),CalcResultItem("Bags required",bags.toString(),"bags"),CalcResultItem("Adjusted area",fmt(a*(1+w/100),p),"m²")),"Mass=area×manufacturer consumption rate×thickness×(1+wastage%)",listOf("Total mass includes ${fmt(w,p)}% wastage."),"Use the selected product data sheet; consumption depends on substrate texture, coat thickness and number of passes."))
        }
    )
}

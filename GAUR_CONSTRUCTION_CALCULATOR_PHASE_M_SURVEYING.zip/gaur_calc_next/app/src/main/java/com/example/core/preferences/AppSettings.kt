package com.example.core.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.i18n.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gaur_settings")

enum class UnitSystemPref(val label: String) {
    METRIC("Metric (m, cm, mm, kg)"),
    IMPERIAL("Imperial (ft, in, sq.ft, CFT)")
}

enum class ThemeModePref(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

data class UserSettings(
    val language: AppLanguage = AppLanguage.ENGLISH,
    val unitSystem: UnitSystemPref = UnitSystemPref.METRIC,
    val themeMode: ThemeModePref = ThemeModePref.SYSTEM,
    val decimalPrecision: Int = 2,
    val defaultConcreteMix: String = "M20",
    val defaultWastagePercent: Double = 5.0,
    val bighaSqFt: Double = 27225.0,
    val bighaRegionName: String = "Standard Pucca Bigha (27,225 sq.ft)",
    val currencySymbol: String = "₹",
    val companyName: String = "Gaur Engineering & Constructions",
    val engineerName: String = "Site Engineer"
)

class AppSettingsStore(private val context: Context) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language")
        val UNIT_SYSTEM = stringPreferencesKey("unit_system")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val PRECISION = intPreferencesKey("decimal_precision")
        val CONCRETE_MIX = stringPreferencesKey("default_concrete_mix")
        val WASTAGE = doublePreferencesKey("default_wastage")
        val BIGHA_SQFT = doublePreferencesKey("bigha_sqft")
        val BIGHA_REGION = stringPreferencesKey("bigha_region")
        val CURRENCY = stringPreferencesKey("currency_symbol")
        val COMPANY = stringPreferencesKey("company_name")
        val ENGINEER = stringPreferencesKey("engineer_name")
    }

    val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
        UserSettings(
            language = AppLanguage.entries.firstOrNull { it.code == prefs[Keys.LANGUAGE] }
                ?: AppLanguage.ENGLISH,
            unitSystem = UnitSystemPref.entries.firstOrNull { it.name == prefs[Keys.UNIT_SYSTEM] }
                ?: UnitSystemPref.METRIC,
            themeMode = ThemeModePref.entries.firstOrNull { it.name == prefs[Keys.THEME_MODE] }
                ?: ThemeModePref.SYSTEM,
            decimalPrecision = (prefs[Keys.PRECISION] ?: 2).coerceIn(1, 4),
            defaultConcreteMix = prefs[Keys.CONCRETE_MIX] ?: "M20",
            defaultWastagePercent = prefs[Keys.WASTAGE] ?: 5.0,
            bighaSqFt = prefs[Keys.BIGHA_SQFT] ?: 27225.0,
            bighaRegionName = prefs[Keys.BIGHA_REGION] ?: "Standard Pucca Bigha (27,225 sq.ft)",
            currencySymbol = prefs[Keys.CURRENCY] ?: "₹",
            companyName = prefs[Keys.COMPANY] ?: "Gaur Engineering & Constructions",
            engineerName = prefs[Keys.ENGINEER] ?: "Site Engineer"
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[Keys.LANGUAGE] = language.code }
    }

    suspend fun setUnitSystem(system: UnitSystemPref) {
        context.dataStore.edit { it[Keys.UNIT_SYSTEM] = system.name }
    }

    suspend fun setThemeMode(mode: ThemeModePref) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setPrecision(precision: Int) {
        context.dataStore.edit { it[Keys.PRECISION] = precision.coerceIn(1, 4) }
    }

    suspend fun setDefaultMix(mix: String) {
        context.dataStore.edit { it[Keys.CONCRETE_MIX] = mix }
    }

    suspend fun setDefaultWastage(wastage: Double) {
        context.dataStore.edit { it[Keys.WASTAGE] = wastage.coerceIn(0.0, 25.0) }
    }

    suspend fun setBighaRegion(name: String, sqFt: Double) {
        context.dataStore.edit {
            it[Keys.BIGHA_REGION] = name
            it[Keys.BIGHA_SQFT] = sqFt.coerceAtLeast(1000.0)
        }
    }

    suspend fun setBranding(companyName: String, engineerName: String, currency: String) {
        context.dataStore.edit {
            it[Keys.COMPANY] = companyName
            it[Keys.ENGINEER] = engineerName
            it[Keys.CURRENCY] = currency.ifBlank { "₹" }
        }
    }
}

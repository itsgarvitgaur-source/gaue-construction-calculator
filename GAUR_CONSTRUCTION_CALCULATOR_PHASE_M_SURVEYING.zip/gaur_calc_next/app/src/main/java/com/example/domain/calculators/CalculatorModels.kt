package com.example.domain.calculators

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apartment
import androidx.compose.material.icons.rounded.Architecture
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.FormatPaint
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.core.preferences.UserSettings
import com.example.domain.units.LengthUnit

enum class CalcCategory(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val subtitle: String,
    val icon: ImageVector
) {
    BASIC("basic", "Area, Volume & Geometry", "क्षेत्रफल और आयतन", "All 2D/3D Shapes, Perimeter, Fractions", Icons.Rounded.Calculate),
    CONCRETE("concrete", "Concrete & Mortar", "कंक्रीट और मसाला", "PCC, Mix M5-M40, RMC, Mortar, W/C", Icons.Rounded.Construction),
    STRUCTURAL("structural", "Structural Members", "स्ट्रक्चरल गणना", "Footing, Column, Beam, Slab, Stair, Roof", Icons.Rounded.Apartment),
    MASONRY("masonry", "Brick, Block & Stone", "ईंट, ब्लॉक और पत्थर", "Bricks, AAC, Stone, Pavers, Fence", Icons.Rounded.GridView),
    FINISHING("finishing", "Plaster, Paint & Interior", "प्लास्टर, पेंट और फिनिशिंग", "Plaster, Paint, Tiles, Wood, Ceiling, Road", Icons.Rounded.FormatPaint),
    STEEL("steel", "Steel & Rebar (BBS)", "स्टील और सरिया", "Rebar, Stirrups, Ld, Structural Sections", Icons.Rounded.Architecture),
    EARTHWORK("earthwork", "Excavation & Earth", "खुदाई और मिट्टी कार्य", "Pit, Sloped, Backfill, Cut/Fill, Road", Icons.Rounded.Terrain),
    UTILITIES("utilities", "Tanks & Plumbing", "टैंक और प्लंबिंग", "Water Tank, Septic, Rainwater, Pipe, Load", Icons.Rounded.WaterDrop),
    CONVERTERS("converters", "Unit Converters", "यूनिट कनवर्टर", "Land, Length, Vol, Weight, Stress, Temp", Icons.Rounded.SwapHoriz),
    SITE_TOOLKIT("site", "Site, Level & Cost", "साइट, लेवल और लागत", "RL, Slope, 3-4-5, Bearing, Scale, Cost", Icons.Rounded.Explore)
}

enum class FieldUnitKind {
    NONE,
    LENGTH,
    THICKNESS_MM,
    AREA_SQ_M,
    VOLUME_CU_M,
    PERCENT,
    ANGLE_DEG,
    COUNT,
    RATE
}

data class CalcFieldSpec(
    val key: String,
    val label: String,
    val defaultValue: String = "",
    val unitKind: FieldUnitKind = FieldUnitKind.NONE,
    val defaultLengthUnit: LengthUnit = LengthUnit.M,
    val allowZero: Boolean = false,
    val options: List<String> = emptyList(),
    val hint: String = "",
    val visibleWhen: ((Map<String, String>) -> Boolean)? = null,
    val dynamicLabel: ((Map<String, String>) -> String)? = null
)

data class CalcResultItem(
    val label: String,
    val value: String,
    val unit: String = "",
    val isPrimary: Boolean = false
)

data class CalcOutcome(
    val results: List<CalcResultItem>,
    val formula: String,
    val steps: List<String>,
    val assumptions: String,
    val warnings: List<String> = emptyList(),
    val estimatedCost: Double? = null
)

data class CalcContext(
    val inputs: Map<String, String>,
    val lengthUnits: Map<String, LengthUnit>,
    val settings: UserSettings,
    val ratesByKeyword: Map<String, Double>
) {
    fun raw(key: String): String = inputs[key]?.trim().orEmpty()

    fun doubleOrNull(key: String): Double? = raw(key).toDoubleOrNull()

    fun lengthMeters(key: String): Double? {
        val v = doubleOrNull(key) ?: return null
        val u = lengthUnits[key] ?: LengthUnit.M
        return v * u.toMeters
    }

    fun lengthUnitLabel(key: String): String = (lengthUnits[key] ?: LengthUnit.M).symbol
}

data class CalcToolSpec(
    val id: String,
    val title: String,
    val titleHi: String,
    val subtitle: String,
    val category: CalcCategory,
    val keywords: List<String>,
    val isPreliminaryStructural: Boolean = false,
    val typeFieldKey: String? = null,
    val fields: List<CalcFieldSpec>,
    val compute: (CalcContext) -> Result<CalcOutcome>
)

package com.example.features.diagrams

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

internal fun DrawScope.drawFoundationDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    when (s.toolId) {
        "struct_pile" -> {
            val pileType = s.raw("pileType", "Bored Cast-in-Situ Pile")
            val dia = s.lenMeters("dia", 0.5).toFloat().coerceAtLeast(0.2f)
            val depth = s.lenMeters("depth", 12.0).toFloat().coerceAtLeast(1.0f)
            val count = s.dbl("count", 16.0).roundToInt().coerceAtLeast(1)
            val diaLbl = if (pileType == "Driven Precast Square Pile") "B=${s.lenLabel("dia", 0.5)}" else "Ø=${s.lenLabel("dia", 0.5)}"
            val depthLbl = "L=${s.lenLabel("depth", 12.0)}"
            val isDriven = pileType == "Driven Precast Square Pile"
            val isUnderReam = pileType == "Under-Reamed Pile (Bulb)"

            when (mode) {
                DiagramViewMode.VIEW_3D -> {
                    val scale = (size.height * 0.54f) / depth
                    val r = max(dia / 2f, depth * 0.08f)
                    val cRef = Vec3D(0f, 0f, depth / 2f)
                    val center = Offset(size.width / 2f, size.height * 0.54f)
                    if (isDriven) {
                        draw3DPrism(Vec3D(-r, -r, 0f), Vec3D(r, r, depth), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                    } else {
                        draw3DCylinder(Offset(0f, 0f), 0f, depth, r, cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                        if (isUnderReam) {
                            draw3DCylinder(Offset(0f, 0f), depth * 0.22f, depth * 0.34f, r * 1.9f, cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                            draw3DCylinder(Offset(0f, 0f), depth * 0.55f, depth * 0.67f, r * 1.9f, cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                        }
                    }
                    drawCadTextPill("$pileType • $diaLbl • $depthLbl ($count Nos)", Offset(size.width / 2f, 26f), CadColors.DimOrange)
                }
                DiagramViewMode.PLAN_2D -> {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val rPx = min(size.width, size.height) * 0.24f
                    if (isDriven) {
                        drawRect(CadColors.ConcreteFill, Offset(c.x - rPx, c.y - rPx), Size(rPx * 2f, rPx * 2f))
                        drawRect(CadColors.ConcreteStroke, Offset(c.x - rPx, c.y - rPx), Size(rPx * 2f, rPx * 2f), style = Stroke(3f))
                    } else {
                        if (isUnderReam) {
                            drawCircle(CadColors.SoilFill, rPx * 1.45f, c)
                            drawCircle(CadColors.SoilStroke, rPx * 1.45f, c, style = Stroke(2f))
                        }
                        drawCircle(CadColors.ConcreteFill, rPx, c)
                        drawCircle(CadColors.ConcreteStroke, rPx, c, style = Stroke(3f))
                    }
                    drawDimensionLine(Offset(c.x - rPx, c.y + rPx), Offset(c.x + rPx, c.y + rPx), 36f, diaLbl)
                    drawCadTextPill(pileType, Offset(c.x, 26f), CadColors.DimBlue)
                }
                else -> {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val pw = 60f
                    val ph = size.height * 0.62f
                    val topY = c.y - ph / 2f
                    val botY = c.y + ph / 2f
                    if (isDriven) {
                        val path = Path().apply {
                            moveTo(c.x - pw / 2f, topY)
                            lineTo(c.x + pw / 2f, topY)
                            lineTo(c.x + pw / 2f, botY - 26f)
                            lineTo(c.x, botY + 12f)
                            lineTo(c.x - pw / 2f, botY - 26f)
                            close()
                        }
                        drawPath(path, CadColors.ConcreteFill)
                        drawPath(path, CadColors.ConcreteStroke, style = Stroke(3f))
                    } else {
                        drawRect(CadColors.ConcreteFill, Offset(c.x - pw / 2f, topY), Size(pw, ph))
                        drawRect(CadColors.ConcreteStroke, Offset(c.x - pw / 2f, topY), Size(pw, ph), style = Stroke(3f))
                        if (isUnderReam) {
                            for (frac in listOf(0.42f, 0.76f)) {
                                val by = topY + ph * frac
                                val bulbPath = Path().apply {
                                    moveTo(c.x - pw / 2f, by - 22f)
                                    lineTo(c.x - pw * 1.05f, by)
                                    lineTo(c.x - pw / 2f, by + 22f)
                                    lineTo(c.x + pw / 2f, by + 22f)
                                    lineTo(c.x + pw * 1.05f, by)
                                    lineTo(c.x + pw / 2f, by - 22f)
                                    close()
                                }
                                drawPath(bulbPath, CadColors.ConcreteFill)
                                drawPath(bulbPath, CadColors.ConcreteStroke, style = Stroke(2.5f))
                            }
                        }
                    }
                    drawLine(CadColors.SteelBar, Offset(c.x - 16f, topY - 18f), Offset(c.x - 16f, botY - 10f), 3f)
                    drawLine(CadColors.SteelBar, Offset(c.x + 16f, topY - 18f), Offset(c.x + 16f, botY - 10f), 3f)
                    drawDimensionLine(Offset(c.x - pw / 2f, botY), Offset(c.x + pw / 2f, botY), 32f, diaLbl)
                    drawDimensionLine(Offset(c.x + pw / 2f, topY), Offset(c.x + pw / 2f, botY), -48f, depthLbl, CadColors.DimOrange)
                    drawCadTextPill(pileType, Offset(c.x, 26f), CadColors.DimBlue)
                }
            }
        }
        "struct_raft_strip" -> {
            val type = s.raw("type", "Raft / Mat Foundation")
            val l = s.lenMeters("l", 12.0).toFloat().coerceAtLeast(1f)
            val w = s.lenMeters("w", 9.0).toFloat().coerceAtLeast(1f)
            val t = s.lenMeters("t", 0.45).toFloat().coerceAtLeast(0.1f)
            val lLbl = "L=${s.lenLabel("l", 12.0)}"
            val wLbl = "W=${s.lenLabel("w", 9.0)}"
            val tLbl = "D=${s.lenLabel("t", 0.45)}"
            val isPileCap = type.startsWith("Pile Cap")
            val isBeamRaft = type == "Combined Slab-Beam Raft"
            val isStrip = type == "Continuous Strip Footing"

            when (mode) {
                DiagramViewMode.VIEW_3D -> {
                    val scale = (min(size.width, size.height) * 0.48f) / max(l, w)
                    val visT = max(t, max(l, w) * 0.10f)
                    val cRef = Vec3D(l / 2f, w / 2f, visT / 2f)
                    val center = Offset(size.width / 2f, size.height * 0.56f)
                    val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l, w, visT), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                    if (isBeamRaft) {
                        draw3DPrism(Vec3D(0f, w * 0.4f, visT), Vec3D(l, w * 0.6f, visT * 1.8f), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                    } else if (isPileCap) {
                        draw3DPrism(Vec3D(l * 0.35f, w * 0.35f, visT), Vec3D(l * 0.65f, w * 0.65f, visT * 2.2f), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                    }
                    drawDimensionLine(pts[0], pts[1], 28f, lLbl)
                    drawDimensionLine(pts[1], pts[2], 28f, wLbl)
                    drawDimensionLine(pts[2], pts[6], -38f, tLbl, CadColors.DimOrange)
                }
                DiagramViewMode.SECTION, DiagramViewMode.REINFORCEMENT -> {
                    val pad = 74f
                    val rw = size.width - pad * 2f
                    val slabH = 56f
                    val top = size.height * 0.48f
                    drawRect(CadColors.SoilFill, Offset(pad - 12f, top + slabH), Size(rw + 24f, 18f))
                    drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(rw, slabH))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, slabH), style = Stroke(3f))
                    if (isPileCap) {
                        // Pile heads underneath cap
                        listOf(pad + rw * 0.25f, pad + rw * 0.75f).forEach { px ->
                            drawRect(CadColors.ConcreteDarkFill, Offset(px - 22f, top + slabH), Size(44f, 54f))
                            drawRect(CadColors.ConcreteStroke, Offset(px - 22f, top + slabH), Size(44f, 54f), style = Stroke(2f))
                        }
                        drawRect(CadColors.ConcreteDarkFill, Offset(size.width / 2f - 28f, top - 46f), Size(56f, 46f))
                    } else if (isBeamRaft) {
                        drawRect(CadColors.ConcreteDarkFill, Offset(pad + rw * 0.42f, top - 36f), Size(rw * 0.16f, 36f))
                    }
                    drawLine(CadColors.SteelBar, Offset(pad + 12f, top + 12f), Offset(pad + rw - 12f, top + 12f), 3f)
                    drawLine(CadColors.SteelBar, Offset(pad + 12f, top + slabH - 12f), Offset(pad + rw - 12f, top + slabH - 12f), 3.5f)
                    drawDimensionLine(Offset(pad, top + slabH + 18f), Offset(pad + rw, top + slabH + 18f), 30f, lLbl)
                    drawDimensionLine(Offset(pad + rw, top), Offset(pad + rw, top + slabH), -44f, tLbl, CadColors.DimOrange)
                }
                else -> {
                    val pad = 74f
                    val rw = size.width - pad * 2f
                    val rh = if (isStrip) 68f else (rw * (w / l).coerceIn(0.4f, 0.85f)).coerceAtMost(size.height * 0.56f)
                    val top = (size.height - rh) / 2f
                    drawRect(CadColors.ConcreteFill.copy(alpha = 0.65f), Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                    if (isPileCap) {
                        val pxList = listOf(pad + rw * 0.25f, pad + rw * 0.75f)
                        val pyList = listOf(top + rh * 0.28f, top + rh * 0.72f)
                        pxList.forEach { px ->
                            pyList.forEach { py ->
                                drawCircle(CadColors.DimBlue.copy(alpha = 0.35f), 16f, Offset(px, py))
                                drawCircle(CadColors.DimBlue, 16f, Offset(px, py), style = Stroke(2f))
                            }
                        }
                        drawRect(CadColors.DimOrange, Offset(size.width / 2f - 22f, size.height / 2f - 18f), Size(44f, 36f), style = Stroke(2.5f))
                    } else if (isBeamRaft) {
                        drawLine(CadColors.DimOrange, Offset(pad, top + rh * 0.33f), Offset(pad + rw, top + rh * 0.33f), 4f)
                        drawLine(CadColors.DimOrange, Offset(pad, top + rh * 0.67f), Offset(pad + rw, top + rh * 0.67f), 4f)
                    }
                    drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 34f, lLbl)
                    drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -46f, wLbl, CadColors.DimOrange)
                    drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
                }
            }
        }
        else -> drawMultiTypeFootingDiagram(s, mode, yaw, pitch)
    }
}

private fun DrawScope.drawMultiTypeFootingDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val type = s.raw("footingType", "Sloped Footing")
    val bl = s.lenMeters("bl", 2.2).toFloat().coerceAtLeast(0.5f)
    val bw = s.lenMeters("bw", 1.8).toFloat().coerceAtLeast(0.5f)
    val b2 = s.lenMeters("b2", 2.6).toFloat().coerceAtLeast(0.5f)
    val l2 = s.lenMeters("l2", 1.4).toFloat().coerceAtLeast(0.5f)
    val dia = s.lenMeters("dia", 2.2).toFloat().coerceAtLeast(0.5f)
    val d1 = s.lenMeters("d1", 0.25).toFloat().coerceAtLeast(0.1f)
    val d2 = s.lenMeters("d2", 0.35).toFloat().coerceAtLeast(0.0f)
    val tl = s.lenMeters("tl", 0.45).toFloat().coerceAtLeast(0.2f)
    val tw = s.lenMeters("tw", 0.35).toFloat().coerceAtLeast(0.2f)

    val isCirc = type == "Circular Footing"
    val isSq = type == "Square Footing"
    val isStepped = type == "Stepped Footing"
    val isSloped = type in setOf("Sloped Footing", "Tapered Footing")
    val isTrapCombined = type == "Trapezoidal Combined Footing"
    val isRectCombined = type == "Combined Footing (Rectangular)"
    val isStrap = type == "Strap Footing"
    val isStripOrWall = type in setOf("Strip Footing", "Continuous Wall Footing")

    val effL = when {
        isCirc -> dia
        isSq -> bw
        else -> bl
    }
    val effB = when {
        isCirc -> dia
        else -> bw
    }

    val lLbl = if (isCirc) "Ø=${s.lenLabel("dia", 2.2)}" else if (isSq) "B=${s.lenLabel("bw", 1.8)}" else "L=${s.lenLabel("bl", 2.2)}"
    val wLbl = if (isTrapCombined) "B1=${s.lenLabel("bw", 1.8)} / B2=${s.lenLabel("b2", 2.6)}" else "B=${s.lenLabel("bw", 1.8)}"
    val dTotLbl = "D=${UnitConverter.fmt((d1 + if (isSloped || isStepped) d2 else 0f).toDouble(), s.p)}m"

    when (mode) {
        DiagramViewMode.PLAN_2D -> {
            val cx = size.width / 2f
            val cy = size.height / 2f
            if (isCirc) {
                val r = min(size.width, size.height) * 0.27f
                drawCircle(CadColors.SoilFill, r + 14f, Offset(cx, cy))
                drawCircle(CadColors.SoilStroke, r + 14f, Offset(cx, cy), style = Stroke(1.8f))
                drawCircle(CadColors.ConcreteFill, r, Offset(cx, cy))
                drawCircle(CadColors.ConcreteStroke, r, Offset(cx, cy), style = Stroke(3f))
                drawCircle(CadColors.DimOrange, r * 0.24f, Offset(cx, cy), style = Stroke(2.5f))
                drawDimensionLine(Offset(cx - r, cy + r), Offset(cx + r, cy + r), 36f, lLbl)
            } else if (isTrapCombined) {
                val lenPx = size.width * 0.62f
                val h1 = (size.height * 0.28f)
                val h2 = (size.height * 0.50f)
                val left = cx - lenPx / 2f
                val path = Path().apply {
                    moveTo(left, cy - h1 / 2f)
                    lineTo(left + lenPx, cy - h2 / 2f)
                    lineTo(left + lenPx, cy + h2 / 2f)
                    lineTo(left, cy + h1 / 2f)
                    close()
                }
                drawPath(path, CadColors.ConcreteFill)
                drawPath(path, CadColors.ConcreteStroke, style = Stroke(3f))
                // Two columns
                drawRect(CadColors.DimOrange, Offset(left + lenPx * 0.16f, cy - 16f), Size(32f, 32f), style = Stroke(2.5f))
                drawRect(CadColors.DimOrange, Offset(left + lenPx * 0.74f, cy - 20f), Size(40f, 40f), style = Stroke(2.5f))
                drawDimensionLine(Offset(left, cy + h2 / 2f), Offset(left + lenPx, cy + h2 / 2f), 32f, lLbl)
                drawDimensionLine(Offset(left, cy - h1 / 2f), Offset(left, cy + h1 / 2f), -44f, "B1=${s.lenLabel("bw", 1.8)}")
                drawDimensionLine(Offset(left + lenPx, cy - h2 / 2f), Offset(left + lenPx, cy + h2 / 2f), -46f, "B2=${s.lenLabel("b2", 2.6)}", CadColors.DimOrange)
            } else if (isStrap) {
                val pad = 64f
                val totalW = size.width - pad * 2f
                val pad1W = totalW * 0.28f
                val pad2W = totalW * 0.30f
                val h1 = 96f
                val h2 = 120f
                drawRect(CadColors.ConcreteFill, Offset(pad, cy - h1 / 2f), Size(pad1W, h1))
                drawRect(CadColors.ConcreteStroke, Offset(pad, cy - h1 / 2f), Size(pad1W, h1), style = Stroke(3f))
                drawRect(CadColors.ConcreteFill, Offset(pad + totalW - pad2W, cy - h2 / 2f), Size(pad2W, h2))
                drawRect(CadColors.ConcreteStroke, Offset(pad + totalW - pad2W, cy - h2 / 2f), Size(pad2W, h2), style = Stroke(3f))
                // Strap beam connecting both pads
                drawRect(CadColors.DimOrange.copy(alpha = 0.28f), Offset(pad + 12f, cy - 16f), Size(totalW - 24f, 32f))
                drawRect(CadColors.DimOrange, Offset(pad + 12f, cy - 16f), Size(totalW - 24f, 32f), style = Stroke(2.5f))
                drawDimensionLine(Offset(pad, cy + h2 / 2f), Offset(pad + pad1W, cy + h2 / 2f), 30f, "L1=${s.lenLabel("bl", 2.2)}")
                drawDimensionLine(Offset(pad + totalW - pad2W, cy + h2 / 2f), Offset(pad + totalW, cy + h2 / 2f), 30f, "L2=${s.lenLabel("l2", 1.4)}", CadColors.DimOrange)
            } else {
                val maxS = min(size.width, size.height) * 0.52f
                val aspect = if (isSq) 1f else if (isStripOrWall) 2.2f else (effL / effB).coerceIn(0.5f, 1.9f)
                val wPx = if (aspect >= 1f) maxS else maxS * aspect
                val hPx = if (aspect >= 1f) maxS / aspect else maxS
                val left = cx - wPx / 2f
                val top = cy - hPx / 2f
                drawRect(CadColors.SoilFill, Offset(left - 12f, top - 12f), Size(wPx + 24f, hPx + 24f))
                drawRect(CadColors.SoilStroke, Offset(left - 12f, top - 12f), Size(wPx + 24f, hPx + 24f), style = Stroke(1.8f))
                drawRect(CadColors.ConcreteFill, Offset(left, top), Size(wPx, hPx))
                drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(wPx, hPx), style = Stroke(3f))
                if (isStepped) {
                    val s2W = wPx * 0.65f
                    val s2H = hPx * 0.65f
                    drawRect(CadColors.ConcreteDarkFill.copy(alpha = 0.45f), Offset(cx - s2W / 2f, cy - s2H / 2f), Size(s2W, s2H))
                    drawRect(CadColors.ConcreteStroke, Offset(cx - s2W / 2f, cy - s2H / 2f), Size(s2W, s2H), style = Stroke(2f))
                }
                if (isRectCombined) {
                    drawRect(CadColors.DimOrange, Offset(left + wPx * 0.2f - 14f, cy - 14f), Size(28f, 28f), style = Stroke(2.5f))
                    drawRect(CadColors.DimOrange, Offset(left + wPx * 0.8f - 14f, cy - 14f), Size(28f, 28f), style = Stroke(2.5f))
                } else if (isStripOrWall) {
                    drawRect(CadColors.DimOrange, Offset(left, cy - 12f), Size(wPx, 24f), style = Stroke(2.5f))
                } else {
                    val colW = (wPx * (tl / effL)).coerceIn(22f, wPx * 0.42f)
                    val colH = (hPx * (tw / effB)).coerceIn(22f, hPx * 0.42f)
                    drawRect(CadColors.DimOrange, Offset(cx - colW / 2f, cy - colH / 2f), Size(colW, colH), style = Stroke(2.5f))
                }
                drawDimensionLine(Offset(left, top + hPx), Offset(left + wPx, top + hPx), 36f, lLbl)
                drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -48f, wLbl)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
        DiagramViewMode.SECTION, DiagramViewMode.REINFORCEMENT -> {
            val pad = 74f
            val baseW = size.width - pad * 2f
            val baseY = size.height * 0.74f
            val pccH = 20f
            val padH = 44f
            drawRect(CadColors.SoilFill, Offset(pad - 12f, baseY), Size(baseW + 24f, pccH))
            drawRect(CadColors.SoilStroke, Offset(pad - 12f, baseY), Size(baseW + 24f, pccH), style = Stroke(2f))

            if (isRectCombined || isTrapCombined) {
                drawRect(CadColors.ConcreteFill, Offset(pad, baseY - padH - 14f), Size(baseW, padH + 14f))
                drawRect(CadColors.ConcreteStroke, Offset(pad, baseY - padH - 14f), Size(baseW, padH + 14f), style = Stroke(3f))
                listOf(pad + baseW * 0.22f, pad + baseW * 0.78f).forEach { colCx ->
                    drawRect(CadColors.ConcreteFill, Offset(colCx - 20f, baseY - padH - 64f), Size(40f, 50f))
                    drawRect(CadColors.ConcreteStroke, Offset(colCx - 20f, baseY - padH - 64f), Size(40f, 50f), style = Stroke(2.5f))
                }
                drawLine(CadColors.SteelBar, Offset(pad + 12f, baseY - padH - 4f), Offset(pad + baseW - 12f, baseY - padH - 4f), 3f)
                drawLine(CadColors.SteelBar, Offset(pad + 12f, baseY - 10f), Offset(pad + baseW - 12f, baseY - 10f), 4f)
            } else if (isStrap) {
                val p1W = baseW * 0.30f
                val p2W = baseW * 0.32f
                drawRect(CadColors.ConcreteFill, Offset(pad, baseY - padH), Size(p1W, padH))
                drawRect(CadColors.ConcreteStroke, Offset(pad, baseY - padH), Size(p1W, padH), style = Stroke(3f))
                drawRect(CadColors.ConcreteFill, Offset(pad + baseW - p2W, baseY - padH), Size(p2W, padH))
                drawRect(CadColors.ConcreteStroke, Offset(pad + baseW - p2W, baseY - padH), Size(p2W, padH), style = Stroke(3f))
                // Elevated Strap Beam
                drawRect(CadColors.ConcreteDarkFill, Offset(pad + p1W * 0.3f, baseY - padH - 44f), Size(baseW - p1W * 0.3f - p2W * 0.3f, 44f))
                drawRect(CadColors.ConcreteStroke, Offset(pad + p1W * 0.3f, baseY - padH - 44f), Size(baseW - p1W * 0.3f - p2W * 0.3f, 44f), style = Stroke(2.5f))
                drawLine(CadColors.SteelBar, Offset(pad + p1W * 0.3f + 8f, baseY - padH - 34f), Offset(pad + baseW - p2W * 0.3f - 8f, baseY - padH - 34f), 4f)
            } else if (isStepped) {
                val s2W = baseW * 0.62f
                val s2X = size.width / 2f - s2W / 2f
                drawRect(CadColors.ConcreteFill, Offset(pad, baseY - padH), Size(baseW, padH))
                drawRect(CadColors.ConcreteStroke, Offset(pad, baseY - padH), Size(baseW, padH), style = Stroke(3f))
                drawRect(CadColors.ConcreteFill, Offset(s2X, baseY - padH - 42f), Size(s2W, 42f))
                drawRect(CadColors.ConcreteStroke, Offset(s2X, baseY - padH - 42f), Size(s2W, 42f), style = Stroke(3f))
                drawRect(CadColors.ConcreteDarkFill, Offset(size.width / 2f - 28f, baseY - padH - 92f), Size(56f, 50f))
                drawLine(CadColors.SteelBar, Offset(pad + 12f, baseY - 12f), Offset(pad + baseW - 12f, baseY - 12f), 4f)
            } else {
                val trapH = if (isSloped) 54f else 0f
                val colW = (baseW * (tl / effL)).coerceIn(46f, 96f)
                val colX = size.width / 2f - colW / 2f
                val footPath = Path().apply {
                    moveTo(pad, baseY)
                    lineTo(pad + baseW, baseY)
                    lineTo(pad + baseW, baseY - padH)
                    lineTo(colX + colW, baseY - padH - trapH)
                    lineTo(colX + colW, baseY - padH - trapH - 54f)
                    lineTo(colX, baseY - padH - trapH - 54f)
                    lineTo(colX, baseY - padH - trapH)
                    lineTo(pad, baseY - padH)
                    close()
                }
                drawPath(footPath, CadColors.ConcreteFill)
                drawPath(footPath, CadColors.ConcreteStroke, style = Stroke(3f))
                drawLine(CadColors.SteelBar, Offset(pad + 14f, baseY - 12f), Offset(pad + baseW - 14f, baseY - 12f), 4f)
                drawLine(CadColors.SteelBar, Offset(colX + 12f, baseY - padH - trapH - 60f), Offset(colX + 12f, baseY - 14f), 3f)
                drawLine(CadColors.SteelBar, Offset(colX + colW - 12f, baseY - padH - trapH - 60f), Offset(colX + colW - 12f, baseY - 14f), 3f)
            }
            drawDimensionLine(Offset(pad, baseY + pccH), Offset(pad + baseW, baseY + pccH), 30f, lLbl)
            drawDimensionLine(Offset(pad + baseW, baseY - padH - 36f), Offset(pad + baseW, baseY), -44f, dTotLbl, CadColors.DimOrange)
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        else -> {
            val scale = (min(size.width, size.height) * 0.48f) / max(effL, effB)
            val center = Offset(size.width / 2f, size.height * 0.62f)
            val cRef = Vec3D(effL / 2f, effB / 2f, (d1 + d2) / 2f)
            if (isCirc) {
                val r = effL / 2f
                val (_, topPts) = draw3DCylinder(Offset(r, r), 0f, d1, r, cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                draw3DCylinder(Offset(r, r), d1, d1 + 0.6f, tl / 2f, cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                drawDimensionLine(topPts[0], topPts[topPts.size / 2], -28f, lLbl)
            } else if (isStepped) {
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(effL, effB, d1), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                draw3DPrism(
                    Vec3D((effL - l2) / 2f, (effB - b2) / 2f, d1),
                    Vec3D((effL + l2) / 2f, (effB + b2) / 2f, d1 + d2),
                    cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill
                )
                drawDimensionLine(pts[0], pts[1], 28f, lLbl)
                drawDimensionLine(pts[1], pts[2], 28f, wLbl)
            } else if (isStrap) {
                val span = 1.6f
                val cStrapRef = Vec3D((effL + l2 + span) / 2f, max(effB, b2) / 2f, d1 / 2f)
                val pts1 = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(effL, effB, d1), cStrapRef, center, scale * 0.65f, yaw, pitch, CadColors.ConcreteFill)
                draw3DPrism(Vec3D(effL + span, 0f, 0f), Vec3D(effL + span + l2, b2, d1), cStrapRef, center, scale * 0.65f, yaw, pitch, CadColors.ConcreteFill)
                draw3DPrism(Vec3D(effL * 0.4f, effB * 0.38f, d1), Vec3D(effL + span + l2 * 0.6f, effB * 0.62f, d1 + 0.45f), cStrapRef, center, scale * 0.65f, yaw, pitch, CadColors.ConcreteDarkFill)
                drawDimensionLine(pts1[0], pts1[1], 28f, "L1=${s.lenLabel("bl", 2.2)}")
            } else {
                draw3DPrism(Vec3D(-0.1f, -0.1f, -0.1f), Vec3D(effL + 0.1f, effB + 0.1f, 0f), cRef, center, scale, yaw, pitch, CadColors.SoilFill, CadColors.SoilStroke)
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(effL, effB, d1 + d2 * 0.4f), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                if (isRectCombined || isTrapCombined) {
                    draw3DPrism(Vec3D(effL * 0.18f, (effB - tw) / 2f, d1), Vec3D(effL * 0.18f + tl, (effB + tw) / 2f, d1 + 0.65f), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                    draw3DPrism(Vec3D(effL * 0.72f, (effB - tw) / 2f, d1), Vec3D(effL * 0.72f + tl, (effB + tw) / 2f, d1 + 0.65f), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                } else {
                    draw3DPrism(
                        Vec3D((effL - tl) / 2f, (effB - tw) / 2f, d1 + d2 * 0.4f),
                        Vec3D((effL + tl) / 2f, (effB + tw) / 2f, d1 + d2 + 0.65f),
                        cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill
                    )
                }
                drawDimensionLine(pts[0], pts[1], 28f, lLbl)
                drawDimensionLine(pts[1], pts[2], 28f, wLbl)
                drawDimensionLine(pts[2], pts[6], -38f, dTotLbl, CadColors.DimOrange)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
    }
}

internal fun DrawScope.drawStaircaseDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val type = if (s.toolId == "struct_stair_doglegged") "Dog-Legged Staircase" else s.raw("stairType", "Straight Staircase")
    val isSpiral = type in setOf("Spiral Staircase", "Circular / Helical Staircase")
    val isUOrOpen = type in setOf("Dog-Legged Staircase", "Open-Well Staircase", "U-Shaped Staircase", "Half-Turn Staircase")
    val isL = type == "L-Shaped (Quarter-Turn)"

    val fh = s.lenMeters("floorH", 3.0).toFloat().coerceAtLeast(1.0f)
    val riser = s.lenMeters("riser", 0.15).toFloat().coerceAtLeast(0.08f)
    val tread = s.lenMeters("tread", 0.28).toFloat().coerceAtLeast(0.15f)
    val width = s.lenMeters(if (s.toolId == "struct_stair_doglegged") "flightW" else "width", 1.2).toFloat().coerceAtLeast(0.6f)
    val numRisers = max(2, (fh / riser).roundToInt()).coerceAtMost(24)
    val risersInDrawnFlight = if (isUOrOpen) max(2, numRisers / 2) else numRisers
    val runM = (risersInDrawnFlight - 1) * tread
    val angleDeg = Math.toDegrees(atan2((if (isUOrOpen) fh / 2f else fh).toDouble(), max(runM, 0.2f).toDouble()))

    when (mode) {
        DiagramViewMode.PLAN_2D -> {
            val cx = size.width / 2f
            val cy = size.height / 2f
            if (isSpiral) {
                val rOut = min(size.width, size.height) * 0.34f
                val rIn = rOut * 0.22f
                drawCircle(CadColors.ConcreteFill.copy(alpha = 0.55f), rOut, Offset(cx, cy))
                drawCircle(CadColors.ConcreteStroke, rOut, Offset(cx, cy), style = Stroke(3f))
                val wedges = numRisers.coerceIn(8, 18)
                for (i in 0 until wedges) {
                    val a = 2.0 * PI * i / wedges
                    val p1 = Offset(cx + (rIn * cos(a)).toFloat(), cy + (rIn * sin(a)).toFloat())
                    val p2 = Offset(cx + (rOut * cos(a)).toFloat(), cy + (rOut * sin(a)).toFloat())
                    drawLine(CadColors.ConcreteStroke, p1, p2, 2f)
                }
                drawCircle(CadColors.DimOrange, rIn, Offset(cx, cy))
                drawDimensionLine(Offset(cx - rOut, cy + rOut), Offset(cx + rOut, cy + rOut), 32f, "Ø=${s.lenLabel("outerDia", 2.2)}")
            } else if (isL) {
                val pad = 76f
                val armW = (size.width - pad * 2f) * 0.62f
                val flightT = 68f
                val left = cx - armW / 2f - 20f
                val top = cy - armW * 0.45f
                drawRect(CadColors.ConcreteFill, Offset(left, top), Size(armW, flightT))
                drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(armW, flightT), style = Stroke(3f))
                drawRect(CadColors.ConcreteFill, Offset(left + armW - flightT, top), Size(flightT, armW * 0.85f))
                drawRect(CadColors.ConcreteStroke, Offset(left + armW - flightT, top), Size(flightT, armW * 0.85f), style = Stroke(3f))
                for (i in 1..6) drawLine(CadColors.ConcreteStroke, Offset(left + (armW - flightT) * i / 7f, top), Offset(left + (armW - flightT) * i / 7f, top + flightT), 1.5f)
                for (j in 1..5) drawLine(CadColors.ConcreteStroke, Offset(left + armW - flightT, top + flightT + (armW * 0.85f - flightT) * j / 6f), Offset(left + armW, top + flightT + (armW * 0.85f - flightT) * j / 6f), 1.5f)
                drawCadTextPill("90° Quarter-Turn Landing", Offset(left + armW - flightT / 2f, top - 20f), CadColors.DimOrange)
                drawDimensionLine(Offset(left, top + flightT), Offset(left + armW, top + flightT), 32f, "W=${s.lenLabel("width", 1.2)}")
            } else {
                val pad = 74f
                val planW = size.width - pad * 2f
                val planH = if (isUOrOpen) 168f else 98f
                val top = cy - planH / 2f
                drawRect(CadColors.ConcreteFill.copy(alpha = 0.5f), Offset(pad, top), Size(planW, planH))
                drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(planW, planH), style = Stroke(3f))
                val steps = risersInDrawnFlight - 1
                val flightW = if (isUOrOpen) planW * 0.72f else planW
                for (i in 1..steps) {
                    val x = pad + flightW * i / (steps + 1)
                    drawLine(CadColors.ConcreteStroke, Offset(x, top), Offset(x, top + planH), 1.8f)
                }
                if (isUOrOpen) {
                    if (type == "Open-Well Staircase") {
                        drawRect(Color.White, Offset(pad, top + planH * 0.34f), Size(flightW, planH * 0.32f))
                        drawRect(CadColors.DimOrange, Offset(pad, top + planH * 0.34f), Size(flightW, planH * 0.32f), style = Stroke(2.5f))
                        drawCadTextPill("Open Well", Offset(pad + flightW / 2f, top + planH / 2f), CadColors.DimOrange, textSizePx = 20f)
                    } else {
                        drawLine(CadColors.DimOrange, Offset(pad, top + planH / 2f), Offset(pad + flightW, top + planH / 2f), 3f)
                    }
                    drawCadTextPill("Landing", Offset(pad + flightW + (planW - flightW) / 2f, top + planH / 2f), CadColors.DimOrange)
                }
                drawDimensionLine(Offset(pad, top + planH), Offset(pad + flightW, top + planH), 34f, "Run=${UnitConverter.fmt(runM.toDouble(), s.p)}m")
                drawDimensionLine(Offset(pad, top), Offset(pad, top + planH), -46f, "W=${s.lenLabel(if (s.toolId == "struct_stair_doglegged") "flightW" else "width", 1.2)}")
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        DiagramViewMode.VIEW_3D -> {
            if (isSpiral) {
                val r = 1.1f
                val scale = (min(size.width, size.height) * 0.42f) / max(fh, r * 2f)
                val cRef = Vec3D(0f, 0f, fh / 2f)
                val center = Offset(size.width / 2f, size.height * 0.56f)
                draw3DCylinder(Offset(0f, 0f), 0f, fh, 0.14f, cRef, center, scale, yaw, pitch, CadColors.DimOrange)
                val steps = 12
                for (i in 0 until steps) {
                    val a1 = 2.0 * PI * i / steps
                    val a2 = 2.0 * PI * (i + 1) / steps
                    val z = fh * i / steps
                    val p0 = project3DPoint(Vec3D(0f, 0f, z), cRef, center, scale, yaw, pitch).first
                    val p1 = project3DPoint(Vec3D((r * cos(a1)).toFloat(), (r * sin(a1)).toFloat(), z), cRef, center, scale, yaw, pitch).first
                    val p2 = project3DPoint(Vec3D((r * cos(a2)).toFloat(), (r * sin(a2)).toFloat(), z), cRef, center, scale, yaw, pitch).first
                    val tp = Path().apply { moveTo(p0.x, p0.y); lineTo(p1.x, p1.y); lineTo(p2.x, p2.y); close() }
                    drawPath(tp, CadColors.ConcreteFill)
                    drawPath(tp, CadColors.ConcreteStroke, style = Stroke(2f))
                }
            } else {
                val stepCount = risersInDrawnFlight.coerceAtMost(10)
                val scale = (min(size.width, size.height) * 0.45f) / max(runM, fh)
                val cRef = Vec3D(runM / 2f, width / 2f, fh / 4f)
                val center = Offset(size.width / 2f, size.height * 0.58f)
                val rH = (if (isUOrOpen) fh / 2f else fh) / stepCount
                val tD = runM / max(1, stepCount - 1)
                for (i in 0 until stepCount - 1) {
                    draw3DPrism(
                        Vec3D(i * tD, 0f, i * rH),
                        Vec3D((i + 1) * tD, width, (i + 1) * rH),
                        cRef, center, scale, yaw, pitch, CadColors.ConcreteFill
                    )
                }
            }
            drawCadTextPill("$type • $numRisers Risers", Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
        else -> {
            val pad = 74f
            val baseX = pad
            val baseY = size.height * 0.78f
            val hasLanding = type != "Straight Staircase"
            val drawW = size.width - pad * 2f - (if (hasLanding) 64f else 0f)
            val drawH = size.height * 0.50f
            val steps = risersInDrawnFlight.coerceAtMost(14)
            val dx = drawW / max(1, steps - 1)
            val dy = drawH / steps

            val path = Path().apply {
                moveTo(baseX, baseY)
                var cx = baseX
                var cy = baseY
                for (i in 0 until steps - 1) {
                    cy -= dy
                    lineTo(cx, cy)
                    cx += dx
                    lineTo(cx, cy)
                }
                if (hasLanding) {
                    lineTo(cx + 62f, cy)
                    lineTo(cx + 62f, cy + 26f)
                    lineTo(cx + 12f, cy + 26f)
                } else {
                    lineTo(cx + 16f, cy + 24f)
                }
                lineTo(baseX + 22f, baseY)
                close()
            }
            drawPath(path, CadColors.ConcreteFill)
            drawPath(path, CadColors.ConcreteStroke, style = Stroke(3f))
            drawDimensionLine(Offset(baseX, baseY), Offset(baseX + drawW, baseY), 32f, "Run=${UnitConverter.fmt(runM.toDouble(), s.p)}m")
            drawDimensionLine(Offset(baseX, baseY - drawH), Offset(baseX, baseY), -48f, "H=${s.lenLabel("floorH", 3.0)}", CadColors.DimOrange)
            drawAngularArc(Offset(baseX, baseY), 46f, -angleDeg.toFloat(), angleDeg.toFloat(), "${UnitConverter.fmt(angleDeg, 1)}°")
            drawCadTextPill("$type • $numRisers Risers", Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
    }
}

internal fun DrawScope.drawRetainingWallDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val type = s.raw("retType", "Cantilever T-Wall")
    val h = s.lenMeters("h", 3.5).toFloat().coerceAtLeast(0.5f)
    val topW = s.lenMeters("topW", 0.2).toFloat().coerceAtLeast(0.1f)
    val botW = s.lenMeters("botW", 0.4).toFloat().coerceAtLeast(topW)
    val baseW = s.lenMeters("baseW", 2.4).toFloat().coerceAtLeast(botW + 0.3f)
    val baseT = s.lenMeters("baseT", 0.4).toFloat().coerceAtLeast(0.1f)
    val len = s.lenMeters("len", 15.0).toFloat().coerceAtLeast(1f)
    val isGravity = type == "Gravity Trapezoidal Wall"
    val isL = type == "L-Shaped Retaining Wall"
    val isCounterfort = type == "Counterfort Retaining Wall"

    if (mode == DiagramViewMode.VIEW_3D) {
        val scale = (min(size.width, size.height) * 0.48f) / max(len * 0.4f, h)
        val cRef = Vec3D(len * 0.25f, baseW / 2f, h / 2f)
        val center = Offset(size.width / 2f, size.height * 0.6f)
        val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(len * 0.5f, baseW, if (isGravity) h else baseT), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
        if (!isGravity) {
            val stemY = if (isL) 0f else baseW * 0.3f
            draw3DPrism(Vec3D(0f, stemY, baseT), Vec3D(len * 0.5f, stemY + botW, baseT + h), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
            if (isCounterfort) {
                draw3DPrism(Vec3D(len * 0.1f, stemY + botW, baseT), Vec3D(len * 0.1f + 0.35f, baseW, baseT + h * 0.85f), cRef, center, scale, yaw, pitch, CadColors.DimOrange)
                draw3DPrism(Vec3D(len * 0.35f, stemY + botW, baseT), Vec3D(len * 0.35f + 0.35f, baseW, baseT + h * 0.85f), cRef, center, scale, yaw, pitch, CadColors.DimOrange)
            }
        }
        drawDimensionLine(pts[0], pts[1], 28f, "L=${s.lenLabel("len", 15.0)}")
        drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
    } else {
        val pad = 74f
        val drawBaseW = size.width - pad * 2f
        val scale = min(drawBaseW / baseW, (size.height * 0.56f) / (h + baseT))
        val bx = size.width / 2f - (baseW * scale) / 2f
        val by = size.height * 0.80f
        val btPx = (baseT * scale).coerceAtLeast(20f)
        val stemH = (h * scale).coerceAtLeast(70f)
        val toePx = if (isL) 0f else baseW * scale * 0.32f
        val botWPx = (botW * scale).coerceAtLeast(26f)
        val topWPx = (topW * scale).coerceAtLeast(16f)

        val wallPath = Path().apply {
            if (isGravity) {
                moveTo(bx, by)
                lineTo(bx + baseW * scale, by)
                lineTo(bx + topWPx * 1.6f, by - stemH - btPx)
                lineTo(bx, by - stemH - btPx)
                close()
            } else {
                moveTo(bx, by)
                lineTo(bx + baseW * scale, by)
                lineTo(bx + baseW * scale, by - btPx)
                lineTo(bx + toePx + botWPx, by - btPx)
                lineTo(bx + toePx + topWPx, by - btPx - stemH)
                lineTo(bx + toePx, by - btPx - stemH)
                lineTo(bx + toePx, by - btPx)
                if (!isL) lineTo(bx, by - btPx)
                close()
            }
        }
        drawPath(wallPath, CadColors.ConcreteFill)
        drawPath(wallPath, CadColors.ConcreteStroke, style = Stroke(3f))
        if (isCounterfort) {
            val cfPath = Path().apply {
                moveTo(bx + toePx + topWPx, by - btPx - stemH)
                lineTo(bx + baseW * scale - 10f, by - btPx)
                lineTo(bx + toePx + botWPx, by - btPx)
                close()
            }
            drawPath(cfPath, CadColors.DimOrange.copy(alpha = 0.25f))
            drawPath(cfPath, CadColors.DimOrange, style = Stroke(2f))
        }
        drawDimensionLine(Offset(bx, by), Offset(bx + baseW * scale, by), 32f, "Base=${s.lenLabel("baseW", 2.4)}")
        drawDimensionLine(Offset(bx + toePx, by - btPx - stemH), Offset(bx + toePx, by - btPx), -48f, "H=${s.lenLabel("h", 3.5)}", CadColors.DimOrange)
        drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
    }
}

internal fun DrawScope.drawStructuralWallDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val type = s.raw("wallType", "Shear Wall")
    val l1 = s.lenMeters("l", 6.0).toFloat().coerceAtLeast(1f)
    val l2 = s.lenMeters("l2", 4.0).toFloat().coerceAtLeast(1f)
    val dia = s.lenMeters("dia", 5.0).toFloat().coerceAtLeast(1f)
    val h = s.lenMeters("h", 3.5).toFloat().coerceAtLeast(0.8f)
    val t = s.lenMeters("t", 0.25).toFloat().coerceAtLeast(0.1f)
    val cx = size.width / 2f
    val cy = size.height / 2f

    when (mode) {
        DiagramViewMode.PLAN_2D -> {
            val pad = 74f
            when (type) {
                "Circular Wall" -> {
                    val rOut = min(size.width, size.height) * 0.29f
                    val rIn = rOut * 0.78f
                    drawCircle(CadColors.ConcreteFill, rOut, Offset(cx, cy))
                    drawCircle(Color.White, rIn, Offset(cx, cy))
                    drawCircle(CadColors.ConcreteStroke, rOut, Offset(cx, cy), style = Stroke(3f))
                    drawCircle(CadColors.ConcreteStroke, rIn, Offset(cx, cy), style = Stroke(2.5f))
                    drawDimensionLine(Offset(cx - rOut, cy + rOut), Offset(cx + rOut, cy + rOut), 32f, "Ø=${s.lenLabel("dia", 5.0)}")
                }
                "Curved Wall" -> {
                    val r = min(size.width, size.height) * 0.42f
                    drawArc(CadColors.ConcreteFill, 200f, 140f, false, Offset(cx - r, cy - r * 0.4f), Size(r * 2f, r * 2f), style = Stroke(26f))
                    drawArc(CadColors.ConcreteStroke, 200f, 140f, false, Offset(cx - r, cy - r * 0.4f), Size(r * 2f, r * 2f), style = Stroke(3f))
                    drawCadTextPill("Arc L=${s.lenLabel("l", 6.0)}", Offset(cx, cy + 36f), CadColors.DimBlue)
                }
                "L-Shaped Wall" -> {
                    val wPx = size.width * 0.56f
                    val hPx = size.height * 0.52f
                    val left = cx - wPx / 2f
                    val top = cy - hPx / 2f
                    val wt = 36f
                    val path = Path().apply {
                        moveTo(left, top)
                        lineTo(left + wPx, top)
                        lineTo(left + wPx, top + wt)
                        lineTo(left + wt, top + wt)
                        lineTo(left + wt, top + hPx)
                        lineTo(left, top + hPx)
                        close()
                    }
                    drawPath(path, CadColors.ConcreteFill)
                    drawPath(path, CadColors.ConcreteStroke, style = Stroke(3f))
                    drawDimensionLine(Offset(left, top), Offset(left + wPx, top), -28f, "L1=${s.lenLabel("l", 6.0)}")
                    drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -44f, "L2=${s.lenLabel("l2", 4.0)}", CadColors.DimOrange)
                }
                "Cavity Wall" -> {
                    val wallW = size.width - pad * 2f
                    drawRect(CadColors.ConcreteFill, Offset(pad, cy - 32f), Size(wallW, 20f))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, cy - 32f), Size(wallW, 20f), style = Stroke(2.5f))
                    drawRect(CadColors.ConcreteFill, Offset(pad, cy + 12f), Size(wallW, 20f))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, cy + 12f), Size(wallW, 20f), style = Stroke(2.5f))
                    drawCadTextPill("Double Leaf + Air Cavity", Offset(cx, cy), CadColors.DimOrange, textSizePx = 20f)
                    drawDimensionLine(Offset(pad, cy + 32f), Offset(pad + wallW, cy + 32f), 32f, "L=${s.lenLabel("l", 6.0)}")
                }
                else -> {
                    val wallW = size.width - pad * 2f
                    val wallT = 44f
                    drawRect(CadColors.ConcreteFill, Offset(pad, cy - wallT / 2f), Size(wallW, wallT))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, cy - wallT / 2f), Size(wallW, wallT), style = Stroke(3f))
                    if (type == "Shear Wall") {
                        // Boundary element zones at both ends
                        drawRect(CadColors.DimOrange.copy(alpha = 0.25f), Offset(pad, cy - wallT / 2f), Size(46f, wallT))
                        drawRect(CadColors.DimOrange.copy(alpha = 0.25f), Offset(pad + wallW - 46f, cy - wallT / 2f), Size(46f, wallT))
                    }
                    drawDimensionLine(Offset(pad, cy + wallT / 2f), Offset(pad + wallW, cy + wallT / 2f), 32f, "L=${s.lenLabel("l", 6.0)}")
                    drawDimensionLine(Offset(pad + wallW, cy - wallT / 2f), Offset(pad + wallW, cy + wallT / 2f), -44f, "T=${s.lenLabel("t", 0.25)}", CadColors.DimOrange)
                }
            }
            drawCadTextPill(type, Offset(cx, 26f), CadColors.DimBlue)
        }
        DiagramViewMode.VIEW_3D -> {
            val scale = (min(size.width, size.height) * 0.48f) / max(l1, h)
            val center = Offset(cx, size.height * 0.58f)
            if (type == "Circular Wall") {
                draw3DCylinder(Offset(0f, 0f), 0f, h, dia / 2f, Vec3D(0f, 0f, h / 2f), center, scale, yaw, pitch, CadColors.ConcreteFill)
            } else if (type == "L-Shaped Wall") {
                val cRef = Vec3D(l1 / 2f, l2 / 2f, h / 2f)
                draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l1, t, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(t, l2, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
            } else {
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l1, max(t, 0.3f), h), Vec3D(l1 / 2f, t / 2f, h / 2f), center, scale, yaw, pitch, CadColors.ConcreteFill)
                drawDimensionLine(pts[0], pts[1], 28f, "L=${s.lenLabel("l", 6.0)}")
                drawDimensionLine(pts[1], pts[5], -38f, "H=${s.lenLabel("h", 3.5)}", CadColors.DimOrange)
            }
            drawCadTextPill(type, Offset(cx, 26f), CadColors.DimOrange)
        }
        else -> {
            val pad = 74f
            val ww = size.width - pad * 2f
            val wh = size.height * 0.52f
            val top = cy - wh / 2f
            drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(ww, wh))
            drawDiagonalHatch(Offset(pad, top), Size(ww, wh))
            drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(ww, wh), style = Stroke(3f))
            drawDimensionLine(Offset(pad, top + wh), Offset(pad + ww, top + wh), 32f, if (type == "Circular Wall") "Ø=${s.lenLabel("dia", 5.0)}" else "L=${s.lenLabel("l", 6.0)}")
            drawDimensionLine(Offset(pad, top), Offset(pad, top + wh), -46f, "H=${s.lenLabel("h", 3.5)}", CadColors.DimOrange)
            drawCadTextPill(type, Offset(cx, 26f), CadColors.DimBlue)
        }
    }
}

internal fun DrawScope.drawMiscStructuralDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val type = s.raw("elemType", "Concrete Ramp")
    val l = s.lenMeters("l", 6.0).toFloat().coerceAtLeast(0.5f)
    val w = s.lenMeters("w", 3.0).toFloat().coerceAtLeast(0.2f)
    val h = s.lenMeters("h", 0.9).toFloat().coerceAtLeast(0.2f)
    val lLbl = "L=${s.lenLabel("l", 6.0)}"
    val wLbl = "W=${s.lenLabel("w", 3.0)}"
    val hLbl = "H=${s.lenLabel("h", 0.9)}"

    when {
        mode == DiagramViewMode.VIEW_3D -> {
            val scale = (min(size.width, size.height) * 0.48f) / max(max(l, w), h)
            val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l, w, h), Vec3D(l / 2f, w / 2f, h / 2f), Offset(size.width / 2f, size.height * 0.56f), scale, yaw, pitch, CadColors.ConcreteFill)
            drawDimensionLine(pts[0], pts[1], 28f, lLbl)
            drawDimensionLine(pts[1], pts[2], 28f, wLbl)
            drawDimensionLine(pts[2], pts[6], -38f, hLbl, CadColors.DimOrange)
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
        mode == DiagramViewMode.PLAN_2D -> {
            val pad = 74f
            val rw = size.width - pad * 2f
            val rh = (rw * (w / l).coerceIn(0.3f, 0.75f)).coerceAtMost(size.height * 0.54f)
            val top = (size.height - rh) / 2f
            drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, lLbl)
            drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -46f, wLbl, CadColors.DimOrange)
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        type == "Concrete Ramp" -> {
            val pad = 74f
            val baseW = size.width - pad * 2f
            val baseY = size.height * 0.78f
            val riseH = size.height * 0.44f
            val wedge = Path().apply {
                moveTo(pad, baseY)
                lineTo(pad + baseW, baseY)
                lineTo(pad + baseW, baseY - riseH)
                close()
            }
            drawPath(wedge, CadColors.SoilFill)
            drawPath(wedge, CadColors.SoilStroke, style = Stroke(2f))
            val rampSlab = Path().apply {
                moveTo(pad, baseY)
                lineTo(pad + baseW, baseY - riseH)
                lineTo(pad + baseW, baseY - riseH - 22f)
                lineTo(pad, baseY - 22f)
                close()
            }
            drawPath(rampSlab, CadColors.ConcreteFill)
            drawPath(rampSlab, CadColors.ConcreteStroke, style = Stroke(3f))
            val deg = Math.toDegrees(atan2(h.toDouble(), l.toDouble()))
            drawAngularArc(Offset(pad, baseY), 48f, -deg.toFloat().coerceIn(5f, 45f), deg.toFloat().coerceIn(5f, 45f), "${UnitConverter.fmt(deg, 1)}°")
            drawDimensionLine(Offset(pad, baseY), Offset(pad + baseW, baseY), 32f, lLbl)
            drawDimensionLine(Offset(pad + baseW, baseY - riseH), Offset(pad + baseW, baseY), -46f, hLbl, CadColors.DimOrange)
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        type == "Concrete Steps (Entry)" -> {
            val nSteps = s.dbl("stepsCount", 5.0).roundToInt().coerceIn(2, 10)
            val pad = 74f
            val baseW = size.width - pad * 2f
            val baseY = size.height * 0.78f
            val totalH = size.height * 0.46f
            val dx = baseW / nSteps
            val dy = totalH / nSteps
            val p = Path().apply {
                moveTo(pad, baseY)
                lineTo(pad + baseW, baseY)
                lineTo(pad + baseW, baseY - totalH)
                var cx = pad + baseW
                var cy = baseY - totalH
                for (i in 0 until nSteps) {
                    cx -= dx
                    lineTo(cx, cy)
                    cy += dy
                    lineTo(cx, cy)
                }
                close()
            }
            drawPath(p, CadColors.ConcreteFill)
            drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
            drawDimensionLine(Offset(pad, baseY), Offset(pad + baseW, baseY), 32f, lLbl)
            drawDimensionLine(Offset(pad + baseW, baseY - totalH), Offset(pad + baseW, baseY), -46f, hLbl, CadColors.DimOrange)
            drawCadTextPill("$type ($nSteps Steps)", Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        else -> {
            val pad = 74f
            val rw = size.width - pad * 2f
            val rh = size.height * 0.44f
            val top = (size.height - rh) / 2f
            drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, lLbl)
            drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -46f, hLbl, CadColors.DimOrange)
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
    }
}

internal fun DrawScope.drawRoofingDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val type = s.raw("roofType", "Double-Slope / Gable Roof")
    val span = s.lenMeters("span", 18.0).toFloat().coerceAtLeast(2f)
    val len = s.lenMeters("len", 36.0).toFloat().coerceAtLeast(2f)
    val rise = if (type == "Flat Roof") 0f else s.lenMeters("rise", 2.2).toFloat().coerceAtLeast(0.3f)
    val eaveH = if (type in setOf("Industrial PEB Shed", "Warehouse Roof & Sheet Layout", "Canopy Roof")) s.lenMeters("eaveH", 7.5).toFloat() else 3.2f
    val isSingleSlope = type in setOf("Single-Slope / Shed Roof", "Canopy Roof")
    val isFlat = type == "Flat Roof"
    val isHip = type == "Hip Roof"

    when (mode) {
        DiagramViewMode.PLAN_2D -> {
            val pad = 74f
            val rw = size.width - pad * 2f
            val rh = (rw * (span / len).coerceIn(0.38f, 0.78f)).coerceAtMost(size.height * 0.56f)
            val top = size.height / 2f - rh / 2f
            drawRect(CadColors.GlassFill.copy(alpha = 0.35f), Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            if (isHip) {
                val inset = min(rw * 0.28f, rh * 0.5f)
                val rLeft = Offset(pad + inset, top + rh / 2f)
                val rRight = Offset(pad + rw - inset, top + rh / 2f)
                drawLine(CadColors.DimOrange, rLeft, rRight, 3.5f)
                listOf(Offset(pad, top), Offset(pad, top + rh)).forEach { drawLine(CadColors.DimOrange, it, rLeft, 3f) }
                listOf(Offset(pad + rw, top), Offset(pad + rw, top + rh)).forEach { drawLine(CadColors.DimOrange, it, rRight, 3f) }
            } else if (!isFlat && !isSingleSlope) {
                drawDashedLine(Offset(pad, top + rh / 2f), Offset(pad + rw, top + rh / 2f), CadColors.DimOrange, 3f)
            }
            for (i in 1..6) {
                val sx = pad + rw * i / 7f
                drawLine(CadColors.DimBlue.copy(alpha = 0.4f), Offset(sx, top), Offset(sx, top + rh), 1.5f)
            }
            drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 34f, "L=${s.lenLabel("len", 36.0)}")
            drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -48f, "W=${s.lenLabel("span", 18.0)}", CadColors.DimOrange)
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        DiagramViewMode.VIEW_3D -> {
            val scale = (min(size.width, size.height) * 0.46f) / max(span, len)
            val cRef = Vec3D(len / 2f, span / 2f, (eaveH + rise) / 2f)
            val center = Offset(size.width / 2f, size.height * 0.58f)
            val nF = 5
            var firstL = Offset.Zero
            var firstR = Offset.Zero
            for (i in 0 until nF) {
                val x = len * i / (nF - 1)
                val pBL = project3DPoint(Vec3D(x, 0f, 0f), cRef, center, scale, yaw, pitch).first
                val pEL = project3DPoint(Vec3D(x, 0f, eaveH), cRef, center, scale, yaw, pitch).first
                val pER = project3DPoint(Vec3D(x, span, if (isSingleSlope) eaveH + rise else eaveH), cRef, center, scale, yaw, pitch).first
                val pBR = project3DPoint(Vec3D(x, span, 0f), cRef, center, scale, yaw, pitch).first
                val fp = Path().apply {
                    moveTo(pBL.x, pBL.y)
                    lineTo(pEL.x, pEL.y)
                    if (!isFlat && !isSingleSlope) {
                        val pR = project3DPoint(Vec3D(x, span / 2f, eaveH + rise), cRef, center, scale, yaw, pitch).first
                        lineTo(pR.x, pR.y)
                    }
                    lineTo(pER.x, pER.y)
                    lineTo(pBR.x, pBR.y)
                }
                drawPath(fp, CadColors.DimOrange, style = Stroke(width = 3.5f, join = StrokeJoin.Round))
                if (i == 0) { firstL = pBL; firstR = pBR }
            }
            drawDimensionLine(firstL, firstR, 28f, "W=${s.lenLabel("span", 18.0)}")
            drawCadTextPill("$type (Drag to Orbit)", Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        else -> {
            val pad = 74f
            val baseW = size.width - pad * 2f
            val baseY = size.height * 0.78f
            val colH = size.height * 0.34f
            val eaveY = baseY - colH
            val risePx = if (isFlat) 0f else size.height * 0.22f
            val leftX = pad
            val rightX = pad + baseW
            val midX = size.width / 2f

            drawLine(CadColors.ConcreteStroke, Offset(leftX - 14f, baseY), Offset(rightX + 14f, baseY), 4f)
            val path = Path().apply {
                moveTo(leftX, baseY)
                lineTo(leftX, eaveY)
                when {
                    isFlat -> lineTo(rightX, eaveY)
                    isSingleSlope -> lineTo(rightX, eaveY - risePx)
                    else -> {
                        lineTo(midX, eaveY - risePx)
                        lineTo(rightX, eaveY)
                    }
                }
                if (type != "Canopy Roof") lineTo(rightX, baseY)
            }
            drawPath(path, CadColors.DimOrange, style = Stroke(width = 6f, join = StrokeJoin.Round))
            drawDimensionLine(Offset(leftX, baseY), Offset(rightX, baseY), 32f, "Span=${s.lenLabel("span", 18.0)}")
            if (!isFlat) {
                drawDimensionLine(Offset(rightX, eaveY - risePx), Offset(rightX, eaveY), -48f, "Rise=${s.lenLabel("rise", 2.2)}", CadColors.DimBlue)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
    }
}

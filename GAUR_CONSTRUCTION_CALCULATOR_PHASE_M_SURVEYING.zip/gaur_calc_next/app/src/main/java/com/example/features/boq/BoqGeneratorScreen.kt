package com.example.features.boq

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CompareArrows
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.core.i18n.LocalAppStrings
import com.example.data.local.BoqEstimateEntity
import com.example.domain.units.UnitConverter
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette
import org.json.JSONArray
import org.json.JSONObject

data class BoqLineItem(
    val id: Long,
    val itemNo: String,
    val category: String,
    val description: String,
    val unit: String,
    val quantity: Double,
    val materialRate: Double,
    val labourRate: Double,
    val wastagePct: Double,
    val remarks: String
) {
    val effectiveQty: Double get() = quantity * (1.0 + wastagePct / 100.0)
    val unitRate: Double get() = materialRate + labourRate
    val amount: Double get() = effectiveQty * unitRate
}

private fun boqTemplateItems(template: String): List<BoqLineItem> = when (template) {
    "Commercial" -> listOf(
        BoqLineItem(1, "1.1", "Substructure", "Deep Foundation Excavation & Dewatering", "m³", 180.0, 40.0, 260.0, 0.0, "Mechanical"),
        BoqLineItem(2, "2.1", "RCC Frame", "M25 Ready-Mix Concrete for Columns & Beams", "m³", 95.0, 5800.0, 650.0, 3.0, "IS 456"),
        BoqLineItem(3, "2.2", "Steel", "Fe500D TMT Reinforcement Supply & Bending", "kg", 11500.0, 68.0, 12.0, 3.0, "Cut & Bend"),
        BoqLineItem(4, "3.1", "Facade & Glass", "Structural Curtain Glazing & ACP Cladding", "sq.ft", 1400.0, 420.0, 95.0, 2.0, "Toughened")
    )
    "Industrial" -> listOf(
        BoqLineItem(1, "1.1", "Earthwork", "Industrial Site Grading & Compaction", "m³", 420.0, 80.0, 180.0, 0.0, "95% Proctor"),
        BoqLineItem(2, "2.1", "Flooring", "VDF Trimix Industrial Floor Slab (150mm M25)", "m²", 1200.0, 920.0, 220.0, 3.0, "With Hardener"),
        BoqLineItem(3, "3.1", "Masonry", "200mm AAC Block Partition Wall", "m²", 360.0, 860.0, 240.0, 3.0, "3mm Adhesive")
    )
    "Warehouse", "PEB" -> listOf(
        BoqLineItem(1, "1.1", "PEB Steel", "Primary Built-up Portal Frames & Secondary Purlins", "kg", 36000.0, 92.0, 24.0, 2.0, "IS 2062 E350"),
        BoqLineItem(2, "1.2", "Sheeting", "0.5mm PPGI Bare Galvalume Roof & Side Cladding", "sq.ft", 16500.0, 52.0, 15.0, 4.0, "Self-drilling screws"),
        BoqLineItem(3, "2.1", "Flooring", "Trimix Heavy-Duty Warehouse Slab (150mm)", "m²", 1150.0, 950.0, 240.0, 3.0, "Fiber reinforced")
    )
    "Roadwork" -> listOf(
        BoqLineItem(1, "1.1", "Subgrade", "Earthwork Excavation & Subgrade Compaction", "m³", 600.0, 75.0, 160.0, 0.0, "MoRTH"),
        BoqLineItem(2, "1.2", "GSB / WMM", "Granular Sub-Base & Wet Mix Macadam", "m³", 320.0, 1450.0, 320.0, 5.0, "Compacted"),
        BoqLineItem(3, "2.1", "Pavement", "M30 Pavement Quality Concrete (PQC)", "m³", 240.0, 6200.0, 700.0, 3.0, "200mm thick")
    )
    "Renovation" -> listOf(
        BoqLineItem(1, "1.1", "Demolition", "Dismantling Existing Flooring & Debris Carting", "sq.ft", 1200.0, 15.0, 45.0, 0.0, "Safe disposal"),
        BoqLineItem(2, "2.1", "Flooring", "Double-Charge Vitrified Tile Laying", "sq.ft", 1200.0, 72.0, 32.0, 7.0, "600x600mm"),
        BoqLineItem(3, "3.1", "Painting", "2-Coat Putty + Primer + Premium Emulsion", "sq.ft", 3400.0, 18.0, 14.0, 2.0, "Interior")
    )
    else -> listOf(
        BoqLineItem(1, "1.1", "Earthwork", "Foundation Pit Excavation in Soft/Hard Soil", "m³", 65.0, 0.0, 240.0, 0.0, "Upto 1.5m depth"),
        BoqLineItem(2, "1.2", "PCC", "PCC 1:4:8 (M7.5) Leveling Bed under Footings", "m³", 8.5, 3900.0, 550.0, 5.0, "100mm thick"),
        BoqLineItem(3, "2.1", "RCC", "M20 RCC for Footings, Columns, Beams & Slab", "m³", 48.0, 5400.0, 750.0, 4.0, "Vibrator compacted"),
        BoqLineItem(4, "2.2", "Steel", "Fe500D TMT Reinforcement Steel Work", "kg", 4400.0, 68.0, 12.0, 3.0, "As per BBS"),
        BoqLineItem(5, "3.1", "Masonry", "230mm Brick Masonry in Cement Mortar 1:6", "m³", 52.0, 4400.0, 1100.0, 5.0, "Standard clay bricks")
    )
}

@Composable
fun BoqGeneratorScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val savedBoqs by viewModel.boqs.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()

    val templates = listOf("Residential", "Commercial", "Industrial", "Warehouse", "PEB", "Roadwork", "Renovation")
    var selectedTemplate by remember { mutableStateOf("Residential") }
    var projectName by remember { mutableStateOf("G+1 Residential Villa") }
    var clientName by remember { mutableStateOf("") }
    var siteLocation by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("Preliminary BOQ Estimate") }
    var gstStr by remember { mutableStateOf("18") }

    val items = remember { mutableStateListOf<BoqLineItem>().apply { addAll(boqTemplateItems("Residential")) } }
    var editingItem by remember { mutableStateOf<BoqLineItem?>(null) }
    var showItemDialog by remember { mutableStateOf(false) }
    var compareTarget by remember { mutableStateOf<BoqEstimateEntity?>(null) }

    val gstPct = (gstStr.toDoubleOrNull() ?: 18.0).coerceIn(0.0, 30.0)
    val subtotal = items.sumOf { it.amount }
    val gstAmount = subtotal * (gstPct / 100.0)
    val grandTotal = subtotal + gstAmount

    fun itemsToJson(): String = JSONArray().apply {
        items.forEach { it ->
            put(JSONObject().apply {
                put("itemNo", it.itemNo)
                put("category", it.category)
                put("description", it.description)
                put("unit", it.unit)
                put("qty", it.quantity)
                put("matRate", it.materialRate)
                put("labRate", it.labourRate)
                put("wastage", it.wastagePct)
                put("remarks", it.remarks)
            })
        }
    }.toString()

    fun loadFromJson(json: String) {
        runCatching {
            val arr = JSONArray(json)
            items.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(
                    BoqLineItem(
                        id = System.nanoTime() + i,
                        itemNo = o.optString("itemNo", "${i + 1}"),
                        category = o.optString("category", "General"),
                        description = o.optString("description", ""),
                        unit = o.optString("unit", "m³"),
                        quantity = o.optDouble("qty", 1.0),
                        materialRate = o.optDouble("matRate", 0.0),
                        labourRate = o.optDouble("labRate", 0.0),
                        wastagePct = o.optDouble("wastage", 0.0),
                        remarks = o.optString("remarks", "")
                    )
                )
            }
        }
    }

    fun buildBoqReport(): EngineeringReportData {
        val rows = items.map {
            listOf(
                it.itemNo,
                it.description.take(26),
                it.unit,
                UnitConverter.fmt(it.effectiveQty, 2),
                UnitConverter.fmt(it.unitRate, 0),
                UnitConverter.fmt(it.amount, 0)
            )
        }
        return EngineeringReportData(
            title = "Bill of Quantities (BOQ) — $projectName",
            projectName = projectName,
            clientName = clientName,
            companyName = settings.companyName,
            engineerName = settings.engineerName,
            subtitle = "$selectedTemplate Template • $siteLocation",
            sections = listOf(
                ReportSection(
                    heading = "BOQ Line Items",
                    tableHeaders = listOf("No.", "Description", "Unit", "Qty", "Rate", "Amount"),
                    tableRows = rows
                ),
                ReportSection(
                    heading = "Financial Summary",
                    rows = listOf(
                        "Subtotal" to "${settings.currencySymbol}${UnitConverter.fmt(subtotal, 2)}",
                        "GST (${UnitConverter.fmt(gstPct, 1)}%)" to "${settings.currencySymbol}${UnitConverter.fmt(gstAmount, 2)}",
                        "GRAND TOTAL" to "${settings.currencySymbol}${UnitConverter.fmt(grandTotal, 2)}"
                    ),
                    paragraphs = listOf(description)
                )
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = strings.boqTitle,
            subtitle = "Total: ${settings.currencySymbol}${UnitConverter.fmt(grandTotal, 0)}",
            onBack = onBack,
            actions = {
                IconButton(
                    onClick = {
                        viewModel.saveBoq(
                            BoqEstimateEntity(
                                projectId = projects.firstOrNull()?.id,
                                title = projectName.ifBlank { "$selectedTemplate BOQ" },
                                clientName = clientName,
                                siteLocation = siteLocation,
                                description = description,
                                templateType = selectedTemplate,
                                gstPercent = gstPct,
                                itemsJson = itemsToJson()
                            )
                        )
                        Toast.makeText(context, "BOQ saved locally", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("boq_save_btn")
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = "Save BOQ", tint = palette.orangeDark)
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Template Selector
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(templates) { tpl ->
                        FilterChip(
                            selected = selectedTemplate == tpl,
                            onClick = {
                                selectedTemplate = tpl
                                items.clear()
                                items.addAll(boqTemplateItems(tpl))
                            },
                            label = { Text(tpl) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = palette.orangeSoft,
                                selectedLabelColor = palette.orangeDark
                            ),
                            border = BorderStroke(1.dp, palette.metallicBorder)
                        )
                    }
                }
            }

            // Project Header & Summary
            item {
                EngineeringCard(accentColor = palette.orange) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = projectName, onValueChange = { projectName = it }, label = { Text("Project Name") }, singleLine = true, modifier = Modifier.weight(1.2f))
                        OutlinedTextField(value = gstStr, onValueChange = { gstStr = it }, label = { Text("GST %") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(0.6f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = clientName, onValueChange = { clientName = it }, label = { Text("Client Name") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = siteLocation, onValueChange = { siteLocation = it }, label = { Text("Site Location") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    Surface(color = palette.skyGlassTint, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Subtotal (${items.size} items)", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                                Text("${settings.currencySymbol}${UnitConverter.fmt(subtotal, 0)}", fontWeight = FontWeight.SemiBold)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("GST (${UnitConverter.fmt(gstPct, 1)}%)", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                                Text("${settings.currencySymbol}${UnitConverter.fmt(gstAmount, 0)}", fontWeight = FontWeight.SemiBold)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("GRAND TOTAL", style = MaterialTheme.typography.titleSmall, color = palette.skyBlue)
                                Text("${settings.currencySymbol}${UnitConverter.fmt(grandTotal, 0)}", style = MaterialTheme.typography.titleMedium, color = palette.skyBlue, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { editingItem = null; showItemDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.orange),
                            modifier = Modifier.weight(1f).testTag("boq_add_item_btn")
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add BOQ Item")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = {
                                val file = ReportExportEngine.generatePdfFile(context, buildBoqReport())
                                ReportExportEngine.shareFile(context, file, "application/pdf", projectName)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.error)
                            Spacer(Modifier.width(3.dp))
                            Text("PDF")
                        }
                        OutlinedButton(
                            onClick = {
                                val headers = listOf("Item No", "Category", "Description", "Unit", "Qty", "Wastage %", "Mat. Rate", "Lab. Rate", "Amount", "Remarks")
                                val rows = items.map {
                                    listOf(it.itemNo, it.category, it.description, it.unit, UnitConverter.fmt(it.quantity, 2), UnitConverter.fmt(it.wastagePct, 1), UnitConverter.fmt(it.materialRate, 2), UnitConverter.fmt(it.labourRate, 2), UnitConverter.fmt(it.amount, 2), it.remarks)
                                }
                                val file = ReportExportEngine.generateExcelWorkbookFile(context, "BOQ_$projectName", headers, rows)
                                ReportExportEngine.shareFile(context, file, "application/vnd.ms-excel", projectName)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.success)
                            Spacer(Modifier.width(3.dp))
                            Text("Excel")
                        }
                        OutlinedButton(
                            onClick = {
                                val file = ReportExportEngine.generatePdfFile(context, buildBoqReport())
                                ReportExportEngine.printPdfFile(context, file, projectName)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(3.dp))
                            Text("Print")
                        }
                    }
                }
            }

            // BOQ Items
            itemsIndexed(items, key = { _, it -> it.id }) { index, item ->
                EngineeringCard(accentColor = palette.skyBlue) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            GlassBluePill(text = "#${item.itemNo}")
                            Text(item.category, style = MaterialTheme.typography.labelMedium, color = palette.inkMuted)
                        }
                        Text(
                            "${settings.currencySymbol}${UnitConverter.fmt(item.amount, 0)}",
                            style = MaterialTheme.typography.titleMedium,
                            color = palette.orangeDark,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(item.description, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Text(
                        "${UnitConverter.fmt(item.quantity, 2)} ${item.unit} (+${UnitConverter.fmt(item.wastagePct, 1)}% wast.) × ${settings.currencySymbol}${UnitConverter.fmt(item.unitRate, 0)} (Mat ${UnitConverter.fmt(item.materialRate, 0)} + Lab ${UnitConverter.fmt(item.labourRate, 0)})",
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.inkSecondary
                    )
                    if (item.remarks.isNotBlank()) {
                        Text("Remarks: ${item.remarks}", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        IconButton(onClick = {
                            if (index > 0) {
                                val moving = items.removeAt(index)
                                items.add(index - 1, moving)
                            }
                        }) { Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move Up", tint = palette.inkMuted) }
                        IconButton(onClick = {
                            if (index < items.lastIndex) {
                                val moving = items.removeAt(index)
                                items.add(index + 1, moving)
                            }
                        }) { Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move Down", tint = palette.inkMuted) }
                        IconButton(onClick = {
                            items.add(index + 1, item.copy(id = System.nanoTime(), itemNo = "${item.itemNo}b"))
                        }) { Icon(Icons.Rounded.ContentCopy, contentDescription = "Duplicate", tint = palette.skyBlue) }
                        IconButton(onClick = {
                            editingItem = item
                            showItemDialog = true
                        }) { Icon(Icons.Rounded.Edit, contentDescription = "Edit", tint = palette.orangeDark) }
                        IconButton(onClick = { items.removeAt(index) }) {
                            Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = palette.error)
                        }
                    }
                }
            }

            // Saved BOQ Estimates (Reopen & Compare)
            if (savedBoqs.isNotEmpty()) {
                item {
                    Text("Saved BOQ Estimates (${savedBoqs.size})", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                }
                items(savedBoqs, key = { it.id }) { saved ->
                    EngineeringCard(onClick = {
                        projectName = saved.title
                        clientName = saved.clientName
                        siteLocation = saved.siteLocation
                        description = saved.description
                        selectedTemplate = saved.templateType
                        gstStr = saved.gstPercent.toString()
                        loadFromJson(saved.itemsJson)
                    }) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(saved.title, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                Text("${saved.templateType} • ${saved.siteLocation}", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            }
                            IconButton(onClick = { compareTarget = saved }) {
                                Icon(Icons.Rounded.CompareArrows, contentDescription = "Compare", tint = palette.skyBlue)
                            }
                            IconButton(onClick = { viewModel.deleteBoq(saved.id) }) {
                                Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = palette.error)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showItemDialog) {
        BoqItemDialog(
            initial = editingItem,
            onDismiss = { showItemDialog = false },
            onSave = { updated ->
                if (editingItem != null) {
                    val idx = items.indexOfFirst { it.id == editingItem!!.id }
                    if (idx >= 0) items[idx] = updated
                } else {
                    items.add(updated)
                }
                showItemDialog = false
            }
        )
    }

    compareTarget?.let { target ->
        val savedTotal = runCatching {
            val arr = JSONArray(target.itemsJson)
            var sub = 0.0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val q = o.optDouble("qty", 0.0) * (1.0 + o.optDouble("wastage", 0.0) / 100.0)
                sub += q * (o.optDouble("matRate", 0.0) + o.optDouble("labRate", 0.0))
            }
            sub * (1.0 + target.gstPercent / 100.0)
        }.getOrDefault(0.0)
        val delta = grandTotal - savedTotal
        AlertDialog(
            onDismissRequest = { compareTarget = null },
            title = { Text("BOQ Comparison") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Current ($projectName): ${settings.currencySymbol}${UnitConverter.fmt(grandTotal, 0)}")
                    Text("Saved (${target.title}): ${settings.currencySymbol}${UnitConverter.fmt(savedTotal, 0)}")
                    Text(
                        "Difference: ${if (delta >= 0) "+" else ""}${settings.currencySymbol}${UnitConverter.fmt(delta, 0)}",
                        fontWeight = FontWeight.Bold,
                        color = if (delta >= 0) palette.orangeDark else palette.success
                    )
                }
            },
            confirmButton = { TextButton(onClick = { compareTarget = null }) { Text("Close") } }
        )
    }
}

@Composable
private fun BoqItemDialog(
    initial: BoqLineItem?,
    onDismiss: () -> Unit,
    onSave: (BoqLineItem) -> Unit
) {
    var itemNo by remember { mutableStateOf(initial?.itemNo ?: "4.1") }
    var category by remember { mutableStateOf(initial?.category ?: "Finishing") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var unit by remember { mutableStateOf(initial?.unit ?: "m²") }
    var qty by remember { mutableStateOf((initial?.quantity ?: 10.0).toString()) }
    var matRate by remember { mutableStateOf((initial?.materialRate ?: 100.0).toString()) }
    var labRate by remember { mutableStateOf((initial?.labourRate ?: 40.0).toString()) }
    var wastage by remember { mutableStateOf((initial?.wastagePct ?: 5.0).toString()) }
    var remarks by remember { mutableStateOf(initial?.remarks ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add BOQ Item" else "Edit BOQ Item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = itemNo, onValueChange = { itemNo = it }, label = { Text("Item No") }, singleLine = true, modifier = Modifier.weight(0.7f))
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true, modifier = Modifier.weight(1.3f))
                }
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Item Description") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("Unit") }, singleLine = true, modifier = Modifier.weight(0.8f))
                    OutlinedTextField(value = qty, onValueChange = { qty = it }, label = { Text("Qty") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = wastage, onValueChange = { wastage = it }, label = { Text("Wast %") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(0.8f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = matRate, onValueChange = { matRate = it }, label = { Text("Mat. Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = labRate, onValueChange = { labRate = it }, label = { Text("Lab. Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = remarks, onValueChange = { remarks = it }, label = { Text("Remarks") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = {
                if (desc.isNotBlank()) {
                    onSave(
                        BoqLineItem(
                            id = initial?.id ?: System.nanoTime(),
                            itemNo = itemNo.ifBlank { "1" },
                            category = category.ifBlank { "General" },
                            description = desc.trim(),
                            unit = unit.ifBlank { "Nos" },
                            quantity = (qty.toDoubleOrNull() ?: 1.0).coerceAtLeast(0.0),
                            materialRate = (matRate.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                            labourRate = (labRate.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0),
                            wastagePct = (wastage.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 50.0),
                            remarks = remarks.trim()
                        )
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

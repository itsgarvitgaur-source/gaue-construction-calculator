package com.example.features.more

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.Engineering
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material.icons.rounded.Warehouse
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.i18n.LocalAppStrings
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.LocalEngineeringPalette

private data class HubModuleItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val orange: Boolean,
    val route: String
)

@Composable
fun ToolkitHubScreen(
    onNavigate: (String) -> Unit
) {
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current

    val items = remember(strings) {
        listOf(
            HubModuleItem("bbs", strings.bbsTitle, "Shape previews, cutting length, weight & PDF/Excel", Icons.Rounded.Layers, true, "bbs"),
            HubModuleItem("peb", strings.pebTitle, "Shed dimensions, roof slope, purlins, Trimix & bolts", Icons.Rounded.Warehouse, false, "peb"),
            HubModuleItem("boq", strings.boqTitle, "7 project templates, GST, compare & PDF/Excel", Icons.Rounded.ReceiptLong, true, "boq"),
            HubModuleItem("materials", strings.materialEstimator, "Material & labour rates, wastage, custom items", Icons.Rounded.Inventory2, false, "materials"),
            HubModuleItem("studio2d", strings.studio2D, "CAD floor/foundation plans, blueprint mode, layers", Icons.Rounded.Draw, false, "studio2d"),
            HubModuleItem("studio3d", strings.studio3D, "Interactive 3D structural viewer & section cut", Icons.Rounded.ViewInAr, true, "studio3d"),
            HubModuleItem("converters", "Unit Converters Hub", "Instant & full-table conversions (Length, Land, MPa, °C)", Icons.Rounded.SwapHoriz, false, "converters"),
            HubModuleItem("feet_inch_calc", "Feet-Inch Construction Calc", "Fraction keypad (1/16\"), area, volume, memory & tape", Icons.Rounded.Straighten, true, "feet_inch_calc"),
            HubModuleItem("scientific_calc", "Scientific & Trig Calc", "Sin/Cos/Tan, DMS ° ' \", log, power & tape", Icons.Rounded.Functions, false, "scientific_calc"),
            HubModuleItem("site_diary", "DPR, MB Book & QA/QC Safety", "Daily Progress Report, MB N×L×B×D & checklists", Icons.Rounded.Engineering, true, "site_diary"),
            HubModuleItem("knowledge", "Civil Engineering Knowledge", "Bridge, High-Rise, RCC, Roads, Hindi guides & Quiz", Icons.Rounded.MenuBook, false, "knowledge"),
            HubModuleItem("site", strings.siteToolkit, "Rise & fall, slope, 3-4-5, coordinate bearing, scale", Icons.Rounded.Explore, true, "category/site"),
            HubModuleItem("history", strings.historyTitle, "Saved calculations, templates & search", Icons.Rounded.History, false, "history"),
            HubModuleItem("security", strings.securityShield, "APK SHA-256, AES-256 Keystore & diagnostics", Icons.Rounded.Security, true, "security"),
            HubModuleItem("settings", strings.settingsTitle, "Dark/Light mode, Hindi/English, Units, Bigha & backup", Icons.Rounded.Settings, false, "settings")
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = "Engineering Studios & Hub",
            subtitle = "BBS, PEB, BOQ, 2D/3D CAD, Site DPR & Knowledge"
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items, key = { it.id }) { mod ->
                val accent = if (mod.orange) palette.orange else palette.skyBlue
                val bg = if (mod.orange) palette.orangeSoft else palette.skyGlassTint
                EngineeringCard(
                    accentColor = accent,
                    onClick = { onNavigate(mod.route) },
                    modifier = Modifier.testTag("hub_item_${mod.id}")
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(bg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(mod.icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(mod.title, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                            Text(mod.subtitle, style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                        }
                    }
                }
            }
        }
    }
}

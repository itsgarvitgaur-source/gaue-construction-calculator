package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ProjectEntity::class,
        CalculationHistoryEntity::class,
        FavoriteToolEntity::class,
        BoqEstimateEntity::class,
        BbsScheduleEntity::class,
        MaterialRateEntity::class,
        StudioDrawingEntity::class,
        StudioModel3DEntity::class,
        SecurityEventEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun historyDao(): HistoryDao
    abstract fun favoriteToolDao(): FavoriteToolDao
    abstract fun boqDao(): BoqDao
    abstract fun bbsDao(): BbsDao
    abstract fun materialRateDao(): MaterialRateDao
    abstract fun studioDrawingDao(): StudioDrawingDao
    abstract fun studioModel3DDao(): StudioModel3DDao
    abstract fun securityEventDao(): SecurityEventDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "gaur_construction_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}

package com.example.domain.units

enum class ExtendedAreaUnit(val symbol: String, val sqMetersFactor: Double) {
    SQ_MM("mm²", 1e-6),
    SQ_CM("cm²", 1e-4),
    SQ_M("m²", 1.0),
    SQ_FT("sq.ft", 0.09290304),
    SQ_YD("sq.yd (Gaj)", 0.83612736),
    CENT("Cent", 40.468564224),
    GUNTHA("Guntha", 101.17141056),
    MARLA("Marla", 25.29285264),
    KANAL("Kanal", 505.8570528),
    ACRE("Acre", 4046.8564224),
    HECTARE("Hectare", 10000.0)
}

enum class WeightUnit(val symbol: String, val toKg: Double) {
    MG("mg", 1e-6),
    G("g", 0.001),
    KG("kg", 1.0),
    QUINTAL("Quintal", 100.0),
    MT("Metric Ton", 1000.0),
    LB("lb (Pound)", 0.45359237),
    OZ("oz (Ounce)", 0.028349523125),
    SHORT_TON("US Ton", 907.18474)
}

enum class PressureUnit(val symbol: String, val toKpa: Double) {
    PA("Pa (N/m²)", 0.001),
    KPA("kPa (kN/m²)", 1.0),
    MPA("MPa (N/mm²)", 1000.0),
    BAR("Bar", 100.0),
    PSI("PSI (lb/in²)", 6.894757293),
    KG_CM2("kg/cm²", 98.0665),
    ATM("atm", 101.325)
}

enum class ForceUnit(val symbol: String, val toNewton: Double) {
    N("N", 1.0),
    KN("kN", 1000.0),
    MN("MN", 1_000_000.0),
    KGF("kgf", 9.80665),
    TON_F("tf (Metric)", 9806.65),
    LBF("lbf", 4.448221615),
    KIP("kip (1000 lbf)", 4448.221615)
}

enum class SpeedUnit(val symbol: String, val toMps: Double) {
    MPS("m/s", 1.0),
    KMPH("km/h", 1.0 / 3.6),
    MPH("mph", 0.44704),
    FTPS("ft/s", 0.3048),
    KNOT("knot", 0.514444444)
}

enum class TempUnit(val symbol: String) {
    CELSIUS("°C"),
    FAHRENHEIT("°F"),
    KELVIN("K")
}

object EngineeringUnitConverter {
    fun convertExtendedArea(value: Double, from: ExtendedAreaUnit, to: ExtendedAreaUnit): Double =
        (value * from.sqMetersFactor) / to.sqMetersFactor

    fun convertWeight(value: Double, from: WeightUnit, to: WeightUnit): Double =
        (value * from.toKg) / to.toKg

    fun convertPressure(value: Double, from: PressureUnit, to: PressureUnit): Double =
        (value * from.toKpa) / to.toKpa

    fun convertForce(value: Double, from: ForceUnit, to: ForceUnit): Double =
        (value * from.toNewton) / to.toNewton

    fun convertSpeed(value: Double, from: SpeedUnit, to: SpeedUnit): Double =
        (value * from.toMps) / to.toMps

    fun convertTemperature(value: Double, from: TempUnit, to: TempUnit): Double {
        val celsius = when (from) {
            TempUnit.CELSIUS -> value
            TempUnit.FAHRENHEIT -> (value - 32.0) * 5.0 / 9.0
            TempUnit.KELVIN -> value - 273.15
        }
        return when (to) {
            TempUnit.CELSIUS -> celsius
            TempUnit.FAHRENHEIT -> celsius * 9.0 / 5.0 + 32.0
            TempUnit.KELVIN -> celsius + 273.15
        }
    }
}

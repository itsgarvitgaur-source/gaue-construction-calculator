package com.example.core.export

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.example.R
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ReportSection(
    val heading: String,
    val rows: List<Pair<String, String>> = emptyList(),
    val paragraphs: List<String> = emptyList(),
    val tableHeaders: List<String> = emptyList(),
    val tableRows: List<List<String>> = emptyList()
)

data class EngineeringReportData(
    val title: String,
    val projectName: String,
    val clientName: String = "",
    val companyName: String = "Gaur Engineering & Constructions",
    val engineerName: String = "Site Engineer",
    val subtitle: String = "",
    val sections: List<ReportSection>,
    val footerNote: String = "Generated offline by Gaur Construction Calculator"
)

object ReportExportEngine {

    private fun exportsDir(context: Context): File =
        File(context.cacheDir, "exports").apply { mkdirs() }

    private fun safeFileName(base: String, ext: String): String {
        val clean = base.replace(Regex("[^A-Za-z0-9_\\-]"), "_").take(40).ifBlank { "Gaur_Report" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        return "${clean}_$stamp.$ext"
    }

    fun generatePdfFile(context: Context, report: EngineeringReportData): File {
        val pdf = PdfDocument()
        val pageWidth = 595 // A4 points at 72 dpi
        val pageHeight = 842
        val margin = 36f
        val contentWidth = pageWidth - 2 * margin

        val orangePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(245, 124, 0) }
        val bluePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(2, 136, 209) }
        val silverBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(241, 245, 249) }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(203, 213, 225)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(230, 81, 0)
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(15, 23, 42)
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(51, 65, 85)
            textSize = 9.5f
        }
        val mutedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(100, 116, 139)
            textSize = 8.5f
        }

        val logoBitmap = runCatching {
            BitmapFactory.decodeResource(context.resources, R.drawable.gaur_logo)
        }.getOrNull()

        var pageNum = 1
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        var y = margin

        fun drawFooter(c: Canvas, pNo: Int) {
            c.drawLine(margin, pageHeight - 36f, pageWidth - margin, pageHeight - 36f, borderPaint)
            c.drawText("${report.footerNote}  |  Page $pNo", margin, pageHeight - 22f, mutedPaint)
        }

        fun ensureSpace(needed: Float) {
            if (y + needed > pageHeight - 52f) {
                drawFooter(canvas, pageNum)
                pdf.finishPage(page)
                pageNum++
                page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                canvas = page.canvas
                y = margin
            }
        }

        // Branded Header Banner
        canvas.drawRoundRect(RectF(margin, y, pageWidth - margin, y + 66f), 8f, 8f, silverBgPaint)
        canvas.drawRoundRect(RectF(margin, y, pageWidth - margin, y + 66f), 8f, 8f, borderPaint)
        canvas.drawRect(margin, y, margin + 5f, y + 66f, orangePaint)
        if (logoBitmap != null) {
            canvas.drawBitmap(logoBitmap, null, RectF(margin + 12f, y + 8f, margin + 62f, y + 58f), null)
        }
        val textX = margin + 72f
        canvas.drawText("GAUR CONSTRUCTION CALCULATOR", textX, y + 20f, sectionPaint)
        canvas.drawText(report.title.take(52), textX, y + 36f, titlePaint)
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.US).format(Date())
        canvas.drawText("${report.companyName}  •  $dateStr", textX, y + 52f, mutedPaint)
        y += 78f

        // Metadata Strip
        val metaParts = buildList {
            if (report.projectName.isNotBlank()) add("Project: ${report.projectName}")
            if (report.clientName.isNotBlank()) add("Client: ${report.clientName}")
            if (report.engineerName.isNotBlank()) add("Prepared by: ${report.engineerName}")
        }
        if (metaParts.isNotEmpty()) {
            canvas.drawText(metaParts.joinToString("   |   ").take(95), margin, y, boldPaint)
            y += 14f
        }
        if (report.subtitle.isNotBlank()) {
            canvas.drawText(report.subtitle.take(95), margin, y, bodyPaint)
            y += 14f
        }
        canvas.drawLine(margin, y, pageWidth - margin, y, bluePaint)
        y += 14f

        // Render Sections
        for (sec in report.sections) {
            ensureSpace(34f)
            canvas.drawText(sec.heading.uppercase(Locale.US), margin, y, sectionPaint)
            y += 6f
            canvas.drawLine(margin, y, margin + 120f, y, orangePaint)
            y += 14f

            sec.rows.forEachIndexed { idx, (k, v) ->
                ensureSpace(18f)
                if (idx % 2 == 0) {
                    canvas.drawRect(margin, y - 11f, pageWidth - margin, y + 5f, silverBgPaint)
                }
                canvas.drawText(k.take(48), margin + 6f, y, boldPaint)
                canvas.drawText(v.take(44), margin + contentWidth * 0.52f, y, bodyPaint)
                y += 17f
            }

            if (sec.tableHeaders.isNotEmpty()) {
                val cols = sec.tableHeaders.size
                val colW = contentWidth / cols
                ensureSpace(22f)
                canvas.drawRect(margin, y - 12f, pageWidth - margin, y + 6f, silverBgPaint)
                sec.tableHeaders.forEachIndexed { cIdx, h ->
                    canvas.drawText(h.take(18), margin + cIdx * colW + 4f, y, boldPaint)
                }
                y += 18f
                sec.tableRows.forEach { row ->
                    ensureSpace(18f)
                    row.forEachIndexed { cIdx, cell ->
                        canvas.drawText(cell.take(20), margin + cIdx * colW + 4f, y, bodyPaint)
                    }
                    canvas.drawLine(margin, y + 4f, pageWidth - margin, y + 4f, borderPaint)
                    y += 16f
                }
            }

            sec.paragraphs.forEach { para ->
                val words = para.split(" ")
                val lines = mutableListOf<String>()
                var current = StringBuilder()
                for (word in words) {
                    if (current.length + word.length + 1 > 88) {
                        lines.add(current.toString())
                        current = StringBuilder(word)
                    } else {
                        if (current.isNotEmpty()) current.append(" ")
                        current.append(word)
                    }
                }
                if (current.isNotEmpty()) lines.add(current.toString())
                for (line in lines) {
                    ensureSpace(15f)
                    canvas.drawText(line, margin, y, bodyPaint)
                    y += 14f
                }
            }
            y += 10f
        }

        drawFooter(canvas, pageNum)
        pdf.finishPage(page)

        val file = File(exportsDir(context), safeFileName(report.title, "pdf"))
        FileOutputStream(file).use { out -> pdf.writeTo(out) }
        pdf.close()
        return file
    }

    fun generateCsvFile(context: Context, title: String, headers: List<String>, rows: List<List<String>>): File {
        val file = File(exportsDir(context), safeFileName(title, "csv"))
        val sb = StringBuilder()
        sb.appendLine(headers.joinToString(",") { escapeCsv(it) })
        rows.forEach { r -> sb.appendLine(r.joinToString(",") { escapeCsv(it) }) }
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    /**
     * Generates a genuine Excel-compatible SpreadsheetML (.xls) XML workbook
     * that opens cleanly in Microsoft Excel, WPS Office, and Google Sheets.
     */
    fun generateExcelWorkbookFile(
        context: Context,
        title: String,
        headers: List<String>,
        rows: List<List<String>>
    ): File {
        val file = File(exportsDir(context), safeFileName(title, "xls"))
        fun xmlEsc(s: String) = s
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")

        val sb = StringBuilder()
        sb.appendLine("""<?xml version="1.0" encoding="UTF-8"?>""")
        sb.appendLine("""<?mso-application progid="Excel.Sheet"?>""")
        sb.appendLine("""<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">""")
        sb.appendLine(""" <Styles><Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#F57C00" ss:Pattern="Solid"/></Style></Styles>""")
        sb.appendLine(""" <Worksheet ss:Name="Engineering_Sheet">""")
        sb.appendLine("""  <Table>""")
        sb.appendLine("""   <Row><Cell><Data ss:Type="String">${xmlEsc("Gaur Construction Calculator — $title")}</Data></Cell></Row>""")
        sb.append("   <Row>")
        headers.forEach { h ->
            sb.append("""<Cell ss:StyleID="Header"><Data ss:Type="String">${xmlEsc(h)}</Data></Cell>""")
        }
        sb.appendLine("</Row>")
        rows.forEach { r ->
            sb.append("   <Row>")
            r.forEach { cell ->
                val num = cell.toDoubleOrNull()
                if (num != null && !num.isNaN() && !num.isInfinite()) {
                    sb.append("""<Cell><Data ss:Type="Number">$num</Data></Cell>""")
                } else {
                    sb.append("""<Cell><Data ss:Type="String">${xmlEsc(cell)}</Data></Cell>""")
                }
            }
            sb.appendLine("</Row>")
        }
        sb.appendLine("""  </Table>""")
        sb.appendLine(""" </Worksheet>""")
        sb.appendLine("""</Workbook>""")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    fun saveBitmapPng(context: Context, title: String, bitmap: Bitmap): File {
        val file = File(exportsDir(context), safeFileName(title, "png"))
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return file
    }

    fun shareFile(context: Context, file: File, mimeType: String, subject: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share $subject").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    fun sharePlainText(context: Context, subject: String, body: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
        }
        context.startActivity(Intent.createChooser(intent, "Share $subject").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    fun printPdfFile(context: Context, pdfFile: File, jobName: String) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(pdfFile.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback
            ) {
                try {
                    FileInputStream(pdfFile).use { input ->
                        FileOutputStream(destination.fileDescriptor).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback.onWriteFailed(e.message)
                }
            }
        }
        printManager.print(jobName, adapter, PrintAttributes.Builder().build())
    }

    private fun escapeCsv(s: String): String {
        val needsQuotes = s.contains(',') || s.contains('"') || s.contains('\n')
        val escaped = s.replace("\"", "\"\"")
        return if (needsQuotes) "\"$escaped\"" else escaped
    }
}

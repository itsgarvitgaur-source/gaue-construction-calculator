package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val clientName: String,
    val siteLocation: String,
    val projectType: String,
    val startDate: String,
    val status: String, // Planning, In Progress, Completed, Archived
    val notes: String,
    val attachedDocsJson: String = "[]",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "calculation_history")
data class CalculationHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val toolId: String,
    val toolName: String,
    val category: String,
    val customName: String = "",
    val isTemplate: Boolean = false,
    val inputsJson: String,
    val resultsJson: String,
    val formula: String,
    val stepsJson: String,
    val assumptions: String,
    val totalCost: Double? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorite_tools")
data class FavoriteToolEntity(
    @PrimaryKey val toolId: String,
    val isFavorite: Boolean = false,
    val lastUsedAt: Long = 0L,
    val useCount: Int = 0
)

@Entity(tableName = "boq_estimates")
data class BoqEstimateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val title: String,
    val clientName: String,
    val siteLocation: String,
    val description: String,
    val templateType: String,
    val gstPercent: Double = 18.0,
    val itemsJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "bbs_schedules")
data class BbsScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val title: String,
    val memberType: String, // Beam, Column, Slab, Footing, Staircase
    val itemsJson: String,
    val totalWeightKg: Double,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "material_rates")
data class MaterialRateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val unit: String,
    val materialRate: Double,
    val labourRate: Double,
    val isCustom: Boolean = false
)

@Entity(tableName = "studio_drawings")
data class StudioDrawingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val title: String,
    val drawingType: String, // Floor Plan, Foundation Plan, Column Layout, Beam Layout, Slab Layout, Elevation, Section, Site Layout, Warehouse Plan
    val scaleRatio: Int = 100, // 1:100
    val unitLabel: String = "m",
    val blueprintMode: Boolean = true,
    val elementsJson: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "studio_models_3d")
data class StudioModel3DEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long? = null,
    val title: String,
    val objectsJson: String,
    val cameraYaw: Float = 40f,
    val cameraPitch: Float = 28f,
    val isPerspective: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "security_events")
data class SecurityEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventType: String,
    val severity: String, // INFO, WARNING, PASS
    val title: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

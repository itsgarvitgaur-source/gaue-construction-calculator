package com.example.domain.calculators

import com.example.domain.units.AreaUnit
import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.ceil

object MasonryAndFinishingCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        brickWorkCalculator(),
        blockWorkCalculator(),
        plasterCalculator(),
        paintPuttyPrimerCalculator(),
        waterproofingCalculator(),
        tilesFlooringCalculator(),
        trimixEpoxyFlooringCalculator()
    )

    private fun brickWorkCalculator() = CalcToolSpec(
        id = "masonry_bricks",
        title = "Brick Wall (All Wall Types & Shapes)",
        titleHi = "ईंट की दीवार (सभी प्रकार)",
        subtitle = "Straight, Boundary, Cavity, Partition, L-Shaped & Curved Brick Walls + Mortar",
        category = CalcCategory.MASONRY,
        typeFieldKey = "wallShape",
        keywords = listOf("brick", "wall", "mortar", "boundary", "cavity", "partition", "l-shaped", "curved", "circular"),
        fields = listOf(
            CalcFieldSpec(
                "wallShape", "Wall Type / Shape", "Straight Wall",
                options = listOf("Straight Wall", "Boundary Wall (with Pillars)", "Cavity Wall (Double Leaf)", "Partition Wall (Half-Brick)", "L-Shaped Wall", "Curved / Circular Wall")
            ),
            CalcFieldSpec(
                key = "wallL", label = "Total Wall Length (L)", defaultValue = "12.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["wallShape"] != "Curved / Circular Wall" },
                dynamicLabel = { m -> if (m["wallShape"] == "L-Shaped Wall") "Wing 1 Length (L1)" else "Wall Length (L)" }
            ),
            CalcFieldSpec(
                key = "wallL2", label = "Wing 2 Length (L2)", defaultValue = "6.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["wallShape"] == "L-Shaped Wall" }
            ),
            CalcFieldSpec(
                key = "dia", label = "Centerline Wall Diameter (Ø)", defaultValue = "5.0",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.M,
                visibleWhen = { it["wallShape"] == "Curved / Circular Wall" }
            ),
            CalcFieldSpec("wallH", "Wall Height", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec(
                key = "wallT", label = "Wall Thickness", defaultValue = "230",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                dynamicLabel = { m -> if (m["wallShape"] == "Cavity Wall (Double Leaf)") "Single Leaf Thickness (mm)" else "Wall Thickness" }
            ),
            CalcFieldSpec("brickPreset", "Brick Size Preset", "Standard Indian (230×110×70 mm)", options = listOf(
                "Standard Indian (230×110×70 mm)",
                "Modular BIS (190×90×90 mm)",
                "Custom Brick Size"
            )),
            CalcFieldSpec("bL", "Custom Brick Length (mm)", "230", FieldUnitKind.NONE, visibleWhen = { it["brickPreset"] == "Custom Brick Size" }),
            CalcFieldSpec("bW", "Custom Brick Width (mm)", "110", FieldUnitKind.NONE, visibleWhen = { it["brickPreset"] == "Custom Brick Size" }),
            CalcFieldSpec("bH", "Custom Brick Height (mm)", "70", FieldUnitKind.NONE, visibleWhen = { it["brickPreset"] == "Custom Brick Size" }),
            CalcFieldSpec("deductArea", "Door & Window Deduction Area (m²)", "3.6", FieldUnitKind.AREA_SQ_M, allowZero = true),
            CalcFieldSpec("mortar", "Mortar Ratio (Cement:Sand)", "1:6", options = listOf("1:3", "1:4", "1:5", "1:6")),
            CalcFieldSpec("wastage", "Brick Wastage (%)", "5", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val shape = ctx.raw("wallShape").ifBlank { "Straight Wall" }
            val wl1 = ctx.lengthMeters("wallL") ?: 12.0
            val wl2 = ctx.lengthMeters("wallL2") ?: 6.0
            val dia = ctx.lengthMeters("dia") ?: 5.0
            val wh = ctx.lengthMeters("wallH") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter wall height."))
            val wt = if (shape == "Partition Wall (Half-Brick)") 0.115 else (ctx.lengthMeters("wallT") ?: 0.23)
            val wl = when (shape) {
                "L-Shaped Wall" -> wl1 + wl2 - wt
                "Curved / Circular Wall" -> kotlin.math.PI * dia
                else -> wl1
            }
            val deductArea = ctx.doubleOrNull("deductArea") ?: 0.0
            val wastage = ctx.doubleOrNull("wastage") ?: 5.0
            if (wl <= 0 || wh <= 0 || wt <= 0 || deductArea < 0 || wastage < 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid dimensions."))
            }
            val grossArea = wl * wh
            val netArea = (grossArea - deductArea).coerceAtLeast(0.0)
            val leafMult = if (shape == "Cavity Wall (Double Leaf)") 2.0 else 1.0
            val pillarFactor = if (shape == "Boundary Wall (with Pillars)") 1.12 else 1.0
            val wallVol = netArea * wt * leafMult * pillarFactor

            val (blMm, bwMm, bhMm) = when (ctx.raw("brickPreset")) {
                "Modular BIS (190×90×90 mm)" -> Triple(190.0, 90.0, 90.0)
                "Custom Brick Size" -> Triple(
                    (ctx.doubleOrNull("bL") ?: 230.0).coerceAtLeast(50.0),
                    (ctx.doubleOrNull("bW") ?: 110.0).coerceAtLeast(40.0),
                    (ctx.doubleOrNull("bH") ?: 70.0).coerceAtLeast(30.0)
                )
                else -> Triple(230.0, 110.0, 70.0)
            }
            val jointMm = 10.0
            val brickVolOnly = (blMm / 1000.0) * (bwMm / 1000.0) * (bhMm / 1000.0)
            val brickVolWithMortar = ((blMm + jointMm) / 1000.0) * ((bwMm + jointMm) / 1000.0) * ((bhMm + jointMm) / 1000.0)
            val exactBricks = wallVol / brickVolWithMortar
            val totalBricks = ceil(exactBricks * (1.0 + wastage / 100.0)).toLong()
            val wetMortarVol = (wallVol - exactBricks * brickVolOnly).coerceAtLeast(0.0)
            // Dry mortar factor 1.33 (voids + wastage)
            val dryMortarVol = wetMortarVol * 1.33
            val sandPart = ctx.raw("mortar").substringAfter(":").toDoubleOrNull() ?: 6.0
            val sumParts = 1.0 + sandPart
            val cementBags = (dryMortarVol * (1.0 / sumParts)) / 0.0347
            val sandCft = (dryMortarVol * (sandPart / sumParts)) * UnitConverter.CU_FT_IN_CU_M
            val cost = totalBricks * (ctx.ratesByKeyword["brick"] ?: 8.5) +
                cementBags * (ctx.ratesByKeyword["cement"] ?: 390.0) +
                sandCft * (ctx.ratesByKeyword["sand"] ?: 62.0)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Bricks Required (w/ Wastage)", "$totalBricks", "Nos", isPrimary = true),
                        CalcResultItem("Cement for Mortar", UnitConverter.fmt(cementBags, p), "Bags", isPrimary = true),
                        CalcResultItem("Sand for Mortar", UnitConverter.fmt(sandCft, p), "CFT", isPrimary = true),
                        CalcResultItem("Net Masonry Volume", UnitConverter.fmt(wallVol, p), "m³"),
                        CalcResultItem("Net Wall Area", UnitConverter.fmt(netArea, p), "m²"),
                        CalcResultItem("Est. Material Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "N_bricks = V_wall / V_(brick+10mm mortar); Mortar = V_wall - N×V_brick",
                    steps = listOf(
                        "Net Area = ${UnitConverter.fmt(grossArea, p)} - ${UnitConverter.fmt(deductArea, p)} = ${UnitConverter.fmt(netArea, p)} m²",
                        "Wall Vol = ${UnitConverter.fmt(wallVol, p)} m³",
                        "Wet Mortar = ${UnitConverter.fmt(wetMortarVol, p)} m³; Dry Mortar (×1.33) = ${UnitConverter.fmt(dryMortarVol, p)} m³"
                    ),
                    assumptions = "10 mm mortar joint thickness; dry-to-wet mortar bulking factor = 1.33.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun blockWorkCalculator() = CalcToolSpec(
        id = "masonry_blocks",
        title = "AAC / Concrete Block Wall (All Types)",
        titleHi = "AAC / कंक्रीट ब्लॉक दीवार गणना",
        subtitle = "Straight, Cavity, Partition, Boundary & L-Shaped AAC / Hollow Block Walls",
        category = CalcCategory.MASONRY,
        typeFieldKey = "wallShape",
        keywords = listOf("aac", "block", "hollow", "concrete block", "masonry", "cavity", "boundary", "partition"),
        fields = listOf(
            CalcFieldSpec("wallShape", "Wall Type / Shape", "Straight Wall", options = listOf("Straight Wall", "Boundary Wall", "Cavity Wall (Double Leaf)", "Partition Wall", "L-Shaped Wall", "Curved / Circular Wall")),
            CalcFieldSpec("wallL", "Wall Length", "10.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["wallShape"] != "Curved / Circular Wall" }),
            CalcFieldSpec("wallL2", "Wing 2 Length (L2)", "5.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["wallShape"] == "L-Shaped Wall" }),
            CalcFieldSpec("dia", "Centerline Diameter (Ø)", "5.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["wallShape"] == "Curved / Circular Wall" }),
            CalcFieldSpec("wallH", "Wall Height", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("blockType", "Block Standard", "AAC Block (600×200×150 mm)", options = listOf(
                "AAC Block (600×200×150 mm)",
                "AAC Block (600×200×200 mm)",
                "Concrete / Hollow Block (400×200×200 mm)",
                "Concrete Block (400×200×150 mm)"
            )),
            CalcFieldSpec("deductArea", "Openings Deduction (m²)", "2.5", FieldUnitKind.AREA_SQ_M, allowZero = true),
            CalcFieldSpec("wastage", "Wastage (%)", "3", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val shape = ctx.raw("wallShape").ifBlank { "Straight Wall" }
            val wl1 = ctx.lengthMeters("wallL") ?: 10.0
            val wl2 = ctx.lengthMeters("wallL2") ?: 5.0
            val dia = ctx.lengthMeters("dia") ?: 5.0
            val wl = when (shape) {
                "L-Shaped Wall" -> wl1 + wl2 - 0.15
                "Curved / Circular Wall" -> kotlin.math.PI * dia
                else -> wl1
            }
            val wh = ctx.lengthMeters("wallH") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter wall height."))
            val deduct = ctx.doubleOrNull("deductArea") ?: 0.0
            val wastage = ctx.doubleOrNull("wastage") ?: 3.0
            if (wl <= 0 || wh <= 0 || deduct < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val mult = if (shape == "Cavity Wall (Double Leaf)") 2.0 else 1.0
            val netArea = ((wl * wh - deduct).coerceAtLeast(0.0)) * mult
            val isAac = ctx.raw("blockType").startsWith("AAC")
            val (blM, bhM, btM) = when (ctx.raw("blockType")) {
                "AAC Block (600×200×200 mm)" -> Triple(0.60, 0.20, 0.20)
                "Concrete / Hollow Block (400×200×200 mm)" -> Triple(0.40, 0.20, 0.20)
                "Concrete Block (400×200×150 mm)" -> Triple(0.40, 0.20, 0.15)
                else -> Triple(0.60, 0.20, 0.15)
            }
            val joint = if (isAac) 0.003 else 0.010 // 3mm polymer adhesive vs 10mm mortar
            val faceAreaWithJoint = (blM + joint) * (bhM + joint)
            val blocks = ceil((netArea / faceAreaWithJoint) * (1.0 + wastage / 100.0)).toLong()
            val volM3 = netArea * btM
            val adhesiveBags40kg = if (isAac) ceil(volM3 * 1.1) else 0.0 // ~1.1 bags/m³ for 150mm AAC
            val mortarCementBags = if (!isAac) (volM3 * 0.18 * 1.33 / 6.0) / 0.0347 else 0.0
            val cost = blocks * (if (isAac) 58.0 else 42.0)

            Result.success(
                CalcOutcome(
                    results = buildList {
                        add(CalcResultItem("Blocks Required", "$blocks", "Nos", isPrimary = true))
                        add(CalcResultItem("Net Wall Area", UnitConverter.fmt(netArea, p), "m²", isPrimary = true))
                        add(CalcResultItem("Wall Volume", UnitConverter.fmt(volM3, p), "m³"))
                        if (isAac) {
                            add(CalcResultItem("Block Adhesive (40 kg)", UnitConverter.fmt(adhesiveBags40kg, 0), "Bags"))
                        } else {
                            add(CalcResultItem("Mortar Cement (1:5 est.)", UnitConverter.fmt(mortarCementBags, p), "Bags"))
                        }
                        add(CalcResultItem("Est. Block Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", ""))
                    },
                    formula = "N_blocks = (Net Area / ((L_b + joint)×(H_b + joint))) × (1 + Wastage%)",
                    steps = listOf("Net Area = ${UnitConverter.fmt(netArea, p)} m²; Joint = ${joint * 1000} mm"),
                    assumptions = "AAC assumes 3 mm thin-bed polymer adhesive; Concrete blocks assume 10 mm cement mortar.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun plasterCalculator() = CalcToolSpec(
        id = "finish_plaster",
        title = "Plaster Estimator (Internal / External / Ceiling)",
        titleHi = "प्लास्टर और मसाला गणना",
        subtitle = "12mm Internal, 15/20mm External, 6mm Ceiling Plaster Cement & Sand",
        category = CalcCategory.FINISHING,
        keywords = listOf("plaster", "internal", "external", "ceiling", "mortar", "cement", "sand"),
        fields = listOf(
            CalcFieldSpec("type", "Plaster Type", "Internal Wall (12 mm)", options = listOf("Internal Wall (12 mm)", "External Wall (20 mm)", "Ceiling (6 mm)")),
            CalcFieldSpec("l", "Length", "10.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Height / Width", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("deduct", "Opening Deductions (m²)", "2.0", FieldUnitKind.AREA_SQ_M, allowZero = true),
            CalcFieldSpec("ratio", "Mortar Ratio", "1:4", options = listOf("1:3", "1:4", "1:5", "1:6"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height/width."))
            val deduct = ctx.doubleOrNull("deduct") ?: 0.0
            if (l <= 0 || h <= 0 || deduct < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val netArea = (l * h - deduct).coerceAtLeast(0.0)
            val thicknessM = when (ctx.raw("type")) {
                "External Wall (20 mm)" -> 0.020
                "Ceiling (6 mm)" -> 0.006
                else -> 0.012
            }
            // Add 20% unevenness/filling + 1.33 dry factor = ~1.60 combined multiplier on neat volume
            val wetVol = netArea * thicknessM * 1.20
            val dryVol = wetVol * 1.33
            val sandPart = ctx.raw("ratio").substringAfter(":").toDoubleOrNull() ?: 4.0
            val sumParts = 1.0 + sandPart
            val cementBags = (dryVol / sumParts) / 0.0347
            val sandCft = (dryVol * (sandPart / sumParts)) * UnitConverter.CU_FT_IN_CU_M
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Net Plaster Area", UnitConverter.fmt(netArea, p), "m²", isPrimary = true),
                        CalcResultItem("Cement Required", UnitConverter.fmt(cementBags, p), "Bags", isPrimary = true),
                        CalcResultItem("Plaster Sand", UnitConverter.fmt(sandCft, p), "CFT", isPrimary = true),
                        CalcResultItem("Dry Mortar Volume", UnitConverter.fmt(dryVol, p), "m³")
                    ),
                    formula = "V_dry = Area × Thickness × 1.20 (joints) × 1.33 (dry factor)",
                    steps = listOf("Net Area = ${UnitConverter.fmt(netArea, p)} m²; Dry Vol = ${UnitConverter.fmt(dryVol, p)} m³"),
                    assumptions = "Includes 20% allowance for masonry frog/joint filling + 1.33 dry mortar bulking factor."
                )
            )
        }
    )

    private fun paintPuttyPrimerCalculator() = CalcToolSpec(
        id = "finish_paint_putty",
        title = "Wall Putty, Primer & Paint Estimator",
        titleHi = "पुट्टी, प्राइमर और पेंट गणना",
        subtitle = "Multi-Coat Putty (kg), Primer (L) & Emulsion Paint (L)",
        category = CalcCategory.FINISHING,
        keywords = listOf("paint", "putty", "primer", "wall", "finishing", "emulsion"),
        fields = listOf(
            CalcFieldSpec("area", "Paintable Wall/Ceiling Area (sq.ft)", "1200", FieldUnitKind.NONE),
            CalcFieldSpec("deduct", "Door/Window Deduction (sq.ft)", "150", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("puttyCoats", "Wall Putty Coats", "2", FieldUnitKind.COUNT, allowZero = true),
            CalcFieldSpec("paintCoats", "Paint Coats", "2", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter area."))
            val deduct = ctx.doubleOrNull("deduct") ?: 0.0
            val puttyCoats = ctx.doubleOrNull("puttyCoats") ?: 2.0
            val paintCoats = ctx.doubleOrNull("paintCoats") ?: 2.0
            if (area <= 0 || deduct < 0 || paintCoats <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val netSqFt = (area - deduct).coerceAtLeast(0.0)
            // Standard Indian coverage: Putty ~14 sq.ft/kg (2 coats), Primer ~130 sq.ft/L (1 coat), Emulsion ~120 sq.ft/L per coat
            val puttyKg = if (puttyCoats > 0) (netSqFt / 28.0) * puttyCoats else 0.0
            val primerL = netSqFt / 130.0
            val paintL = (netSqFt / 120.0) * paintCoats
            val cost = puttyKg * (ctx.ratesByKeyword["putty"] ?: 28.0) +
                primerL * (ctx.ratesByKeyword["primer"] ?: 210.0) +
                paintL * (ctx.ratesByKeyword["paint"] ?: 320.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Net Paintable Area", UnitConverter.fmt(netSqFt, p), "sq.ft", isPrimary = true),
                        CalcResultItem("Emulsion Paint", UnitConverter.fmt(paintL, p), "Liters", isPrimary = true),
                        CalcResultItem("Wall Putty", UnitConverter.fmt(puttyKg, p), "kg", isPrimary = true),
                        CalcResultItem("Primer (1 Coat)", UnitConverter.fmt(primerL, p), "Liters"),
                        CalcResultItem("Est. Material Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "Putty = Area×Coats/28; Primer = Area/130; Paint = Area×Coats/120",
                    steps = listOf("Net Area = ${UnitConverter.fmt(netSqFt, p)} sq.ft"),
                    assumptions = "Typical coverage: Putty 14 sq.ft/kg (2 coats), Primer 130 sq.ft/L, Emulsion 120 sq.ft/L/coat.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun waterproofingCalculator() = CalcToolSpec(
        id = "finish_waterproofing",
        title = "Waterproofing Chemical Estimator",
        titleHi = "वॉटरप्रूफिंग गणना",
        subtitle = "Roof, Toilet Sunken Slab & Water Tank Coating",
        category = CalcCategory.FINISHING,
        keywords = listOf("waterproofing", "terrace", "roof", "bathroom", "chemical", "damp"),
        fields = listOf(
            CalcFieldSpec("l", "Length", "10.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Width", "8.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("system", "Coating System", "2-Coat Elastomeric Acrylic", options = listOf("2-Coat Elastomeric Acrylic", "2-Coat Polymer Cementitious", "Integral Liquid Admixture (Concrete)")),
            CalcFieldSpec("coats", "Number of Coats", "2", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val coats = ctx.doubleOrNull("coats") ?: 2.0
            if (l <= 0 || w <= 0 || coats <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid dimensions."))
            val areaM2 = l * w
            val sqFt = UnitConverter.sqMetersToArea(areaM2, AreaUnit.SQ_FT)
            val chemicalL = when (ctx.raw("system")) {
                "2-Coat Polymer Cementitious" -> areaM2 * 0.65 * coats
                "Integral Liquid Admixture (Concrete)" -> areaM2 * 0.25
                else -> areaM2 * 0.45 * coats // ~0.45 L/m²/coat
            }
            val cost = chemicalL * (ctx.ratesByKeyword["waterproof"] ?: 260.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Treatment Area", UnitConverter.fmt(areaM2, p), "m²", isPrimary = true),
                        CalcResultItem("Chemical Required", UnitConverter.fmt(chemicalL, p), "Liters / kg", isPrimary = true),
                        CalcResultItem("Area in Sq.ft", UnitConverter.fmt(sqFt, p), "sq.ft"),
                        CalcResultItem("Est. Material Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "Qty = Area × Coverage Consumption × Coats",
                    steps = listOf("Area = ${UnitConverter.fmt(areaM2, p)} m²"),
                    assumptions = "Elastomeric ~0.45 L/m²/coat; Polymer cementitious ~0.65 kg/m²/coat.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun tilesFlooringCalculator() = CalcToolSpec(
        id = "finish_tiles_flooring",
        title = "Tiles, Granite, Marble & Skirting",
        titleHi = "टाइल, ग्रेनाइट, मार्बल और स्कर्टिंग",
        subtitle = "Floor Area, Tile Count, Skirting RFT, Wastage & Bedding Mortar",
        category = CalcCategory.FINISHING,
        keywords = listOf("tile", "flooring", "granite", "marble", "skirting", "wastage"),
        fields = listOf(
            CalcFieldSpec("roomL", "Room Length", "5.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("roomW", "Room Width", "4.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("tileL", "Tile Length (mm)", "600", FieldUnitKind.NONE),
            CalcFieldSpec("tileW", "Tile Width (mm)", "600", FieldUnitKind.NONE),
            CalcFieldSpec("skirtingH", "Skirting Height (mm, 0 if none)", "100", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("wastage", "Cutting Wastage (%)", "7", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val rl = ctx.lengthMeters("roomL") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter room length."))
            val rw = ctx.lengthMeters("roomW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter room width."))
            val tl = (ctx.doubleOrNull("tileL") ?: 600.0) / 1000.0
            val tw = (ctx.doubleOrNull("tileW") ?: 600.0) / 1000.0
            val skH = (ctx.doubleOrNull("skirtingH") ?: 100.0) / 1000.0
            val wastage = ctx.doubleOrNull("wastage") ?: 7.0
            if (rl <= 0 || rw <= 0 || tl <= 0 || tw <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val floorArea = rl * rw
            val perimeter = 2.0 * (rl + rw)
            val skirtingArea = perimeter * skH
            val totalArea = floorArea + skirtingArea
            val netAreaWithWastage = totalArea * (1.0 + wastage / 100.0)
            val singleTileArea = tl * tw
            val tilesCount = ceil(netAreaWithWastage / singleTileArea).toLong()
            val sqFt = UnitConverter.sqMetersToArea(netAreaWithWastage, AreaUnit.SQ_FT)
            val cementBags = (floorArea * 0.040 * 1.33 / 5.0) / 0.0347 // 40mm 1:4 bedding screed
            val cost = sqFt * (ctx.ratesByKeyword["tile"] ?: 65.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Tiles Needed", "$tilesCount", "Tiles", isPrimary = true),
                        CalcResultItem("Total Area (w/ Wastage)", UnitConverter.fmt(sqFt, p), "sq.ft", isPrimary = true),
                        CalcResultItem("Skirting Run", UnitConverter.fmt(UnitConverter.fromMeters(perimeter, LengthUnit.FT), p), "RFT"),
                        CalcResultItem("Bedding Cement (40mm 1:4)", UnitConverter.fmt(cementBags, p), "Bags"),
                        CalcResultItem("Est. Material Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "N_tiles = ⌈((L×W + 2(L+W)×H_skirt) × (1+Wastage%)) / (t_L×t_W)⌉",
                    steps = listOf("Floor = ${UnitConverter.fmt(floorArea, p)} m², Skirting = ${UnitConverter.fmt(skirtingArea, p)} m²"),
                    assumptions = "Assumes 40 mm 1:4 cement mortar screed bedding.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun trimixEpoxyFlooringCalculator() = CalcToolSpec(
        id = "finish_trimix_epoxy",
        title = "Trimix (VDF) & Epoxy Industrial Flooring",
        titleHi = "ट्रिमिक्स और एपॉक्सी इंडस्ट्रियल फ्लोरिंग",
        subtitle = "Vacuum Dewatered Concrete, Floor Hardener & Epoxy Coats",
        category = CalcCategory.FINISHING,
        keywords = listOf("trimix", "vdf", "epoxy", "industrial", "flooring", "hardener"),
        fields = listOf(
            CalcFieldSpec("l", "Floor Length", "30.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Floor Width", "20.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("thick", "Trimix Concrete Thickness", "150", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("hardener", "Dry-Shake Hardener (kg/m²)", "4.0", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("epoxyCoats", "Epoxy Top Coats (0 if Trimix only)", "2", FieldUnitKind.COUNT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val t = ctx.lengthMeters("thick") ?: 0.15
            val hardenerRate = ctx.doubleOrNull("hardener") ?: 4.0
            val epoxyCoats = ctx.doubleOrNull("epoxyCoats") ?: 2.0
            if (l <= 0 || w <= 0 || t <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val areaM2 = l * w
            val sqFt = UnitConverter.sqMetersToArea(areaM2, AreaUnit.SQ_FT)
            val concM3 = areaM2 * t
            val hardenerKg = areaM2 * hardenerRate
            val epoxyKg = areaM2 * 0.25 * epoxyCoats // ~0.25 kg/m²/coat
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Floor Area", "${UnitConverter.fmt(areaM2, p)} m² (${UnitConverter.fmt(sqFt, 0)} sq.ft)", "", isPrimary = true),
                        CalcResultItem("Trimix Concrete Volume", UnitConverter.fmt(concM3, p), "m³", isPrimary = true),
                        CalcResultItem("Metallic/Non-Metallic Hardener", UnitConverter.fmt(hardenerKg, p), "kg"),
                        CalcResultItem("Epoxy Resin (if applied)", UnitConverter.fmt(epoxyKg, p), "kg")
                    ),
                    formula = "Area = L×W; Concrete = Area×t; Hardener = Area×Rate",
                    steps = listOf("Area = ${UnitConverter.fmt(areaM2, p)} m²; Concrete = ${UnitConverter.fmt(concM3, p)} m³"),
                    assumptions = "Epoxy consumption ~0.25 kg/m² per coat; control joint saw-cuts every 4×4 m panel."
                )
            )
        }
    )
}

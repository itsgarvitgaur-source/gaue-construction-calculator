package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.sqrt

/** Phase H: detailed earthwork quantity estimators. */
object PhaseHEarthworkCalculators {
    private fun dim(key: String, label: String, value: String = "10") =
        CalcFieldSpec(key, label, value, FieldUnitKind.LENGTH, LengthUnit.M)
    private fun pct(key: String, label: String, value: String = "10") =
        CalcFieldSpec(key, label, value, FieldUnitKind.PERCENT)
    private fun tool(id: String, title: String, subtitle: String, fields: List<CalcFieldSpec>, keywords: List<String>, calc: (CalcContext) -> Result<CalcOutcome>) =
        CalcToolSpec(id, title, title, subtitle, CalcCategory.EARTHWORK, keywords, fields = fields, compute = calc)
    private fun fmt(v: Double, p: Int) = UnitConverter.fmt(v, p)

    fun all(): List<CalcToolSpec> = listOf(
        tool("phase_h_average_end_area", "Average End Area Earthwork", "Volume between two cross-sections", listOf(CalcFieldSpec("a1","Section 1 area","20",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("a2","Section 2 area","28",FieldUnitKind.AREA_SQ_M),dim("l","Distance between sections","20")), listOf("average end area","cross section","earthwork volume")) { c ->
            val a1=c.doubleOrNull("a1")?:0.0; val a2=c.doubleOrNull("a2")?:0.0; val l=c.lengthMeters("l")?:0.0; val p=c.settings.decimalPrecision
            if(a1<=0||a2<=0||l<=0) return@tool Result.failure(IllegalArgumentException("Areas and distance must be positive."))
            val v=(a1+a2)*0.5*l
            Result.success(CalcOutcome(listOf(CalcResultItem("Earthwork volume",fmt(v,p),"m³",true),CalcResultItem("Mean section area",fmt((a1+a2)/2,p),"m²")),"V = (A1 + A2) / 2 × L",listOf("Mean area = (${fmt(a1,p)} + ${fmt(a2,p)}) / 2","Volume = mean area × ${fmt(l,p)} m = ${fmt(v,p)} m³"),"Average end area method; assumes linear change between adjacent sections."))
        },
        tool("phase_h_prismoidal_volume", "Prismoidal Earthwork Volume", "End areas with mid-section correction", listOf(CalcFieldSpec("a1","First end area","20",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("am","Mid-section area","24",FieldUnitKind.AREA_SQ_M),CalcFieldSpec("a2","Second end area","28",FieldUnitKind.AREA_SQ_M),dim("l","Section interval","20")), listOf("prismoidal","earthwork","volume")) { c ->
            val a1=c.doubleOrNull("a1")?:0.0; val am=c.doubleOrNull("am")?:0.0; val a2=c.doubleOrNull("a2")?:0.0; val l=c.lengthMeters("l")?:0.0; val p=c.settings.decimalPrecision
            if(listOf(a1,am,a2,l).any{it<=0}) return@tool Result.failure(IllegalArgumentException("All areas and interval must be positive."))
            val v=l/6*(a1+4*am+a2)
            Result.success(CalcOutcome(listOf(CalcResultItem("Prismoidal volume",fmt(v,p),"m³",true),CalcResultItem("Equivalent average area",fmt(v/l,p),"m²")),"V = L/6 × (A1 + 4Am + A2)",listOf("V = ${fmt(l,p)}/6 × (${fmt(a1,p)} + 4×${fmt(am,p)} + ${fmt(a2,p)})"),"Mid-section area must represent the section halfway between the end sections."))
        },
        tool("phase_h_swell_shrink", "Soil Swell & Shrinkage Converter", "Convert bank, loose and compacted volumes", listOf(CalcFieldSpec("v","Reference volume","100",FieldUnitKind.VOLUME_CU_M),pct("swell","Swell from bank to loose","25"),pct("shrink","Shrink from bank to compacted","10")), listOf("swell","shrinkage","bank volume","loose volume","compacted soil")) { c ->
            val v=c.doubleOrNull("v")?:0.0; val s=c.doubleOrNull("swell")?:0.0; val r=c.doubleOrNull("shrink")?:0.0; val p=c.settings.decimalPrecision
            if(v<=0||s<0||r<0||r>=100) return@tool Result.failure(IllegalArgumentException("Volume must be positive; swell non-negative and shrinkage below 100%."))
            val loose=v*(1+s/100); val compact=v*(1-r/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Bank volume",fmt(v,p),"m³",true),CalcResultItem("Loose volume",fmt(loose,p),"m³"),CalcResultItem("Compacted volume",fmt(compact,p),"m³")),"Loose = Bank×(1+swell%); Compacted = Bank×(1−shrink%)",listOf("Loose expansion = ${fmt(s,p)}%","Compaction reduction = ${fmt(r,p)}%"),"Percentages are user-supplied project factors; confirm with soil tests and specifications."))
        },
        tool("phase_h_embankment_layers", "Embankment Layer Quantity Planner", "Layer count and compacted fill volume", listOf(dim("l","Embankment length","100"),dim("w","Top width","8"),dim("h","Total compacted height","2"),dim("t","Compacted layer thickness","0.2"),pct("extra","Extra allowance","5")), listOf("embankment","layers","fill","compacted")) { c ->
            val l=c.lengthMeters("l")?:0.0; val w=c.lengthMeters("w")?:0.0; val h=c.lengthMeters("h")?:0.0; val t=c.lengthMeters("t")?:0.0; val e=c.doubleOrNull("extra")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||w<=0||h<=0||t<=0||e<0) return@tool Result.failure(IllegalArgumentException("Dimensions must be positive and allowance non-negative."))
            val n=kotlin.math.ceil(h/t).toInt(); val v=l*w*h; val req=v*(1+e/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Compacted fill volume",fmt(v,p),"m³",true),CalcResultItem("Number of layers",n.toString(),"layers"),CalcResultItem("Average final layer thickness",fmt(h/n,p),"m"),CalcResultItem("Volume incl. allowance",fmt(req,p),"m³")),"V=L×W×H; layers=ceil(H/t)",listOf("Layer count = ceil(${fmt(h,p)}/${fmt(t,p)}) = $n"),"Rectangular prism approximation; side slopes and settlement are not included."))
        },
        tool("phase_h_trench_bedding_backfill", "Trench Bedding & Backfill", "Pipe trench excavation, bedding and net backfill", listOf(dim("l","Trench length","30"),dim("w","Trench width","0.8"),dim("d","Trench depth","1.2"),dim("od","Pipe outside diameter","0.3"),dim("bed","Bedding thickness","0.15")), listOf("trench","bedding","pipe backfill","excavation")) { c ->
            val l=c.lengthMeters("l")?:0.0; val w=c.lengthMeters("w")?:0.0; val d=c.lengthMeters("d")?:0.0; val od=c.lengthMeters("od")?:0.0; val b=c.lengthMeters("bed")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||w<=0||d<=0||od<=0||b<0||od>w||b>d) return@tool Result.failure(IllegalArgumentException("Check dimensions; pipe must fit trench and bedding cannot exceed depth."))
            val ex=l*w*d; val bed=l*w*b; val pipe=PI*od*od/4*l; val back=(ex-bed-pipe).coerceAtLeast(0.0)
            Result.success(CalcOutcome(listOf(CalcResultItem("Excavation",fmt(ex,p),"m³",true),CalcResultItem("Bedding",fmt(bed,p),"m³"),CalcResultItem("Pipe displacement",fmt(pipe,p),"m³"),CalcResultItem("Net backfill",fmt(back,p),"m³")),"Excavation=LWD; bedding=LWB; backfill=excavation−bedding−pipe displacement",listOf("Pipe displacement assumes a full circular outside diameter."),"No working space, haunching profile, compaction factor or unsuitable soil deduction included."))
        },
        tool("phase_h_stockpile_cone", "Conical Soil Stockpile Volume", "Estimate stockpile volume from base radius and height", listOf(dim("r","Base radius","5"),dim("h","Stockpile height","3")), listOf("stockpile","cone","soil heap","volume")) { c ->
            val r=c.lengthMeters("r")?:0.0; val h=c.lengthMeters("h")?:0.0; val p=c.settings.decimalPrecision
            if(r<=0||h<=0) return@tool Result.failure(IllegalArgumentException("Radius and height must be positive."))
            val v=PI*r*r*h/3; val a=PI*r*r
            Result.success(CalcOutcome(listOf(CalcResultItem("Estimated volume",fmt(v,p),"m³",true),CalcResultItem("Base area",fmt(a,p),"m²"),CalcResultItem("Slant height",fmt(sqrt(r*r+h*h),p),"m")),"V = πr²h/3",listOf("V = π×${fmt(r,p)}²×${fmt(h,p)}/3"),"Assumes an ideal right circular cone; real stockpiles may be irregular."))
        },
        tool("phase_h_haul_quantity", "Earthwork Haul & Truck Planner", "Truck trips and haul quantity with loose volume", listOf(CalcFieldSpec("v","Bank excavation volume","250",FieldUnitKind.VOLUME_CU_M),pct("swell","Swell allowance","20"),CalcFieldSpec("cap","Truck loose capacity","10",FieldUnitKind.VOLUME_CU_M)), listOf("haul","truck trips","soil transport","truck capacity")) { c ->
            val v=c.doubleOrNull("v")?:0.0; val s=c.doubleOrNull("swell")?:0.0; val cap=c.doubleOrNull("cap")?:0.0; val p=c.settings.decimalPrecision
            if(v<=0||s<0||cap<=0) return@tool Result.failure(IllegalArgumentException("Volume and truck capacity must be positive; swell cannot be negative."))
            val loose=v*(1+s/100); val trips=kotlin.math.ceil(loose/cap).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Loose haul volume",fmt(loose,p),"m³",true),CalcResultItem("Truck trips",trips.toString(),"trips"),CalcResultItem("Nominal capacity",fmt(cap,p),"m³/trip"),CalcResultItem("Average load per trip",fmt(loose/trips,p),"m³")),"Loose volume=bank volume×(1+swell%); trips=ceil(loose/capacity)",listOf("Trips rounded up to the next whole truck."),"Assumes each truck can carry its stated loose-volume capacity; legal payload and route restrictions must be checked."))
        },
        tool("phase_h_batter_slope_cut", "Cut Slope Batter Geometry", "Top width and cross-section area for side slopes", listOf(dim("b","Formation/base width","6"),dim("d","Cut depth","2"),CalcFieldSpec("z","Side slope H:V (each side)","1",FieldUnitKind.NONE)), listOf("batter","side slope","cut slope","trapezoid")) { c ->
            val b=c.lengthMeters("b")?:0.0; val d=c.lengthMeters("d")?:0.0; val z=c.doubleOrNull("z")?:0.0; val p=c.settings.decimalPrecision
            if(b<=0||d<=0||z<0) return@tool Result.failure(IllegalArgumentException("Base width and depth must be positive; slope ratio cannot be negative."))
            val top=b+2*z*d; val a=(b+top)*d/2
            Result.success(CalcOutcome(listOf(CalcResultItem("Top width",fmt(top,p),"m",true),CalcResultItem("Cross-section area",fmt(a,p),"m²"),CalcResultItem("One-side horizontal run",fmt(z*d,p),"m"),CalcResultItem("Slope face length",fmt(d*sqrt(1+z*z),p),"m")),"Top width=b+2zD; A=(b+top)D/2",listOf("Side slope = ${fmt(z,p)}H:1V"),"Symmetrical straight side slopes assumed; check geotechnical stability separately."))
        },
        tool("phase_h_circular_shaft_excavation", "Circular Shaft Excavation with Working Space", "Shaft excavation volume and disposal estimate", listOf(dim("dia","Shaft clear diameter","1.2"),dim("d","Excavation depth","4"),dim("ws","Working space per side","0.15"),pct("swell","Swell allowance","20")), listOf("shaft","circular excavation","well","working space")) { c ->
            val dia=c.lengthMeters("dia")?:0.0; val d=c.lengthMeters("d")?:0.0; val ws=c.lengthMeters("ws")?:0.0; val s=c.doubleOrNull("swell")?:0.0; val p=c.settings.decimalPrecision
            if(dia<=0||d<=0||ws<0||s<0) return@tool Result.failure(IllegalArgumentException("Diameter and depth must be positive; allowances non-negative."))
            val exDia=dia+2*ws; val v=PI*exDia*exDia/4*d; val loose=v*(1+s/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Excavation diameter",fmt(exDia,p),"m",true),CalcResultItem("Bank excavation volume",fmt(v,p),"m³"),CalcResultItem("Loose disposal volume",fmt(loose,p),"m³")),"V=π(D+2ws)²/4×depth",listOf("Working space added to both sides of clear diameter."),"Vertical cylindrical shaft assumed; shoring thickness and bottom sump excluded."))
        },
        tool("phase_h_roadway_earthwork", "Roadway Formation Earthwork", "Prismoidal trapezoidal section volume over road length", listOf(dim("l","Road length","500"),dim("b","Formation width","7"),dim("h","Average fill/cut depth","0.5"),CalcFieldSpec("z","Side slope H:V","1.5",FieldUnitKind.NONE)), listOf("road formation","road earthwork","embankment volume","trapezoid")) { c ->
            val l=c.lengthMeters("l")?:0.0; val b=c.lengthMeters("b")?:0.0; val h=c.lengthMeters("h")?:0.0; val z=c.doubleOrNull("z")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||b<=0||h<=0||z<0) return@tool Result.failure(IllegalArgumentException("Length, width and depth must be positive; slope cannot be negative."))
            val a=b*h+z*h*h; val v=a*l
            Result.success(CalcOutcome(listOf(CalcResultItem("Cross-section area",fmt(a,p),"m²",true),CalcResultItem("Earthwork volume",fmt(v,p),"m³"),CalcResultItem("Top width",fmt(b+2*z*h,p),"m")),"A=bh+zh²; V=A×L",listOf("Symmetrical side slopes ${fmt(z,p)}H:1V"),"Constant average depth and formation width assumed; use chainage sections for varying terrain."))
        }
    )
}

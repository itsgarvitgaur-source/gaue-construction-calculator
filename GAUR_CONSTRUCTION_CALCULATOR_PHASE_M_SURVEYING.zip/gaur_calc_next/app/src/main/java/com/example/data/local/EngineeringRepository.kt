package com.example.data.local

import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class EngineeringRepository(private val db: AppDatabase) {

    val projects: Flow<List<ProjectEntity>> = db.projectDao().observeAll()
    val history: Flow<List<CalculationHistoryEntity>> = db.historyDao().observeAll()
    val toolUsage: Flow<List<FavoriteToolEntity>> = db.favoriteToolDao().observeAll()
    val boqEstimates: Flow<List<BoqEstimateEntity>> = db.boqDao().observeAll()
    val bbsSchedules: Flow<List<BbsScheduleEntity>> = db.bbsDao().observeAll()
    val materialRates: Flow<List<MaterialRateEntity>> = db.materialRateDao().observeAll()
    val drawings2D: Flow<List<StudioDrawingEntity>> = db.studioDrawingDao().observeAll()
    val models3D: Flow<List<StudioModel3DEntity>> = db.studioModel3DDao().observeAll()
    val securityEvents: Flow<List<SecurityEventEntity>> = db.securityEventDao().observeRecent()

    fun observeProject(id: Long): Flow<ProjectEntity?> = db.projectDao().observeById(id)
    fun observeProjectHistory(projectId: Long): Flow<List<CalculationHistoryEntity>> =
        db.historyDao().observeForProject(projectId)
    fun observeProjectBoqs(projectId: Long): Flow<List<BoqEstimateEntity>> =
        db.boqDao().observeForProject(projectId)
    fun observeProjectBbs(projectId: Long): Flow<List<BbsScheduleEntity>> =
        db.bbsDao().observeForProject(projectId)
    fun observeProjectDrawings(projectId: Long): Flow<List<StudioDrawingEntity>> =
        db.studioDrawingDao().observeForProject(projectId)
    fun observeProjectModels3D(projectId: Long): Flow<List<StudioModel3DEntity>> =
        db.studioModel3DDao().observeForProject(projectId)

    suspend fun ensureDefaultRatesSeeded() {
        if (db.materialRateDao().count() == 0) {
            db.materialRateDao().insertAll(defaultMaterialRates())
        }
    }

    suspend fun saveProject(project: ProjectEntity): Long {
        val now = System.currentTimeMillis()
        return db.projectDao().insert(
            project.copy(
                createdAt = if (project.id == 0L) now else project.createdAt,
                updatedAt = now
            )
        )
    }

    suspend fun duplicateProject(project: ProjectEntity): Long {
        val now = System.currentTimeMillis()
        return db.projectDao().insert(
            project.copy(
                id = 0,
                name = "${project.name} (Copy)",
                createdAt = now,
                updatedAt = now
            )
        )
    }

    suspend fun deleteProject(project: ProjectEntity) = db.projectDao().delete(project)

    suspend fun saveCalculation(entry: CalculationHistoryEntity): Long = db.historyDao().insert(entry)
    suspend fun deleteHistory(id: Long) = db.historyDao().deleteById(id)
    suspend fun clearHistory() = db.historyDao().clearAll()

    suspend fun recordToolUsage(toolId: String) {
        val existing = db.favoriteToolDao().getById(toolId)
        val now = System.currentTimeMillis()
        db.favoriteToolDao().upsert(
            FavoriteToolEntity(
                toolId = toolId,
                isFavorite = existing?.isFavorite ?: false,
                lastUsedAt = now,
                useCount = (existing?.useCount ?: 0) + 1
            )
        )
    }

    suspend fun toggleFavorite(toolId: String) {
        val existing = db.favoriteToolDao().getById(toolId)
        db.favoriteToolDao().upsert(
            FavoriteToolEntity(
                toolId = toolId,
                isFavorite = !(existing?.isFavorite ?: false),
                lastUsedAt = existing?.lastUsedAt ?: 0L,
                useCount = existing?.useCount ?: 0
            )
        )
    }

    suspend fun saveBoq(estimate: BoqEstimateEntity): Long = db.boqDao().insert(
        estimate.copy(updatedAt = System.currentTimeMillis())
    )
    suspend fun deleteBoq(id: Long) = db.boqDao().deleteById(id)

    suspend fun saveBbs(schedule: BbsScheduleEntity): Long = db.bbsDao().insert(
        schedule.copy(updatedAt = System.currentTimeMillis())
    )
    suspend fun deleteBbs(id: Long) = db.bbsDao().deleteById(id)

    suspend fun saveMaterialRate(rate: MaterialRateEntity): Long = db.materialRateDao().insert(rate)
    suspend fun deleteMaterialRate(id: Long) = db.materialRateDao().deleteById(id)
    suspend fun resetDefaultRates() {
        db.materialRateDao().clearAll()
        db.materialRateDao().insertAll(defaultMaterialRates())
    }

    suspend fun saveDrawing2D(drawing: StudioDrawingEntity): Long = db.studioDrawingDao().insert(
        drawing.copy(updatedAt = System.currentTimeMillis())
    )
    suspend fun deleteDrawing2D(id: Long) = db.studioDrawingDao().deleteById(id)

    suspend fun saveModel3D(model: StudioModel3DEntity): Long = db.studioModel3DDao().insert(
        model.copy(updatedAt = System.currentTimeMillis())
    )
    suspend fun deleteModel3D(id: Long) = db.studioModel3DDao().deleteById(id)

    suspend fun logSecurityEvent(type: String, severity: String, title: String, details: String) {
        db.securityEventDao().insert(
            SecurityEventEntity(
                eventType = type,
                severity = severity,
                title = title,
                details = details
            )
        )
    }

    suspend fun clearSecurityEvents() = db.securityEventDao().clearAll()

    suspend fun exportFullBackupJson(): String {
        val root = JSONObject()
        root.put("app", "Gaur Construction Calculator")
        root.put("schemaVersion", 1)
        root.put("exportedAt", System.currentTimeMillis())

        val projectsArr = JSONArray()
        db.projectDao().getAllOnce().forEach { p ->
            projectsArr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("clientName", p.clientName)
                put("siteLocation", p.siteLocation)
                put("projectType", p.projectType)
                put("startDate", p.startDate)
                put("status", p.status)
                put("notes", p.notes)
                put("attachedDocsJson", p.attachedDocsJson)
                put("createdAt", p.createdAt)
                put("updatedAt", p.updatedAt)
            })
        }
        root.put("projects", projectsArr)

        val historyArr = JSONArray()
        db.historyDao().getAllOnce().forEach { h ->
            historyArr.put(JSONObject().apply {
                put("id", h.id)
                put("projectId", h.projectId ?: JSONObject.NULL)
                put("toolId", h.toolId)
                put("toolName", h.toolName)
                put("category", h.category)
                put("customName", h.customName)
                put("isTemplate", h.isTemplate)
                put("inputsJson", h.inputsJson)
                put("resultsJson", h.resultsJson)
                put("formula", h.formula)
                put("stepsJson", h.stepsJson)
                put("assumptions", h.assumptions)
                put("totalCost", h.totalCost ?: JSONObject.NULL)
                put("timestamp", h.timestamp)
            })
        }
        root.put("history", historyArr)

        val boqArr = JSONArray()
        db.boqDao().getAllOnce().forEach { b ->
            boqArr.put(JSONObject().apply {
                put("id", b.id)
                put("projectId", b.projectId ?: JSONObject.NULL)
                put("title", b.title)
                put("clientName", b.clientName)
                put("siteLocation", b.siteLocation)
                put("description", b.description)
                put("templateType", b.templateType)
                put("gstPercent", b.gstPercent)
                put("itemsJson", b.itemsJson)
                put("createdAt", b.createdAt)
                put("updatedAt", b.updatedAt)
            })
        }
        root.put("boqs", boqArr)

        val bbsArr = JSONArray()
        db.bbsDao().getAllOnce().forEach { s ->
            bbsArr.put(JSONObject().apply {
                put("id", s.id)
                put("projectId", s.projectId ?: JSONObject.NULL)
                put("title", s.title)
                put("memberType", s.memberType)
                put("itemsJson", s.itemsJson)
                put("totalWeightKg", s.totalWeightKg)
                put("createdAt", s.createdAt)
                put("updatedAt", s.updatedAt)
            })
        }
        root.put("bbsSchedules", bbsArr)

        val ratesArr = JSONArray()
        db.materialRateDao().getAllOnce().forEach { r ->
            ratesArr.put(JSONObject().apply {
                put("name", r.name)
                put("category", r.category)
                put("unit", r.unit)
                put("materialRate", r.materialRate)
                put("labourRate", r.labourRate)
                put("isCustom", r.isCustom)
            })
        }
        root.put("rates", ratesArr)

        val drawingsArr = JSONArray()
        db.studioDrawingDao().getAllOnce().forEach { d ->
            drawingsArr.put(JSONObject().apply {
                put("title", d.title)
                put("drawingType", d.drawingType)
                put("scaleRatio", d.scaleRatio)
                put("unitLabel", d.unitLabel)
                put("blueprintMode", d.blueprintMode)
                put("elementsJson", d.elementsJson)
                put("createdAt", d.createdAt)
                put("updatedAt", d.updatedAt)
            })
        }
        root.put("drawings2D", drawingsArr)

        val modelsArr = JSONArray()
        db.studioModel3DDao().getAllOnce().forEach { m ->
            modelsArr.put(JSONObject().apply {
                put("title", m.title)
                put("objectsJson", m.objectsJson)
                put("cameraYaw", m.cameraYaw.toDouble())
                put("cameraPitch", m.cameraPitch.toDouble())
                put("isPerspective", m.isPerspective)
                put("createdAt", m.createdAt)
                put("updatedAt", m.updatedAt)
            })
        }
        root.put("models3D", modelsArr)

        return root.toString(2)
    }

    suspend fun importBackupJson(rawJson: String): Result<Int> = runCatching {
        val root = JSONObject(rawJson)
        var restoredCount = 0

        root.optJSONArray("projects")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.projectDao().insert(
                    ProjectEntity(
                        name = o.optString("name", "Imported Project"),
                        clientName = o.optString("clientName", ""),
                        siteLocation = o.optString("siteLocation", ""),
                        projectType = o.optString("projectType", "Residential"),
                        startDate = o.optString("startDate", ""),
                        status = o.optString("status", "Planning"),
                        notes = o.optString("notes", ""),
                        attachedDocsJson = o.optString("attachedDocsJson", "[]"),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
                restoredCount++
            }
        }
        root.optJSONArray("history")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.historyDao().insert(
                    CalculationHistoryEntity(
                        toolId = o.optString("toolId", "imported"),
                        toolName = o.optString("toolName", "Imported Calculation"),
                        category = o.optString("category", "General"),
                        customName = o.optString("customName", ""),
                        isTemplate = o.optBoolean("isTemplate", false),
                        inputsJson = o.optString("inputsJson", "[]"),
                        resultsJson = o.optString("resultsJson", "[]"),
                        formula = o.optString("formula", ""),
                        stepsJson = o.optString("stepsJson", "[]"),
                        assumptions = o.optString("assumptions", ""),
                        totalCost = if (o.isNull("totalCost")) null else o.optDouble("totalCost"),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis())
                    )
                )
                restoredCount++
            }
        }
        root.optJSONArray("boqs")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.boqDao().insert(
                    BoqEstimateEntity(
                        title = o.optString("title", "Imported BOQ"),
                        clientName = o.optString("clientName", ""),
                        siteLocation = o.optString("siteLocation", ""),
                        description = o.optString("description", ""),
                        templateType = o.optString("templateType", "Residential"),
                        gstPercent = o.optDouble("gstPercent", 18.0),
                        itemsJson = o.optString("itemsJson", "[]")
                    )
                )
                restoredCount++
            }
        }
        root.optJSONArray("bbsSchedules")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.bbsDao().insert(
                    BbsScheduleEntity(
                        title = o.optString("title", "Imported BBS"),
                        memberType = o.optString("memberType", "Beam"),
                        itemsJson = o.optString("itemsJson", "[]"),
                        totalWeightKg = o.optDouble("totalWeightKg", 0.0)
                    )
                )
                restoredCount++
            }
        }
        root.optJSONArray("drawings2D")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.studioDrawingDao().insert(
                    StudioDrawingEntity(
                        title = o.optString("title", "Imported Drawing"),
                        drawingType = o.optString("drawingType", "Floor Plan"),
                        scaleRatio = o.optInt("scaleRatio", 100),
                        unitLabel = o.optString("unitLabel", "m"),
                        blueprintMode = o.optBoolean("blueprintMode", true),
                        elementsJson = o.optString("elementsJson", "[]")
                    )
                )
                restoredCount++
            }
        }
        root.optJSONArray("models3D")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                db.studioModel3DDao().insert(
                    StudioModel3DEntity(
                        title = o.optString("title", "Imported 3D Model"),
                        objectsJson = o.optString("objectsJson", "[]"),
                        cameraYaw = o.optDouble("cameraYaw", 40.0).toFloat(),
                        cameraPitch = o.optDouble("cameraPitch", 28.0).toFloat(),
                        isPerspective = o.optBoolean("isPerspective", true)
                    )
                )
                restoredCount++
            }
        }
        restoredCount
    }

    companion object {
        fun defaultMaterialRates(): List<MaterialRateEntity> = listOf(
            MaterialRateEntity(name = "OPC/PPC Cement (50 kg bag)", category = "Concrete & Masonry", unit = "Bag", materialRate = 390.0, labourRate = 25.0),
            MaterialRateEntity(name = "River / M-Sand", category = "Concrete & Masonry", unit = "CFT", materialRate = 62.0, labourRate = 8.0),
            MaterialRateEntity(name = "Crushed Aggregate (20mm)", category = "Concrete & Masonry", unit = "CFT", materialRate = 48.0, labourRate = 8.0),
            MaterialRateEntity(name = "Ready-Mix Concrete (M20)", category = "Concrete & Masonry", unit = "m³", materialRate = 5400.0, labourRate = 450.0),
            MaterialRateEntity(name = "TMT Steel Rebar (Fe500D)", category = "Steel & PEB", unit = "kg", materialRate = 68.0, labourRate = 12.0),
            MaterialRateEntity(name = "Structural PEB Steel", category = "Steel & PEB", unit = "kg", materialRate = 92.0, labourRate = 24.0),
            MaterialRateEntity(name = "Red Clay / Modular Bricks", category = "Masonry", unit = "Nos", materialRate = 8.5, labourRate = 4.0),
            MaterialRateEntity(name = "AAC Blocks (600x200x150)", category = "Masonry", unit = "Nos", materialRate = 58.0, labourRate = 14.0),
            MaterialRateEntity(name = "Solid Concrete Blocks", category = "Masonry", unit = "Nos", materialRate = 42.0, labourRate = 12.0),
            MaterialRateEntity(name = "Vitrified Floor Tiles", category = "Finishing", unit = "sq.ft", materialRate = 65.0, labourRate = 28.0),
            MaterialRateEntity(name = "Granite / Marble Slab", category = "Finishing", unit = "sq.ft", materialRate = 145.0, labourRate = 55.0),
            MaterialRateEntity(name = "Interior Emulsion Paint", category = "Finishing", unit = "Liter", materialRate = 320.0, labourRate = 110.0),
            MaterialRateEntity(name = "Exterior Primer", category = "Finishing", unit = "Liter", materialRate = 210.0, labourRate = 60.0),
            MaterialRateEntity(name = "Wall Putty (White Cement)", category = "Finishing", unit = "kg", materialRate = 28.0, labourRate = 12.0),
            MaterialRateEntity(name = "Waterproofing Compound", category = "Finishing", unit = "Liter", materialRate = 260.0, labourRate = 85.0),
            MaterialRateEntity(name = "PPGI Roofing Sheet (0.5mm)", category = "Steel & PEB", unit = "sq.ft", materialRate = 52.0, labourRate = 15.0),
            MaterialRateEntity(name = "uPVC Plumbing Pipe (110mm)", category = "MEP", unit = "RFT", materialRate = 95.0, labourRate = 30.0),
            MaterialRateEntity(name = "Electrical Conduit (25mm)", category = "MEP", unit = "RFT", materialRate = 18.0, labourRate = 12.0)
        )
    }
}

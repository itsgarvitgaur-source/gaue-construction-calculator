package com.example.features.knowledge

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette

data class CivilKnowledgeArticle(
    val id: String,
    val topic: String,
    val titleEn: String,
    val titleHi: String,
    val standardRef: String,
    val summaryEn: String,
    val summaryHi: String,
    val stepsEn: List<String>,
    val commonMistakeEn: String
)

data class QuizQuestion(
    val id: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

object CivilKnowledgeCatalog {
    val topics = listOf("All", "RCC & Concrete", "Foundations", "Bridge Engg", "High-Rise", "PEB & Steel", "Roads & Infra", "Site QC & Safety")

    val articles: List<CivilKnowledgeArticle> = listOf(
        CivilKnowledgeArticle(
            id = "k_rcc_cover",
            topic = "RCC & Concrete",
            titleEn = "Clear Cover, Slump & 28-Day Curing Rules",
            titleHi = "क्लियर कवर, स्लम्प और तराई (Curing) के नियम",
            standardRef = "IS 456:2000",
            summaryEn = "Clear cover protects rebar from corrosion and fire. Minimum cover depends on exposure and member type: Footings 50mm, Columns 40mm, Beams 25mm, Slabs 20mm.",
            summaryHi = "क्लियर कवर सरिया को जंग और आग से बचाता है: फुटिंग 50mm, कॉलम 40mm, बीम 25mm, स्लैब 20mm। कम से कम 7–14 दिन लगातार तराई जरूरी है।",
            stepsEn = listOf(
                "Use factory-made cover blocks of matching mortar/concrete grade, never broken brick or stone.",
                "Verify Water-Cement (W/C) ratio ≤ 0.45–0.50 with slump 75–100mm for pumped or beam/column pours.",
                "Cast 150×150×150 mm test cubes: 3 cubes for 7-day check (~65% fck) and 3 cubes for 28-day strength."
            ),
            commonMistakeEn = "Adding extra water at site to make concrete runny drops compressive strength by 15–25% and causes honeycombing."
        ),
        CivilKnowledgeArticle(
            id = "k_foundation_soil",
            topic = "Foundations",
            titleEn = "Soil Bearing Capacity (SBC) & Footing Selection",
            titleHi = "मिट्टी की भार क्षमता (SBC) और नींव (Footing) का चयन",
            standardRef = "IS 6403 / IS 2911",
            summaryEn = "Footing type depends on column loads and soil SBC. Isolated footings suit hard soil with light-to-medium loads; combined/raft footings control differential settlement on weak clay; piles transfer loads to deep hard strata.",
            summaryHi = "कठोर मिट्टी में आइसोलेटेड/स्लोप्ड फुटिंग, कमजोर मिट्टी में राफ्ट फाउंडेशन और गहरी नरम परत में पाइल फाउंडेशन का उपयोग किया जाता है।",
            stepsEn = listOf(
                "Excavate down to virgin undisturbed stratum below organic topsoil, then lay 75–100mm PCC M10 leveling bed.",
                "Verify excavation pit diagonal (3-4-5 rule) and check anti-termite chemical barrier along bottom & sides.",
                "Maintain minimum 50mm cover around footing bottom mat and turn starter bars with 90° L-bend into pedestal."
            ),
            commonMistakeEn = "Placing footings on uncompacted loose fill without PCC leveling causes uneven settlement and wall cracks."
        ),
        CivilKnowledgeArticle(
            id = "k_bridge_components",
            topic = "Bridge Engg",
            titleEn = "Bridge Substructure: Piers, Abutments, Bearings & Deck Slab",
            titleHi = "ब्रिज इंजीनियरिंग: पियर, एबटमेंट, बेयरिंग और डेक स्लैब",
            standardRef = "IRC:6 / IRC:112 / IRC:78",
            summaryEn = "A highway or river bridge comprises Substructure (abutments at ends, intermediate piers, pile caps, well/pile foundations) transferring loads through elastomeric/POT-PTFE bearings from the Superstructure (PSC/RCC girders & deck slab).",
            summaryHi = "पुल में नींव (Pile/Well), पियर, एबटमेंट, बेयरिंग और डेक स्लैब मुख्य भाग होते हैं। बेयरिंग थर्मल एक्सपेंशन और लाइव लोड ट्रांसफर को संभालती है।",
            stepsEn = listOf(
                "Abutments retain approach embankment earth using wing walls/return walls while supporting end deck spans.",
                "Circular or hammerhead piers minimize river scour obstruction and support pier caps with pedestals.",
                "Install elastomeric or POT bearings strictly level at pedestal top before launching precast girders or casting deck slab."
            ),
            commonMistakeEn = "Ignoring expansion joint gap clearance or scupper drainage slope on bridge decks leads to ponding and reinforcement corrosion."
        ),
        CivilKnowledgeArticle(
            id = "k_highrise",
            topic = "High-Rise",
            titleEn = "High-Rise RCC Core, Shear Walls & Floor Cycle",
            titleHi = "मल्टी-स्टोरी / हाई-राइज बिल्डिंग और शियर वॉल तकनीक",
            standardRef = "IS 13920 / IS 16700",
            summaryEn = "Tall buildings resist wind and seismic lateral forces using RCC Shear Walls and lift cores alongside ductile beam-column frames (IS 13920). Aluminum formwork (Mivan) or jump-form systems achieve 7–10 day typical floor cycles.",
            summaryHi = "ऊंची इमारतों में भूकंप और हवा के दबाव को रोकने के लिए शियर वॉल, लिफ्ट कोर और डक्टाइल डिटेलिंग (135° हुक) का उपयोग किया जाता है।",
            stepsEn = listOf(
                "Provide 135° seismic hooks with confining hoops closely spaced near column ends (lo zone).",
                "Stagger column main bar laps in the middle half of clear height — never splice all bars at floor slab joint.",
                "Use high-grade concrete (M35–M60) with boom placers and thermal control on thick raft/transfer girders."
            ),
            commonMistakeEn = "Lapping 100% of column vertical bars at the exact same floor kicker level creates a weak plastic hinge under earthquake loading."
        ),
        CivilKnowledgeArticle(
            id = "k_peb_steel",
            topic = "PEB & Steel",
            titleEn = "PEB Warehouse Frames, Purlins, Bracing & Anchor Bolts",
            titleHi = "PEB और वेयरहाउस स्टील स्ट्रक्चर निर्माण",
            standardRef = "IS 800:2007 / MBMA",
            summaryEn = "Pre-Engineered Buildings use tapered I-section columns and rafters matched to bending moment diagrams, cold-formed Z/C purlins for roof sheets, sag rods, and X-bracing bays for longitudinal wind/crane stability.",
            summaryHi = "PEB वेयरहाउस में टेपर्ड राफ्टर, Z/C पर्लिन, एंकर बोल्ट और X-ब्रेसिंग का प्रयोग कर कम स्टील वजन में बड़ा स्पैन बनाया जाता है।",
            stepsEn = listOf(
                "Set baseplate anchor bolts using precision steel templates before pouring concrete pedestals.",
                "Install flange braces and sag rods to prevent lateral-torsional buckling of rafters and Z-purlins.",
                "Tighten HSFG connections systematically and finish warehouse floor with vacuum-dewatered Trimix M25–M30 slab."
            ),
            commonMistakeEn = "Omitting longitudinal wind X-bracing or eave struts compromises the entire shed stability during high wind uplift."
        ),
        CivilKnowledgeArticle(
            id = "k_road_layers",
            topic = "Roads & Infra",
            titleEn = "Flexible Pavement Layers: Subgrade, GSB, WMM, DBM & BC",
            titleHi = "सड़क निर्माण की परतें: सबग्रेड, GSB, WMM, DBM और BC",
            standardRef = "MoRTH / IRC:37",
            summaryEn = "Flexible bituminous highways distribute wheel loads layer by layer: compacted Subgrade (CBR checked) → Granular Sub-Base (GSB drainage) → Wet Mix Macadam (WMM) → Prime Coat → Dense Bituminous Macadam (DBM) → Tack Coat → Bituminous Concrete (BC).",
            summaryHi = "डामर सड़क में नीचे से ऊपर क्रमशः सबग्रेड, GSB, WMM, प्राइम कोट, DBM, टैक कोट और BC सतह डाली जाती है।",
            stepsEn = listOf(
                "Test Field Dry Density (FDD ≥ 97–98% of MDD) using sand replacement method on subgrade, GSB & WMM.",
                "Maintain 2.5%–3.0% camber slope toward shoulders and side drains so water never stagnates under base layers.",
                "Apply prime coat over WMM before laying hot-mix DBM/BC at controlled rolling temperatures."
            ),
            commonMistakeEn = "Rolling bituminous concrete below minimum compaction temperature (~110°C) leads to early raveling and potholes."
        ),
        CivilKnowledgeArticle(
            id = "k_qc_safety",
            topic = "Site QC & Safety",
            titleEn = "Site Safety, Bar Bending 135° Hooks & Rebar Wastage",
            titleHi = "साइट सेफ्टी, सरिया कटिंग वेस्टेज और गुणवत्ता जांच",
            standardRef = "IS 2502 / NBC Safety",
            summaryEn = "Steel accounts for ~25–30% of structural cost. Controlling cut-piece reuse via BBS, checking bar diameter tolerances (±weight per meter = d²/162.2), and enforcing PPE/shoring keep projects safe and profitable.",
            summaryHi = "सरिया के सही BBS से 3–5% वेस्टेज बचाया जा सकता है। खुदाई > 1.5m पर शोरिंग और सभी कर्मचारियों के लिए हेलमेट/बूट अनिवार्य है।",
            stepsEn = listOf(
                "Check unit weight of random 1m TMT sample (12mm = 0.888 kg/m, 16mm = 1.578 kg/m).",
                "Ensure stirrup hook length is 10d (min 75mm) bent at 135° for confinement.",
                "Log Daily Progress Reports (DPR) and Measurement Books (MB) daily to prevent billing disputes."
            ),
            commonMistakeEn = "Using 90° stirrup hooks on seismic columns instead of 135° anchorage allows core concrete spalling under shear."
        )
    )

    val quizzes: List<QuizQuestion> = listOf(
        QuizQuestion(
            id = "q1",
            question = "What is the standard clear concrete cover for an underground RCC Footing per IS 456?",
            options = listOf("20 mm", "25 mm", "40 mm", "50 mm"),
            correctIndex = 3,
            explanation = "IS 456 specifies minimum 50 mm clear cover for footings in direct contact with soil/ground."
        ),
        QuizQuestion(
            id = "q2",
            question = "What is the approximate dry volume conversion factor used for concrete material estimation?",
            options = listOf("1.10", "1.33", "1.54", "1.75"),
            correctIndex = 2,
            explanation = "Due to voids in dry sand & coarse aggregate, 1 m³ of wet concrete requires ~1.54 m³ of dry ingredients."
        ),
        QuizQuestion(
            id = "q3",
            question = "What is the weight per meter of a 16 mm TMT steel bar using d² / 162.2?",
            options = listOf("0.89 kg/m", "1.58 kg/m", "2.47 kg/m", "3.85 kg/m"),
            correctIndex = 1,
            explanation = "16² / 162.2 = 256 / 162.2 ≈ 1.578 kg/m."
        ),
        QuizQuestion(
            id = "q4",
            question = "For comfortable staircase ergonomics, what is the ideal range for 2R + G (2×Riser + Tread)?",
            options = listOf("450 – 500 mm", "600 – 640 mm", "720 – 780 mm", "800 – 850 mm"),
            correctIndex = 1,
            explanation = "Standard architectural/NBC comfort rule requires 2R + G between 600 mm and 640 mm (e.g. 2×150 + 300 = 600 mm)."
        ),
        QuizQuestion(
            id = "q5",
            question = "In flexible highway construction (MoRTH), which coat binds WMM granular base to DBM asphalt?",
            options = listOf("Tack Coat", "Prime Coat", "Seal Coat", "Curing Compound"),
            correctIndex = 1,
            explanation = "Low-viscosity Prime Coat penetrates the top of WMM granular layer; Tack Coat is applied between bituminous layers (DBM to BC)."
        )
    )
}

@Composable
fun CivilKnowledgeScreen(
    viewModel: MainViewModel,
    initialTopic: String? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val prefs = remember { context.getSharedPreferences("gaur_knowledge", Context.MODE_PRIVATE) }

    var activeTab by remember { mutableIntStateOf(0) } // 0=Articles, 1=Quiz
    var selectedTopic by remember(initialTopic) { mutableStateOf(initialTopic?.takeIf { it in CivilKnowledgeCatalog.topics } ?: "All") }
    var search by remember { mutableStateOf("") }
    var showHindi by remember(settings.language) { mutableStateOf(settings.language == AppLanguage.HINDI) }
    var bookmarks by remember {
        mutableStateOf(prefs.getString("bookmarks", "").orEmpty().split("|").filter { it.isNotBlank() }.toSet())
    }

    val filtered = remember(selectedTopic, search) {
        val q = search.trim().lowercase()
        CivilKnowledgeCatalog.articles.filter { a ->
            val matchTopic = selectedTopic == "All" || a.topic == selectedTopic
            val matchQ = q.isEmpty() ||
                a.titleEn.lowercase().contains(q) ||
                a.titleHi.lowercase().contains(q) ||
                a.summaryEn.lowercase().contains(q) ||
                a.topic.lowercase().contains(q) ||
                a.standardRef.lowercase().contains(q)
            matchTopic && matchQ
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = "Civil Engineering Knowledge",
            subtitle = "Bridge, High-Rise, RCC, Foundations, Roads & Quiz (EN/HI)",
            onBack = onBack,
            actions = {
                FilterChip(
                    selected = showHindi,
                    onClick = { showHindi = !showHindi },
                    label = { Text(if (showHindi) "हिन्दी ON" else "EN/HI") },
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        )

        TabRow(selectedTabIndex = activeTab, containerColor = palette.concreteCard) {
            Tab(
                selected = activeTab == 0,
                onClick = { activeTab = 0 },
                icon = { Icon(Icons.Rounded.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp)) },
                text = { Text("Articles (${filtered.size})") }
            )
            Tab(
                selected = activeTab == 1,
                onClick = { activeTab = 1 },
                icon = { Icon(Icons.Rounded.Quiz, contentDescription = null, modifier = Modifier.size(18.dp)) },
                text = { Text("Site Quiz (${CivilKnowledgeCatalog.quizzes.size})") }
            )
        }

        if (activeTab == 0) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text("Search RCC, Bridge, High-Rise, IS 456, MoRTH...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.orange) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("knowledge_search")
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(CivilKnowledgeCatalog.topics) { topic ->
                        FilterChip(
                            selected = selectedTopic == topic,
                            onClick = { selectedTopic = topic },
                            label = { Text(topic) }
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.id }) { art ->
                    val isBookmarked = bookmarks.contains(art.id)
                    EngineeringCard(accentColor = if (art.topic == "Bridge Engg") palette.skyBlue else palette.orange) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                GlassBluePill(text = art.topic)
                                GlassBluePill(text = art.standardRef)
                            }
                            IconButton(onClick = {
                                bookmarks = if (isBookmarked) bookmarks - art.id else bookmarks + art.id
                                prefs.edit().putString("bookmarks", bookmarks.joinToString("|")).apply()
                            }) {
                                Icon(
                                    imageVector = if (isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                                    contentDescription = "Bookmark",
                                    tint = if (isBookmarked) palette.orange else palette.inkMuted
                                )
                            }
                        }
                        Text(
                            text = if (showHindi) art.titleHi else art.titleEn,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = palette.inkPrimary
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = if (showHindi) art.summaryHi else art.summaryEn,
                            style = MaterialTheme.typography.bodyMedium,
                            color = palette.inkSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Practical Site Steps:", style = MaterialTheme.typography.labelLarge, color = palette.skyBlue)
                        art.stepsEn.forEachIndexed { idx, step ->
                            Text("${idx + 1}. $step", style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary, modifier = Modifier.padding(top = 2.dp))
                        }
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            color = palette.warningBg,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, palette.warning.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Common Mistake: ${art.commonMistakeEn}",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkPrimary,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        } else {
            val selectedAnswers = remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
            val score = CivilKnowledgeCatalog.quizzes.count { q -> selectedAnswers.value[q.id] == q.correctIndex }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    EngineeringCard(accentColor = palette.skyBlue) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text("Site Engineering Quiz", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                Text("Score: $score / ${CivilKnowledgeCatalog.quizzes.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = palette.orangeDark)
                            }
                            Button(
                                onClick = { selectedAnswers.value = emptyMap() },
                                colors = ButtonDefaults.buttonColors(containerColor = palette.orange)
                            ) { Text("Reset Quiz") }
                        }
                    }
                }
                items(CivilKnowledgeCatalog.quizzes, key = { it.id }) { q ->
                    val chosen = selectedAnswers.value[q.id]
                    EngineeringCard {
                        Text(q.question, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                        Spacer(Modifier.height(8.dp))
                        q.options.forEachIndexed { idx, opt ->
                            val isChosen = chosen == idx
                            val isRight = idx == q.correctIndex
                            val border = when {
                                chosen == null -> palette.metallicBorder
                                isRight -> palette.success
                                isChosen -> palette.error
                                else -> palette.metallicBorder
                            }
                            val bg = when {
                                chosen == null -> palette.concreteSurfaceAlt
                                isRight -> palette.successBg
                                isChosen -> palette.errorBg
                                else -> palette.concreteSurfaceAlt
                            }
                            Surface(
                                onClick = {
                                    if (chosen == null) {
                                        selectedAnswers.value = selectedAnswers.value + (q.id to idx)
                                    }
                                },
                                color = bg,
                                border = BorderStroke(1.dp, border),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            ) {
                                Text(opt, style = MaterialTheme.typography.bodyMedium, color = palette.inkPrimary, modifier = Modifier.padding(10.dp))
                            }
                        }
                        if (chosen != null) {
                            Spacer(Modifier.height(6.dp))
                            Text(q.explanation, style = MaterialTheme.typography.bodySmall, color = palette.skyBlue)
                        }
                    }
                }
            }
        }
    }
}

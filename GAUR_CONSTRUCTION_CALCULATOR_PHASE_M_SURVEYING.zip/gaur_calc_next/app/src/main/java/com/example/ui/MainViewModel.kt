package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.GaurApp
import com.example.core.i18n.AppLanguage
import com.example.core.preferences.ThemeModePref
import com.example.core.preferences.UnitSystemPref
import com.example.core.preferences.UserSettings
import com.example.data.local.BbsScheduleEntity
import com.example.data.local.BoqEstimateEntity
import com.example.data.local.CalculationHistoryEntity
import com.example.data.local.FavoriteToolEntity
import com.example.data.local.MaterialRateEntity
import com.example.data.local.ProjectEntity
import com.example.data.local.SecurityEventEntity
import com.example.data.local.StudioDrawingEntity
import com.example.data.local.StudioModel3DEntity
import com.example.domain.calculators.CalculatorRegistry
import com.example.features.security.SecurityDiagnosticReport
import com.example.features.security.SecurityShieldEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as GaurApp
    val repository = app.repository
    val settingsStore = app.settingsStore

    val settings: StateFlow<UserSettings> = settingsStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val projects: StateFlow<List<ProjectEntity>> = repository.projects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history: StateFlow<List<CalculationHistoryEntity>> = repository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val toolUsage: StateFlow<List<FavoriteToolEntity>> = repository.toolUsage
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val boqs: StateFlow<List<BoqEstimateEntity>> = repository.boqEstimates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bbsList: StateFlow<List<BbsScheduleEntity>> = repository.bbsSchedules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val materialRates: StateFlow<List<MaterialRateEntity>> = repository.materialRates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val drawings2D: StateFlow<List<StudioDrawingEntity>> = repository.drawings2D
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val models3D: StateFlow<List<StudioModel3DEntity>> = repository.models3D
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val securityEvents: StateFlow<List<SecurityEventEntity>> = repository.securityEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteToolIds: StateFlow<Set<String>> = toolUsage
        .combine(MutableStateFlow(Unit)) { list, _ -> list.filter { it.isFavorite }.map { it.toolId }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val recentToolIds: StateFlow<List<String>> = toolUsage
        .combine(MutableStateFlow(Unit)) { list, _ ->
            list.filter { it.lastUsedAt > 0L }
                .sortedByDescending { it.lastUsedAt }
                .map { it.toolId }
                .take(8)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _shieldReport = MutableStateFlow<SecurityDiagnosticReport?>(null)
    val shieldReport: StateFlow<SecurityDiagnosticReport?> = _shieldReport.asStateFlow()

    // Bridge for 2D -> 3D switching
    private val _pending3DFrom2DJson = MutableStateFlow<String?>(null)
    val pending3DFrom2DJson: StateFlow<String?> = _pending3DFrom2DJson.asStateFlow()

    init {
        runSecurityScan(application.applicationContext, logEvent = false)
    }

    fun runSecurityScan(context: Context = app.applicationContext, logEvent: Boolean = true) {
        viewModelScope.launch(Dispatchers.IO) {
            val report = SecurityShieldEngine.runDiagnosticScan(context)
            _shieldReport.value = report
            if (logEvent) {
                repository.logSecurityEvent(
                    type = "SHIELD_SCAN",
                    severity = if (report.hasWarnings) "WARNING" else "PASS",
                    title = "Master Gaur Security Scan",
                    details = report.overallStatusLabel
                )
            }
        }
    }

    fun setPending3DFrom2D(json: String?) {
        _pending3DFrom2DJson.value = json
    }

    fun onToolOpened(toolId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.recordToolUsage(toolId)
        }
    }

    fun toggleFavorite(toolId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleFavorite(toolId)
        }
    }

    fun saveCalculation(entry: CalculationHistoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveCalculation(entry)
        }
    }

    fun deleteHistory(id: Long) = viewModelScope.launch(Dispatchers.IO) { repository.deleteHistory(id) }
    fun clearHistory() = viewModelScope.launch(Dispatchers.IO) { repository.clearHistory() }

    fun saveProject(project: ProjectEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.saveProject(project)
            onSaved(id)
        }
    }

    fun duplicateProject(project: ProjectEntity) = viewModelScope.launch(Dispatchers.IO) {
        repository.duplicateProject(project)
    }

    fun deleteProject(project: ProjectEntity) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteProject(project)
    }

    fun saveBoq(estimate: BoqEstimateEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.saveBoq(estimate)
            onSaved(id)
        }
    }

    fun deleteBoq(id: Long) = viewModelScope.launch(Dispatchers.IO) { repository.deleteBoq(id) }

    fun saveBbs(schedule: BbsScheduleEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.saveBbs(schedule)
            onSaved(id)
        }
    }

    fun deleteBbs(id: Long) = viewModelScope.launch(Dispatchers.IO) { repository.deleteBbs(id) }

    fun saveMaterialRate(rate: MaterialRateEntity) = viewModelScope.launch(Dispatchers.IO) {
        repository.saveMaterialRate(rate)
    }

    fun deleteMaterialRate(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteMaterialRate(id)
    }

    fun resetRates() = viewModelScope.launch(Dispatchers.IO) {
        repository.resetDefaultRates()
    }

    fun saveDrawing2D(drawing: StudioDrawingEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.saveDrawing2D(drawing)
            onSaved(id)
        }
    }

    fun deleteDrawing2D(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteDrawing2D(id)
    }

    fun saveModel3D(model: StudioModel3DEntity, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = repository.saveModel3D(model)
            onSaved(id)
        }
    }

    fun deleteModel3D(id: Long) = viewModelScope.launch(Dispatchers.IO) {
        repository.deleteModel3D(id)
    }

    fun clearSecurityEvents() = viewModelScope.launch(Dispatchers.IO) {
        repository.clearSecurityEvents()
    }

    fun logSecurityEvent(type: String, severity: String, title: String, details: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.logSecurityEvent(type, severity, title, details)
        }
    }

    // Settings updates
    fun setLanguage(lang: AppLanguage) = viewModelScope.launch { settingsStore.setLanguage(lang) }
    fun setUnitSystem(sys: UnitSystemPref) = viewModelScope.launch { settingsStore.setUnitSystem(sys) }
    fun setThemeMode(mode: ThemeModePref) = viewModelScope.launch { settingsStore.setThemeMode(mode) }
    fun setPrecision(p: Int) = viewModelScope.launch { settingsStore.setPrecision(p) }
    fun setDefaultMix(mix: String) = viewModelScope.launch { settingsStore.setDefaultMix(mix) }
    fun setDefaultWastage(w: Double) = viewModelScope.launch { settingsStore.setDefaultWastage(w) }
    fun setBighaRegion(name: String, sqFt: Double) = viewModelScope.launch { settingsStore.setBighaRegion(name, sqFt) }
    fun setBranding(company: String, engineer: String, currency: String) = viewModelScope.launch {
        settingsStore.setBranding(company, engineer, currency)
    }

    fun getRatesKeywordMap(): Map<String, Double> {
        val list = materialRates.value
        fun findRate(vararg keys: String, fallback: Double): Double =
            list.firstOrNull { r -> keys.any { k -> r.name.contains(k, ignoreCase = true) } }?.materialRate ?: fallback
        return mapOf(
            "cement" to findRate("cement", fallback = 390.0),
            "sand" to findRate("sand", fallback = 62.0),
            "aggregate" to findRate("aggregate", fallback = 48.0),
            "steel" to findRate("tmt", "rebar", "steel", fallback = 68.0),
            "brick" to findRate("brick", fallback = 8.5),
            "tile" to findRate("tile", fallback = 65.0),
            "paint" to findRate("paint", fallback = 320.0),
            "primer" to findRate("primer", fallback = 210.0),
            "putty" to findRate("putty", fallback = 28.0),
            "waterproof" to findRate("waterproof", fallback = 260.0)
        )
    }

    fun toolCount(): Int = CalculatorRegistry.allTools.size
}

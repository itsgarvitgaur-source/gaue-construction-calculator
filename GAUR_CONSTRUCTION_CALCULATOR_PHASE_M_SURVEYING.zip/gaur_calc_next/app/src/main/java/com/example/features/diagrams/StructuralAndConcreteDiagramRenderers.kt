package com.example.features.diagrams

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun DrawScope.drawStructuralOrConcreteDiagram(
    s: DiagramInputSnapshot,
    mode: DiagramViewMode,
    yaw: Float,
    pitch: Float
): Boolean {
    when (s.toolId) {
        "struct_slab" -> drawSlabDiagram(s, mode, yaw, pitch)
        "struct_beam", "struct_lintel", "struct_ground_beams" -> drawBeamOrLintelDiagram(s, mode, yaw, pitch)
        "struct_rect_column", "struct_circ_column", "struct_pedestal" -> drawColumnDiagram(s, mode, yaw, pitch)
        "struct_isolated_footing", "struct_raft_strip", "struct_pile" -> drawFoundationDiagram(s, mode, yaw, pitch)
        "struct_stair_straight", "struct_stair_doglegged" -> drawStaircaseDiagram(s, mode, yaw, pitch)
        "struct_retaining_wall" -> drawRetainingWallDiagram(s, mode, yaw, pitch)
        "struct_wall_multi" -> drawStructuralWallDiagram(s, mode, yaw, pitch)
        "struct_misc_elements" -> drawMiscStructuralDiagram(s, mode, yaw, pitch)
        "struct_roofing" -> drawRoofingDiagram(s, mode, yaw, pitch)
        "conc_pcc", "conc_rcc_mix", "conc_rmc" -> drawConcreteMixOrPccDiagram(s, mode, yaw, pitch)
        else -> return false
    }
    return true
}

private fun DrawScope.drawSlabDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val type = s.raw("slabType", "Two-Way Slab")
    val isCirc = type == "Circular Slab"
    val isSq = type == "Square Slab"
    val isFlatDrop = type == "Flat Slab (Drop Panel)"
    val isRibbed = type == "Ribbed Slab"
    val isWaffle = type == "Waffle Slab"
    val isHollow = type == "Hollow-Core Slab"
    val isSloped = type == "Sloped Slab"
    val isCantilever = type in setOf("Cantilever Slab", "Balcony Slab")

    val lx = s.lenMeters("lx", 4.0).coerceAtLeast(0.5).toFloat()
    val ly = if (isSq || isCirc) lx else s.lenMeters("ly", 5.2).coerceAtLeast(0.5).toFloat()
    val t = s.lenMeters("t", 0.125).coerceAtLeast(0.05).toFloat()
    val slopeDeg = s.dbl("slopeDeg", 18.0).coerceIn(0.0, 50.0)
    val lxLbl = if (isCirc) "Ø=${s.lenLabel("lx", 4.0)}" else if (isSq) "L=${s.lenLabel("lx", 4.0)}" else "Lx=${s.lenLabel("lx", 4.0)}"
    val lyLbl = "Ly=${s.lenLabel("ly", 5.2)}"
    val tLbl = "T=${s.lenLabel("t", 0.125)}"

    when (mode) {
        DiagramViewMode.VIEW_3D -> {
            val visT = (t * 2.5f).coerceIn(0.25f, 1.2f)
            val maxDim = max(lx, ly)
            val scale = (min(size.width, size.height) * 0.50f) / maxDim
            val center = Offset(size.width / 2f, size.height * 0.56f)
            if (isCirc) {
                val r = lx / 2f
                val (_, topPts) = draw3DCylinder(Offset(0f, 0f), 0f, visT, r, Vec3D(0f, 0f, visT / 2f), center, scale, yaw, pitch, CadColors.ConcreteFill)
                drawDimensionLine(topPts[0], topPts[topPts.size / 2], -26f, lxLbl)
            } else {
                val pts = draw3DPrism(
                    Vec3D(0f, 0f, 0f), Vec3D(lx, ly, visT),
                    Vec3D(lx / 2f, ly / 2f, visT / 2f),
                    center, scale, yaw, pitch, CadColors.ConcreteFill
                )
                if (isFlatDrop) {
                    draw3DPrism(
                        Vec3D(lx * 0.34f, ly * 0.34f, -visT * 0.8f),
                        Vec3D(lx * 0.66f, ly * 0.66f, 0f),
                        Vec3D(lx / 2f, ly / 2f, visT / 2f),
                        center, scale, yaw, pitch, CadColors.ConcreteDarkFill
                    )
                }
                drawDimensionLine(pts[0], pts[1], 28f, lxLbl)
                drawDimensionLine(pts[1], pts[2], 28f, lyLbl)
                drawDimensionLine(pts[2], pts[6], -36f, tLbl, CadColors.DimOrange)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
        DiagramViewMode.SECTION -> {
            val pad = 74f
            val rectW = size.width - pad * 2f
            val rectH = (rectW * (t / max(lx, ly)).coerceIn(0.14f, 0.32f)).coerceIn(48f, 100f)
            val top = size.height / 2f - rectH / 2f

            if (isSloped) {
                val risePx = (rectW * kotlin.math.tan(Math.toRadians(slopeDeg)).toFloat()).coerceIn(24f, 100f)
                val yLeft = size.height * 0.66f
                val yRight = yLeft - risePx
                val slopePath = Path().apply {
                    moveTo(pad, yLeft)
                    lineTo(pad + rectW, yRight)
                    lineTo(pad + rectW, yRight - rectH * 0.55f)
                    lineTo(pad, yLeft - rectH * 0.55f)
                    close()
                }
                drawPath(slopePath, CadColors.ConcreteFill)
                drawPath(slopePath, CadColors.ConcreteStroke, style = Stroke(3f))
                drawDashedLine(Offset(pad, yLeft), Offset(pad + rectW, yLeft), CadColors.DimBlue, 2f)
                drawAngularArc(Offset(pad, yLeft), 52f, -slopeDeg.toFloat(), slopeDeg.toFloat(), "${UnitConverter.fmt(slopeDeg, 1)}°")
                drawDimensionLine(Offset(pad, yLeft), Offset(pad + rectW, yLeft), 30f, lxLbl)
            } else if (isRibbed || isWaffle) {
                val topH = 30f
                val ribD = 62f
                drawRect(CadColors.ConcreteFill, Offset(pad, top - 16f), Size(rectW, topH))
                drawRect(CadColors.ConcreteStroke, Offset(pad, top - 16f), Size(rectW, topH), style = Stroke(2.5f))
                val ribs = 5
                val ribW = 26f
                for (i in 0 until ribs) {
                    val rx = pad + 18f + (rectW - 36f - ribW) * i / (ribs - 1)
                    drawRect(CadColors.ConcreteFill, Offset(rx, top - 16f + topH), Size(ribW, ribD))
                    drawRect(CadColors.ConcreteStroke, Offset(rx, top - 16f + topH), Size(ribW, ribD), style = Stroke(2.5f))
                    drawCircle(CadColors.SteelBar, 4.5f, Offset(rx + ribW / 2f, top - 16f + topH + ribD - 10f))
                }
                drawDimensionLine(Offset(pad, top - 16f + topH + ribD), Offset(pad + rectW, top - 16f + topH + ribD), 32f, lxLbl)
                drawDimensionLine(Offset(pad + rectW, top - 16f), Offset(pad + rectW, top - 16f + topH + ribD), -46f, "Tf+Rib", CadColors.DimOrange)
            } else if (isHollow) {
                val hPx = 76f
                val y0 = size.height / 2f - hPx / 2f
                drawRect(CadColors.ConcreteFill, Offset(pad, y0), Size(rectW, hPx))
                drawRect(CadColors.ConcreteStroke, Offset(pad, y0), Size(rectW, hPx), style = Stroke(3f))
                val cores = 6
                for (i in 1..cores) {
                    val cx = pad + rectW * i / (cores + 1)
                    drawCircle(Color.White, hPx * 0.28f, Offset(cx, y0 + hPx / 2f))
                    drawCircle(CadColors.ConcreteStroke, hPx * 0.28f, Offset(cx, y0 + hPx / 2f), style = Stroke(2f))
                }
                drawDimensionLine(Offset(pad, y0 + hPx), Offset(pad + rectW, y0 + hPx), 32f, lxLbl)
                drawDimensionLine(Offset(pad + rectW, y0), Offset(pad + rectW, y0 + hPx), -44f, tLbl, CadColors.DimOrange)
            } else {
                drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(rectW, rectH))
                drawDiagonalHatch(Offset(pad, top), Size(rectW, rectH))
                drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(rectW, rectH), style = Stroke(3f))
                if (isFlatDrop) {
                    val dw = rectW * 0.42f
                    drawRect(CadColors.ConcreteDarkFill, Offset(size.width / 2f - dw / 2f, top + rectH), Size(dw, 28f))
                    drawRect(CadColors.ConcreteStroke, Offset(size.width / 2f - dw / 2f, top + rectH), Size(dw, 28f), style = Stroke(2.5f))
                }
                if (isCantilever) {
                    drawRect(CadColors.ConcreteDarkFill, Offset(pad - 24f, top - 28f), Size(24f, rectH + 56f))
                    drawLine(CadColors.SteelBar, Offset(pad - 12f, top + 12f), Offset(pad + rectW - 12f, top + 12f), 4f)
                } else {
                    drawLine(CadColors.SteelBar, Offset(pad + 12f, top + rectH - 12f), Offset(pad + rectW - 12f, top + rectH - 12f), 4f)
                }
                drawDimensionLine(Offset(pad, top + rectH), Offset(pad + rectW, top + rectH), 34f, lxLbl)
                drawDimensionLine(Offset(pad + rectW, top), Offset(pad + rectW, top + rectH), -44f, tLbl, CadColors.DimOrange)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.SteelBar)
        }
        else -> {
            val cx = size.width / 2f
            val cy = size.height / 2f
            if (isCirc) {
                val r = min(size.width, size.height) * 0.28f
                drawCircle(if (mode == DiagramViewMode.REINFORCEMENT) Color(0xFFF8FAFC) else CadColors.ConcreteFill.copy(alpha = 0.55f), r, Offset(cx, cy))
                drawCircle(CadColors.ConcreteStroke, r, Offset(cx, cy), style = Stroke(3f))
                if (mode == DiagramViewMode.REINFORCEMENT) {
                    for (i in -3..3) {
                        val off = r * i / 4f
                        val chord = kotlin.math.sqrt((r * r - off * off).coerceAtLeast(0f))
                        drawLine(CadColors.SteelBar, Offset(cx + off, cy - chord + 6f), Offset(cx + off, cy + chord - 6f), 2f)
                        drawLine(CadColors.DimOrange, Offset(cx - chord + 6f, cy + off), Offset(cx + chord - 6f, cy + off), 2f)
                    }
                }
                drawDimensionLine(Offset(cx - r, cy + r), Offset(cx + r, cy + r), 34f, lxLbl)
            } else {
                val maxSide = min(size.width, size.height) * 0.58f
                val aspect = if (isSq) 1f else (lx / ly).coerceIn(0.45f, 2.1f)
                val wPx = if (aspect >= 1f) maxSide else maxSide * aspect
                val hPx = if (aspect >= 1f) maxSide / aspect else maxSide
                val left = cx - wPx / 2f
                val top = cy - hPx / 2f
                drawRect(if (mode == DiagramViewMode.REINFORCEMENT) Color(0xFFF8FAFC) else CadColors.ConcreteFill.copy(alpha = 0.55f), Offset(left, top), Size(wPx, hPx))
                drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(wPx, hPx), style = Stroke(3f))
                if (isWaffle || isRibbed) {
                    val cols = 5
                    val rows = if (isWaffle) 5 else 1
                    for (i in 1 until cols) {
                        val x = left + wPx * i / cols
                        drawLine(CadColors.ConcreteStroke.copy(alpha = 0.6f), Offset(x, top), Offset(x, top + hPx), 3f)
                    }
                    for (j in 1 until rows) {
                        val y = top + hPx * j / rows
                        drawLine(CadColors.ConcreteStroke.copy(alpha = 0.6f), Offset(left, y), Offset(left + wPx, y), 3f)
                    }
                } else if (isHollow) {
                    for (i in 1..5) {
                        val x = left + wPx * i / 6f
                        drawDashedLine(Offset(x, top + 6f), Offset(x, top + hPx - 6f), CadColors.DimBlue, 2.5f)
                    }
                } else if (isFlatDrop) {
                    drawRect(CadColors.DimOrange.copy(alpha = 0.25f), Offset(cx - wPx * 0.22f, cy - hPx * 0.22f), Size(wPx * 0.44f, hPx * 0.44f))
                    drawRect(CadColors.DimOrange, Offset(cx - wPx * 0.22f, cy - hPx * 0.22f), Size(wPx * 0.44f, hPx * 0.44f), style = Stroke(2.5f))
                } else if (isCantilever) {
                    drawRect(CadColors.ConcreteDarkFill, Offset(left - 14f, top), Size(14f, hPx))
                }
                if (mode == DiagramViewMode.REINFORCEMENT) {
                    for (i in 1..5) drawLine(CadColors.SteelBar, Offset(left + wPx * i / 6f, top + 10f), Offset(left + wPx * i / 6f, top + hPx - 10f), 2.5f)
                    for (j in 1..5) drawLine(CadColors.DimOrange, Offset(left + 10f, top + hPx * j / 6f), Offset(left + wPx - 10f, top + hPx * j / 6f), 2f)
                }
                drawDimensionLine(Offset(left, top + hPx), Offset(left + wPx, top + hPx), 34f, lxLbl)
                drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -48f, if (isSq) lxLbl else lyLbl)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
    }
}

private fun DrawScope.drawBeamOrLintelDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val isLintel = s.toolId == "struct_lintel"
    val isGround = s.toolId == "struct_ground_beams"
    val type = when {
        isLintel -> s.raw("lintelType", "Lintel + Chajja Sunshade")
        isGround -> s.raw("gBeamType", "Plinth Beam")
        else -> s.raw("beamType", "Rectangular Beam")
    }
    val isRing = type == "Circular / Ring Beam"
    val isTBeam = type == "T-Beam"
    val isLBeam = type == "L-Beam"
    val isInvT = type == "Inverted T-Beam"
    val isCantilever = type == "Cantilever Beam"
    val isContinuous = type == "Continuous Beam"
    val isTapered = type in setOf("Tapered / Haunched Beam", "Varying Cross-Section Beam")

    val l = when {
        isLintel -> (s.lenMeters("openW", 1.5) + 2.0 * s.lenMeters("bearing", 0.15)).toFloat().coerceAtLeast(0.6f)
        isGround -> s.lenMeters("len", 45.0).toFloat().coerceAtLeast(1.0f)
        isRing -> (PI * s.lenMeters("ringDia", 6.0)).toFloat().coerceAtLeast(2.0f)
        else -> s.lenMeters("l", 5.0).toFloat().coerceAtLeast(0.8f)
    }
    val b = s.lenMeters(if (isLintel) "lW" else "b", 0.23).toFloat().coerceAtLeast(0.1f)
    val d = if (type == "Square Beam") b else s.lenMeters(if (isLintel) "lD" else "d", 0.45).toFloat().coerceAtLeast(0.1f)
    val chajja = if (isLintel && type == "Lintel + Chajja Sunshade") s.lenMeters("chajjaProj", 0.6).toFloat() else 0f

    val lLbl = when {
        isLintel -> "L=${UnitConverter.fmt(l.toDouble(), s.p)}m"
        isGround -> "L=${s.lenLabel("len", 45.0)}"
        isRing -> "Ø=${s.lenLabel("ringDia", 6.0)}"
        else -> "L=${s.lenLabel("l", 5.0)}"
    }
    val bLbl = if (isLintel) "W=${s.lenLabel("lW", 0.23)}" else "B=${s.lenLabel("b", 0.23)}"
    val dLbl = if (isLintel) "D=${s.lenLabel("lD", 0.15)}" else "D=${s.lenLabel("d", 0.45)}"

    when (mode) {
        DiagramViewMode.SECTION -> {
            val cx = size.width / 2f
            val cy = size.height / 2f
            if (isTBeam || isLBeam || isInvT) {
                val flangeW = size.width * 0.54f
                val totalH = size.height * 0.56f
                val flangeT = totalH * 0.26f
                val webW = flangeW * 0.34f
                val leftF = cx - flangeW / 2f
                val top = cy - totalH / 2f
                val webLeft = if (isLBeam) leftF else cx - webW / 2f

                val path = Path().apply {
                    if (isInvT) {
                        moveTo(webLeft, top)
                        lineTo(webLeft + webW, top)
                        lineTo(webLeft + webW, top + totalH - flangeT)
                        lineTo(leftF + flangeW, top + totalH - flangeT)
                        lineTo(leftF + flangeW, top + totalH)
                        lineTo(leftF, top + totalH)
                        lineTo(leftF, top + totalH - flangeT)
                        lineTo(webLeft, top + totalH - flangeT)
                        close()
                    } else {
                        moveTo(leftF, top)
                        lineTo(leftF + flangeW, top)
                        lineTo(leftF + flangeW, top + flangeT)
                        lineTo(webLeft + webW, top + flangeT)
                        lineTo(webLeft + webW, top + totalH)
                        lineTo(webLeft, top + totalH)
                        lineTo(webLeft, top + flangeT)
                        lineTo(leftF, top + flangeT)
                        close()
                    }
                }
                drawPath(path, CadColors.ConcreteFill)
                drawPath(path, CadColors.ConcreteStroke, style = Stroke(3f))
                // Stirrup + rebar inside web
                drawRect(CadColors.StirrupColor, Offset(webLeft + 12f, top + 12f), Size(webW - 24f, totalH - 24f), style = Stroke(2.5f))
                drawCircle(CadColors.SteelBar, 6f, Offset(webLeft + 18f, top + totalH - 18f))
                drawCircle(CadColors.SteelBar, 6f, Offset(webLeft + webW - 18f, top + totalH - 18f))
                drawDimensionLine(Offset(leftF, top), Offset(leftF + flangeW, top), -26f, "Bf=${s.lenLabel("bf", 0.9)}")
                drawDimensionLine(Offset(webLeft, top + totalH), Offset(webLeft + webW, top + totalH), 30f, "Bw=${s.lenLabel("b", 0.23)}")
                drawDimensionLine(Offset(leftF + flangeW, top), Offset(leftF + flangeW, top + totalH), -44f, dLbl, CadColors.DimOrange)
            } else {
                val maxH = size.height * 0.56f
                val ratio = (b / d).coerceIn(0.4f, 1.8f)
                val rectH = maxH
                val rectW = (rectH * ratio).coerceIn(80f, size.width * 0.52f)
                val left = cx - rectW / 2f
                val top = cy - rectH / 2f - 8f
                if (isGround) {
                    drawRect(CadColors.SoilFill, Offset(left - 18f, top + rectH), Size(rectW + 36f, 18f))
                    drawRect(CadColors.SoilStroke, Offset(left - 18f, top + rectH), Size(rectW + 36f, 18f), style = Stroke(2f))
                }
                drawRect(CadColors.ConcreteFill, Offset(left, top), Size(rectW, rectH))
                drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(rectW, rectH), style = Stroke(3f))
                if (chajja > 0f) {
                    val cw = (rectW * 1.05f).coerceAtMost(size.width - left - rectW - 24f)
                    drawRect(CadColors.ConcreteFill, Offset(left + rectW, top + rectH * 0.2f), Size(cw, rectH * 0.3f))
                    drawRect(CadColors.ConcreteStroke, Offset(left + rectW, top + rectH * 0.2f), Size(cw, rectH * 0.3f), style = Stroke(2.5f))
                    drawDimensionLine(Offset(left + rectW, top + rectH * 0.2f), Offset(left + rectW + cw, top + rectH * 0.2f), -26f, "Proj=${s.lenLabel("chajjaProj", 0.6)}", CadColors.DimOrange)
                }
                val cov = 16f
                drawRect(CadColors.StirrupColor, Offset(left + cov, top + cov), Size(rectW - 2 * cov, rectH - 2 * cov), style = Stroke(3f))
                listOf(
                    Offset(left + cov + 8f, top + cov + 8f),
                    Offset(left + rectW - cov - 8f, top + cov + 8f),
                    Offset(left + cov + 8f, top + rectH - cov - 8f),
                    Offset(left + rectW - cov - 8f, top + rectH - cov - 8f)
                ).forEach { drawCircle(CadColors.SteelBar, 7f, it) }
                drawDimensionLine(Offset(left, top + rectH), Offset(left + rectW, top + rectH), 34f, bLbl)
                drawDimensionLine(Offset(left, top), Offset(left, top + rectH), -46f, dLbl, CadColors.DimOrange)
            }
            drawCadTextPill("$type Cross-Section", Offset(size.width / 2f, 26f), CadColors.SteelBar)
        }
        DiagramViewMode.VIEW_3D -> {
            val center = Offset(size.width / 2f, size.height * 0.56f)
            if (isRing) {
                val r = s.lenMeters("ringDia", 6.0).toFloat() / 2f
                val scale = (min(size.width, size.height) * 0.42f) / max(r * 2f, 1f)
                val (_, topPts) = draw3DCylinder(Offset(0f, 0f), 0f, max(d, 0.5f), r, Vec3D(0f, 0f, d / 2f), center, scale, yaw, pitch, CadColors.ConcreteFill)
                drawDimensionLine(topPts[0], topPts[topPts.size / 2], -26f, lLbl)
            } else {
                val scale = (min(size.width, size.height) * 0.54f) / max(l, 1f)
                val visB = max(b, l * 0.14f)
                val visD = max(d, l * 0.18f)
                val pts = draw3DPrism(
                    Vec3D(0f, 0f, 0f), Vec3D(l, visB, visD),
                    Vec3D(l / 2f, visB / 2f, visD / 2f),
                    center, scale, yaw, pitch, CadColors.ConcreteFill
                )
                drawDimensionLine(pts[0], pts[1], 28f, lLbl)
                drawDimensionLine(pts[1], pts[2], 26f, bLbl)
                drawDimensionLine(pts[2], pts[6], -34f, dLbl, CadColors.DimOrange)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        else -> {
            if (isRing) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val rOut = min(size.width, size.height) * 0.30f
                val rIn = rOut * 0.72f
                drawCircle(CadColors.ConcreteFill, rOut, Offset(cx, cy))
                drawCircle(Color.White, rIn, Offset(cx, cy))
                drawCircle(CadColors.ConcreteStroke, rOut, Offset(cx, cy), style = Stroke(3f))
                drawCircle(CadColors.ConcreteStroke, rIn, Offset(cx, cy), style = Stroke(2.5f))
                drawCircle(CadColors.SteelBar, (rOut + rIn) / 2f, Offset(cx, cy), style = Stroke(3f))
                drawDimensionLine(Offset(cx - rOut, cy + rOut), Offset(cx + rOut, cy + rOut), 32f, lLbl)
                drawCadTextPill(type, Offset(cx, 26f), CadColors.DimBlue)
            } else {
                val pad = 68f
                val beamW = size.width - pad * 2f
                val beamH = (beamW * (d / l).coerceIn(0.15f, 0.34f)).coerceIn(66f, 126f)
                val top = size.height * 0.44f - beamH / 2f
                if (isTapered) {
                    val endH = beamH * 0.56f
                    val path = Path().apply {
                        moveTo(pad, top)
                        lineTo(pad + beamW, top)
                        lineTo(pad + beamW, top + endH)
                        lineTo(pad, top + beamH)
                        close()
                    }
                    drawPath(path, CadColors.ConcreteFill)
                    drawPath(path, CadColors.ConcreteStroke, style = Stroke(3f))
                    drawDimensionLine(Offset(pad + beamW, top), Offset(pad + beamW, top + endH), -44f, "D2=${s.lenLabel("endD", 0.25)}", CadColors.DimOrange)
                    drawDimensionLine(Offset(pad, top), Offset(pad, top + beamH), -46f, "D1=${s.lenLabel("d", 0.45)}", CadColors.DimOrange)
                } else {
                    drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(beamW, beamH))
                    drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(beamW, beamH), style = Stroke(3f))
                    drawDimensionLine(Offset(pad + beamW, top), Offset(pad + beamW, top + beamH), -44f, dLbl, CadColors.DimOrange)
                }

                if (isCantilever) {
                    drawRect(CadColors.ConcreteDarkFill, Offset(pad - 24f, top - 30f), Size(24f, beamH + 60f))
                    drawRect(CadColors.ConcreteStroke, Offset(pad - 24f, top - 30f), Size(24f, beamH + 60f), style = Stroke(2.5f))
                } else if (isContinuous) {
                    val spans = s.dbl("spans", 3.0).roundToInt().coerceIn(2, 4)
                    val supSize = 22f
                    for (i in 0..spans) {
                        val sx = pad + 14f + (beamW - 28f) * i / spans
                        val p = Path().apply {
                            moveTo(sx, top + beamH)
                            lineTo(sx - supSize * 0.6f, top + beamH + supSize)
                            lineTo(sx + supSize * 0.6f, top + beamH + supSize)
                            close()
                        }
                        drawPath(p, CadColors.DimOrange)
                    }
                } else {
                    val supSize = 24f
                    listOf(pad + 18f, pad + beamW - 18f).forEach { sx ->
                        val p = Path().apply {
                            moveTo(sx, top + beamH)
                            lineTo(sx - supSize * 0.65f, top + beamH + supSize)
                            lineTo(sx + supSize * 0.65f, top + beamH + supSize)
                            close()
                        }
                        drawPath(p, CadColors.DimOrange)
                    }
                }
                drawLine(CadColors.SteelBar, Offset(pad + 10f, top + 14f), Offset(pad + beamW - 10f, top + 14f), if (isCantilever) 5f else 3.5f)
                drawLine(CadColors.SteelBar, Offset(pad + 10f, top + beamH - 14f), Offset(pad + beamW - 10f, top + beamH - 14f), if (isCantilever) 3f else 4.5f)
                if (mode == DiagramViewMode.REINFORCEMENT) {
                    for (i in 0..12) {
                        val x = pad + 16f + (beamW - 32f) * i / 12
                        drawLine(CadColors.StirrupColor, Offset(x, top + 10f), Offset(x, top + beamH - 10f), 2f)
                    }
                }
                drawDimensionLine(Offset(pad, top + beamH), Offset(pad + beamW, top + beamH), 44f, lLbl)
                drawCadTextPill("$type • $bLbl", Offset(size.width / 2f, 26f), CadColors.DimBlue)
            }
        }
    }
}

private fun DrawScope.drawColumnDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val isPed = s.toolId == "struct_pedestal"
    val type = when {
        isPed -> s.raw("pedType", "Rectangular Pedestal")
        s.toolId == "struct_circ_column" -> "Circular / Round Column"
        else -> s.raw("colType", "Rectangular Column")
    }
    val isCirc = type in setOf("Circular / Round Column", "Circular Pedestal")
    val isSq = type in setOf("Square Column", "Square Pedestal")
    val isL = type == "L-Shaped Column"
    val isT = type == "T-Shaped Column"
    val isCross = type == "Cross-Shaped (+) Column"
    val isPoly = type == "Polygonal Column (Hex/Oct)"
    val isTapered = type == "Tapered Column"
    val isStepped = type in setOf("Stepped Column", "Stepped Pedestal")
    val hasCapital = type == "Column with Capital"
    val hasPedestalBase = type in setOf("Column with Pedestal", "Column with Base")

    val h = s.lenMeters("h", if (isPed) 0.9 else 3.2).toFloat().coerceAtLeast(0.4f)
    val b = s.lenMeters(if (isCirc) "dia" else "b", 0.35).toFloat().coerceAtLeast(0.15f)
    val d = if (isCirc || isSq) b else s.lenMeters("d", 0.45).toFloat().coerceAtLeast(0.15f)
    val hLbl = "H=${s.lenLabel("h", if (isPed) 0.9 else 3.2)}"
    val bLbl = if (isCirc) "Ø=${s.lenLabel("dia", 0.45)}" else "B=${s.lenLabel("b", 0.30)}"
    val dLbl = if (isCirc || isSq) bLbl else "D=${s.lenLabel("d", 0.45)}"

    when (mode) {
        DiagramViewMode.SECTION, DiagramViewMode.REINFORCEMENT -> {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val maxDim = min(size.width, size.height) * 0.54f
            when {
                isCirc -> {
                    val r = maxDim / 2f
                    drawCircle(CadColors.ConcreteFill, r, Offset(cx, cy))
                    drawCircle(CadColors.ConcreteStroke, r, Offset(cx, cy), style = Stroke(3f))
                    drawCircle(CadColors.StirrupColor, r - 18f, Offset(cx, cy), style = Stroke(2.5f))
                    for (i in 0 until 6) {
                        val a = i * Math.PI / 3.0
                        drawCircle(CadColors.SteelBar, 7f, Offset(cx + ((r - 24f) * cos(a)).toFloat(), cy + ((r - 24f) * sin(a)).toFloat()))
                    }
                    drawDimensionLine(Offset(cx - r, cy + r), Offset(cx + r, cy + r), 34f, bLbl, CadColors.DimOrange)
                }
                isL -> {
                    val leg = maxDim
                    val thick = leg * 0.42f
                    val left = cx - leg / 2f
                    val top = cy - leg / 2f
                    val p = Path().apply {
                        moveTo(left, top)
                        lineTo(left + thick, top)
                        lineTo(left + thick, top + leg - thick)
                        lineTo(left + leg, top + leg - thick)
                        lineTo(left + leg, top + leg)
                        lineTo(left, top + leg)
                        close()
                    }
                    drawPath(p, CadColors.ConcreteFill)
                    drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
                    listOf(
                        Offset(left + 16f, top + 16f), Offset(left + thick - 16f, top + 16f),
                        Offset(left + 16f, top + leg - 16f), Offset(left + thick - 16f, top + leg - thick + 16f),
                        Offset(left + leg - 16f, top + leg - thick + 16f), Offset(left + leg - 16f, top + leg - 16f)
                    ).forEach { drawCircle(CadColors.SteelBar, 6.5f, it) }
                    drawDimensionLine(Offset(left, top + leg), Offset(left + leg, top + leg), 32f, "L1=${s.lenLabel("b", 0.30)}")
                    drawDimensionLine(Offset(left, top), Offset(left, top + leg), -46f, "L2=${s.lenLabel("d", 0.45)}", CadColors.DimOrange)
                }
                isT -> {
                    val wPx = maxDim
                    val hPx = maxDim
                    val ft = wPx * 0.38f
                    val wt = wPx * 0.38f
                    val left = cx - wPx / 2f
                    val top = cy - hPx / 2f
                    val p = Path().apply {
                        moveTo(left, top)
                        lineTo(left + wPx, top)
                        lineTo(left + wPx, top + ft)
                        lineTo(cx + wt / 2f, top + ft)
                        lineTo(cx + wt / 2f, top + hPx)
                        lineTo(cx - wt / 2f, top + hPx)
                        lineTo(cx - wt / 2f, top + ft)
                        lineTo(left, top + ft)
                        close()
                    }
                    drawPath(p, CadColors.ConcreteFill)
                    drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
                    listOf(
                        Offset(left + 16f, top + 16f), Offset(left + wPx - 16f, top + 16f),
                        Offset(cx - wt / 2f + 14f, top + ft - 14f), Offset(cx + wt / 2f - 14f, top + ft - 14f),
                        Offset(cx - wt / 2f + 14f, top + hPx - 16f), Offset(cx + wt / 2f - 14f, top + hPx - 16f)
                    ).forEach { drawCircle(CadColors.SteelBar, 6.5f, it) }
                    drawDimensionLine(Offset(left, top), Offset(left + wPx, top), -26f, "Bf=${s.lenLabel("b", 0.30)}")
                    drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -46f, dLbl, CadColors.DimOrange)
                }
                isCross -> {
                    val sPx = maxDim
                    val arm = sPx * 0.36f
                    val half = sPx / 2f
                    val ha = arm / 2f
                    val p = Path().apply {
                        moveTo(cx - ha, cy - half); lineTo(cx + ha, cy - half)
                        lineTo(cx + ha, cy - ha); lineTo(cx + half, cy - ha)
                        lineTo(cx + half, cy + ha); lineTo(cx + ha, cy + ha)
                        lineTo(cx + ha, cy + half); lineTo(cx - ha, cy + half)
                        lineTo(cx - ha, cy + ha); lineTo(cx - half, cy + ha)
                        lineTo(cx - half, cy - ha); lineTo(cx - ha, cy - ha)
                        close()
                    }
                    drawPath(p, CadColors.ConcreteFill)
                    drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
                    listOf(
                        Offset(cx - ha + 12f, cy - half + 14f), Offset(cx + ha - 12f, cy - half + 14f),
                        Offset(cx - ha + 12f, cy + half - 14f), Offset(cx + ha - 12f, cy + half - 14f),
                        Offset(cx - half + 14f, cy - ha + 12f), Offset(cx - half + 14f, cy + ha - 12f),
                        Offset(cx + half - 14f, cy - ha + 12f), Offset(cx + half - 14f, cy + ha - 12f)
                    ).forEach { drawCircle(CadColors.SteelBar, 6f, it) }
                    drawDimensionLine(Offset(cx - half, cy + half), Offset(cx + half, cy + half), 32f, "A=${s.lenLabel("b", 0.30)}")
                }
                isPoly -> {
                    val sides = s.raw("polySides", "6 (Hexagon)").substringBefore(" ").toIntOrNull() ?: 6
                    val r = maxDim * 0.50f
                    val p = Path()
                    val tieP = Path()
                    val pts = mutableListOf<Offset>()
                    for (i in 0 until sides) {
                        val a = 2.0 * PI * i / sides - PI / 2.0
                        val pt = Offset(cx + (r * cos(a)).toFloat(), cy + (r * sin(a)).toFloat())
                        val tPt = Offset(cx + ((r - 18f) * cos(a)).toFloat(), cy + ((r - 18f) * sin(a)).toFloat())
                        pts += Offset(cx + ((r - 24f) * cos(a)).toFloat(), cy + ((r - 24f) * sin(a)).toFloat())
                        if (i == 0) { p.moveTo(pt.x, pt.y); tieP.moveTo(tPt.x, tPt.y) }
                        else { p.lineTo(pt.x, pt.y); tieP.lineTo(tPt.x, tPt.y) }
                    }
                    p.close(); tieP.close()
                    drawPath(p, CadColors.ConcreteFill)
                    drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
                    drawPath(tieP, CadColors.StirrupColor, style = Stroke(2.5f))
                    pts.forEach { drawCircle(CadColors.SteelBar, 6.5f, it) }
                    drawDimensionLine(Offset(cx - r, cy + r), Offset(cx + r, cy + r), 30f, "$sides Sides • a=${s.lenLabel("polySideLen", 0.22)}")
                }
                else -> {
                    val ratio = (b / d).coerceIn(0.45f, 2.0f)
                    val wPx = if (ratio >= 1f) maxDim else maxDim * ratio
                    val hPx = if (ratio >= 1f) maxDim / ratio else maxDim
                    val left = cx - wPx / 2f
                    val top = cy - hPx / 2f
                    drawRect(CadColors.ConcreteFill, Offset(left, top), Size(wPx, hPx))
                    drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(wPx, hPx), style = Stroke(3f))
                    drawRect(CadColors.StirrupColor, Offset(left + 16f, top + 16f), Size(wPx - 32f, hPx - 32f), style = Stroke(3f))
                    listOf(
                        Offset(left + 24f, top + 24f), Offset(left + wPx / 2f, top + 24f), Offset(left + wPx - 24f, top + 24f),
                        Offset(left + 24f, top + hPx - 24f), Offset(left + wPx / 2f, top + hPx - 24f), Offset(left + wPx - 24f, top + hPx - 24f)
                    ).forEach { drawCircle(CadColors.SteelBar, 7f, it) }
                    drawDimensionLine(Offset(left, top + hPx), Offset(left + wPx, top + hPx), 34f, bLbl)
                    drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -46f, dLbl, CadColors.DimOrange)
                }
            }
            drawCadTextPill("$type Section", Offset(size.width / 2f, 26f), CadColors.SteelBar)
        }
        DiagramViewMode.ELEVATION -> {
            val colH = size.height * 0.62f
            val colW = (colH * (b / h).coerceIn(0.22f, 0.44f)).coerceIn(66f, 128f)
            val cx = size.width / 2f
            val top = (size.height - colH) / 2f + 10f
            val left = cx - colW / 2f

            when {
                isTapered -> {
                    val topW = colW * 0.62f
                    val p = Path().apply {
                        moveTo(cx - topW / 2f, top)
                        lineTo(cx + topW / 2f, top)
                        lineTo(cx + colW / 2f, top + colH)
                        lineTo(cx - colW / 2f, top + colH)
                        close()
                    }
                    drawPath(p, CadColors.ConcreteFill)
                    drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
                    drawDimensionLine(Offset(cx - topW / 2f, top), Offset(cx + topW / 2f, top), -26f, "B2=${s.lenLabel("topB", 0.23)}")
                }
                isStepped -> {
                    val topW = colW * 0.65f
                    drawRect(CadColors.ConcreteFill, Offset(left, top + colH * 0.45f), Size(colW, colH * 0.55f))
                    drawRect(CadColors.ConcreteStroke, Offset(left, top + colH * 0.45f), Size(colW, colH * 0.55f), style = Stroke(3f))
                    drawRect(CadColors.ConcreteFill, Offset(cx - topW / 2f, top), Size(topW, colH * 0.45f))
                    drawRect(CadColors.ConcreteStroke, Offset(cx - topW / 2f, top), Size(topW, colH * 0.45f), style = Stroke(3f))
                }
                hasCapital -> {
                    val capW = colW * 1.85f
                    val capH = colH * 0.22f
                    val p = Path().apply {
                        moveTo(cx - capW / 2f, top)
                        lineTo(cx + capW / 2f, top)
                        lineTo(left + colW, top + capH)
                        lineTo(left + colW, top + colH)
                        lineTo(left, top + colH)
                        lineTo(left, top + capH)
                        close()
                    }
                    drawPath(p, CadColors.ConcreteFill)
                    drawPath(p, CadColors.ConcreteStroke, style = Stroke(3f))
                }
                hasPedestalBase -> {
                    val pedW = colW * 1.7f
                    val pedH = colH * 0.26f
                    drawRect(CadColors.ConcreteFill, Offset(left, top), Size(colW, colH - pedH))
                    drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(colW, colH - pedH), style = Stroke(3f))
                    drawRect(CadColors.ConcreteDarkFill, Offset(cx - pedW / 2f, top + colH - pedH), Size(pedW, pedH))
                    drawRect(CadColors.ConcreteStroke, Offset(cx - pedW / 2f, top + colH - pedH), Size(pedW, pedH), style = Stroke(3f))
                }
                else -> {
                    drawRect(CadColors.ConcreteFill, Offset(left, top), Size(colW, colH))
                    drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(colW, colH), style = Stroke(3f))
                }
            }
            drawLine(CadColors.SteelBar, Offset(left + 14f, top - 22f), Offset(left + 14f, top + colH), 3.5f)
            drawLine(CadColors.SteelBar, Offset(left + colW - 14f, top - 22f), Offset(left + colW - 14f, top + colH), 3.5f)
            drawDimensionLine(Offset(left, top + colH), Offset(left + colW, top + colH), 30f, bLbl)
            drawDimensionLine(Offset(left + colW, top), Offset(left + colW, top + colH), -50f, hLbl, CadColors.DimOrange)
            drawCadTextPill(type, Offset(cx, 26f), CadColors.DimBlue)
        }
        else -> {
            val scale = (size.height * 0.54f) / max(h, 1f)
            val visB = max(b, h * 0.16f)
            val visD = max(d, h * 0.16f)
            val center = Offset(size.width / 2f, size.height * 0.56f)
            val cRef = Vec3D(visB / 2f, visD / 2f, h / 2f)
            if (isCirc) {
                val (_, topPts) = draw3DCylinder(Offset(0f, 0f), 0f, h, visB / 2f, Vec3D(0f, 0f, h / 2f), center, scale, yaw, pitch, CadColors.ConcreteFill)
                drawDimensionLine(topPts[0], topPts[topPts.size / 2], -28f, bLbl)
            } else if (isL) {
                draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(visB, visD * 0.45f, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(visB * 0.45f, visD, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
            } else if (isT) {
                draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(visB, visD * 0.38f, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                draw3DPrism(Vec3D(visB * 0.32f, visD * 0.38f, 0f), Vec3D(visB * 0.68f, visD, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
            } else if (isCross) {
                draw3DPrism(Vec3D(0f, visD * 0.32f, 0f), Vec3D(visB, visD * 0.68f, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                draw3DPrism(Vec3D(visB * 0.32f, 0f, 0f), Vec3D(visB * 0.68f, visD, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
            } else if (isPoly) {
                val sides = s.raw("polySides", "6 (Hexagon)").substringBefore(" ").toIntOrNull() ?: 6
                draw3DCylinder(Offset(0f, 0f), 0f, h, visB * 0.6f, Vec3D(0f, 0f, h / 2f), center, scale, yaw, pitch, CadColors.ConcreteFill, segments = sides)
            } else {
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(visB, visD, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteFill)
                if (hasPedestalBase) {
                    draw3DPrism(Vec3D(-visB * 0.3f, -visD * 0.3f, 0f), Vec3D(visB * 1.3f, visD * 1.3f, h * 0.25f), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                } else if (hasCapital) {
                    draw3DPrism(Vec3D(-visB * 0.35f, -visD * 0.35f, h * 0.78f), Vec3D(visB * 1.35f, visD * 1.35f, h), cRef, center, scale, yaw, pitch, CadColors.ConcreteDarkFill)
                }
                drawDimensionLine(pts[0], pts[1], 28f, bLbl)
                drawDimensionLine(pts[1], pts[2], 28f, dLbl)
                drawDimensionLine(pts[2], pts[6], -44f, hLbl, CadColors.DimOrange)
            }
            drawCadTextPill(type, Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
    }
}

private fun DrawScope.drawConcreteMixOrPccDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val isPcc = s.toolId == "conc_pcc"
    val l = if (isPcc) s.lenMeters("l", 10.0).toFloat().coerceAtLeast(0.5f) else 2.5f
    val w = if (isPcc) s.lenMeters("w", 5.0).toFloat().coerceAtLeast(0.5f) else 2.0f
    val t = if (isPcc) s.lenMeters("t", 0.1).toFloat().coerceAtLeast(0.05f) else 2.0f
    val vol = if (isPcc) l * w * t else s.dbl("vol", 10.0).toFloat().coerceAtLeast(0.1f)

    if (mode == DiagramViewMode.VIEW_3D) {
        val visT = if (isPcc) max(t * 2.5f, max(l, w) * 0.12f) else 1.8f
        val scale = (min(size.width, size.height) * 0.48f) / max(l, w)
        val pts = draw3DPrism(
            Vec3D(0f, 0f, 0f), Vec3D(l, w, visT),
            Vec3D(l / 2f, w / 2f, visT / 2f),
            Offset(size.width / 2f, size.height * 0.56f),
            scale, yaw, pitch, CadColors.ConcreteFill
        )
        if (isPcc) {
            drawDimensionLine(pts[0], pts[1], 28f, "L=${s.lenLabel("l", 10.0)}")
            drawDimensionLine(pts[1], pts[2], 28f, "W=${s.lenLabel("w", 5.0)}")
            drawDimensionLine(pts[2], pts[6], -38f, "T=${s.lenLabel("t", 0.1)}", CadColors.DimOrange)
        } else {
            drawDimensionLine(pts[0], pts[1], 28f, "Vol=${UnitConverter.fmt(vol.toDouble(), s.p)} m³")
        }
        drawCadTextPill("${s.raw("mix", "M20")} • ${UnitConverter.fmt(vol.toDouble(), s.p)} m³", Offset(size.width / 2f, 26f), CadColors.DimOrange)
    } else {
        val pad = 56f
        val barW = size.width - pad * 2f
        val barH = 56f
        val top = size.height * 0.46f
        val (cP, sP, aP) = when {
            s.raw("mix", "").contains("1:5:10") -> Triple(1f, 5f, 10f)
            s.raw("mix", "").contains("1:4:8") -> Triple(1f, 4f, 8f)
            s.raw("mix", "").contains("1:3:6") -> Triple(1f, 3f, 6f)
            s.raw("mix", "").contains("1:2:4") -> Triple(1f, 2f, 4f)
            s.raw("mix", "").contains("1:1:2") -> Triple(1f, 1f, 2f)
            else -> Triple(1f, 1.5f, 3f)
        }
        val tot = cP + sP + aP
        val cw = barW * (cP / tot)
        val sw = barW * (sP / tot)
        val aw = barW * (aP / tot)
        drawRect(Color(0xFF94A3B8), Offset(pad, top), Size(cw, barH))
        drawRect(Color(0xFFFCD34D), Offset(pad + cw, top), Size(sw, barH))
        drawRect(Color(0xFFFB923C), Offset(pad + cw + sw, top), Size(aw, barH))
        drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(barW, barH), style = Stroke(2.5f))
        drawCadTextPill("Cement", Offset(pad + cw / 2f, top - 24f), CadColors.ConcreteStroke, textSizePx = 22f)
        drawCadTextPill("Sand", Offset(pad + cw + sw / 2f, top - 24f), CadColors.SoilStroke, textSizePx = 22f)
        drawCadTextPill("Aggregate", Offset(pad + cw + sw + aw / 2f, top - 24f), CadColors.DimOrange, textSizePx = 22f)
        drawDimensionLine(Offset(pad, top + barH), Offset(pad + barW, top + barH), 34f, "Wet=${UnitConverter.fmt(vol.toDouble(), s.p)}m³ → Dry(×1.54)=${UnitConverter.fmt(vol * 1.54, s.p)}m³")
    }
}

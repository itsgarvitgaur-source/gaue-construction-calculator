package com.example.features.dashboard

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apartment
import androidx.compose.material.icons.rounded.Architecture
import androidx.compose.material.icons.rounded.Assessment
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.DirectionsBus
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.Engineering
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FormatPaint
import androidx.compose.material.icons.rounded.Foundation
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.HomeWork
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Roofing
import androidx.compose.material.icons.rounded.SquareFoot
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Terrain
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material.icons.rounded.Warehouse
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.domain.calculators.CalcToolSpec
import com.example.domain.calculators.CalculatorRegistry

data class DashboardGridCategory(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val subtitleEn: String,
    val subtitleHi: String,
    val icon: ImageVector,
    val accent: Color,
    val route: String,
    val badgeText: String,
    val keywords: List<String> = emptyList()
)

object DashboardCategoryCatalog {

    fun filterToolsForGroup(groupKey: String): Pair<String, List<CalcToolSpec>> {
        val all = CalculatorRegistry.allTools
        return when (groupKey) {
            "group:concrete" -> "Concrete & RCC" to all.filter {
                it.id.startsWith("conc_") || it.id in setOf(
                    "struct_slab", "struct_beam", "struct_rect_column", "struct_circ_column",
                    "struct_isolated_footing", "struct_stair_straight", "struct_stair_doglegged",
                    "struct_lintel", "struct_ground_beams", "struct_misc_elements"
                )
            }
            "group:foundation" -> "Foundation & Footings" to all.filter {
                it.id in setOf(
                    "struct_isolated_footing", "struct_raft_strip", "struct_pile",
                    "struct_pedestal", "conc_pcc", "earth_excavation_pit", "earth_sloped_excavation"
                )
            }
            "group:plaster_paint" -> "Plaster, Paint & Putty" to all.filter {
                it.id in setOf("finish_plaster", "finish_paint_putty", "finish_waterproofing", "finish_anti_termite")
            }
            "group:flooring" -> "Flooring, Tiles & Timber" to all.filter {
                it.id in setOf(
                    "finish_tiles_flooring", "finish_marble_granite", "finish_trimix_epoxy",
                    "finish_wood_timber", "finish_false_ceiling", "finish_door_window_glass"
                )
            }
            "group:roofing" -> "Roofing, Arch & Dome" to all.filter {
                it.id in setOf("struct_roofing", "struct_arch_dome", "struct_slab", "finish_waterproofing")
            }
            "group:road" -> "Road & Highway Infra" to all.filter {
                it.id in setOf("infra_road_layers", "finish_asphalt_road", "earth_embankment_road", "conc_tube_curb", "earth_cut_fill")
            }
            "group:bridge" -> "Bridge & Culvert Engg" to all.filter {
                it.id in setOf("infra_culvert_pier", "struct_pile", "struct_raft_strip", "struct_retaining_wall", "struct_arch_dome", "conc_tube_curb")
            }
            else -> "All Calculators" to all
        }
    }

    fun buildGridTiles(): List<DashboardGridCategory> {
        val concCount = filterToolsForGroup("group:concrete").second.size
        val foundCount = filterToolsForGroup("group:foundation").second.size
        val plasterCount = filterToolsForGroup("group:plaster_paint").second.size
        val floorCount = filterToolsForGroup("group:flooring").second.size
        val roofCount = filterToolsForGroup("group:roofing").second.size
        val roadCount = filterToolsForGroup("group:road").second.size
        val bridgeCount = filterToolsForGroup("group:bridge").second.size

        fun catCount(catId: String): Int =
            CalculatorRegistry.allTools.count { it.category.id == catId }

        return listOf(
            DashboardGridCategory(
                id = "concrete",
                titleEn = "Concrete",
                titleHi = "कंक्रीट कैलकुलेटर",
                subtitleEn = "PCC, RCC, Mix, Slab, Beam, Stair",
                subtitleHi = "PCC, RCC, मिक्स, स्लैब, बीम",
                icon = Icons.Rounded.Construction,
                accent = Color(0xFFF57C00),
                route = "category/group:concrete",
                badgeText = "$concCount Tools",
                keywords = listOf("concrete", "pcc", "rcc", "cement", "sand", "aggregate", "mix", "mortar", "कंक्रीट")
            ),
            DashboardGridCategory(
                id = "steel",
                titleEn = "Steel & BBS",
                titleHi = "स्टील और BBS",
                subtitleEn = "Rebar, Cutting, Lap, Ld & Sections",
                subtitleHi = "सरिया वजन, कटिंग, लैप, BBS",
                icon = Icons.Rounded.Architecture,
                accent = Color(0xFF0288D1),
                route = "category/steel",
                badgeText = "${catCount("steel")} + BBS",
                keywords = listOf("steel", "rebar", "bbs", "sariya", "tmt", "stirrup", "lap", "siria", "सरिया")
            ),
            DashboardGridCategory(
                id = "masonry",
                titleEn = "Brick & Block",
                titleHi = "ईंट, ब्लॉक और चिनाई",
                subtitleEn = "Bricks, AAC, Stone, Mortar, Pavers",
                subtitleHi = "ईंट, AAC ब्लॉक, पत्थर, मसाला",
                icon = Icons.Rounded.GridView,
                accent = Color(0xFFD84315),
                route = "category/masonry",
                badgeText = "${catCount("masonry")} Tools",
                keywords = listOf("brick", "block", "aac", "masonry", "wall", "mortar", "ईंट")
            ),
            DashboardGridCategory(
                id = "foundation",
                titleEn = "Foundation",
                titleHi = "फाउंडेशन / नींव",
                subtitleEn = "Isolated, Combined, Raft, Pile",
                subtitleHi = "फुटिंग, राफ्ट, पाइल, PCC बेड",
                icon = Icons.Rounded.Foundation,
                accent = Color(0xFF795548),
                route = "category/group:foundation",
                badgeText = "$foundCount Tools",
                keywords = listOf("footing", "foundation", "raft", "pile", "pedestal", "नींव")
            ),
            DashboardGridCategory(
                id = "earthwork",
                titleEn = "Excavation & Earth",
                titleHi = "खुदाई और मिट्टी कार्य",
                subtitleEn = "Pit, Trench, Backfill, Cut & Fill",
                subtitleHi = "खुदाई, भराई, रेत बल्किंग",
                icon = Icons.Rounded.Terrain,
                accent = Color(0xFF6D4C41),
                route = "category/earthwork",
                badgeText = "${catCount("earthwork")} Tools",
                keywords = listOf("excavation", "earthwork", "soil", "backfill", "bulking", "खुदाई")
            ),
            DashboardGridCategory(
                id = "plaster_paint",
                titleEn = "Plaster & Paint",
                titleHi = "प्लास्टर, पेंट और पुट्टी",
                subtitleEn = "Plaster, Paint, Primer, Waterproof",
                subtitleHi = "प्लास्टर, पेंट, वाटरप्रूफिंग",
                icon = Icons.Rounded.FormatPaint,
                accent = Color(0xFF00897B),
                route = "category/group:plaster_paint",
                badgeText = "$plasterCount Tools",
                keywords = listOf("plaster", "paint", "putty", "primer", "waterproofing", "termite", "प्लास्टर")
            ),
            DashboardGridCategory(
                id = "flooring",
                titleEn = "Flooring & Tiles",
                titleHi = "फ्लोरिंग, टाइल्स और लकड़ी",
                subtitleEn = "Tiles, Marble, Trimix, Wood, Glass",
                subtitleHi = "टाइल्स, मार्बल, लकड़ी CFT, सीलिंग",
                icon = Icons.Rounded.Layers,
                accent = Color(0xFF5E35B1),
                route = "category/group:flooring",
                badgeText = "$floorCount Tools",
                keywords = listOf("tile", "flooring", "marble", "granite", "trimix", "wood", "timber", "ceiling")
            ),
            DashboardGridCategory(
                id = "roofing",
                titleEn = "Roofing",
                titleHi = "छत (Roofing)",
                subtitleEn = "Gable, Shed, Hip, Rafter & Sheets",
                subtitleHi = "स्लोप रूफ, राफ्टर, आर्च, डोम",
                icon = Icons.Rounded.Roofing,
                accent = Color(0xFFC62828),
                route = "category/group:roofing",
                badgeText = "$roofCount Tools",
                keywords = listOf("roof", "roofing", "rafter", "gable", "arch", "dome", "shed")
            ),
            DashboardGridCategory(
                id = "utilities",
                titleEn = "Water Tank & Pipe",
                titleHi = "वॉटर टैंक और प्लंबिंग",
                subtitleEn = "Tank, Sump, Septic, Rainwater, AC",
                subtitleHi = "टंकी, सेप्टिक टैंक, पाइप, सोलर",
                icon = Icons.Rounded.WaterDrop,
                accent = Color(0xFF039BE5),
                route = "category/utilities",
                badgeText = "${catCount("utilities")} Tools",
                keywords = listOf("water tank", "sump", "septic", "rainwater", "pipe", "plumbing", "solar")
            ),
            DashboardGridCategory(
                id = "basic",
                titleEn = "Area & Geometry",
                titleHi = "क्षेत्रफल और आयतन",
                subtitleEn = "15 2D Shapes, 12 3D Solids & RFT",
                subtitleHi = "15 2D आकार, 12 3D आयतन",
                icon = Icons.Rounded.SquareFoot,
                accent = Color(0xFF1E88E5),
                route = "category/basic",
                badgeText = "${catCount("basic")} Tools",
                keywords = listOf("area", "volume", "geometry", "circle", "triangle", "trapezoid", "perimeter")
            ),
            DashboardGridCategory(
                id = "converters",
                titleEn = "Unit Converter",
                titleHi = "यूनिट कनवर्टर",
                subtitleEn = "Length, Land, Vol, Weight, MPa, °C",
                subtitleHi = "लंबाई, बीघा/एकड़, वजन, दबाव",
                icon = Icons.Rounded.SwapHoriz,
                accent = Color(0xFF00ACC1),
                route = "converters",
                badgeText = "Instant + ${catCount("converters")}",
                keywords = listOf("converter", "unit", "feet", "meter", "inch", "bigha", "acre", "cft", "brass")
            ),
            DashboardGridCategory(
                id = "feet_inch",
                titleEn = "Feet-Inch Calc",
                titleHi = "फीट-इंच कैलकुलेटर",
                subtitleEn = "Fractions, Ft-In Keypad, Memory",
                subtitleHi = "फीट-इंच-फ्रैक्शन कीपैड और टेप",
                icon = Icons.Rounded.Straighten,
                accent = Color(0xFFEF6C00),
                route = "feet_inch_calc",
                badgeText = "Keypad",
                keywords = listOf("feet", "inch", "fraction", "tape", "ft", "फीट", "इंच")
            ),
            DashboardGridCategory(
                id = "scientific",
                titleEn = "Scientific Calc",
                titleHi = "साइंटिफिक कैलकुलेटर",
                subtitleEn = "Trig, Inverse, DMS ° ' \", Log",
                subtitleHi = "त्रिकोणमिति, DMS, लॉग और टेप",
                icon = Icons.Rounded.Functions,
                accent = Color(0xFF3949AB),
                route = "scientific_calc",
                badgeText = "Trig/DMS",
                keywords = listOf("scientific", "trig", "sin", "cos", "tan", "dms", "angle")
            ),
            DashboardGridCategory(
                id = "peb",
                titleEn = "PEB & Warehouse",
                titleHi = "PEB और वेयरहाउस",
                subtitleEn = "Shed, Purlins, Sheeting, Bolts",
                subtitleHi = "शेड, राफ्टर, पर्लिन, एंकर बोल्ट",
                icon = Icons.Rounded.Warehouse,
                accent = Color(0xFF546E7A),
                route = "peb",
                badgeText = "Studio",
                keywords = listOf("peb", "warehouse", "shed", "purlin", "rafter", "anchor bolt", "industrial")
            ),
            DashboardGridCategory(
                id = "road",
                titleEn = "Road & Infra",
                titleHi = "सड़क निर्माण (Road)",
                subtitleEn = "GSB, WMM, Bitumen, Embankment",
                subtitleHi = "GSB, WMM, डामर, रोड लेयर",
                icon = Icons.Rounded.DirectionsBus,
                accent = Color(0xFF37474F),
                route = "category/group:road",
                badgeText = "$roadCount Tools",
                keywords = listOf("road", "highway", "gsb", "wmm", "dbm", "bitumen", "asphalt", "subgrade", "सड़क")
            ),
            DashboardGridCategory(
                id = "bridge",
                titleEn = "Bridge Engg",
                titleHi = "ब्रिज इंजीनियरिंग",
                subtitleEn = "Pier, Box Culvert, Deck & Guides",
                subtitleHi = "पियर, कल्वर्ट, डेक स्लैब और ज्ञान",
                icon = Icons.Rounded.Apartment,
                accent = Color(0xFF0277BD),
                route = "category/group:bridge",
                badgeText = "$bridgeCount + Guide",
                keywords = listOf("bridge", "pier", "abutment", "culvert", "deck", "bearing", "पुल")
            ),
            DashboardGridCategory(
                id = "building",
                titleEn = "Building Const.",
                titleHi = "भवन निर्माण",
                subtitleEn = "Slab, Column, Beam, Stair, Walls",
                subtitleHi = "स्लैब, कॉलम, बीम, सीढ़ी, दीवार",
                icon = Icons.Rounded.HomeWork,
                accent = Color(0xFFFB8C00),
                route = "category/structural",
                badgeText = "${catCount("structural")} Tools",
                keywords = listOf("building", "room", "slab", "beam", "column", "staircase", "lintel", "घर")
            ),
            DashboardGridCategory(
                id = "boq",
                titleEn = "BOQ & Costing",
                titleHi = "BOQ और लागत",
                subtitleEn = "7 Templates, GST, Compare, PDF",
                subtitleHi = "BOQ जनरेटर, GST, तुलना, PDF",
                icon = Icons.Rounded.ReceiptLong,
                accent = Color(0xFF2E7D32),
                route = "boq",
                badgeText = "BOQ Pro",
                keywords = listOf("boq", "cost", "estimate", "quotation", "gst", "pdf", "excel")
            ),
            DashboardGridCategory(
                id = "materials",
                titleEn = "Material Rates",
                titleHi = "सामग्री दरें (Rates)",
                subtitleEn = "Price Library, Labour & Wastage",
                subtitleHi = "सीमेंट, सरिया, रेत, लेबर रेट",
                icon = Icons.Rounded.Inventory2,
                accent = Color(0xFF43A047),
                route = "materials",
                badgeText = "Rate Master",
                keywords = listOf("rate", "price", "material", "labour", "wastage", "cement rate")
            ),
            DashboardGridCategory(
                id = "site",
                titleEn = "Site Toolkit",
                titleHi = "साइट इंजीनियर टूल",
                subtitleEn = "RL, Slope, 3-4-5, Bearing, Scale",
                subtitleHi = "लेवल RL, ढलान, 3-4-5, स्केल",
                icon = Icons.Rounded.Explore,
                accent = Color(0xFF00838F),
                route = "category/site",
                badgeText = "${catCount("site")} Tools",
                keywords = listOf("site", "level", "rl", "slope", "3-4-5", "bearing", "surveying", "scale")
            ),
            DashboardGridCategory(
                id = "site_diary",
                titleEn = "DPR, MB & Safety",
                titleHi = "DPR, MB और सुरक्षा",
                subtitleEn = "Progress Report, MB Book & QC",
                subtitleHi = "दैनिक रिपोर्ट, MB, चेकलिस्ट",
                icon = Icons.Rounded.Engineering,
                accent = Color(0xFFAD1457),
                route = "site_diary",
                badgeText = "DPR / MB",
                keywords = listOf("dpr", "mb", "measurement book", "checklist", "inspection", "safety", "qc")
            ),
            DashboardGridCategory(
                id = "knowledge",
                titleEn = "Civil Knowledge",
                titleHi = "सिविल ज्ञान और क्विज़",
                subtitleEn = "IS Codes, High-Rise, Bridge, Quiz",
                subtitleHi = "IS कोड, ब्रिज, हाई-राइज, क्विज़",
                icon = Icons.Rounded.MenuBook,
                accent = Color(0xFF6A1B9A),
                route = "knowledge",
                badgeText = "EN/HI + Quiz",
                keywords = listOf("knowledge", "fundamentals", "is 456", "high rise", "bridge", "quiz", "hindi", "ज्ञान")
            ),
            DashboardGridCategory(
                id = "studio2d",
                titleEn = "2D Drawings CAD",
                titleHi = "2D ड्राइंग और प्लान",
                subtitleEn = "Floor, Footing, Column Plans",
                subtitleHi = "फ्लोर प्लान, ब्लूप्रिंट, CAD",
                icon = Icons.Rounded.Draw,
                accent = Color(0xFF1565C0),
                route = "studio2d",
                badgeText = "2D CAD",
                keywords = listOf("2d", "drawing", "plan", "cad", "blueprint", "layout", "ड्राइंग")
            ),
            DashboardGridCategory(
                id = "studio3d",
                titleEn = "3D Visualization",
                titleHi = "3D स्ट्रक्चर व्यूअर",
                subtitleEn = "3D Framing, Section Cut, Orbit",
                subtitleHi = "3D मॉडल, सेक्शन कट, बिल्डिंग",
                icon = Icons.Rounded.ViewInAr,
                accent = Color(0xFF00695C),
                route = "studio3d",
                badgeText = "3D View",
                keywords = listOf("3d", "visualization", "model", "structure", "viewer", "section")
            ),
            DashboardGridCategory(
                id = "projects",
                titleEn = "My Projects",
                titleHi = "मेरे प्रोजेक्ट्स",
                subtitleEn = "Workspaces, Docs & Estimates",
                subtitleHi = "प्रोजेक्ट फ़ोल्डर, नोट्स, PDF",
                icon = Icons.Rounded.Folder,
                accent = Color(0xFFF57C00),
                route = "projects",
                badgeText = "Workspace",
                keywords = listOf("project", "workspace", "folder", "notes", "saved project")
            ),
            DashboardGridCategory(
                id = "history",
                titleEn = "Saved History",
                titleHi = "सहेजे गए रिकॉर्ड",
                subtitleEn = "Saved Calculations & Templates",
                subtitleHi = "इतिहास और टेम्पलेट्स",
                icon = Icons.Rounded.Bookmark,
                accent = Color(0xFF455A64),
                route = "history",
                badgeText = "Records",
                keywords = listOf("history", "saved", "templates", "records", "backup")
            )
        )
    }
}

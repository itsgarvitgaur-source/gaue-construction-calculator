package com.example.features.dashboard

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.automirrored.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Apartment
import androidx.compose.material.icons.rounded.Architecture
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.Construction
import androidx.compose.material.icons.rounded.DirectionsBus
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.Engineering
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FormatPaint
import androidx.compose.material.icons.rounded.Foundation
import androidx.compose.material.icons.rounded.Functions
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.HomeWork
import androidx.compose.material.icons.rounded.Roofing
import androidx.compose.material.icons.rounded.SquareFoot
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Warehouse
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.domain.calculators.CalcToolSpec
import com.example.domain.calculators.CalculatorRegistry

data class NestedSubcategory(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val subtitleEn: String,
    val toolIds: List<String> = emptyList(),
    val directRoute: String? = null,
    val directRouteLabel: String? = null
)

data class NestedMainCategory(
    val id: String,
    val titleEn: String,
    val titleHi: String,
    val subtitleEn: String,
    val subtitleHi: String,
    val icon: ImageVector,
    val accent: Color,
    val subcategories: List<NestedSubcategory>,
    val studioShortcutRoute: String? = null,
    val studioShortcutTitle: String? = null,
    val studioShortcutSubtitle: String? = null,
    val keywords: List<String> = emptyList()
) {
    fun uniqueToolCount(): Int = subcategories.flatMap { it.toolIds }.distinct().size
}

/**
 * 4-Level Hierarchical Engineering Library:
 * Level 1: 18 Main Category Folders (Dashboard)
 * Level 2: Subcategory Folders inside each Main Category
 * Level 3: Tools inside each Subcategory
 * Level 4: Individual Calculator / Studio Screen
 */
object NestedCategoryCatalog {

    val categories: List<NestedMainCategory> by lazy {
        listOf(
            NestedMainCategory(
                id = "cat_concrete",
                titleEn = "Concrete & RCC",
                titleHi = "कंक्रीट और RCC",
                subtitleEn = "Slab, Beam, Column, Mix & Pour",
                subtitleHi = "स्लैब, बीम, कॉलम, मिक्स और पोर",
                icon = Icons.Rounded.Construction,
                accent = Color(0xFFF57C00),
                keywords = listOf("concrete", "pcc", "rcc", "mix", "slab", "beam", "column", "pour", "curing", "shuttering"),
                subcategories = listOf(
                    NestedSubcategory("sub_conc_mix", "Concrete Mix & RMC", "मिक्स डिज़ाइन और RMC", "PCC, Mix M5-M40, RMC, Mortar, W/C", listOf("conc_pcc", "conc_rcc_mix", "conc_rmc", "conc_cement_mortar", "conc_water_cement", "conc_admixture_dosage")),
                    NestedSubcategory("sub_conc_slab", "Slab & Screed", "स्लैब और स्क्रीड", "All Slab Types, Screed Slope & Grout", listOf("struct_slab", "conc_screeding", "conc_grout_micro")),
                    NestedSubcategory("sub_conc_beam", "Beam & Lintel", "बीम और लिंटल", "11 Beam Shapes, Plinth & Lintel/Chajja", listOf("struct_beam", "struct_ground_beams", "struct_lintel")),
                    NestedSubcategory("sub_conc_col", "Columns & Pedestals", "कॉलम और पेडेस्टल", "9 Column Shapes, Circular & Pedestal", listOf("struct_rect_column", "struct_circ_column", "struct_pedestal")),
                    NestedSubcategory("sub_conc_pour", "Pour, Curing & Formwork", "पोर, क्योरिंग और शटरिंग", "Pour Plan, Curing, Joints, Shuttering", listOf("conc_pour_planning", "conc_curing_water", "conc_construction_joint", "conc_shuttering_area")),
                    NestedSubcategory("sub_conc_qc", "Floor Concrete & QC Tests", "फ्लोर कंक्रीट और टेस्ट", "Building RCC, Cube Test IS 516, Yield", listOf("conc_floor_building", "conc_cube_strength", "conc_slump_yield", "conc_tube_curb"))
                )
            ),
            NestedMainCategory(
                id = "cat_steel",
                titleEn = "Steel & BBS",
                titleHi = "स्टील और BBS",
                subtitleEn = "Rebar, Stirrups, 12m Opt & Sections",
                subtitleHi = "सरिया वजन, रिंग, कटिंग और BBS",
                icon = Icons.Rounded.Architecture,
                accent = Color(0xFF0288D1),
                studioShortcutRoute = "bbs",
                studioShortcutTitle = "Open Interactive BBS Studio",
                studioShortcutSubtitle = "Shape previews, multi-dia table, PDF & Excel export",
                keywords = listOf("steel", "rebar", "bbs", "stirrup", "cutting", "coupler", "mesh", "ismb"),
                subcategories = listOf(
                    NestedSubcategory("sub_steel_weight", "Rebar Weight & Tonnage", "सरिया वजन और टन भार", "Single Bar, Multi-Dia, m³/sq.ft Norms", listOf("steel_rebar_weight", "steel_multi_dia", "steel_tonnage_density"), directRoute = "bbs", directRouteLabel = "Launch BBS Studio"),
                    NestedSubcategory("sub_steel_cut", "Cutting Opt, Stirrups & Lap", "कटिंग, रिंग, हुक और कपलर", "12m Stock Opt, Stirrups, Bend, Ld, Couplers", listOf("steel_cutting_opt", "steel_stirrup_cutting", "steel_hook_bend_ld", "steel_couplers", "steel_cover_chair")),
                    NestedSubcategory("sub_steel_members", "Column, Beam & Slab Rebar", "कॉलम, बीम और स्लैब सरिया", "IS 13920 Ties, Beam, 2-Way Slab, Mesh", listOf("steel_column_ties", "steel_beam_bars", "steel_slab_two_way", "steel_member_reinf", "steel_welded_mesh")),
                    NestedSubcategory("sub_steel_bbs", "Footing, Stair & Spiral BBS", "फुटिंग, सीढ़ी और स्पाइरल", "Footing Mesh, Stair Rebar, Helical Cage", listOf("steel_bbs_beam_column", "steel_footing_stair_rebar", "steel_stair_bbs", "steel_helical_spiral")),
                    NestedSubcategory("sub_steel_sec", "Structural Sections & Plates", "स्ट्रक्चरल स्टील और प्लेट", "ISMB, ISMC, Angle, CHS/RHS, Plate+Bolt", listOf("steel_structural_sections", "steel_plate_bolt"))
                )
            ),
            NestedMainCategory(
                id = "cat_masonry",
                titleEn = "Brick & Masonry",
                titleHi = "ईंट, ब्लॉक और चिनाई",
                subtitleEn = "Bricks, AAC, Deductions & Walls",
                subtitleHi = "ईंट, AAC ब्लॉक, कटौती और दीवार",
                icon = Icons.Rounded.GridView,
                accent = Color(0xFFD84315),
                keywords = listOf("brick", "block", "aac", "masonry", "stone", "paver", "arch", "parapet"),
                subcategories = listOf(
                    NestedSubcategory("sub_mas_wall", "Brick, AAC & Stone Walls", "ईंट, AAC और पत्थर की दीवार", "All Wall Shapes, AAC Blocks, Stone", listOf("masonry_bricks", "masonry_blocks", "masonry_stone")),
                    NestedSubcategory("sub_mas_ded", "Openings, Parapet & Arch", "कटौती, पैरापेट और मेहराब", "Door/Window Deduct, Compound, Arch", listOf("masonry_opening_deduct", "masonry_parapet_boundary", "masonry_arch_lintel")),
                    NestedSubcategory("sub_mas_pave", "Pavers & Boundary Fence", "पेवर ब्लॉक और फेंसिंग", "Interlocking Pavers & Barbed Fence", listOf("masonry_interlocking_paver", "masonry_boundary_fence"))
                )
            ),
            NestedMainCategory(
                id = "cat_foundation",
                titleEn = "Foundation & Soil",
                titleHi = "फाउंडेशन और मिट्टी",
                subtitleEn = "Footings, Pile, Excavation & SBC",
                subtitleHi = "फुटिंग, पाइल, खुदाई और SBC",
                icon = Icons.Rounded.Foundation,
                accent = Color(0xFF795548),
                keywords = listOf("foundation", "footing", "pile", "excavation", "soil", "sbc", "backfill", "fdd", "dewatering"),
                subcategories = listOf(
                    NestedSubcategory("sub_fnd_foot", "Footings, Raft & Pile Cap", "फुटिंग, राफ्ट और पाइल कैप", "11 Footing Types, Raft, Strip, Pile Cap", listOf("struct_isolated_footing", "struct_raft_strip", "soil_pile_cap_qty", "struct_pile")),
                    NestedSubcategory("sub_fnd_ret", "Retaining & Gabion Walls", "रिटेनिंग और गेबियन वॉल", "T/L/Gravity Retaining Wall & Gabion", listOf("struct_retaining_wall", "soil_gabion_retaining")),
                    NestedSubcategory("sub_fnd_exc", "Excavation, Cut-Fill & Dewater", "खुदाई, कट-फिल और पंप", "Pit, Sloped, Cut-Fill, Backfill, Dewater", listOf("earth_excavation_pit", "earth_sloped_excavation", "earth_backfill", "earth_cut_fill", "soil_dewatering")),
                    NestedSubcategory("sub_fnd_soil", "Soil SBC, Swell, Sand & FDD", "SBC, मिट्टी फूलना और FDD जांच", "SBC Pressure, Swell/Trips, OMC, Sand, FDD", listOf("soil_bearing_pressure", "soil_swell_shrink", "soil_compaction_layers", "soil_sand_fill", "soil_fdt_check", "earth_soil_bulking"))
                )
            ),
            NestedMainCategory(
                id = "cat_finishing",
                titleEn = "Finishing & Interior",
                titleHi = "फिनिशिंग और इंटीरियर",
                subtitleEn = "Plaster, Paint, Tiles, Wood & Drywall",
                subtitleHi = "प्लास्टर, पेंट, टाइल्स, लकड़ी और प्लाई",
                icon = Icons.Rounded.FormatPaint,
                accent = Color(0xFF00897B),
                keywords = listOf("plaster", "gypsum", "paint", "putty", "tile", "adhesive", "marble", "plywood", "drywall", "ceiling", "waterproofing"),
                subcategories = listOf(
                    NestedSubcategory("sub_fin_plaster", "Plaster & Gypsum/POP", "प्लास्टर और जिप्सम", "Cement Plaster & 25kg Gypsum Bags", listOf("finish_plaster", "finish_gypsum_plaster")),
                    NestedSubcategory("sub_fin_paint", "Paint, Putty & Waterproofing", "पेंट, पुट्टी और वाटरप्रूफिंग", "Putty/Primer/Paint, Waterproof, Anti-Termite", listOf("finish_paint_putty", "finish_waterproofing", "finish_anti_termite")),
                    NestedSubcategory("sub_fin_tile", "Tiles, Adhesive, Marble & Trimix", "टाइल्स, एडहेसिव और मार्बल", "Floor Tiles, Adhesive/Grout, Skirting, Marble, Trimix", listOf("finish_tiles_flooring", "finish_tile_adhesive", "finish_skirting_dado", "finish_marble_granite", "finish_trimix_epoxy")),
                    NestedSubcategory("sub_fin_int", "Ceiling, Drywall, Ply & Wood", "सीलिंग, प्लाई, लकड़ी और ग्लास", "False Ceiling, Drywall, 8×4 Ply, Timber, Doors", listOf("finish_false_ceiling", "finish_drywall_partition", "finish_plywood_laminate", "finish_wood_timber", "finish_door_window_glass", "finish_stone_cladding"))
                )
            ),
            NestedMainCategory(
                id = "cat_peb",
                titleEn = "PEB & Steel Structure",
                titleHi = "PEB और स्टील स्ट्रक्चर",
                subtitleEn = "Warehouse, Shed, Purlins & Bolts",
                subtitleHi = "वेयरहाउस, शेड, पर्लिन और बोल्ट",
                icon = Icons.Rounded.Warehouse,
                accent = Color(0xFF546E7A),
                studioShortcutRoute = "peb",
                studioShortcutTitle = "Open PEB & Warehouse Studio",
                studioShortcutSubtitle = "Portal frames, rafters, purlins, sheeting, Trimix & anchor bolts",
                keywords = listOf("peb", "warehouse", "shed", "purlin", "rafter", "bolt", "plate", "industrial"),
                subcategories = listOf(
                    NestedSubcategory("sub_peb_studio", "PEB Roof, Steel & Baseplates", "PEB छत, सेक्शन और बेसप्लेट", "PEB Roofing, Sections, Plates+Bolts, Trimix", listOf("struct_roofing", "steel_structural_sections", "steel_plate_bolt", "finish_trimix_epoxy"), directRoute = "peb", directRouteLabel = "Launch PEB Studio")
                )
            ),
            NestedMainCategory(
                id = "cat_road",
                titleEn = "Road & Infrastructure",
                titleHi = "सड़क और इन्फ्रास्ट्रक्चर",
                subtitleEn = "GSB, WMM, Asphalt, Kerb & Drain",
                subtitleHi = "GSB, WMM, डामर, कर्ब और ड्रेन",
                icon = Icons.Rounded.DirectionsBus,
                accent = Color(0xFF37474F),
                keywords = listOf("road", "highway", "gsb", "wmm", "dbm", "asphalt", "bitumen", "embankment", "kerb", "drain"),
                subcategories = listOf(
                    NestedSubcategory("sub_road_layers", "Pavement Layers & Asphalt", "रोड लेयर और डामर", "Subgrade/GSB/WMM/DBM/BC, Asphalt & Pavers", listOf("infra_road_layers", "finish_asphalt_road", "masonry_interlocking_paver")),
                    NestedSubcategory("sub_road_earth", "Road Earthwork, Kerb & Drain", "रोड मिट्टी, कर्ब और साइड ड्रेन", "Embankment, Cut & Fill, Kerbs, U-Drain", listOf("earth_embankment_road", "earth_cut_fill", "finish_road_kerb_drain", "conc_tube_curb"))
                )
            ),
            NestedMainCategory(
                id = "cat_bridge",
                titleEn = "Bridge Engineering",
                titleHi = "ब्रिज इंजीनियरिंग",
                subtitleEn = "Piers, Box Culvert, Deck & Piles",
                subtitleHi = "पियर, कल्वर्ट, डेक स्लैब और पाइल",
                icon = Icons.Rounded.Apartment,
                accent = Color(0xFF0277BD),
                studioShortcutRoute = "knowledge/Bridge Engg",
                studioShortcutTitle = "Bridge Components & IRC Guide",
                studioShortcutSubtitle = "Pier, abutment, bearings, deck slab & construction notes",
                keywords = listOf("bridge", "culvert", "pier", "deck", "pile", "retaining", "arch"),
                subcategories = listOf(
                    NestedSubcategory("sub_bridge_struct", "Culvert, Piers, Piles & Arches", "कल्वर्ट, पियर, पाइल और आर्च", "Box Culvert/Pier, Pile, Pile Cap, Wing Wall, Arch", listOf("infra_culvert_pier", "soil_pile_cap_qty", "struct_pile", "struct_raft_strip", "struct_retaining_wall", "struct_arch_dome"), directRoute = "knowledge/Bridge Engg", directRouteLabel = "Bridge Guide")
                )
            ),
            NestedMainCategory(
                id = "cat_geometry",
                titleEn = "Geometry & Shapes",
                titleHi = "ज्यामिति (2D व 3D)",
                subtitleEn = "15 2D Shapes, 12 3D Solids & RFT",
                subtitleHi = "15 2D आकार, 12 3D आयतन",
                icon = Icons.Rounded.SquareFoot,
                accent = Color(0xFF1E88E5),
                keywords = listOf("geometry", "area", "volume", "perimeter", "2d", "3d", "rft", "shape"),
                subcategories = listOf(
                    NestedSubcategory("sub_geo_shapes", "2D Shapes, 3D Solids & RFT", "2D क्षेत्रफल, 3D आयतन और RFT", "15 2D Shapes, 12 3D Solids, RFT & Triangle", listOf("basic_area", "basic_volume_surface", "basic_perimeter_rft", "site_right_angle_triangle"))
                )
            ),
            NestedMainCategory(
                id = "cat_converters",
                titleEn = "Unit Conversion",
                titleHi = "यूनिट कनवर्टर",
                subtitleEn = "Length, Land, Weight, Stress, Temp",
                subtitleHi = "लंबाई, बीघा/एकड़, वजन, दबाव",
                icon = Icons.Rounded.SwapHoriz,
                accent = Color(0xFF00ACC1),
                studioShortcutRoute = "converters",
                studioShortcutTitle = "Open Instant Multi-Unit Hub",
                studioShortcutSubtitle = "Live instant table across Length, Area/Bigha, Volume, Weight & Stress",
                keywords = listOf("converter", "unit", "feet", "meter", "bigha", "acre", "brass", "mpa", "celsius"),
                subcategories = listOf(
                    NestedSubcategory("sub_conv_civil", "Length, Land & Volume Tables", "लंबाई, जमीन और आयतन", "Bigha/Acre, Length, Volume & Brass", listOf("basic_land_converter", "basic_length_converter", "basic_volume_converter"), directRoute = "converters", directRouteLabel = "Instant Converter Hub"),
                    NestedSubcategory("sub_conv_eng", "Weight, Stress, Force & Temp", "वजन, दबाव, बल और तापमान", "MT/kg, MPa/PSI, kN, Density, Temp, Angle", listOf("conv_weight_mass", "conv_pressure_stress", "conv_force_load", "conv_temperature", "conv_density_speed", "conv_angle_slope"))
                )
            ),
            NestedMainCategory(
                id = "cat_measurements",
                titleEn = "Feet-Inch & Scientific",
                titleHi = "फीट-इंच और साइंटिफिक",
                subtitleEn = "Fractions Keypad, Trig, DMS & Scale",
                subtitleHi = "फ्रैक्शन कीपैड, त्रिकोणमिति और स्केल",
                icon = Icons.Rounded.Functions,
                accent = Color(0xFFEF6C00),
                keywords = listOf("feet", "inch", "fraction", "scientific", "trig", "dms", "scale", "slope"),
                subcategories = listOf(
                    NestedSubcategory("sub_meas_fi", "Feet-Inch & Scientific Keypads", "फीट-इंच और साइंटिफिक कीपैड", "Interactive Tape & Form Calculators", listOf("basic_fraction_calc", "site_drawing_scale", "site_slope_gradient", "site_trig_height"), directRoute = "feet_inch_calc", directRouteLabel = "Feet-Inch Keypad"),
                    NestedSubcategory("sub_meas_sci", "Scientific & Trig Calculator", "साइंटिफिक और DMS कैलकुलेटर", "Sin/Cos/Tan, DMS, Log, Memory & Tape", emptyList(), directRoute = "scientific_calc", directRouteLabel = "Open Scientific Calc")
                )
            ),
            NestedMainCategory(
                id = "cat_roof_tank",
                titleEn = "Roofing & Water Tank",
                titleHi = "छत और वॉटर टैंक",
                subtitleEn = "Gable/Hip Roof, Tank, Sump & Dome",
                subtitleHi = "स्लोप रूफ, टंकी, सम्प और डोम",
                icon = Icons.Rounded.Roofing,
                accent = Color(0xFFC62828),
                keywords = listOf("roof", "roofing", "rafter", "gable", "water tank", "sump", "dome", "rainwater"),
                subcategories = listOf(
                    NestedSubcategory("sub_rt_roof", "Sloping Roof, Dome & Terrace", "स्लोपिंग रूफ, डोम और छत", "Gable/Hip/Shed Roof, Arch/Dome, Screed", listOf("struct_roofing", "struct_arch_dome", "conc_screeding", "finish_waterproofing")),
                    NestedSubcategory("sub_rt_tank", "Water Tank, Sump & Rainwater", "वॉटर टैंक, सम्प और रेनवॉटर", "Rect/Circular Tank, Septic & Recharge Pit", listOf("util_water_tank", "util_septic_tank", "util_rainwater_harvest"))
                )
            ),
            NestedMainCategory(
                id = "cat_mep",
                titleEn = "Plumbing & Electrical",
                titleHi = "प्लंबिंग और इलेक्ट्रिकल",
                subtitleEn = "Pipes, Drain Slope, Cable & Lux",
                subtitleHi = "पाइप, ड्रेन स्लोप, केबल और लाइट",
                icon = Icons.Rounded.Bolt,
                accent = Color(0xFF039BE5),
                keywords = listOf("plumbing", "pipe", "drain", "septic", "electrical", "cable", "voltage drop", "lighting", "solar", "ac"),
                subcategories = listOf(
                    NestedSubcategory("sub_mep_plumb", "Water Pipes, Flow & Drainage", "पाइप फ्लो, ड्रेनेज और सेप्टिक", "Pipe Velocity, Drain Slope, Septic & RWH", listOf("util_plumbing_pipe", "util_septic_tank", "util_rainwater_harvest", "conc_tube_curb")),
                    NestedSubcategory("sub_mep_elec", "Electrical Load, Cable & Lighting", "इलेक्ट्रिकल लोड, केबल और लाइट", "Cable Voltage Drop, Room Lux, AC & Solar", listOf("util_voltage_drop_wire", "util_room_lighting", "util_electrical_ac_solar"))
                )
            ),
            NestedMainCategory(
                id = "cat_boq_cost",
                titleEn = "BOQ, Rate & Costing",
                titleHi = "BOQ, रेट और लागत",
                subtitleEn = "BOQ Pro, Rate Analysis & Cashflow",
                subtitleHi = "BOQ, दर विश्लेषण और बजट",
                icon = Icons.AutoMirrored.Rounded.ReceiptLong,
                accent = Color(0xFF2E7D32),
                studioShortcutRoute = "boq",
                studioShortcutTitle = "Open BOQ Pro Generator",
                studioShortcutSubtitle = "7 Project Templates, GST, Comparison, PDF & Excel",
                keywords = listOf("boq", "rate analysis", "cost", "budget", "estimate", "material rates", "cashflow"),
                subcategories = listOf(
                    NestedSubcategory("sub_cost_tools", "Rate Analysis, Cashflow & Thumb Budget", "रेट एनालिसिस और प्रोजेक्ट बजट", "CPWD DAR Rate Analysis, Cashflow, Cost/Sq.Ft", listOf("site_rate_analysis", "site_bar_progress", "site_cost_estimator"), directRoute = "boq", directRouteLabel = "BOQ Pro Studio"),
                    NestedSubcategory("sub_cost_mat", "Material & Labour Rate Master", "सामग्री और लेबर दर लाइब्रेरी", "Edit Custom Material Prices & Wastage", emptyList(), directRoute = "materials", directRouteLabel = "Open Rate Master")
                )
            ),
            NestedMainCategory(
                id = "cat_site_qc",
                titleEn = "Site Engg, QC & Testing",
                titleHi = "साइट इंजीनियरिंग और QC",
                subtitleEn = "DPR, MB Book, RL Survey & Cube/FDD",
                subtitleHi = "DPR, MB बुक, लेवल और क्यूब/FDD टेस्ट",
                icon = Icons.Rounded.Engineering,
                accent = Color(0xFFAD1457),
                studioShortcutRoute = "site_diary",
                studioShortcutTitle = "Open DPR, Measurement Book & Checklists",
                studioShortcutSubtitle = "Daily Progress Report PDF, MB N×L×B×D CSV & Safety QC",
                keywords = listOf("site", "dpr", "mb", "measurement book", "checklist", "rl", "surveying", "cube", "fdd", "safety"),
                subcategories = listOf(
                    NestedSubcategory("sub_site_surv", "Leveling, Survey & Layout", "लेवल RL, सर्वे और लेआउट", "Rise & Fall RL, 3-4-5, Bearing, Trig Elev", listOf("site_rise_fall", "site_right_angle_triangle", "site_coord_bearing", "site_trig_height", "site_slope_gradient"), directRoute = "site_diary", directRouteLabel = "Site DPR & MB Book"),
                    NestedSubcategory("sub_site_qc", "Quality Control & Lab Tests", "क्वालिटी कंट्रोल और टेस्ट", "Cube Strength IS 516, Concrete Yield, Soil FDD", listOf("conc_cube_strength", "conc_slump_yield", "soil_fdt_check", "earth_soil_bulking"))
                )
            ),
            NestedMainCategory(
                id = "cat_highrise",
                titleEn = "High-Rise & Building",
                titleHi = "भवन और हाई-राइज",
                subtitleEn = "FSI/FAR, Lift Core, Stairs & Shear",
                subtitleHi = "FSI, लिफ्ट कोर, सीढ़ी और शीयर वॉल",
                icon = Icons.Rounded.HomeWork,
                accent = Color(0xFFFB8C00),
                keywords = listOf("building", "high-rise", "fsi", "far", "carpet area", "lift", "core", "shear wall", "staircase", "ramp"),
                subcategories = listOf(
                    NestedSubcategory("sub_hr_core", "FSI/FAR, Lift Core & Shear Walls", "FSI, लिफ्ट कोर और शीयर वॉल", "Carpet/Built-Up/FSI, Lift Core, Shear Walls", listOf("highrise_area_fsi", "highrise_lift_core", "struct_wall_multi", "conc_floor_building")),
                    NestedSubcategory("sub_hr_stair", "Staircases, Ramps & Parapets", "सीढ़ी, रैंप और पैरापेट", "Straight/Dog-Legged/Spiral Stairs, 2R+G, Ramps", listOf("struct_stair_straight", "struct_stair_doglegged", "site_stair_pitch_check", "struct_misc_elements"))
                )
            ),
            NestedMainCategory(
                id = "cat_knowledge",
                titleEn = "Civil Knowledge",
                titleHi = "सिविल ज्ञान और क्विज़",
                subtitleEn = "IS Codes, Guides (EN/HI) & Quiz",
                subtitleHi = "IS कोड, हिंदी गाइड और क्विज़",
                icon = Icons.AutoMirrored.Rounded.MenuBook,
                accent = Color(0xFF6A1B9A),
                studioShortcutRoute = "knowledge",
                studioShortcutTitle = "Open Full Civil Knowledge Hub",
                studioShortcutSubtitle = "Searchable bilingual guides, bookmarks & engineering quiz",
                keywords = listOf("knowledge", "is 456", "is 13920", "bridge", "high-rise", "quiz", "hindi", "morth"),
                subcategories = listOf(
                    NestedSubcategory("sub_kn_rcc", "RCC, Foundations & High-Rise", "RCC, नींव और हाई-राइज गाइड", "IS 456 Cover, Dry Factors & High-Rise Notes", emptyList(), directRoute = "knowledge/RCC & Concrete", directRouteLabel = "Read RCC & Foundations"),
                    NestedSubcategory("sub_kn_infra", "Bridge, PEB & Roads (MoRTH)", "ब्रिज, PEB और सड़क गाइड", "Bridge Substructure, PEB Frames & Pavement", emptyList(), directRoute = "knowledge/Bridge Engg", directRouteLabel = "Read Bridge & Roads"),
                    NestedSubcategory("sub_kn_quiz", "Site Safety & Engineering Quiz", "सेफ्टी और सिविल क्विज़", "135° Hooks, PPE & Interactive MCQs", emptyList(), directRoute = "knowledge/Site QC & Safety", directRouteLabel = "Open Safety & Quiz")
                )
            ),
            NestedMainCategory(
                id = "cat_studio_projects",
                titleEn = "2D/3D CAD & Projects",
                titleHi = "2D/3D CAD और प्रोजेक्ट्स",
                subtitleEn = "Drawings, 3D Viewer, Workspaces",
                subtitleHi = "2D ड्राइंग, 3D व्यूअर और प्रोजेक्ट",
                icon = Icons.Rounded.Draw,
                accent = Color(0xFF1565C0),
                keywords = listOf("2d", "3d", "cad", "drawing", "projects", "history", "workspace", "security", "backup"),
                subcategories = listOf(
                    NestedSubcategory("sub_cad_2d", "2D Engineering CAD Studio", "2D CAD ड्राइंग स्टूडियो", "Floor Plans, Footing Layouts & Blueprint PDF", emptyList(), directRoute = "studio2d", directRouteLabel = "Launch 2D CAD"),
                    NestedSubcategory("sub_cad_3d", "3D Structural Visualization", "3D स्ट्रक्चरल व्यूअर", "Interactive 3D Framing, Orbit & Section Cut", emptyList(), directRoute = "studio3d", directRouteLabel = "Launch 3D Viewer"),
                    NestedSubcategory("sub_cad_proj", "My Site Projects", "मेरे साइट प्रोजेक्ट्स", "Workspaces, Docs, Linked Estimates & PDF", emptyList(), directRoute = "projects", directRouteLabel = "Open Projects"),
                    NestedSubcategory("sub_cad_hist", "Saved History & Security Shield", "इतिहास और सिक्योरिटी शील्ड", "Saved Calculations & Integrity Diagnostics", emptyList(), directRoute = "history", directRouteLabel = "Open Saved History")
                )
            )
        )
    }

    fun categoryById(id: String): NestedMainCategory? = categories.firstOrNull { it.id == id }

    fun subcategoryById(categoryId: String, subId: String): Pair<NestedMainCategory, NestedSubcategory>? {
        val cat = categoryById(categoryId) ?: return null
        val sub = cat.subcategories.firstOrNull { it.id == subId } ?: return null
        return cat to sub
    }

    fun toolsInSubcategory(sub: NestedSubcategory): List<CalcToolSpec> =
        sub.toolIds.mapNotNull { CalculatorRegistry.byId(it) }

    fun allAssignedToolIds(): Set<String> =
        categories.flatMap { c -> c.subcategories.flatMap { it.toolIds } }.toSet()

    fun searchSubcategories(query: String): List<Pair<NestedMainCategory, NestedSubcategory>> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        val matches = mutableListOf<Pair<NestedMainCategory, NestedSubcategory>>()
        categories.forEach { cat ->
            cat.subcategories.forEach { sub ->
                if (sub.titleEn.lowercase().contains(q) ||
                    sub.titleHi.lowercase().contains(q) ||
                    sub.subtitleEn.lowercase().contains(q)
                ) {
                    matches += cat to sub
                }
            }
        }
        return matches
    }
}

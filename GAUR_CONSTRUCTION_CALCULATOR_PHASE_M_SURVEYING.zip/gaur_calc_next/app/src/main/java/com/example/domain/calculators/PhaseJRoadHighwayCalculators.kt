package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.sqrt

/** Phase J: road and highway geometry and quantity estimators. */
object PhaseJRoadHighwayCalculators {
    private fun dim(k:String,l:String,v:String="100") = CalcFieldSpec(k,l,v,FieldUnitKind.LENGTH,LengthUnit.M)
    private fun num(k:String,l:String,v:String) = CalcFieldSpec(k,l,v,FieldUnitKind.NONE)
    private fun pct(k:String,l:String,v:String) = CalcFieldSpec(k,l,v,FieldUnitKind.PERCENT)
    private fun fmt(v:Double,p:Int)=UnitConverter.fmt(v,p)
    private fun tool(id:String,title:String,sub:String,fields:List<CalcFieldSpec>,keys:List<String>,calc:(CalcContext)->Result<CalcOutcome>) =
        CalcToolSpec(id,title,title,sub,CalcCategory.FINISHING,keys,fields=fields,compute=calc)

    fun all():List<CalcToolSpec> = listOf(
        tool("phase_j_camber", "Road Camber & Crossfall", "Crossfall height difference and slope percentage", listOf(dim("w","Carriageway width","7"),num("n","Camber ratio 1 in N","50")), listOf("camber","crossfall","road slope")) { c ->
            val w=c.lengthMeters("w")?:0.0; val n=c.doubleOrNull("n")?:0.0; val p=c.settings.decimalPrecision
            if(w<=0||n<=0) return@tool Result.failure(IllegalArgumentException("Width and camber denominator must be positive."))
            val rise=w/n; val half=(w/2)/n
            Result.success(CalcOutcome(listOf(CalcResultItem("Total edge-to-edge level difference",fmt(rise,p),"m",true),CalcResultItem("Centre-to-edge level difference",fmt(half,p),"m"),CalcResultItem("Crossfall",fmt(100/n,p),"%")),"Fall = width / N; crossfall = 100/N",listOf("Assumes a single straight crossfall across the full width."),"For crown roads, centre-to-edge fall is shown separately. Adopt camber from applicable road standard and surface type."))
        },
        tool("phase_j_superelevation", "Superelevation Calculator", "Required e from speed and curve radius", listOf(num("v","Design speed (km/h)","80"),dim("r","Horizontal curve radius","250"),num("f","Side friction factor","0.15"),pct("emax","Maximum superelevation (%)","7")), listOf("superelevation","cant","road curve")) { c ->
            val v=c.doubleOrNull("v")?:0.0; val r=c.lengthMeters("r")?:0.0; val f=c.doubleOrNull("f")?:0.0; val emax=c.doubleOrNull("emax")?:0.0; val p=c.settings.decimalPrecision
            if(v<=0||r<=0||f<0||emax<=0) return@tool Result.failure(IllegalArgumentException("Speed, radius and maximum e must be positive; friction cannot be negative."))
            val eReq=v*v/(225.0*r)-f; val e=(v*v/(225.0*r)).coerceAtMost(emax/100.0)
            Result.success(CalcOutcome(listOf(CalcResultItem("Calculated e (without friction)",fmt(v*v/(225*r)*100,p),"%",true),CalcResultItem("Design e adopted (capped)",fmt(e*100,p),"%"),CalcResultItem("Friction demand at adopted e",fmt((v*v/(225*r)-e),p),""),CalcResultItem("Raw e−f balance",fmt(eReq*100,p),"%")),"e + f = V²/(225R)",listOf("V=${fmt(v,p)} km/h, R=${fmt(r,p)} m, f=${fmt(f,p)}"),"Preliminary relationship only. Apply governing IRC/authority rules, terrain limits, transition and drainage requirements; this result is not a design approval."))
        },
        tool("phase_j_horizontal_curve", "Horizontal Circular Curve Elements", "Tangent, curve length, long chord and external distance", listOf(dim("r","Curve radius","300"),num("deg","Intersection / deflection angle (degrees)","30")), listOf("horizontal curve","simple circular curve","tangent length","long chord")) { c ->
            val r=c.lengthMeters("r")?:0.0; val d=c.doubleOrNull("deg")?:0.0; val p=c.settings.decimalPrecision
            if(r<=0||d<=0||d>=180) return@tool Result.failure(IllegalArgumentException("Radius must be positive and angle must be between 0 and 180 degrees."))
            val rad=d*PI/180; val t=r*kotlin.math.tan(rad/2); val lc=PI*r*d/180; val chord=2*r*kotlin.math.sin(rad/2); val e=r*(1/kotlin.math.cos(rad/2)-1)
            Result.success(CalcOutcome(listOf(CalcResultItem("Tangent length (T)",fmt(t,p),"m",true),CalcResultItem("Circular arc length (L)",fmt(lc,p),"m"),CalcResultItem("Long chord",fmt(chord,p),"m"),CalcResultItem("External distance",fmt(e,p),"m"),CalcResultItem("Mid-ordinate",fmt(r*(1-kotlin.math.cos(rad/2)),p),"m")),"T=R tan(Δ/2); L=πRΔ/180; LC=2R sin(Δ/2)",listOf("Angle converted to radians for trigonometric calculations."),"Simple circular curve geometry; stationing, PI coordinates and design checks are not included."))
        },
        tool("phase_j_vertical_curve", "Symmetrical Vertical Curve", "Parabolic vertical curve length and mid-ordinate", listOf(dim("l","Vertical curve length","120"),num("g1","Initial gradient (%)","1.5"),num("g2","Final gradient (%)","-1.0")), listOf("vertical curve","summit curve","valley curve","parabolic curve")) { c ->
            val l=c.lengthMeters("l")?:0.0; val g1=c.doubleOrNull("g1")?:0.0; val g2=c.doubleOrNull("g2")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0) return@tool Result.failure(IllegalArgumentException("Curve length must be positive."))
            val a=kotlin.math.abs(g2-g1); val mid=a*l/800.0; val k=l/(if(a==0.0) 1e-12 else a)
            Result.success(CalcOutcome(listOf(CalcResultItem("Algebraic grade difference",fmt(a,p),"%",true),CalcResultItem("Mid-ordinate offset",fmt(mid,p),"m"),CalcResultItem("K value (L/A)",fmt(k,p),"m/%"),CalcResultItem("Curve type",if(g2<g1) "Summit / crest" else if(g2>g1) "Valley / sag" else "Constant grade","")),"A=|g2−g1|; mid-ordinate=A×L/800",listOf("Grades are entered in percent."),"Symmetrical parabolic curve approximation. Check sight distance, comfort, drainage and governing design standards."))
        },
        tool("phase_j_transition_curve", "Transition Curve Length", "Compute length from rate of change of centrifugal acceleration", listOf(num("v","Design speed (km/h)","80"),dim("r","Circular curve radius","300"),num("c","Permissible rate C (m/s³)","0.5")), listOf("transition curve","spiral","clothoid","road curve")) { c ->
            val v=c.doubleOrNull("v")?:0.0; val r=c.lengthMeters("r")?:0.0; val rate=c.doubleOrNull("c")?:0.0; val p=c.settings.decimalPrecision
            if(v<=0||r<=0||rate<=0) return@tool Result.failure(IllegalArgumentException("Speed, radius and permissible rate must be positive."))
            val ms=v/3.6; val l=ms*ms*ms/(rate*r)
            Result.success(CalcOutcome(listOf(CalcResultItem("Transition length",fmt(l,p),"m",true),CalcResultItem("Speed",fmt(ms,p),"m/s"),CalcResultItem("Circular radius",fmt(r,p),"m")),"L = v³/(C×R), v in m/s",listOf("Convert speed: ${fmt(v,p)} / 3.6 = ${fmt(ms,p)} m/s"),"Based on rate-of-change of centrifugal acceleration only. Check superelevation runoff, relative gradient and applicable standard; adopt the governing larger length."))
        },
        tool("phase_j_road_gradient", "Road Gradient & Level Calculator", "Rise/fall, gradient and end reduced level", listOf(dim("l","Horizontal distance","250"),dim("rise","Rise (+) / fall magnitude (m)","2.5"),num("sign","Direction: 1 rise, -1 fall","1"),num("rl","Starting reduced level (m)","100.000")), listOf("road gradient","longitudinal slope","reduced level","rise fall")) { c ->
            val l=c.lengthMeters("l")?:0.0; val h=c.lengthMeters("rise")?:0.0; val s=c.doubleOrNull("sign")?:1.0; val rl=c.doubleOrNull("rl")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||h<0||s !in listOf(-1.0,1.0)) return@tool Result.failure(IllegalArgumentException("Distance must be positive, rise/fall non-negative and direction must be 1 or -1."))
            val grad=h/l*100; val end=rl+s*h
            Result.success(CalcOutcome(listOf(CalcResultItem("Gradient",fmt(grad,p),"%",true),CalcResultItem("Gradient ratio",if(grad==0.0) "Level" else "1 in ${fmt(l/h,p)}",""),CalcResultItem("End RL",fmt(end,p),"m"),CalcResultItem("Rise / fall",if(s>0) "Rise ${fmt(h,p)} m" else "Fall ${fmt(h,p)} m","")),"Gradient (%) = vertical change / horizontal distance × 100",listOf("End RL = start RL ± rise/fall"),"Uses horizontal distance; confirm sign convention and benchmark datum."))
        },
        tool("phase_j_pavement_asphalt", "Bituminous Mix Tonnage & Trucks", "Asphalt quantity from area, thickness and density", listOf(CalcFieldSpec("a","Paved area","3500",FieldUnitKind.AREA_SQ_M),dim("t","Compacted thickness","0.05"),num("rho","Compacted mix density (t/m³)","2.35"),pct("w","Wastage / handling allowance (%)","3"),num("cap","Truck payload (tonnes)","15")), listOf("asphalt","bituminous","dbm","bc","tonnage","hot mix")) { c ->
            val a=c.doubleOrNull("a")?:0.0; val t=c.lengthMeters("t")?:0.0; val rho=c.doubleOrNull("rho")?:0.0; val w=c.doubleOrNull("w")?:0.0; val cap=c.doubleOrNull("cap")?:0.0; val p=c.settings.decimalPrecision
            if(a<=0||t<=0||rho<=0||w<0||cap<=0) return@tool Result.failure(IllegalArgumentException("Area, thickness, density and truck payload must be positive; allowance non-negative."))
            val vol=a*t; val net=vol*rho; val total=net*(1+w/100); val trips=ceil(total/cap).toInt()
            Result.success(CalcOutcome(listOf(CalcResultItem("Compacted mix volume",fmt(vol,p),"m³",true),CalcResultItem("Net mix mass",fmt(net,p),"tonnes"),CalcResultItem("Mass incl. allowance",fmt(total,p),"tonnes"),CalcResultItem("Truck trips",trips.toString(),"trips")),"Mass = area × compacted thickness × density × (1+wastage%)",listOf("Volume = ${fmt(a,p)} × ${fmt(t,p)} = ${fmt(vol,p)} m³"),"Use approved job-mix formula density and actual payload restrictions. Allowance is user-defined."))
        },
        tool("phase_j_road_marking", "Road Marking Paint Quantity", "Line length, width, coats and paint consumption", listOf(dim("len","Total marking line length","2500"),dim("width","Line width","0.1"),num("rate","Paint consumption (litre/m²/coat)","0.35"),num("coats","Number of coats","2"),pct("w","Wastage (%)","5")), listOf("road marking","thermoplastic","lane line","paint quantity")) { c ->
            val l=c.lengthMeters("len")?:0.0; val w=c.lengthMeters("width")?:0.0; val rate=c.doubleOrNull("rate")?:0.0; val coats=c.doubleOrNull("coats")?:0.0; val waste=c.doubleOrNull("w")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||w<=0||rate<=0||coats<=0||coats%1.0!=0.0||waste<0) return@tool Result.failure(IllegalArgumentException("Line dimensions, consumption and whole-number coats must be positive."))
            val area=l*w*coats; val litres=area*rate*(1+waste/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Painted area incl. coats",fmt(area,p),"m²",true),CalcResultItem("Paint quantity",fmt(litres,p),"litres"),CalcResultItem("Single-coat line area",fmt(l*w,p),"m²")),"Paint = length × width × coats × consumption rate × (1+wastage%)",listOf("Area per coat = ${fmt(l*w,p)} m²"),"Consumption rate must match the selected paint/thermoplastic product data sheet; beads and surface preparation excluded."))
        },
        tool("phase_j_road_sign_board", "Road Sign Board & Post Quantity", "Sign face area and post concrete estimate", listOf(num("n","Number of signs","12"),dim("w","Sign board width","0.9"),dim("h","Sign board height","0.6"),num("posts","Posts per sign","2"),dim("fd","Post foundation depth","0.75"),dim("fw","Foundation width","0.45"),dim("fh","Foundation length","0.45")), listOf("road sign","sign board","road furniture","sign post")) { c ->
            val n=c.doubleOrNull("n")?:0.0; val w=c.lengthMeters("w")?:0.0; val h=c.lengthMeters("h")?:0.0; val posts=c.doubleOrNull("posts")?:0.0; val d=c.lengthMeters("fd")?:0.0; val fw=c.lengthMeters("fw")?:0.0; val fh=c.lengthMeters("fh")?:0.0; val p=c.settings.decimalPrecision
            if(n<=0||n%1.0!=0.0||w<=0||h<=0||posts<=0||posts%1.0!=0.0||d<=0||fw<=0||fh<=0) return@tool Result.failure(IllegalArgumentException("Counts must be positive whole numbers and dimensions positive."))
            val face=n*w*h; val pc=n*posts; val conc=pc*fw*fh*d
            Result.success(CalcOutcome(listOf(CalcResultItem("Total sign face area",fmt(face,p),"m²",true),CalcResultItem("Total support posts",pc.toInt().toString(),"posts"),CalcResultItem("Post foundation concrete",fmt(conc,p),"m³")),"Face area=N×W×H; concrete=N×posts×foundation width×length×depth",listOf("Foundations assumed one per post."),"Simplified rectangular isolated foundation estimate; post embedment, reinforcement, wind load, soil capacity and standard sign dimensions require project design."))
        },
        tool("phase_j_pavement_crossfall", "Pavement Crossfall Level Difference", "Calculate edge levels from crown or one-way crossfall", listOf(dim("w","Half carriageway width / offset","3.5"),num("cross","Crossfall (%)","2.5"),num("rl","Reference crown / high-side RL (m)","100.000"),num("side","Direction: 1 downward, -1 upward","1")), listOf("crossfall level","pavement level","road level","edge level")) { c ->
            val w=c.lengthMeters("w")?:0.0; val x=c.doubleOrNull("cross")?:0.0; val rl=c.doubleOrNull("rl")?:0.0; val s=c.doubleOrNull("side")?:1.0; val p=c.settings.decimalPrecision
            if(w<=0||x<0||s !in listOf(-1.0,1.0)) return@tool Result.failure(IllegalArgumentException("Offset must be positive, crossfall non-negative and direction 1 or -1."))
            val fall=w*x/100; val edge=rl+s*fall
            Result.success(CalcOutcome(listOf(CalcResultItem("Level difference",fmt(fall,p),"m",true),CalcResultItem("Calculated edge RL",fmt(edge,p),"m"),CalcResultItem("Crossfall",fmt(x,p),"%")),"Level difference = offset × crossfall / 100",listOf("ΔRL = ${fmt(w,p)} × ${fmt(x,p)} / 100 = ${fmt(fall,p)} m"),"Reference level is treated as crown/high-side level; choose direction sign consistently with site datum."))
        }
    )
}

package com.example.domain.calculators

import com.example.domain.units.UnitConverter
import kotlin.math.ceil

/** Phase F: practical reinforcement/BBS quantity tools. Inputs are engineering estimates, not design checks. */
object PhaseFSteelBbsCalculators {
    fun all(): List<CalcToolSpec> = listOf(
        barWeight(), straightBarBbs(), rectangularStirrupBbs(), stirrupCount(), lapQuantity(), developmentLength(), slabBbs(), columnBbs(),
        beamBbs(), stockBarPlanner()
    )

    private fun weight(diaMm: Double, lengthM: Double) = diaMm * diaMm / 162.2 * lengthM

    private fun barWeight() = CalcToolSpec(
        id="phase_f_steel_bar_weight", title="Rebar Unit Weight & Length", titleHi="सरिया वजन और लंबाई", subtitle="Diameter-based unit weight and total bar weight",
        category=CalcCategory.STEEL, keywords=listOf("steel", "bar", "weight", "kg/m", "rebar"), fields=listOf(
            CalcFieldSpec("dia","Bar Diameter (mm)","12"), CalcFieldSpec("len","Total Length (m)","100",FieldUnitKind.NONE), CalcFieldSpec("qty","Number of Bars","1",FieldUnitKind.COUNT)
        ), compute={ c -> val d=c.doubleOrNull("dia")?:0.0; val l=c.doubleOrNull("len")?:0.0; val n=c.doubleOrNull("qty")?:0.0
            if(d<=0||l<=0||n<=0) Result.failure(IllegalArgumentException("Diameter, length and count must be positive.")) else { val unit=d*d/162.2; val total=weight(d,l)*n
                Result.success(CalcOutcome(listOf(CalcResultItem("Unit Weight",UnitConverter.fmt(unit,3),"kg/m",true),CalcResultItem("Total Length",UnitConverter.fmt(l*n,2),"m"),CalcResultItem("Total Weight",UnitConverter.fmt(total,2),"kg",true)),"Weight = d²/162.2 × length × count",listOf("Ø$d mm → ${UnitConverter.fmt(unit,3)} kg/m","$l m × $n bars = ${UnitConverter.fmt(total,2)} kg"),"Nominal steel density formula; actual bar mass varies by product.")) }
        })

    private fun straightBarBbs() = CalcToolSpec(
        id="phase_f_steel_straight_bbs", title="Straight Bar BBS with End Hooks", titleHi="सीधा सरिया BBS और हुक", subtitle="Bar length, hook allowance, total length and weight",
        category=CalcCategory.STEEL, keywords=listOf("bbs", "straight bar", "hook", "cutting length"), fields=listOf(
            CalcFieldSpec("base","Base Bar Length (m)","3.0"), CalcFieldSpec("hook1","Hook 1 Allowance (mm)","0",allowZero=true), CalcFieldSpec("hook2","Hook 2 Allowance (mm)","0",allowZero=true), CalcFieldSpec("dia","Diameter (mm)","12"), CalcFieldSpec("qty","Bar Quantity","10",FieldUnitKind.COUNT)
        ), compute={ c -> val b=c.doubleOrNull("base")?:0.0; val h1=c.doubleOrNull("hook1")?:0.0; val h2=c.doubleOrNull("hook2")?:0.0; val d=c.doubleOrNull("dia")?:0.0; val n=c.doubleOrNull("qty")?:0.0
            if(b<=0||h1<0||h2<0||d<=0||n<=0) Result.failure(IllegalArgumentException("Enter valid positive bar inputs.")) else { val cut=b+(h1+h2)/1000; val total=cut*n; val kg=weight(d,total)
                Result.success(CalcOutcome(listOf(CalcResultItem("Cut Length / Bar",UnitConverter.fmt(cut,3),"m",true),CalcResultItem("Total Length",UnitConverter.fmt(total,2),"m"),CalcResultItem("Total Weight",UnitConverter.fmt(kg,2),"kg",true)),"Cut length = base + (hook allowances ÷ 1000)",listOf("$b m + ${(h1+h2)} mm = ${UnitConverter.fmt(cut,3)} m/bar","$n bars → ${UnitConverter.fmt(total,2)} m"),"Hook lengths must be entered as allowances from approved detailing.")) }
        })

    private fun rectangularStirrupBbs() = CalcToolSpec(
        id="phase_f_steel_rect_stirrup_bbs", title="Rectangular Stirrup Cutting Length", titleHi="आयताकार रिंग कटिंग लेंथ", subtitle="Clear dimensions, cover and hook allowance based cutting length",
        category=CalcCategory.STEEL, keywords=listOf("stirrup", "ring", "cut length", "bbs"), fields=listOf(
            CalcFieldSpec("b","Member Width (mm)","250"), CalcFieldSpec("d","Member Depth (mm)","450"), CalcFieldSpec("cover","Clear Cover (mm)","40"), CalcFieldSpec("hook","Total Hook Allowance (mm)","160"), CalcFieldSpec("dia","Stirrup Diameter (mm)","8"), CalcFieldSpec("qty","Number of Stirrups","40",FieldUnitKind.COUNT)
        ), compute={ c -> val b=c.doubleOrNull("b")?:0.0; val d=c.doubleOrNull("d")?:0.0; val cv=c.doubleOrNull("cover")?:0.0; val h=c.doubleOrNull("hook")?:0.0; val dia=c.doubleOrNull("dia")?:0.0; val n=c.doubleOrNull("qty")?:0.0
            if(b<=2*cv||d<=2*cv||h<0||dia<=0||n<=0) Result.failure(IllegalArgumentException("Dimensions/cover or quantity are invalid.")) else { val cut=(2*((b-2*cv)+(d-2*cv))+h)/1000; val tot=cut*n; val kg=weight(dia,tot)
                Result.success(CalcOutcome(listOf(CalcResultItem("Stirrup Cut Length",UnitConverter.fmt(cut,3),"m/each",true),CalcResultItem("Total Length",UnitConverter.fmt(tot,2),"m"),CalcResultItem("Total Weight",UnitConverter.fmt(kg,2),"kg",true)),"Cut length = 2[(b−2c)+(d−2c)] + hook allowance",listOf("Inside dimensions: ${b-2*cv} × ${d-2*cv} mm","$n rings → ${UnitConverter.fmt(tot,2)} m"),"Hook allowance is user-entered; verify shape and bend deductions against project detailing.")) }
        })

    private fun stirrupCount() = CalcToolSpec(
        id="phase_f_steel_stirrup_spacing_count", title="Stirrups Count by Spacing", titleHi="स्पेसिंग से रिंग संख्या", subtitle="Estimate ties along member length with end-zone spacing input",
        category=CalcCategory.STEEL, keywords=listOf("stirrup count", "spacing", "beam ties", "column ties"), fields=listOf(
            CalcFieldSpec("length","Member Length (m)","5.0"), CalcFieldSpec("spacing","Spacing (mm)","150"), CalcFieldSpec("extra","Extra End Ties (Nos)","2",FieldUnitKind.COUNT,allowZero=true), CalcFieldSpec("qty","Member Count","4",FieldUnitKind.COUNT)
        ), compute={ c -> val l=c.doubleOrNull("length")?:0.0; val s=c.doubleOrNull("spacing")?:0.0; val e=c.doubleOrNull("extra")?:0.0; val n=c.doubleOrNull("qty")?:0.0
            if(l<=0||s<=0||e<0||n<=0) Result.failure(IllegalArgumentException("Inputs must be positive.")) else { val per=ceil(l*1000/s).toInt()+1+e.toInt(); val all=per*n
                Result.success(CalcOutcome(listOf(CalcResultItem("Ties per Member",per.toString(),"nos",true),CalcResultItem("Total Ties",UnitConverter.fmt(all,0),"nos",true)),"Count ≈ ceil(length(mm)/spacing) + 1 + extra end ties",listOf("$l m at $s mm spacing → $per ties/member","$n members → ${all.toInt()} ties"),"Spacing layout and end-zone requirements must be taken from drawings.")) }
        })

    private fun lapQuantity() = CalcToolSpec(
        id="phase_f_steel_lap_quantity", title="Rebar Lap Length & Lap Count", titleHi="सरिया लैप लेंथ और लैप संख्या", subtitle="Calculate lap allowance from diameter and lap factor",
        category=CalcCategory.STEEL, keywords=listOf("lap", "splice", "overlap", "rebar"), fields=listOf(
            CalcFieldSpec("dia","Bar Diameter (mm)","16"), CalcFieldSpec("factor","Lap Factor (×d)","50"), CalcFieldSpec("total","Total Bar Run (m)","30"), CalcFieldSpec("stock","Stock Bar Length (m)","12")
        ), compute={ c -> val d=c.doubleOrNull("dia")?:0.0; val f=c.doubleOrNull("factor")?:0.0; val t=c.doubleOrNull("total")?:0.0; val st=c.doubleOrNull("stock")?:0.0
            if(d<=0||f<=0||t<=0||st<=0) Result.failure(IllegalArgumentException("All values must be positive.")) else { val lap=d*f/1000; val count=ceil(t/st).toInt().coerceAtLeast(1); val extra=lap*(count-1); val adj=t+extra; val kg=weight(d,adj)
                Result.success(CalcOutcome(listOf(CalcResultItem("Lap Length",UnitConverter.fmt(lap,3),"m",true),CalcResultItem("Approx. Splices",(count-1).toString(),"nos"),CalcResultItem("Lap Allowance",UnitConverter.fmt(extra,2),"m"),CalcResultItem("Total Length incl. Lap",UnitConverter.fmt(adj,2),"m",true),CalcResultItem("Steel Weight",UnitConverter.fmt(kg,2),"kg")),"Lap = diameter × factor; total allowance = lap × splice count",listOf("Ø$d mm × $f = ${UnitConverter.fmt(lap,3)} m/lap"),"Lap factor is an input assumption; actual splice location and length follow design/code and drawings.")) }
        })

    private fun developmentLength() = CalcToolSpec(
        id="phase_f_steel_development_length", title="Development Length (Ld) Estimator", titleHi="डेवलपमेंट लेंथ Ld", subtitle="Ld = φ × 4σs / (3τbd) with entered stress values",
        category=CalcCategory.STEEL, keywords=listOf("development length", "ld", "bond", "anchorage"), fields=listOf(
            CalcFieldSpec("dia","Bar Diameter (mm)","16"), CalcFieldSpec("stress","Steel Stress σs (N/mm²)","415"), CalcFieldSpec("bond","Design Bond Stress τbd (N/mm²)","1.6"), CalcFieldSpec("factor","Bond Stress Factor (plain=1, deformed=1.6)","1.6")
        ), compute={ c -> val d=c.doubleOrNull("dia")?:0.0; val s=c.doubleOrNull("stress")?:0.0; val b=c.doubleOrNull("bond")?:0.0; val f=c.doubleOrNull("factor")?:0.0
            if(d<=0||s<=0||b<=0||f<=0) Result.failure(IllegalArgumentException("Inputs must be positive.")) else { val tau=b*f; val ld=d*4*s/(3*tau); val m=ld/1000
                Result.success(CalcOutcome(listOf(CalcResultItem("Development Length Ld",UnitConverter.fmt(ld,1),"mm",true),CalcResultItem("Equivalent Length",UnitConverter.fmt(m,3),"m"),CalcResultItem("Ld / Diameter",UnitConverter.fmt(ld/d,1),"×d")),"Ld = φ × 4σs ÷ (3τbd)",listOf("Adjusted τbd = ${UnitConverter.fmt(tau,2)} N/mm²","Ld = ${UnitConverter.fmt(ld,1)} mm"),"Educational estimator only. Confirm code edition, concrete grade, bar type, stress and anchorage conditions with engineer.")) }
        })

    private fun slabBbs() = CalcToolSpec(
        id="phase_f_steel_slab_bbs", title="Slab Reinforcement BBS", titleHi="स्लैब सरिया BBS", subtitle="Main and distribution bars with cover and spacing",
        category=CalcCategory.STEEL, keywords=listOf("slab", "bbs", "main bars", "distribution"), fields=listOf(
            CalcFieldSpec("length","Slab Length (m)","5"), CalcFieldSpec("width","Slab Width (m)","4"), CalcFieldSpec("cover","Cover (mm)","25"), CalcFieldSpec("mainSpacing","Main Spacing (mm)","150"), CalcFieldSpec("distSpacing","Distribution Spacing (mm)","200"), CalcFieldSpec("mainDia","Main Dia (mm)","12"), CalcFieldSpec("distDia","Distribution Dia (mm)","8")
        ), compute={ c -> val l=c.doubleOrNull("length")?:0.0; val w=c.doubleOrNull("width")?:0.0; val cv=c.doubleOrNull("cover")?:0.0; val sm=c.doubleOrNull("mainSpacing")?:0.0; val sd=c.doubleOrNull("distSpacing")?:0.0; val dm=c.doubleOrNull("mainDia")?:0.0; val dd=c.doubleOrNull("distDia")?:0.0
            if(l<=0||w<=0||cv<0||sm<=0||sd<=0||dm<=0||dd<=0) Result.failure(IllegalArgumentException("Enter valid slab dimensions and spacings.")) else { val nMain=ceil((w*1000-2*cv)/sm).toInt()+1; val nDist=ceil((l*1000-2*cv)/sd).toInt()+1; val lm=nMain*(l-2*cv/1000); val ld=nDist*(w-2*cv/1000); val kg=weight(dm,lm)+weight(dd,ld)
                Result.success(CalcOutcome(listOf(CalcResultItem("Main Bars",nMain.toString(),"nos",true),CalcResultItem("Distribution Bars",nDist.toString(),"nos",true),CalcResultItem("Main Steel Length",UnitConverter.fmt(lm,2),"m"),CalcResultItem("Distribution Steel Length",UnitConverter.fmt(ld,2),"m"),CalcResultItem("Total Steel Weight",UnitConverter.fmt(kg,2),"kg",true)),"Bars = ceil(clear dimension / spacing) + 1; Weight = d²/162.2 × total length",listOf("Main bars run along slab length; distribution bars run along width."),"Assumes straight bars and rectangular slab. Extra top bars, laps, bends, openings and anchorage are not included.")) }
        })

    private fun columnBbs() = CalcToolSpec(
        id="phase_f_steel_column_bbs", title="Column Main Bars BBS", titleHi="कॉलम मेन सरिया BBS", subtitle="Vertical bars length and weight with lap allowance",
        category=CalcCategory.STEEL, keywords=listOf("column", "main bars", "bbs", "vertical rebar"), fields=listOf(
            CalcFieldSpec("height","Column Height (m)","3.2"), CalcFieldSpec("dia","Main Bar Diameter (mm)","16"), CalcFieldSpec("bars","Bars per Column","8",FieldUnitKind.COUNT), CalcFieldSpec("lap","Lap Allowance per Bar (m)","0.8",allowZero=true), CalcFieldSpec("columns","Number of Columns","6",FieldUnitKind.COUNT)
        ), compute={ c -> val h=c.doubleOrNull("height")?:0.0; val d=c.doubleOrNull("dia")?:0.0; val b=c.doubleOrNull("bars")?:0.0; val lap=c.doubleOrNull("lap")?:0.0; val nc=c.doubleOrNull("columns")?:0.0
            if(h<=0||d<=0||b<=0||lap<0||nc<=0) Result.failure(IllegalArgumentException("Inputs are invalid.")) else { val len=(h+lap)*b*nc; val kg=weight(d,len)
                Result.success(CalcOutcome(listOf(CalcResultItem("Total Main Bars",(b*nc).toInt().toString(),"nos",true),CalcResultItem("Total Bar Length",UnitConverter.fmt(len,2),"m"),CalcResultItem("Main Steel Weight",UnitConverter.fmt(kg,2),"kg",true)),"Total length = (height + lap allowance) × bars/column × columns",listOf("${h+lap} m/bar × ${b.toInt()} × ${nc.toInt()} = ${UnitConverter.fmt(len,2)} m"),"Does not include ties, hooks, starter bars, offsets or joint detailing.")) }
        })

    private fun beamBbs() = CalcToolSpec(
        id="phase_f_steel_beam_bbs", title="Beam Main Bars BBS", titleHi="बीम मेन सरिया BBS", subtitle="Top and bottom longitudinal bars with individual length allowances",
        category=CalcCategory.STEEL, keywords=listOf("beam", "bbs", "longitudinal bars", "top", "bottom"), fields=listOf(
            CalcFieldSpec("length","Beam Length (m)","5.0"), CalcFieldSpec("topDia","Top Bar Dia (mm)","12"), CalcFieldSpec("topQty","Top Bars","2",FieldUnitKind.COUNT), CalcFieldSpec("topExtra","Top Extra Length per Bar (m)","0",allowZero=true), CalcFieldSpec("botDia","Bottom Bar Dia (mm)","16"), CalcFieldSpec("botQty","Bottom Bars","3",FieldUnitKind.COUNT), CalcFieldSpec("botExtra","Bottom Extra Length per Bar (m)","0",allowZero=true), CalcFieldSpec("beams","Number of Beams","4",FieldUnitKind.COUNT)
        ), compute={ c -> val l=c.doubleOrNull("length")?:0.0; val td=c.doubleOrNull("topDia")?:0.0; val tq=c.doubleOrNull("topQty")?:0.0; val te=c.doubleOrNull("topExtra")?:0.0; val bd=c.doubleOrNull("botDia")?:0.0; val bq=c.doubleOrNull("botQty")?:0.0; val be=c.doubleOrNull("botExtra")?:0.0; val n=c.doubleOrNull("beams")?:0.0
            if(l<=0||td<=0||tq<=0||te<0||bd<=0||bq<=0||be<0||n<=0) Result.failure(IllegalArgumentException("Enter valid beam BBS inputs.")) else { val top=(l+te)*tq*n; val bot=(l+be)*bq*n; val kg=weight(td,top)+weight(bd,bot)
                Result.success(CalcOutcome(listOf(CalcResultItem("Top Steel Length",UnitConverter.fmt(top,2),"m"),CalcResultItem("Bottom Steel Length",UnitConverter.fmt(bot,2),"m"),CalcResultItem("Total Main Steel",UnitConverter.fmt(kg,2),"kg",true)),"Top = (beam length + extra) × count; Bottom calculated separately",listOf("Top: ${tq.toInt()} × $n beams","Bottom: ${bq.toInt()} × $n beams"),"Extra lengths are manual allowances. Does not include bent bars, stirrups, anchorage or splice design.")) }
        })

    private fun stockBarPlanner() = CalcToolSpec(
        id="phase_f_steel_stock_bar_planner", title="Stock Bars & Procurement Planner", titleHi="स्टॉक सरिया खरीद प्लानर", subtitle="Convert required length and diameter into stock bars, weight and surplus",
        category=CalcCategory.STEEL, keywords=listOf("stock", "procurement", "12m", "bars", "steel purchase"), fields=listOf(
            CalcFieldSpec("dia","Bar Diameter (mm)","16"), CalcFieldSpec("required","Required Total Length (m)","850"), CalcFieldSpec("stock","Stock Bar Length (m)","12"), CalcFieldSpec("waste","Wastage Allowance (%)","3",FieldUnitKind.PERCENT,allowZero=true)
        ), compute={ c -> val d=c.doubleOrNull("dia")?:0.0; val r=c.doubleOrNull("required")?:0.0; val s=c.doubleOrNull("stock")?:0.0; val w=c.doubleOrNull("waste")?:0.0
            if(d<=0||r<=0||s<=0||w<0) Result.failure(IllegalArgumentException("Inputs must be valid.")) else { val target=r*(1+w/100); val bars=ceil(target/s).toInt(); val buy=bars*s; val kg=weight(d,buy); val surplus=buy-r
                Result.success(CalcOutcome(listOf(CalcResultItem("Stock Bars to Buy",bars.toString(),"nos",true),CalcResultItem("Purchased Length",UnitConverter.fmt(buy,2),"m"),CalcResultItem("Approx. Purchase Weight",UnitConverter.fmt(kg,2),"kg",true),CalcResultItem("Surplus vs Net Requirement",UnitConverter.fmt(surplus,2),"m")),"Bars = ceil(required × (1 + waste%) ÷ stock length)",listOf("Waste-adjusted target = ${UnitConverter.fmt(target,2)} m","Round up to whole stock bars"),"Procurement estimate only; optimized cutting plans may reduce offcuts.")) }
        })
}

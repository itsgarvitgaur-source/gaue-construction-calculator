package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

object ConcreteAndStructuralCalculators {

    private data class MixSpec(val c: Double, val s: Double, val a: Double, val wc: Double, val note: String)

    private fun mixSpecFor(grade: String, customC: Double, customS: Double, customA: Double): MixSpec = when (grade) {
        "M5 (1:5:10)" -> MixSpec(1.0, 5.0, 10.0, 0.60, "Lean PCC leveling base")
        "M7.5 (1:4:8)" -> MixSpec(1.0, 4.0, 8.0, 0.58, "Standard PCC foundation bed")
        "M10 (1:3:6)" -> MixSpec(1.0, 3.0, 6.0, 0.55, "Heavy PCC / mass concrete")
        "M15 (1:2:4)" -> MixSpec(1.0, 2.0, 4.0, 0.52, "Nominal plain / light RCC")
        "M20 (1:1.5:3)" -> MixSpec(1.0, 1.5, 3.0, 0.50, "IS 456 min RCC grade")
        "M25 (1:1:2)" -> MixSpec(1.0, 1.0, 2.0, 0.45, "Nominal M25 RCC")
        "M30 (Design Est.)" -> MixSpec(1.0, 0.85, 1.75, 0.42, "Design mix approx. yield ~8.4 bags/m³")
        "M35 (Design Est.)" -> MixSpec(1.0, 0.75, 1.55, 0.40, "Design mix approx. yield ~9.0 bags/m³")
        "M40 (Design Est.)" -> MixSpec(1.0, 0.68, 1.40, 0.38, "High-strength design mix approx.")
        else -> MixSpec(customC.coerceAtLeast(0.1), customS.coerceAtLeast(0.1), customA.coerceAtLeast(0.1), 0.48, "Custom volumetric ratio")
    }

    private val mixOptions = listOf(
        "M5 (1:5:10)", "M7.5 (1:4:8)", "M10 (1:3:6)", "M15 (1:2:4)",
        "M20 (1:1.5:3)", "M25 (1:1:2)", "M30 (Design Est.)", "M35 (Design Est.)",
        "M40 (Design Est.)", "Custom Mix"
    )

    private fun computeConcreteQuantities(
        wetVolM3: Double,
        mix: MixSpec,
        wastagePct: Double,
        dryFactor: Double = 1.54
    ): Triple<Double, Double, Double> {
        val totalWet = wetVolM3 * (1.0 + wastagePct / 100.0)
        val dryVol = totalWet * dryFactor
        val sumParts = mix.c + mix.s + mix.a
        val cementVolM3 = dryVol * (mix.c / sumParts)
        val sandVolM3 = dryVol * (mix.s / sumParts)
        val aggVolM3 = dryVol * (mix.a / sumParts)
        // 1 bag (50 kg) cement = 0.0347 m³ (1440 kg/m³)
        val bags = cementVolM3 / 0.0347
        val sandCft = sandVolM3 * UnitConverter.CU_FT_IN_CU_M
        val aggCft = aggVolM3 * UnitConverter.CU_FT_IN_CU_M
        return Triple(bags, sandCft, aggCft)
    }

    fun all(): List<CalcToolSpec> = listOf(
        pccCalculator(),
        rccConcreteMixCalculator(),
        rmcEstimator(),
        ExpandedBeamSlabStairRoofCalculators.multiTypeSlabCalculator(),
        ExpandedBeamSlabStairRoofCalculators.multiTypeBeamCalculator(),
        ExpandedFootingAndColumnCalculators.multiTypeColumnCalculator(),
        circularColumnCalculator(),
        ExpandedFootingAndColumnCalculators.isolatedMultiTypeFooting(),
        combinedStripRaftFooting(),
        pileFoundationCalculator(),
        ExpandedFootingAndColumnCalculators.pedestalCalculator(),
        ExpandedBeamSlabStairRoofCalculators.groundPlinthTieBeamCalculator(),
        ExpandedBeamSlabStairRoofCalculators.multiTypeStaircaseCalculator(),
        dogLeggedStaircaseCalculator(),
        retainingWallCalculator(),
        ExpandedBeamSlabStairRoofCalculators.structuralWallCalculator(),
        lintelChajjaCalculator(),
        ExpandedBeamSlabStairRoofCalculators.miscStructuralElementsCalculator(),
        ExpandedBeamSlabStairRoofCalculators.roofingAndPebMultiTypeCalculator()
    )

    private fun pccCalculator() = CalcToolSpec(
        id = "conc_pcc",
        title = "PCC Bed & Material Estimator",
        titleHi = "PCC (सादा कंक्रीट) गणना",
        subtitle = "Plain Cement Concrete Volume, Cement, Sand, Aggregate & Cost",
        category = CalcCategory.CONCRETE,
        keywords = listOf("pcc", "plain concrete", "bed", "cement", "sand", "aggregate", "lean"),
        fields = listOf(
            CalcFieldSpec("l", "Length", "10", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Width", "5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("t", "Thickness", "0.10", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("mix", "PCC Grade", "M7.5 (1:4:8)", options = listOf("M5 (1:5:10)", "M7.5 (1:4:8)", "M10 (1:3:6)", "M15 (1:2:4)")),
            CalcFieldSpec("wastage", "Wastage (%)", "5", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid width."))
            val t = ctx.lengthMeters("t") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid thickness."))
            val wastage = ctx.doubleOrNull("wastage") ?: ctx.settings.defaultWastagePercent
            if (l <= 0 || w <= 0 || t <= 0 || wastage < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val mix = mixSpecFor(ctx.raw("mix"), 1.0, 4.0, 8.0)
            val wetVol = l * w * t
            val dryVol = wetVol * (1.0 + wastage / 100.0) * 1.54
            val (bags, sandCft, aggCft) = computeConcreteQuantities(wetVol, mix, wastage)
            val waterL = bags * 50.0 * mix.wc
            val cost = bags * (ctx.ratesByKeyword["cement"] ?: 390.0) +
                sandCft * (ctx.ratesByKeyword["sand"] ?: 62.0) +
                aggCft * (ctx.ratesByKeyword["aggregate"] ?: 48.0)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Wet PCC Volume", UnitConverter.fmt(wetVol, p), "m³", isPrimary = true),
                        CalcResultItem("Cement (50 kg bags)", UnitConverter.fmt(bags, p), "Bags", isPrimary = true),
                        CalcResultItem("Sand Quantity", UnitConverter.fmt(sandCft, p), "CFT"),
                        CalcResultItem("Aggregate (20/40mm)", UnitConverter.fmt(aggCft, p), "CFT"),
                        CalcResultItem("Dry Volume (×1.54)", UnitConverter.fmt(dryVol, p), "m³"),
                        CalcResultItem("Water Estimate", UnitConverter.fmt(waterL, 0), "Liters"),
                        CalcResultItem("Est. Material Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "Dry Vol = Wet Vol × (1 + Wastage%) × 1.54; Component = Dry Vol × (Part / ΣParts)",
                    steps = listOf(
                        "Wet Vol = ${UnitConverter.fmt(l, p)} × ${UnitConverter.fmt(w, p)} × ${UnitConverter.fmt(t, p)} = ${UnitConverter.fmt(wetVol, p)} m³",
                        "Mix Ratio = ${mix.c}:${mix.s}:${mix.a} (Sum = ${mix.c + mix.s + mix.a})",
                        "Cement Bags = Cement Vol / 0.0347 = ${UnitConverter.fmt(bags, p)} bags"
                    ),
                    assumptions = "1 cement bag (50 kg) = 0.0347 m³; Dry-to-wet factor = 1.54; W/C = ${mix.wc}.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun rccConcreteMixCalculator() = CalcToolSpec(
        id = "conc_rcc_mix",
        title = "Concrete Mix Design (M5 – M40 & Custom)",
        titleHi = "कंक्रीट मिक्स (M5 – M40) गणना",
        subtitle = "Cement, Sand, Aggregate, Water, Cost & Custom Mix Ratio",
        category = CalcCategory.CONCRETE,
        keywords = listOf("concrete", "mix", "m15", "m20", "m25", "m30", "m35", "m40", "cement", "sand", "aggregate"),
        fields = listOf(
            CalcFieldSpec("vol", "Wet Concrete Volume (m³)", "10", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("mix", "Concrete Grade", "M20 (1:1.5:3)", options = mixOptions),
            CalcFieldSpec("cPart", "Custom Cement Part", "1", FieldUnitKind.NONE),
            CalcFieldSpec("sPart", "Custom Sand Part", "1.5", FieldUnitKind.NONE),
            CalcFieldSpec("aPart", "Custom Aggregate Part", "3", FieldUnitKind.NONE),
            CalcFieldSpec("wastage", "Wastage (%)", "5", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val wetVol = ctx.doubleOrNull("vol") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter concrete volume."))
            val wastage = ctx.doubleOrNull("wastage") ?: ctx.settings.defaultWastagePercent
            if (wetVol <= 0 || wastage < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Volume must be positive."))
            val grade = ctx.raw("mix")
            val mix = mixSpecFor(
                grade,
                ctx.doubleOrNull("cPart") ?: 1.0,
                ctx.doubleOrNull("sPart") ?: 1.5,
                ctx.doubleOrNull("aPart") ?: 3.0
            )
            val (bags, sandCft, aggCft) = computeConcreteQuantities(wetVol, mix, wastage)
            val waterL = bags * 50.0 * mix.wc
            val cost = bags * (ctx.ratesByKeyword["cement"] ?: 390.0) +
                sandCft * (ctx.ratesByKeyword["sand"] ?: 62.0) +
                aggCft * (ctx.ratesByKeyword["aggregate"] ?: 48.0)

            val warnings = if (grade.contains("M30") || grade.contains("M35") || grade.contains("M40")) {
                listOf("M30+ requires laboratory Mix Design per IS 10262. Values shown are preliminary batch estimates.")
            } else emptyList()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Cement (50 kg bags)", UnitConverter.fmt(bags, p), "Bags", isPrimary = true),
                        CalcResultItem("Cement Weight", UnitConverter.fmt(bags * 50.0, p), "kg"),
                        CalcResultItem("Fine Aggregate (Sand)", UnitConverter.fmt(sandCft, p), "CFT", isPrimary = true),
                        CalcResultItem("Coarse Aggregate", UnitConverter.fmt(aggCft, p), "CFT", isPrimary = true),
                        CalcResultItem("Water (W/C=${mix.wc})", UnitConverter.fmt(waterL, 0), "Liters"),
                        CalcResultItem("Est. Material Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "Dry Vol = Wet Vol × (1 + Wastage%) × 1.54; Bags = V_cement / 0.0347",
                    steps = listOf(
                        "Effective Wet Vol = ${UnitConverter.fmt(wetVol * (1 + wastage / 100.0), p)} m³",
                        "Dry Vol = ${UnitConverter.fmt(wetVol * (1 + wastage / 100.0) * 1.54, p)} m³",
                        "Ratio = ${mix.c}:${mix.s}:${mix.a} (${mix.note})"
                    ),
                    assumptions = "Dry bulk density of cement = 1440 kg/m³ (1 bag = 0.0347 m³). ${mix.note}.",
                    warnings = warnings,
                    estimatedCost = cost
                )
            )
        }
    )

    private fun rmcEstimator() = CalcToolSpec(
        id = "conc_rmc",
        title = "Ready-Mix Concrete (RMC) & Transit Mixer",
        titleHi = "रेडी-मिक्स कंक्रीट (RMC) अनुमान",
        subtitle = "Order Volume, Transit Mixer Loads & Pump Wastage Allowance",
        category = CalcCategory.CONCRETE,
        keywords = listOf("rmc", "ready mix", "transit mixer", "pump", "concrete"),
        fields = listOf(
            CalcFieldSpec("vol", "Net Structural Volume (m³)", "32.5", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("wastage", "Pump & Pour Wastage (%)", "3", FieldUnitKind.PERCENT, allowZero = true),
            CalcFieldSpec("truck", "Transit Mixer Capacity (m³)", "6", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("rate", "RMC Rate per m³", "5400", FieldUnitKind.RATE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val vol = ctx.doubleOrNull("vol") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter volume."))
            val wastage = ctx.doubleOrNull("wastage") ?: 3.0
            val truck = ctx.doubleOrNull("truck") ?: 6.0
            val rate = ctx.doubleOrNull("rate") ?: 5400.0
            if (vol <= 0 || truck <= 0 || wastage < 0 || rate < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val orderVol = vol * (1.0 + wastage / 100.0)
            val loads = ceil(orderVol / truck).toInt()
            val totalCost = orderVol * rate
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Order Volume (with Wastage)", UnitConverter.fmt(orderVol, p), "m³", isPrimary = true),
                        CalcResultItem("Transit Mixer Trips", "$loads", "Trucks", isPrimary = true),
                        CalcResultItem("Volume in CFT", UnitConverter.fmt(orderVol * UnitConverter.CU_FT_IN_CU_M, p), "CFT"),
                        CalcResultItem("Total RMC Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(totalCost, 0)}", "")
                    ),
                    formula = "Order Vol = Net Vol × (1 + Wastage%); Trucks = ⌈Order Vol / Capacity⌉",
                    steps = listOf(
                        "Order Vol = ${UnitConverter.fmt(vol, p)} × (1 + $wastage%) = ${UnitConverter.fmt(orderVol, p)} m³",
                        "Mixer Trips = ceil(${UnitConverter.fmt(orderVol, p)} / $truck) = $loads"
                    ),
                    assumptions = "Includes pipeline/chute dead-volume wastage allowance.",
                    estimatedCost = totalCost
                )
            )
        }
    )

    private fun circularColumnCalculator() = CalcToolSpec(
        id = "struct_circ_column",
        title = "Circular RCC Column Estimator",
        titleHi = "गोलाकार RCC कॉलम",
        subtitle = "Circular Pier / Column Volume & Reinforcement Estimate",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        keywords = listOf("circular", "column", "pier", "round", "rcc"),
        fields = listOf(
            CalcFieldSpec("dia", "Column Diameter (D)", "450", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("h", "Column Height (H)", "3.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("count", "Number of Columns", "4", FieldUnitKind.COUNT),
            CalcFieldSpec("steelPct", "Est. Steel %", "2.0", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val dia = ctx.lengthMeters("dia") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter diameter."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val n = ctx.doubleOrNull("count") ?: 1.0
            val sp = ctx.doubleOrNull("steelPct") ?: 2.0
            if (dia <= 0 || h <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val r = dia / 2.0
            val vol = PI * r * r * h * n
            val steelKg = vol * (sp / 100.0) * 7850.0
            val mix = mixSpecFor("M25 (1:1:2)", 1.0, 1.0, 2.0)
            val (bags, sandCft, aggCft) = computeConcreteQuantities(vol, mix, ctx.settings.defaultWastagePercent)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Concrete Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Preliminary Steel", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true),
                        CalcResultItem("Cement (M25)", UnitConverter.fmt(bags, p), "Bags"),
                        CalcResultItem("Sand / Aggregate", "${UnitConverter.fmt(sandCft, 1)} / ${UnitConverter.fmt(aggCft, 1)}", "CFT")
                    ),
                    formula = "V = π × (D/2)² × H × N",
                    steps = listOf("Area = π×(${UnitConverter.fmt(r, 3)})² = ${UnitConverter.fmt(PI * r * r, 4)} m²"),
                    assumptions = "Preliminary quantity estimate only; verify longitudinal min 6 bars & helical ties per IS 456."
                )
            )
        }
    )

    private fun combinedStripRaftFooting() = CalcToolSpec(
        id = "struct_raft_strip",
        title = "Raft / Mat, Pile Cap & Strip",
        titleHi = "राफ्ट / मैट, पाइल कैप और स्ट्रिप नींव",
        subtitle = "Raft / Mat Foundation, Pile Cap, Combined Beam-Raft & Strip Footing",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "type",
        keywords = listOf("raft", "mat", "pile cap", "combined", "strip", "foundation", "footing"),
        fields = listOf(
            CalcFieldSpec("type", "Foundation Type", "Raft / Mat Foundation", options = listOf("Raft / Mat Foundation", "Pile Cap (Rect / Hex)", "Combined Slab-Beam Raft", "Continuous Strip Footing")),
            CalcFieldSpec("l", "Length (L)", "12.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Width (W)", "9.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("t", "Slab / Cap Depth (D)", "0.45", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("count", "Number of Caps / Units", "1", FieldUnitKind.COUNT, visibleWhen = { it["type"] == "Pile Cap (Rect / Hex)" }),
            CalcFieldSpec("steelPct", "Est. Steel % (Top + Bottom Mesh)", "1.0", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("type").ifBlank { "Raft / Mat Foundation" }
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val t = ctx.lengthMeters("t") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter thickness."))
            val n = if (type == "Pile Cap (Rect / Hex)") (ctx.doubleOrNull("count") ?: 1.0).coerceAtLeast(1.0) else 1.0
            val sp = ctx.doubleOrNull("steelPct") ?: 1.0
            if (l <= 0 || w <= 0 || t <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val vol = l * w * t * (if (type == "Combined Slab-Beam Raft") 1.18 else 1.0) * n
            val fw = 2.0 * (l + w) * t * n
            val pccVol = (l + 0.3) * (w + 0.3) * 0.10 * n
            val steelKg = vol * (sp / 100.0) * 7850.0
            val mix = mixSpecFor("M25 (1:1:2)", 1.0, 1.0, 2.0)
            val (bags, sandCft, aggCft) = computeConcreteQuantities(vol, mix, ctx.settings.defaultWastagePercent)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("RCC Concrete Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Edge Formwork Area", UnitConverter.fmt(fw, p), "m²", isPrimary = true),
                        CalcResultItem("Preliminary Steel Est.", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true),
                        CalcResultItem("PCC Blinding (100mm)", UnitConverter.fmt(pccVol, p), "m³"),
                        CalcResultItem("Cement (M25)", UnitConverter.fmt(bags, p), "Bags"),
                        CalcResultItem("Sand / Aggregate", "${UnitConverter.fmt(sandCft, 1)} / ${UnitConverter.fmt(aggCft, 1)}", "CFT")
                    ),
                    formula = "V = L × W × D × N; Edge Formwork = 2(L + W) × D",
                    steps = listOf("Type: $type | Footprint = ${UnitConverter.fmt(l * w * n, p)} m²; Concrete = ${UnitConverter.fmt(vol, p)} m³"),
                    assumptions = "Preliminary estimate only; raft/pile cap punching & flexure require soil bearing & geotechnical design."
                )
            )
        }
    )

    private fun pileFoundationCalculator() = CalcToolSpec(
        id = "struct_pile",
        title = "Pile Foundation (Bored / Under-Reamed / Driven)",
        titleHi = "पाइल फाउंडेशन गणना",
        subtitle = "Bored Cast-in-Situ, Under-Reamed Bulb & Driven Precast Square Pile",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "pileType",
        keywords = listOf("pile", "foundation", "bored", "under-reamed", "driven", "deep foundation"),
        fields = listOf(
            CalcFieldSpec("pileType", "Pile Type", "Bored Cast-in-Situ Pile", options = listOf("Bored Cast-in-Situ Pile", "Under-Reamed Pile (Bulb)", "Driven Precast Square Pile")),
            CalcFieldSpec(
                key = "dia", label = "Pile Diameter / Side (D)", defaultValue = "500",
                unitKind = FieldUnitKind.LENGTH, defaultLengthUnit = LengthUnit.MM,
                dynamicLabel = { m -> if (m["pileType"] == "Driven Precast Square Pile") "Square Pile Side (B)" else "Pile Shaft Diameter (D)" }
            ),
            CalcFieldSpec("depth", "Design Pile Length", "12.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("cutoff", "Cut-off / Chipping Allowance", "0.6", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true),
            CalcFieldSpec("count", "Number of Piles", "16", FieldUnitKind.COUNT),
            CalcFieldSpec("overbreak", "Borehole Overbreak / Wastage (%)", "8", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("pileType")
            val dia = ctx.lengthMeters("dia") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter diameter."))
            val depth = ctx.lengthMeters("depth") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter depth."))
            val cutoff = ctx.lengthMeters("cutoff") ?: 0.6
            val n = ctx.doubleOrNull("count") ?: 1.0
            val ob = ctx.doubleOrNull("overbreak") ?: 8.0
            if (dia <= 0 || depth <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val shaftArea = if (type == "Driven Precast Square Pile") dia * dia else PI * (dia / 2.0) * (dia / 2.0)
            val bulbExtra = if (type == "Under-Reamed Pile (Bulb)") 0.14 * PI * dia * dia * dia * 4.0 else 0.0
            val neatVol = (shaftArea * (depth + cutoff) + bulbExtra) * n
            val pourVol = neatVol * (1.0 + ob / 100.0)
            val steelKg = neatVol * 0.015 * 7850.0
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Pour Concrete (w/ Overbreak)", UnitConverter.fmt(pourVol, p), "m³", isPrimary = true),
                        CalcResultItem("Neat Concrete Volume", UnitConverter.fmt(neatVol, p), "m³"),
                        CalcResultItem("Est. Pile Cage Steel (~1.5%)", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true)
                    ),
                    formula = if (type == "Driven Precast Square Pile") "V = N × B² × (L + Cut-off)" else "V_pour = N × π(D/2)² × (L + Cut-off) × (1 + Overbreak%)",
                    steps = listOf("Type: $type | Effective Pour Depth = ${UnitConverter.fmt(depth + cutoff, p)} m; Neat Vol = ${UnitConverter.fmt(neatVol, p)} m³"),
                    assumptions = "Tremie concrete typically M25–M35 with 6–10% borehole overbreak allowance."
                )
            )
        }
    )

    private fun dogLeggedStaircaseCalculator() = CalcToolSpec(
        id = "struct_stair_doglegged",
        title = "Dog-Legged Staircase (with Landing)",
        titleHi = "डॉग-लेग्ड सीढ़ी और लैंडिंग",
        subtitle = "2 Flights + Mid-Landing Concrete & Steps Geometry",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        keywords = listOf("dog-legged", "staircase", "landing", "flight"),
        fields = listOf(
            CalcFieldSpec("floorH", "Floor-to-Floor Height", "3.2", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("riser", "Riser Height", "150", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("tread", "Tread Width", "275", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("flightW", "Single Flight Width", "1.1", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("landL", "Landing Length (2 Flights + Gap)", "2.3", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("landW", "Landing Width", "1.2", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("waist", "Waist & Landing Thickness", "150", FieldUnitKind.LENGTH, LengthUnit.MM)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val fh = ctx.lengthMeters("floorH") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val r = ctx.lengthMeters("riser") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter riser."))
            val t = ctx.lengthMeters("tread") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter tread."))
            val fw = ctx.lengthMeters("flightW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter flight width."))
            val ll = ctx.lengthMeters("landL") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter landing length."))
            val lw = ctx.lengthMeters("landW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter landing width."))
            val waist = ctx.lengthMeters("waist") ?: 0.15
            if (fh <= 0 || r <= 0 || t <= 0 || fw <= 0 || ll <= 0 || lw <= 0 || waist <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }
            val totalRisers = max(2, (fh / r).roundToInt())
            val actualR = fh / totalRisers
            val flight1Risers = totalRisers / 2
            val flight2Risers = totalRisers - flight1Risers
            val treadsPerFlight = max(1, flight1Risers - 1)
            val runPerFlight = treadsPerFlight * t
            val inclinedLen = sqrt((fh / 2.0) * (fh / 2.0) + runPerFlight * runPerFlight)
            val flightsWaistVol = 2.0 * inclinedLen * fw * waist
            val stepsVol = (flight1Risers + flight2Risers - 2).coerceAtLeast(1) * 0.5 * actualR * t * fw
            val landingVol = ll * lw * waist
            val totalVol = flightsWaistVol + stepsVol + landingVol
            val steelKg = totalVol * 0.011 * 7850.0
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Preliminary Steel (~1.1%)", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true),
                        CalcResultItem("Flight Risers", "$flight1Risers + $flight2Risers", "Risers"),
                        CalcResultItem("Mid-Landing Volume", UnitConverter.fmt(landingVol, p), "m³"),
                        CalcResultItem("Flight Run Length", UnitConverter.fmt(runPerFlight, p), "m")
                    ),
                    formula = "V_total = 2×(L_inc×W_f×t) + V_steps + (L_land×W_land×t)",
                    steps = listOf(
                        "Waist Slabs = ${UnitConverter.fmt(flightsWaistVol, p)} m³",
                        "Steps = ${UnitConverter.fmt(stepsVol, p)} m³",
                        "Mid-Landing = ${UnitConverter.fmt(landingVol, p)} m³"
                    ),
                    assumptions = "Symmetric two-flight dog-legged stair with mid-landing."
                )
            )
        }
    )

    private fun retainingWallCalculator() = CalcToolSpec(
        id = "struct_retaining_wall",
        title = "Retaining Wall (Cantilever / Gravity / L)",
        titleHi = "रिटेनिंग वॉल (सभी प्रकार)",
        subtitle = "Cantilever T-Wall, L-Shaped, Gravity Trapezoidal & Counterfort Retaining Wall",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "retType",
        keywords = listOf("retaining wall", "cantilever", "gravity", "counterfort", "l-shaped", "stem", "heel", "toe"),
        fields = listOf(
            CalcFieldSpec("retType", "Retaining Wall Type", "Cantilever T-Wall", options = listOf("Cantilever T-Wall", "L-Shaped Retaining Wall", "Gravity Trapezoidal Wall", "Counterfort Retaining Wall")),
            CalcFieldSpec("len", "Wall Length", "15.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Stem Height (above Base)", "3.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("topW", "Stem Top Thickness", "200", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("botW", "Stem Base Thickness", "400", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("baseW", "Base Slab Width (Toe+Heel)", "2.4", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("baseT", "Base Slab Thickness", "400", FieldUnitKind.LENGTH, LengthUnit.MM)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val type = ctx.raw("retType").ifBlank { "Cantilever T-Wall" }
            val len = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val topW = ctx.lengthMeters("topW") ?: 0.2
            val botW = ctx.lengthMeters("botW") ?: 0.4
            val baseW = ctx.lengthMeters("baseW") ?: 2.4
            val baseT = ctx.lengthMeters("baseT") ?: 0.4
            if (len <= 0 || h <= 0 || topW <= 0 || botW <= 0 || baseW <= 0 || baseT <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid dimensions."))
            }
            val stemVol = if (type == "Gravity Trapezoidal Wall") 0.5 * (topW + baseW) * h * len else 0.5 * (topW + botW) * h * len
            val baseVol = if (type == "Gravity Trapezoidal Wall") 0.0 else baseW * baseT * len
            val counterfortExtra = if (type == "Counterfort Retaining Wall") 1.12 else 1.0
            val totalVol = (stemVol + baseVol) * counterfortExtra
            val fw = 2.0 * h * len + 2.0 * baseT * len
            val steelKg = if (type == "Gravity Trapezoidal Wall") 0.0 else totalVol * 0.011 * 7850.0
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Wall Formwork Area", UnitConverter.fmt(fw, p), "m²", isPrimary = true),
                        CalcResultItem("Stem Concrete", UnitConverter.fmt(stemVol, p), "m³"),
                        CalcResultItem("Base Slab Concrete", UnitConverter.fmt(baseVol, p), "m³"),
                        CalcResultItem("Preliminary Steel", UnitConverter.fmt(steelKg, p), "kg")
                    ),
                    formula = "V = [0.5×(t_top+t_bot)×H + B_base×t_base] × L",
                    steps = listOf("Type: $type | Stem = ${UnitConverter.fmt(stemVol, p)} m³, Base = ${UnitConverter.fmt(baseVol, p)} m³"),
                    assumptions = "Quantity estimate only; overturning, sliding & bearing pressure must be checked per IS 456 / geotechnical report."
                )
            )
        }
    )

    private fun lintelChajjaCalculator() = CalcToolSpec(
        id = "struct_lintel",
        title = "Lintel & Chajja (Sunshade)",
        titleHi = "लिंटल और छज्जा गणना",
        subtitle = "Plain Lintel Beam, Lintel + Chajja Sunshade & Canopy Lintel",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "lintelType",
        keywords = listOf("lintel", "chajja", "sunshade", "window", "door"),
        fields = listOf(
            CalcFieldSpec("lintelType", "Lintel Type", "Lintel + Chajja Sunshade", options = listOf("Plain Lintel Beam", "Lintel + Chajja Sunshade", "Continuous Sill/Lintel Band")),
            CalcFieldSpec("openW", "Opening / Band Width", "1.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("bearing", "Wall Bearing (Each Side)", "150", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("lW", "Lintel Width", "230", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("lD", "Lintel Depth", "150", FieldUnitKind.LENGTH, LengthUnit.MM),
            CalcFieldSpec("chajjaProj", "Chajja Projection", "0.6", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true, visibleWhen = { it["lintelType"] != "Plain Lintel Beam" && it["lintelType"] != "Continuous Sill/Lintel Band" }),
            CalcFieldSpec("count", "Number of Openings", "6", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val ow = ctx.lengthMeters("openW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter opening width."))
            val br = ctx.lengthMeters("bearing") ?: 0.15
            val lw = ctx.lengthMeters("lW") ?: 0.23
            val ld = ctx.lengthMeters("lD") ?: 0.15
            val cp = ctx.lengthMeters("chajjaProj") ?: 0.0
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (ow <= 0 || lw <= 0 || ld <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid dimensions."))
            val totalLen = ow + 2.0 * br
            val lintelVol = totalLen * lw * ld * n
            val chajjaVol = if (cp > 0) totalLen * cp * 0.085 * n else 0.0
            val totalVol = lintelVol + chajjaVol
            val steelKg = totalVol * 0.012 * 7850.0
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Lintel Length (w/ Bearing)", UnitConverter.fmt(totalLen, p), "m"),
                        CalcResultItem("Preliminary Steel", UnitConverter.fmt(steelKg, p), "kg", isPrimary = true)
                    ),
                    formula = "L_lintel = W_open + 2×Bearing; V_chajja = L × Proj × 0.085m",
                    steps = listOf("Lintel = ${UnitConverter.fmt(lintelVol, p)} m³, Chajja = ${UnitConverter.fmt(chajjaVol, p)} m³"),
                    assumptions = "Average Chajja thickness assumed 85 mm (100 mm at root tapering to 70 mm at tip)."
                )
            )
        }
    )
}

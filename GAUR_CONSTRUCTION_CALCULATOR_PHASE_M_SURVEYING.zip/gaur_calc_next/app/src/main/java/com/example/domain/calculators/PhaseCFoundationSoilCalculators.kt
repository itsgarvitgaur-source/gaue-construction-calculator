package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.ceil

object PhaseCFoundationSoilCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        soilBearingPressureCalculator(),
        soilSwellShrinkageCalculator(),
        dewateringPumpCalculator(),
        compactionLiftsCalculator(),
        pileCapDetailCalculator(),
        plinthSandFillingCalculator(),
        fieldDryDensityCheckCalculator(),
        gabionWallStoneCalculator()
    )

    private fun soilBearingPressureCalculator() = CalcToolSpec(
        id = "soil_bearing_pressure",
        title = "Footing Soil Bearing Pressure Check",
        titleHi = "नींव मिट्टी बेयरिंग प्रेशर जांच (SBC)",
        subtitle = "Gross & Net Bearing Pressure vs Soil Safe Bearing Capacity (kPa)",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        keywords = listOf("sbc", "bearing pressure", "footing", "soil", "foundation", "kpa"),
        fields = listOf(
            CalcFieldSpec("loadKn", "Unfactored Column Axial Load (kN)", "650", FieldUnitKind.NONE),
            CalcFieldSpec("fl", "Footing Length (L)", "2.2", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("fb", "Footing Width (B)", "2.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("depth", "Foundation Depth Below GL", "1.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("sbcKpa", "Safe Bearing Capacity (SBC kN/m²)", "180", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val pKn = ctx.doubleOrNull("loadKn") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter axial load."))
            val l = ctx.lengthMeters("fl") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter footing L."))
            val b = ctx.lengthMeters("fb") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter footing B."))
            val df = ctx.lengthMeters("depth") ?: 1.5
            val sbc = ctx.doubleOrNull("sbcKpa") ?: 180.0
            if (pKn <= 0 || l <= 0 || b <= 0 || df <= 0 || sbc <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All values must be positive."))
            }
            val area = l * b
            val selfAndSoilWeightKn = area * (0.45 * 25.0 + (df - 0.45).coerceAtLeast(0.0) * 18.0)
            val qGross = (pKn + selfAndSoilWeightKn) / area
            val qNet = pKn / area
            val utilPct = (qGross / sbc) * 100.0
            val status = if (qGross <= sbc) "SAFE (${UnitConverter.fmt(utilPct, 1)}% of SBC)" else "EXCEEDS SBC — Increase Footing Size"
            val warnings = if (qGross > sbc) listOf("Bearing pressure ${UnitConverter.fmt(qGross, 1)} kPa exceeds SBC $sbc kPa. Geotechnical & structural redesign required.") else emptyList()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Gross Bearing Pressure (q_gross)", UnitConverter.fmt(qGross, p), "kPa (kN/m²)", isPrimary = true),
                        CalcResultItem("SBC Utilization Check", status, "", isPrimary = true),
                        CalcResultItem("Net Column Pressure (P / A)", UnitConverter.fmt(qNet, p), "kPa"),
                        CalcResultItem("Footing Plan Area", UnitConverter.fmt(area, p), "m²")
                    ),
                    formula = "q_gross = (P + SelfWt + BackfillWt) / (L × B); Check q_gross ≤ SBC",
                    steps = listOf("Area = ${UnitConverter.fmt(area, p)} m²; Overburden+Footing = ${UnitConverter.fmt(selfAndSoilWeightKn, 1)} kN"),
                    assumptions = "Uniform concentric axial load without biaxial bending moments; concrete 25 kN/m³, compacted soil 18 kN/m³.",
                    warnings = warnings
                )
            )
        }
    )

    private fun soilSwellShrinkageCalculator() = CalcToolSpec(
        id = "soil_swell_shrink",
        title = "Soil Swell, Shrinkage & Hauling Trips",
        titleHi = "मिट्टी फूलना (Swell), संकुचन और डम्पर ट्रिप",
        subtitle = "Bank (BCY) → Loose (LCY) → Compacted (CCY) & Dumper Trips",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("swell", "shrinkage", "soil", "bank", "loose", "compacted", "dumper", "trips"),
        fields = listOf(
            CalcFieldSpec("bankVol", "In-Situ Bank Soil Volume (m³)", "500.0", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("swellPct", "Excavation Swell Factor (%)", "25", FieldUnitKind.PERCENT),
            CalcFieldSpec("shrinkPct", "Compaction Shrinkage from Bank (%)", "12", FieldUnitKind.PERCENT),
            CalcFieldSpec("dumperM3", "Dumper / Tipper Body Vol (m³)", "14.0", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val bank = ctx.doubleOrNull("bankVol") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter bank volume."))
            val sw = (ctx.doubleOrNull("swellPct") ?: 25.0).coerceIn(0.0, 100.0)
            val sh = (ctx.doubleOrNull("shrinkPct") ?: 12.0).coerceIn(0.0, 50.0)
            val cap = ctx.doubleOrNull("dumperM3") ?: 14.0
            if (bank <= 0 || cap <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Bank volume & dumper capacity must be positive."))

            val looseVol = bank * (1.0 + sw / 100.0)
            val compactedVol = bank * (1.0 - sh / 100.0)
            val trips = ceil(looseVol / cap).toInt()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Loose Volume to Haul", UnitConverter.fmt(looseVol, p), "m³", isPrimary = true),
                        CalcResultItem("Dumper / Tipper Trips", "$trips", "trips (${UnitConverter.fmt(cap, 1)} m³)", isPrimary = true),
                        CalcResultItem("Compacted Fill Volume", UnitConverter.fmt(compactedVol, p), "m³"),
                        CalcResultItem("Load Factor (Bank / Loose)", UnitConverter.fmt(bank / looseVol, 3), "")
                    ),
                    formula = "Loose = Bank × (1 + Swell%); Compacted = Bank × (1 − Shrink%); Trips = ceil(Loose / Cap)",
                    steps = listOf("Loose = $bank × ${1.0 + sw / 100.0} = ${UnitConverter.fmt(looseVol, p)} m³ → $trips trips"),
                    assumptions = "Typical clay/murrum swell 20–30%, shrinkage 10–15% under roller compaction."
                )
            )
        }
    )

    private fun dewateringPumpCalculator() = CalcToolSpec(
        id = "soil_dewatering",
        title = "Excavation Dewatering Pump Estimator",
        titleHi = "नींव जल निकासी पंप क्षमता और समय",
        subtitle = "Pit Water Storage + Seepage Inflow vs Pump Flow & Runtime",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("dewatering", "pump", "water", "seepage", "excavation", "foundation"),
        fields = listOf(
            CalcFieldSpec("pitL", "Excavation Pit Length", "18.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("pitW", "Excavation Pit Width", "12.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("waterD", "Standing Water Depth", "0.8", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("inflowLpm", "Groundwater Seepage Inflow (L/min)", "180", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("pumpLpm", "Selected Pump Discharge (L/min)", "500", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("pitL") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("pitW") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val d = ctx.lengthMeters("waterD") ?: 0.8
            val inflow = (ctx.doubleOrNull("inflowLpm") ?: 180.0).coerceAtLeast(0.0)
            val pump = ctx.doubleOrNull("pumpLpm") ?: 500.0
            if (l <= 0 || w <= 0 || d < 0 || pump <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid dimensions or pump rate."))
            }
            val storedL = l * w * d * 1000.0
            val pumpsMin = kotlin.math.floor(inflow / pump).toInt() + 1
            val netRate = (pumpsMin * pump - inflow).coerceAtLeast(1.0)
            val drainHrs = (storedL / netRate) / 60.0

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Standing Water Volume", UnitConverter.fmt(storedL, 0), "Liters (${UnitConverter.fmt(storedL / 1000.0, p)} m³)", isPrimary = true),
                        CalcResultItem("Min. Pumps to Overcome Seepage", "$pumpsMin", "pumps (@${pump.toInt()} LPM)", isPrimary = true),
                        CalcResultItem("Est. Initial Drain Time", UnitConverter.fmt(drainHrs, p), "hours")
                    ),
                    formula = "Stored L = L × W × D × 1000; Net Rate = (N × PumpLPM) − SeepageLPM",
                    steps = listOf("Storage = ${UnitConverter.fmt(storedL, 0)} L; Net rate = ${UnitConverter.fmt(netRate, 0)} L/min"),
                    assumptions = "Assumes continuous pump head efficiency; add 1 standby pump for critical excavations."
                )
            )
        }
    )

    private fun compactionLiftsCalculator() = CalcToolSpec(
        id = "soil_compaction_layers",
        title = "Earth Compaction Lifts & OMC Water",
        titleHi = "मिट्टी रोलिंग लेयर और OMC पानी की मात्रा",
        subtitle = "Loose Lift Count, Moisture Deficit Water Tankers & Roller Time",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("compaction", "omc", "roller", "lifts", "subgrade", "water"),
        fields = listOf(
            CalcFieldSpec("area", "Compaction Area (m²)", "1500", FieldUnitKind.AREA_SQ_M),
            CalcFieldSpec("fillDepth", "Total Compacted Fill Depth", "0.9", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("liftMm", "Compacted Lift Thickness (mm)", "200", FieldUnitKind.NONE),
            CalcFieldSpec("curMoist", "Natural Soil Moisture (%)", "6.0", FieldUnitKind.PERCENT, allowZero = true),
            CalcFieldSpec("omcMoist", "Target OMC Moisture (%)", "12.0", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter area."))
            val d = ctx.lengthMeters("fillDepth") ?: 0.9
            val lift = ctx.doubleOrNull("liftMm") ?: 200.0
            val curM = (ctx.doubleOrNull("curMoist") ?: 6.0).coerceAtLeast(0.0)
            val omc = ctx.doubleOrNull("omcMoist") ?: 12.0
            if (area <= 0 || d <= 0 || lift <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("All values must be positive."))

            val lifts = ceil((d * 1000.0) / lift).toInt()
            val volM3 = area * d
            val drySoilTonnes = volM3 * 1.75 // avg dry density ~1.75 t/m³
            val moistureDelta = (omc - curM).coerceAtLeast(0.0)
            val waterL = drySoilTonnes * 1000.0 * (moistureDelta / 100.0) * 1.15 // +15% evap
            val tankers = ceil(waterL / 5000.0).toInt()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Compacted Lifts Needed", "$lifts", "layers (@${lift.toInt()}mm)", isPrimary = true),
                        CalcResultItem("Water for OMC (+15% Evap)", UnitConverter.fmt(waterL, 0), "Liters ($tankers×5kL tankers)", isPrimary = true),
                        CalcResultItem("Compacted Volume & Dry Mass", "${UnitConverter.fmt(volM3, p)} m³ • ${UnitConverter.fmt(drySoilTonnes, 0)} MT", "")
                    ),
                    formula = "Lifts = ceil(Depth_mm / Lift_mm); Water L = DryMass_kg × (OMC% − Cur%) × 1.15",
                    steps = listOf("Dry soil ≈ ${UnitConverter.fmt(drySoilTonnes, 0)} MT × ${UnitConverter.fmt(moistureDelta, 1)}% deficit × 1.15"),
                    assumptions = "Assumes avg dry density 1.75 t/m³ and 15% evaporation loss during spreading."
                )
            )
        }
    )

    private fun pileCapDetailCalculator() = CalcToolSpec(
        id = "soil_pile_cap_qty",
        title = "Pile Cap (2 / 3 / 4 / 6 Piles) Estimator",
        titleHi = "पाइल कैप (2, 3, 4, 6 पाइल) कंक्रीट और स्टील",
        subtitle = "Pile Cap Sizing from Pile Spacing (2.5D–3D), PCC, Concrete & Rebar",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        keywords = listOf("pile cap", "pile", "foundation", "pcc", "rebar", "formwork"),
        fields = listOf(
            CalcFieldSpec("group", "Pile Group Configuration", "4-Pile Cap (Square)", options = listOf("2-Pile Cap (Rect)", "3-Pile Cap (Triangular)", "4-Pile Cap (Square)", "6-Pile Cap (2×3)")),
            CalcFieldSpec("pileDia", "Pile Diameter (mm)", "500", FieldUnitKind.NONE),
            CalcFieldSpec("spacingMult", "Pile c/c Spacing (× Dia)", "2.75", FieldUnitKind.NONE),
            CalcFieldSpec("capDepth", "Pile Cap Depth (mm)", "900", FieldUnitKind.NONE),
            CalcFieldSpec("capsCount", "Number of Pile Caps", "4", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val pDiaM = (ctx.doubleOrNull("pileDia") ?: 500.0) / 1000.0
            val sMult = ctx.doubleOrNull("spacingMult") ?: 2.75
            val dCapM = (ctx.doubleOrNull("capDepth") ?: 900.0) / 1000.0
            val nCaps = ctx.doubleOrNull("capsCount") ?: 4.0
            if (pDiaM <= 0 || sMult < 2.0 || dCapM <= 0 || nCaps <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("Check pile dia, spacing (≥2D), depth & count."))
            }
            val sp = pDiaM * sMult
            val edge = pDiaM + 0.30 // outer pile dia + 150mm each side
            val grp = ctx.raw("group")
            val (capL, capW, areaPerCap) = when {
                grp.startsWith("2-") -> Triple(sp + edge, edge, (sp + edge) * edge)
                grp.startsWith("3-") -> {
                    val l = sp + edge
                    val w = sp * 0.866 + edge
                    Triple(l, w, 0.72 * l * w) // trimmed triangular pile cap plan
                }
                grp.startsWith("6-") -> Triple(2.0 * sp + edge, sp + edge, (2.0 * sp + edge) * (sp + edge))
                else -> Triple(sp + edge, sp + edge, (sp + edge) * (sp + edge))
            }
            val totalVol = areaPerCap * dCapM * nCaps
            val pccVol = areaPerCap * 0.10 * nCaps
            val steelKg = totalVol * 105.0

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Pile Cap Concrete", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Cap Footprint (L × W)", "${UnitConverter.fmt(capL, 2)} × ${UnitConverter.fmt(capW, 2)}", "m (c/c ${UnitConverter.fmt(sp, 2)}m)", isPrimary = true),
                        CalcResultItem("Prelim. Rebar Steel (~105 kg/m³)", UnitConverter.fmt(steelKg, 0), "kg"),
                        CalcResultItem("Leveling PCC (100mm)", UnitConverter.fmt(pccVol, p), "m³")
                    ),
                    formula = "Spacing S = ${sMult}×Ø; Edge Overhang = Ø/2 + 150mm; Vol = Area × Depth × N",
                    steps = listOf("Cap plan area = ${UnitConverter.fmt(areaPerCap, p)} m²/cap × ${nCaps.toInt()} caps"),
                    assumptions = "IS 2911 min pile spacing ≥ 2.5D; 150mm clear overhang beyond outer pile edge."
                )
            )
        }
    )

    private fun plinthSandFillingCalculator() = CalcToolSpec(
        id = "soil_sand_fill",
        title = "Plinth Sand Filling & Consolidation",
        titleHi = "प्लिंथ रेत भराई (Sand Filling) अनुमान",
        subtitle = "Sand Quantity in m³, CFT & Brass incl. Water Consolidation (+20%)",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("plinth", "sand filling", "consolidation", "cft", "brass", "subbase"),
        fields = listOf(
            CalcFieldSpec("area", "Plinth Room Floor Area (sq.ft)", "1000", FieldUnitKind.NONE),
            CalcFieldSpec("depthMm", "Compacted Sand Depth (mm)", "300", FieldUnitKind.NONE),
            CalcFieldSpec("consolPct", "Water Consolidation / Bulking (%)", "20", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val sqFt = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter floor area."))
            val dMm = ctx.doubleOrNull("depthMm") ?: 300.0
            val cons = (ctx.doubleOrNull("consolPct") ?: 20.0).coerceAtLeast(0.0)
            if (sqFt <= 0 || dMm <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Area and depth must be positive."))

            val netCft = sqFt * ((dMm / 1000.0) * 3.28084)
            val grossCft = netCft * (1.0 + cons / 100.0)
            val grossM3 = grossCft / 35.3147
            val brass = grossCft / 100.0

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Gross Sand Required (+${cons.toInt()}%)", UnitConverter.fmt(grossM3, p), "m³ (${UnitConverter.fmt(grossCft, 0)} cft)", isPrimary = true),
                        CalcResultItem("Sand in Brass (100 cft)", UnitConverter.fmt(brass, p), "brass", isPrimary = true),
                        CalcResultItem("Net Compacted Volume", UnitConverter.fmt(netCft / 35.3147, p), "m³")
                    ),
                    formula = "Net CFT = Area(sq.ft) × Depth(ft); Gross = Net × (1 + Consolidation%)",
                    steps = listOf("Net = ${UnitConverter.fmt(netCft, 0)} cft → Gross = ${UnitConverter.fmt(grossCft, 0)} cft = ${UnitConverter.fmt(brass, p)} brass"),
                    assumptions = "20% extra sand accounts for flooding consolidation & truck bulking."
                )
            )
        }
    )

    private fun fieldDryDensityCheckCalculator() = CalcToolSpec(
        id = "soil_fdt_check",
        title = "Field Dry Density (FDD) Compaction Check",
        titleHi = "फील्ड ड्राई डेंसिटी (FDD) और कॉम्पैक्शन %",
        subtitle = "Core Cutter / Sand Replacement FDD vs Lab MDD (IS 2720 Part 28/29)",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("fdd", "mdd", "proctor", "compaction", "core cutter", "is 2720", "qc"),
        fields = listOf(
            CalcFieldSpec("wetMassG", "Wet Soil Mass Recovered (grams)", "1980", FieldUnitKind.NONE),
            CalcFieldSpec("holeVolCc", "Core / Pit Volume (cm³ or cc)", "1000", FieldUnitKind.NONE),
            CalcFieldSpec("moistPct", "Field Moisture Content (%)", "11.5", FieldUnitKind.PERCENT),
            CalcFieldSpec("labMdd", "Lab Proctor MDD (g/cc)", "1.82", FieldUnitKind.NONE),
            CalcFieldSpec("reqPct", "Required Compaction (% MDD)", "97", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val mass = ctx.doubleOrNull("wetMassG") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter wet mass."))
            val vol = ctx.doubleOrNull("holeVolCc") ?: 1000.0
            val w = ctx.doubleOrNull("moistPct") ?: 11.5
            val mdd = ctx.doubleOrNull("labMdd") ?: 1.82
            val req = ctx.doubleOrNull("reqPct") ?: 97.0
            if (mass <= 0 || vol <= 0 || w < 0 || mdd <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid positive test readings."))

            val bulk = mass / vol
            val fdd = bulk / (1.0 + w / 100.0)
            val compPct = (fdd / mdd) * 100.0
            val pass = compPct >= req
            val warnings = if (!pass) listOf("Compaction ${UnitConverter.fmt(compPct, 1)}% is below target ${UnitConverter.fmt(req, 1)}%. Additional roller passes needed.") else emptyList()

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Compaction Achieved", "${UnitConverter.fmt(compPct, 2)}%", if (pass) "PASS (≥${req.toInt()}%)" else "FAIL (<${req.toInt()}%)", isPrimary = true),
                        CalcResultItem("Field Dry Density (FDD)", UnitConverter.fmt(fdd, 3), "g/cc", isPrimary = true),
                        CalcResultItem("Wet Bulk Density", UnitConverter.fmt(bulk, 3), "g/cc")
                    ),
                    formula = "Bulk = M_wet / V; FDD = Bulk / (1 + w/100); %Compaction = (FDD / MDD) × 100",
                    steps = listOf("Bulk=${UnitConverter.fmt(bulk, 3)}, FDD=${UnitConverter.fmt(fdd, 3)} g/cc → ${UnitConverter.fmt(compPct, 2)}%"),
                    assumptions = "Calibrated IS 2720 core cutter (~1000 cc) or sand-replacement cylinder.",
                    warnings = warnings
                )
            )
        }
    )

    private fun gabionWallStoneCalculator() = CalcToolSpec(
        id = "soil_gabion_retaining",
        title = "Gabion Retaining Wall & Boulder Stone",
        titleHi = "गेबियन वॉल और बोल्डर स्टोन जाल",
        subtitle = "Trapezoidal/Stepped Gabion Box Cages, Boulder Tonnage & Geotextile",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        keywords = listOf("gabion", "boulder", "retaining wall", "stone", "mesh", "geotextile"),
        fields = listOf(
            CalcFieldSpec("len", "Wall Length", "25.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("h", "Wall Height", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("topW", "Top Cage Width", "1.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("botW", "Base Cage Width", "2.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("voidPct", "Boulder Packing Void (%)", "28", FieldUnitKind.PERCENT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val tw = ctx.lengthMeters("topW") ?: 1.0
            val bw = ctx.lengthMeters("botW") ?: 2.0
            val voids = (ctx.doubleOrNull("voidPct") ?: 28.0).coerceIn(10.0, 45.0)
            if (l <= 0 || h <= 0 || tw <= 0 || bw <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))

            val grossVol = 0.5 * (tw + bw) * h * l
            val solidStoneVol = grossVol * (1.0 - voids / 100.0)
            val stoneMt = solidStoneVol * 2.65
            val boxes2x1x1 = ceil(grossVol / 2.0).toInt()
            val geotextileM2 = l * (h + bw * 0.5)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Gross Gabion Wall Volume", UnitConverter.fmt(grossVol, p), "m³", isPrimary = true),
                        CalcResultItem("Boulder Stone Weight", UnitConverter.fmt(stoneMt, p), "MT", isPrimary = true),
                        CalcResultItem("Equiv. 2×1×1m GI Mesh Cages", "$boxes2x1x1", "boxes"),
                        CalcResultItem("Filter Geotextile (Back Face)", UnitConverter.fmt(geotextileM2, p), "m²")
                    ),
                    formula = "Vol = 0.5×(TopW+BotW)×H×L; Stone MT = Vol×(1−Voids%)×2.65",
                    steps = listOf("Gross=${UnitConverter.fmt(grossVol, p)} m³; Solid rock=${UnitConverter.fmt(solidStoneVol, p)} m³"),
                    assumptions = "Granite/basalt boulder specific gravity ~2.65; non-woven geotextile filter on backfill face."
                )
            )
        }
    )
}

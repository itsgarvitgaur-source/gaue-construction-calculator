package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.ceil
import kotlin.math.sqrt

/** Phase L: preliminary electrical-load, cable, earthing and solar sizing estimators. */
object PhaseLElectricalSolarCalculators {
    private fun num(k: String, label: String, value: String) = CalcFieldSpec(k, label, value, FieldUnitKind.NONE)
    private fun dim(k: String, label: String, value: String) = CalcFieldSpec(k, label, value, FieldUnitKind.LENGTH, LengthUnit.M)
    private fun pct(k: String, label: String, value: String) = CalcFieldSpec(k, label, value, FieldUnitKind.PERCENT)
    private fun fmt(v: Double, p: Int) = UnitConverter.fmt(v, p)
    private fun tool(id: String, title: String, subtitle: String, fields: List<CalcFieldSpec>, keys: List<String>, fn: (CalcContext) -> Result<CalcOutcome>) =
        CalcToolSpec(id, title, title, subtitle, CalcCategory.UTILITIES, keys, fields = fields, compute = fn)

    fun all(): List<CalcToolSpec> = listOf(
        tool("phase_l_single_phase_power", "Single-Phase Power & Current", "Estimate real power, apparent power and current", listOf(num("v","Voltage (V)","230"),num("i","Current (A)","10"),num("pf","Power factor","0.9")), listOf("single phase","power","current","power factor")) { c ->
            val v=c.doubleOrNull("v")?:0.0; val i=c.doubleOrNull("i")?:0.0; val pf=c.doubleOrNull("pf")?:0.0; val p=c.settings.decimalPrecision
            if(v<=0||i<=0||pf<=0||pf>1) return@tool Result.failure(IllegalArgumentException("Voltage/current must be positive and power factor must be >0 to 1."))
            val kva=v*i/1000; val kw=kva*pf
            Result.success(CalcOutcome(listOf(CalcResultItem("Apparent power",fmt(kva,p),"kVA"),CalcResultItem("Real power",fmt(kw,p),"kW",true),CalcResultItem("Current",fmt(i,p),"A")),"S=VI/1000; P=S×power factor",listOf("Single-phase sinusoidal supply assumed."),"Preliminary calculation; excludes harmonics, voltage variation and installation derating."))
        },
        tool("phase_l_three_phase_power", "Three-Phase Power & Current", "Estimate three-phase kW, kVA and line current", listOf(num("v","Line voltage (V)","415"),num("i","Line current (A)","25"),num("pf","Power factor","0.85")), listOf("three phase","3 phase","power","line current")) { c ->
            val v=c.doubleOrNull("v")?:0.0; val i=c.doubleOrNull("i")?:0.0; val pf=c.doubleOrNull("pf")?:0.0; val p=c.settings.decimalPrecision
            if(v<=0||i<=0||pf<=0||pf>1) return@tool Result.failure(IllegalArgumentException("Voltage/current positive; power factor must be >0 to 1."))
            val kva=sqrt(3.0)*v*i/1000; val kw=kva*pf
            Result.success(CalcOutcome(listOf(CalcResultItem("Apparent power",fmt(kva,p),"kVA"),CalcResultItem("Real power",fmt(kw,p),"kW",true),CalcResultItem("Line current",fmt(i,p),"A")),"S=√3 V_L I_L/1000; P=S×PF",listOf("Balanced three-phase load assumed."),"Preliminary estimate; verify phase balance, harmonics and equipment nameplate data."))
        },
        tool("phase_l_voltage_drop", "Cable Voltage Drop Estimator", "Estimate resistive voltage drop for copper or aluminium cable", listOf(dim("l","One-way cable route length (m)","30"),num("i","Load current (A)","20"),num("r","Conductor resistance (Ω/km)","3.08"),num("v","System voltage (V)","230"),num("ph","Phase system (1 or 3)","1")), listOf("voltage drop","cable","conductor resistance","single phase","three phase")) { c ->
            val l=c.lengthMeters("l")?:0.0; val i=c.doubleOrNull("i")?:0.0; val r=c.doubleOrNull("r")?:0.0; val v=c.doubleOrNull("v")?:0.0; val ph=c.doubleOrNull("ph")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||i<=0||r<=0||v<=0||(ph!=1.0&&ph!=3.0)) return@tool Result.failure(IllegalArgumentException("Positive length/current/resistance/voltage required; phase system must be 1 or 3."))
            val factor=if(ph==1.0) 2.0 else sqrt(3.0); val drop=factor*i*r*l/1000; val percent=drop/v*100
            Result.success(CalcOutcome(listOf(CalcResultItem("Voltage drop",fmt(drop,p),"V",true),CalcResultItem("Voltage drop",fmt(percent,p),"%"),CalcResultItem("Estimated receiving voltage",fmt(v-drop,p),"V")),"ΔV = phase factor × I × R(Ω/km) × one-way length / 1000",listOf("Uses conductor resistance supplied by user; reactance and temperature correction omitted."),"Screening estimate only. Final cable selection must check current capacity, installation method, grouping, ambient temperature, short-circuit withstand and applicable electrical code."))
        },
        tool("phase_l_cable_area", "Conductor Area from Voltage-Drop Limit", "Estimate minimum conductor area using resistivity and allowed drop", listOf(dim("l","One-way route length (m)","40"),num("i","Load current (A)","25"),num("rho","Resistivity (Ω·mm²/m)","0.0175"),num("v","System voltage (V)","230"),pct("drop","Allowed voltage drop (%)","3"),num("ph","Phase system (1 or 3)","1")), listOf("cable size","conductor area","voltage drop limit","cable sizing")) { c ->
            val l=c.lengthMeters("l")?:0.0; val i=c.doubleOrNull("i")?:0.0; val rho=c.doubleOrNull("rho")?:0.0; val v=c.doubleOrNull("v")?:0.0; val d=c.doubleOrNull("drop")?:0.0; val ph=c.doubleOrNull("ph")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||i<=0||rho<=0||v<=0||d<=0||d>=100||(ph!=1.0&&ph!=3.0)) return@tool Result.failure(IllegalArgumentException("Check positive inputs, drop below 100%, and phase 1 or 3."))
            val factor=if(ph==1.0) 2.0 else sqrt(3.0); val area=factor*rho*i*l/(v*d/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Minimum calculated area",fmt(area,p),"mm²",true),CalcResultItem("Allowed voltage drop",fmt(v*d/100,p),"V")),"A = phase factor × ρ × I × L / ΔV",listOf("Resistivity entered in Ω·mm²/m; length is one-way."),"Voltage-drop-only estimate, not a cable selection. Check ampacity, installation conditions, protection coordination, fault level and standard cable sizes."))
        },
        tool("phase_l_connected_load", "Connected Load & Demand Calculator", "Calculate connected load and estimated demand load", listOf(num("n","Number of identical loads","12"),num("w","Rating per load (W)","100"),pct("d","Demand factor (%)","70"),pct("sp","Spare capacity (%)","20")), listOf("connected load","demand load","electrical load","load schedule")) { c ->
            val n=c.doubleOrNull("n")?:0.0; val w=c.doubleOrNull("w")?:0.0; val d=c.doubleOrNull("d")?:0.0; val s=c.doubleOrNull("sp")?:0.0; val p=c.settings.decimalPrecision
            if(n<=0||n%1.0!=0.0||w<=0||d<0||d>100||s<0) return@tool Result.failure(IllegalArgumentException("Load count whole and positive; rating positive; demand 0–100%; spare non-negative."))
            val connected=n*w/1000; val demand=connected*d/100; val design=demand*(1+s/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Connected load",fmt(connected,p),"kW"),CalcResultItem("Demand load",fmt(demand,p),"kW"),CalcResultItem("Design load with spare",fmt(design,p),"kW",true)),"Connected=n×W/1000; demand=connected×DF; design=demand×(1+spare%)",listOf("Demand and spare factors are user supplied."),"Planning estimate; diversity, motor starting and statutory load classifications require project-specific review."))
        },
        tool("phase_l_transformer_kva", "Transformer kVA & Loading", "Estimate transformer rating and percentage loading", listOf(num("kw","Maximum demand (kW)","120"),num("pf","Power factor","0.9"),pct("sp","Future growth allowance (%)","20"),num("rated","Selected transformer rating (kVA)","200")), listOf("transformer","kva","transformer loading","electrical distribution")) { c ->
            val kw=c.doubleOrNull("kw")?:0.0; val pf=c.doubleOrNull("pf")?:0.0; val sp=c.doubleOrNull("sp")?:0.0; val rated=c.doubleOrNull("rated")?:0.0; val p=c.settings.decimalPrecision
            if(kw<=0||pf<=0||pf>1||sp<0||rated<=0) return@tool Result.failure(IllegalArgumentException("Demand/rating positive; PF >0 to 1; growth non-negative."))
            val kva=kw/pf*(1+sp/100); val loading=kva/rated*100
            Result.success(CalcOutcome(listOf(CalcResultItem("Required transformer capacity",fmt(kva,p),"kVA",true),CalcResultItem("Selected transformer loading",fmt(loading,p),"%"),CalcResultItem("Demand before growth",fmt(kw/pf,p),"kVA")),"Required kVA = kW / PF × (1 + growth%)",listOf("Compare calculated requirement with selected standard transformer rating."),"Preliminary capacity estimate; check load profile, harmonics, ambient derating, motor starting, redundancy and utility requirements."))
        },
        tool("phase_l_earth_electrode", "Earth Electrode Resistance Screening", "Estimate idealised resistance of a single vertical rod", listOf(dim("l","Rod length (m)","3"),dim("d","Rod diameter (m)","0.016"),num("rho","Soil resistivity (Ω·m)","100")), listOf("earthing","earth electrode","ground resistance","soil resistivity")) { c ->
            val l=c.lengthMeters("l")?:0.0; val d=c.lengthMeters("d")?:0.0; val rho=c.doubleOrNull("rho")?:0.0; val p=c.settings.decimalPrecision
            if(l<=0||d<=0||rho<=0||d>=l) return@tool Result.failure(IllegalArgumentException("Positive dimensions/resistivity required and rod diameter must be less than length."))
            val r=rho/(2*3.141592653589793*l)*(kotlin.math.ln(8*l/d)-1)
            Result.success(CalcOutcome(listOf(CalcResultItem("Estimated electrode resistance",fmt(r,p),"Ω",true),CalcResultItem("Soil resistivity",fmt(rho,p),"Ω·m")),"R ≈ ρ/(2πL) × [ln(8L/d) − 1]",listOf("Homogeneous soil and isolated single rod assumed."),"Rough screening formula only. Earthing design and compliance require site resistivity testing, electrode interaction, seasonal variation and mandatory electrical safety verification."))
        },
        tool("phase_l_solar_pv_size", "Solar PV Array Sizing", "Estimate PV capacity from daily energy use and peak sun hours", listOf(num("e","Daily energy consumption (kWh/day)","12"),num("h","Peak sun hours per day","5"),num("pr","Performance ratio (0–1)","0.75"),pct("sp","Capacity allowance (%)","10")), listOf("solar panel","pv sizing","solar capacity","peak sun hours")) { c ->
            val e=c.doubleOrNull("e")?:0.0; val h=c.doubleOrNull("h")?:0.0; val pr=c.doubleOrNull("pr")?:0.0; val sp=c.doubleOrNull("sp")?:0.0; val p=c.settings.decimalPrecision
            if(e<=0||h<=0||pr<=0||pr>1||sp<0) return@tool Result.failure(IllegalArgumentException("Energy and sun hours positive; PR >0 to 1; allowance non-negative."))
            val kw=e/(h*pr)*(1+sp/100)
            Result.success(CalcOutcome(listOf(CalcResultItem("Estimated PV array",fmt(kw,p),"kWp",true),CalcResultItem("Daily energy target",fmt(e,p),"kWh/day")),"PV kWp = daily kWh / (PSH × performance ratio) × allowance",listOf("Performance ratio accounts broadly for system losses."),"Energy-balance estimate; verify site shading, orientation, module temperature, seasonal irradiation, inverter limits and local grid rules."))
        },
        tool("phase_l_inverter_battery", "Inverter & Battery Backup Sizing", "Estimate inverter capacity and battery energy for backup duration", listOf(num("load","Simultaneous AC load (W)","1000"),num("hours","Backup duration (hours)","4"),num("v","Battery bank voltage (V)","48"),pct("dod","Usable depth of discharge (%)","80"),pct("eff","Inverter efficiency (%)","90")), listOf("inverter sizing","battery capacity","backup time","battery bank")) { c ->
            val load=c.doubleOrNull("load")?:0.0; val h=c.doubleOrNull("hours")?:0.0; val v=c.doubleOrNull("v")?:0.0; val dod=c.doubleOrNull("dod")?:0.0; val eff=c.doubleOrNull("eff")?:0.0; val p=c.settings.decimalPrecision
            if(load<=0||h<=0||v<=0||dod<=0||dod>100||eff<=0||eff>100) return@tool Result.failure(IllegalArgumentException("Load, time, voltage positive; DOD and efficiency must be >0 to 100%."))
            val inverter=load/1000/eff*1.25; val kwh=load*h/(1000*eff)/(dod/100); val ah=kwh*1000/v
            Result.success(CalcOutcome(listOf(CalcResultItem("Suggested inverter minimum",fmt(inverter,p),"kVA approx.",true),CalcResultItem("Battery nominal energy",fmt(kwh,p),"kWh"),CalcResultItem("Battery bank capacity",fmt(ah,p),"Ah")),"Battery kWh = load × hours / inverter efficiency / DOD; Ah = Wh / V",listOf("25% inverter sizing margin is applied."),"Preliminary sizing; check surge loads, battery chemistry, temperature, ageing, BMS limits and manufacturer specifications."))
        },
        tool("phase_l_energy_cost", "Electrical Energy & Bill Estimator", "Calculate energy consumption and estimated electricity cost", listOf(num("w","Equipment power (W)","1500"),num("n","Quantity","2"),num("h","Hours used per day","5"),num("days","Days in billing period","30"),num("rate","Energy tariff (currency/kWh)","8")), listOf("energy consumption","electricity bill","kwh","power cost")) { c ->
            val w=c.doubleOrNull("w")?:0.0; val n=c.doubleOrNull("n")?:0.0; val h=c.doubleOrNull("h")?:0.0; val days=c.doubleOrNull("days")?:0.0; val rate=c.doubleOrNull("rate")?:0.0; val p=c.settings.decimalPrecision
            if(w<=0||n<=0||n%1.0!=0.0||h<0||days<=0||rate<0) return@tool Result.failure(IllegalArgumentException("Power and quantity positive; quantity whole; hours/rate non-negative; days positive."))
            val kwh=w*n*h*days/1000; val cost=kwh*rate
            Result.success(CalcOutcome(listOf(CalcResultItem("Period energy use",fmt(kwh,p),"kWh",true),CalcResultItem("Estimated energy charge",fmt(cost,p),"currency units"),CalcResultItem("Daily energy use",fmt(kwh/days,p),"kWh/day")),"kWh = W × quantity × hours/day × days / 1000; cost = kWh × tariff",listOf("Tariff is a single flat user-entered rate."),"Estimate excludes fixed charges, taxes, slab tariffs, demand charges and power-factor penalties."))
        }
    )
}

package com.example.features.security

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.LocalAppStrings
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.LocalEngineeringPalette
import com.example.ui.theme.MonoFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SecurityShieldScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val report by viewModel.shieldReport.collectAsStateWithLifecycle()
    val events by viewModel.securityEvents.collectAsStateWithLifecycle()

    var encryptionVerificationOutput by remember { mutableStateOf<String?>(null) }
    val timeFmt = remember { SimpleDateFormat("dd MMM HH:mm:ss", Locale.US) }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = strings.securityShield,
            subtitle = "Real Integrity, Keystore AES-256 & Environment Diagnostics",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                val r = report
                val hasWarn = r?.hasWarnings == true
                EngineeringCard(accentColor = if (hasWarn) palette.warning else palette.success) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (hasWarn) palette.warningBg else palette.successBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Security, contentDescription = null, tint = if (hasWarn) palette.warning else palette.success, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(r?.overallStatusLabel ?: "Running Shield Check...", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                            Text(
                                "Note: Diagnostics verify APK signature, debug flags, standard root indicators & AndroidKeyStore status. Core offline calculators remain functional even if warnings appear.",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkMuted
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                viewModel.runSecurityScan(context, logEvent = true)
                                Toast.makeText(context, "Diagnostic scan completed", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.orange),
                            modifier = Modifier.weight(1f).testTag("run_security_scan_btn")
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Run Integrity Scan")
                        }
                        OutlinedButton(
                            onClick = {
                                val sample = "PROJECT_DATA_INTEGRITY_${System.currentTimeMillis()}"
                                val enc = SecurityShieldEngine.encryptPayload(sample)
                                val dec = enc.mapCatching { SecurityShieldEngine.decryptPayload(it).getOrThrow() }
                                encryptionVerificationOutput = if (dec.getOrNull() == sample) {
                                    "AES-256-GCM Roundtrip Verified\nCipher: ${enc.getOrNull()?.take(44)}…"
                                } else {
                                    "Keystore Verification Failed: ${dec.exceptionOrNull()?.message}"
                                }
                                viewModel.logSecurityEvent("AES_TEST", "PASS", "Keystore AES-256-GCM Test", "Verified project encryption key")
                            },
                            border = BorderStroke(1.dp, palette.metallicBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(18.dp), tint = palette.skyBlue)
                            Spacer(Modifier.width(4.dp))
                            Text("Verify AES Key")
                        }
                    }
                    encryptionVerificationOutput?.let { msg ->
                        Spacer(Modifier.height(8.dp))
                        Surface(color = palette.skyGlassTint, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Text(msg, fontFamily = MonoFontFamily, style = MaterialTheme.typography.bodySmall, color = palette.inkPrimary, modifier = Modifier.padding(8.dp))
                        }
                    }
                }
            }

            report?.let { r ->
                items(r.checks, key = { it.id }) { check ->
                    val (icon, tint, bg) = when (check.status) {
                        ShieldCheckStatus.PASS -> Triple(Icons.Rounded.CheckCircle, palette.success, palette.successBg)
                        ShieldCheckStatus.WARNING -> Triple(Icons.Rounded.Warning, palette.warning, palette.warningBg)
                        ShieldCheckStatus.INFO -> Triple(Icons.Rounded.Info, palette.skyBlue, palette.skyGlassTint)
                    }
                    EngineeringCard {
                        Row(verticalAlignment = Alignment.Top) {
                            Box(
                                modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(bg),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(check.title, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                                Text(check.summary, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = tint)
                                Spacer(Modifier.height(2.dp))
                                Text(check.explanation, style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                            }
                        }
                    }
                }

                item {
                    EngineeringCard {
                        Text("Full APK Certificate SHA-256", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                        Spacer(Modifier.height(4.dp))
                        Text(r.apkSha256, fontFamily = MonoFontFamily, style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Security Event Log (${events.size})", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                    if (events.isNotEmpty()) {
                        OutlinedButton(onClick = { viewModel.clearSecurityEvents() }) { Text("Clear Log") }
                    }
                }
            }
            items(events, key = { it.id }) { ev ->
                EngineeringCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(ev.title, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                        Text(timeFmt.format(Date(ev.timestamp)), style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                    }
                    Text(ev.details, style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                }
            }
        }
    }
}

package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

object SteelAndSiteCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        rebarWeightCalculator(),
        multiDiameterSteelCalculator(),
        memberReinforcementCalculator(),
        hookBendLapLdCalculator(),
        stirrupCuttingLengthCalculator(),
        riseFallLevelCalculator(),
        slopeGradientDegreeCalculator(),
        rightAngleTriangleCalculator(),
        coordinateBearingCalculator(),
        trigElevationCalculator(),
        drawingScaleCalculator()
    )

    private fun rebarWeightCalculator() = CalcToolSpec(
        id = "steel_rebar_weight",
        title = "Rebar & Steel Weight Calculator",
        titleHi = "सरिया / स्टील वजन कैलकुलेटर",
        subtitle = "D²×L / 162.2 Formula, Multi-Bar Count, Wastage & Cost",
        category = CalcCategory.STEEL,
        keywords = listOf("steel", "rebar", "weight", "tmt", "bar", "diameter", "162.2"),
        fields = listOf(
            CalcFieldSpec("dia", "Bar Diameter (mm)", "12", options = listOf("6", "8", "10", "12", "16", "20", "25", "28", "32", "36", "40")),
            CalcFieldSpec("len", "Single Bar Length", "12.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("count", "Number of Bars", "20", FieldUnitKind.COUNT),
            CalcFieldSpec("wastage", "Cutting Wastage (%)", "3", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val d = ctx.doubleOrNull("dia") ?: 12.0
            val lenM = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter bar length."))
            val n = ctx.doubleOrNull("count") ?: 1.0
            val wastage = ctx.doubleOrNull("wastage") ?: 3.0
            if (d <= 0 || lenM <= 0 || n <= 0 || wastage < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))
            val unitWtKgPerM = (d * d) / 162.2
            val unitWtKgPerFt = unitWtKgPerM * 0.3048
            val totalLen = lenM * n
            val netWt = totalLen * unitWtKgPerM
            val grossWt = netWt * (1.0 + wastage / 100.0)
            val mt = grossWt / 1000.0
            val cost = grossWt * (ctx.ratesByKeyword["steel"] ?: 68.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Gross Steel Weight", UnitConverter.fmt(grossWt, p), "kg", isPrimary = true),
                        CalcResultItem("Metric Tons (MT)", UnitConverter.fmt(mt, 4), "MT", isPrimary = true),
                        CalcResultItem("Unit Weight", UnitConverter.fmt(unitWtKgPerM, 3), "kg/m"),
                        CalcResultItem("Unit Weight (Imperial)", UnitConverter.fmt(unitWtKgPerFt, 3), "kg/ft"),
                        CalcResultItem("Total Length", UnitConverter.fmt(totalLen, p), "m"),
                        CalcResultItem("Est. Steel Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "Unit Weight = D² / 162.2 (kg/m); Weight = (D² × L / 162.2) × N",
                    steps = listOf(
                        "Unit Wt = ${d.toInt()}² / 162.2 = ${UnitConverter.fmt(unitWtKgPerM, 4)} kg/m",
                        "Net Wt = ${UnitConverter.fmt(totalLen, p)} m × ${UnitConverter.fmt(unitWtKgPerM, 4)} = ${UnitConverter.fmt(netWt, p)} kg",
                        "With $wastage% wastage = ${UnitConverter.fmt(grossWt, p)} kg"
                    ),
                    assumptions = "Uses steel density 7850 kg/m³ (π/4 × 7850 / 10⁶ = 1/162.197).",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun multiDiameterSteelCalculator() = CalcToolSpec(
        id = "steel_multi_dia",
        title = "Diameter-Wise Steel Summary",
        titleHi = "व्यास-वार स्टील सारांश",
        subtitle = "Combine 8mm, 10mm, 12mm, 16mm, 20mm & 25mm Running Lengths",
        category = CalcCategory.STEEL,
        keywords = listOf("diameter", "multi", "steel", "8mm", "10mm", "12mm", "16mm", "20mm", "25mm"),
        fields = listOf(
            CalcFieldSpec("l8", "8 mm Total Length (m)", "120", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("l10", "10 mm Total Length (m)", "80", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("l12", "12 mm Total Length (m)", "150", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("l16", "16 mm Total Length (m)", "96", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("l20", "20 mm Total Length (m)", "60", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("l25", "25 mm Total Length (m)", "0", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val pairs = listOf(
                8 to (ctx.doubleOrNull("l8") ?: 0.0),
                10 to (ctx.doubleOrNull("l10") ?: 0.0),
                12 to (ctx.doubleOrNull("l12") ?: 0.0),
                16 to (ctx.doubleOrNull("l16") ?: 0.0),
                20 to (ctx.doubleOrNull("l20") ?: 0.0),
                25 to (ctx.doubleOrNull("l25") ?: 0.0)
            )
            if (pairs.any { it.second < 0 }) return@CalcToolSpec Result.failure(IllegalArgumentException("Lengths cannot be negative."))
            val breakdown = pairs.map { (d, len) -> Triple(d, len, len * (d * d / 162.2)) }
            val totalKg = breakdown.sumOf { it.third }
            val cost = totalKg * (ctx.ratesByKeyword["steel"] ?: 68.0)
            Result.success(
                CalcOutcome(
                    results = buildList {
                        add(CalcResultItem("Total Steel Weight", UnitConverter.fmt(totalKg, p), "kg", isPrimary = true))
                        add(CalcResultItem("Total Metric Tons", UnitConverter.fmt(totalKg / 1000.0, 4), "MT", isPrimary = true))
                        breakdown.filter { it.second > 0 }.forEach { (d, _, w) ->
                            add(CalcResultItem("${d}mm Weight", UnitConverter.fmt(w, p), "kg"))
                        }
                        add(CalcResultItem("Est. Steel Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", ""))
                    },
                    formula = "Total = Σ (L_i × D_i² / 162.2)",
                    steps = breakdown.filter { it.second > 0 }.map { (d, len, w) ->
                        "${d}mm: ${UnitConverter.fmt(len, p)} m × ${UnitConverter.fmt(d * d / 162.2, 3)} = ${UnitConverter.fmt(w, p)} kg"
                    },
                    assumptions = "12 m standard bar length reference; excludes lap/wastage unless included in input lengths.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun memberReinforcementCalculator() = CalcToolSpec(
        id = "steel_member_reinf",
        title = "Slab / Footing Mesh & Bar Spacing",
        titleHi = "स्लैब / फुटिंग जाली और बार स्पेसिंग",
        subtitle = "Main Bars + Distribution Bars Count, Cover & Total Steel",
        category = CalcCategory.STEEL,
        isPreliminaryStructural = true,
        keywords = listOf("reinforcement", "slab", "footing", "mesh", "main bar", "distribution", "spacing", "cover"),
        fields = listOf(
            CalcFieldSpec("lx", "Clear Span Lx", "4.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("ly", "Clear Span Ly", "5.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("cover", "Side Cover (mm)", "25", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("mainDia", "Main Bar Dia (mm)", "10", options = listOf("8", "10", "12", "16", "20")),
            CalcFieldSpec("mainSpace", "Main Bar Spacing (mm c/c)", "150", FieldUnitKind.NONE),
            CalcFieldSpec("distDia", "Distribution Bar Dia (mm)", "8", options = listOf("8", "10", "12", "16")),
            CalcFieldSpec("distSpace", "Distribution Spacing (mm c/c)", "200", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val lx = ctx.lengthMeters("lx") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Lx."))
            val ly = ctx.lengthMeters("ly") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Ly."))
            val cov = (ctx.doubleOrNull("cover") ?: 25.0) / 1000.0
            val mDia = ctx.doubleOrNull("mainDia") ?: 10.0
            val mSp = (ctx.doubleOrNull("mainSpace") ?: 150.0) / 1000.0
            val dDia = ctx.doubleOrNull("distDia") ?: 8.0
            val dSp = (ctx.doubleOrNull("distSpace") ?: 200.0) / 1000.0
            if (lx <= 0 || ly <= 0 || mSp <= 0 || dSp <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid inputs."))

            val effLx = (lx - 2 * cov).coerceAtLeast(0.1)
            val effLy = (ly - 2 * cov).coerceAtLeast(0.1)
            // Main bars run along shorter span Lx, distributed along Ly
            val mainCount = ceil(effLy / mSp).toInt() + 1
            val distCount = ceil(effLx / dSp).toInt() + 1
            val mainTotalLen = mainCount * effLx
            val distTotalLen = distCount * effLy
            val mainWt = mainTotalLen * (mDia * mDia / 162.2)
            val distWt = distTotalLen * (dDia * dDia / 162.2)
            val totalWt = mainWt + distWt
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Mesh Steel Weight", UnitConverter.fmt(totalWt, p), "kg", isPrimary = true),
                        CalcResultItem("Main Bars (${mDia.toInt()}mm)", "$mainCount Nos (${UnitConverter.fmt(mainWt, p)} kg)", "", isPrimary = true),
                        CalcResultItem("Dist. Bars (${dDia.toInt()}mm)", "$distCount Nos (${UnitConverter.fmt(distWt, p)} kg)", "")
                    ),
                    formula = "N = ⌈(Span - 2×Cover) / Spacing⌉ + 1; Wt = N × L_bar × D²/162.2",
                    steps = listOf(
                        "Main Bars along Lx = $mainCount × ${UnitConverter.fmt(effLx, p)} m = ${UnitConverter.fmt(mainTotalLen, p)} m",
                        "Dist Bars along Ly = $distCount × ${UnitConverter.fmt(effLy, p)} m = ${UnitConverter.fmt(distTotalLen, p)} m"
                    ),
                    assumptions = "Single-layer mesh without crank/development length extensions; add Ld if anchored into beams."
                )
            )
        }
    )

    private fun hookBendLapLdCalculator() = CalcToolSpec(
        id = "steel_hook_bend_ld",
        title = "Hook, Bend Allowance, Lap & Ld Length",
        titleHi = "हुक, बेंड, लैप और Ld लंबाई",
        subtitle = "IS 456 Development Length (Ld), Lap Length, 90°/135° Hooks & Bend Deductions",
        category = CalcCategory.STEEL,
        isPreliminaryStructural = true,
        keywords = listOf("hook", "bend", "lap", "development length", "ld", "is456", "cutting"),
        fields = listOf(
            CalcFieldSpec("dia", "Bar Diameter φ (mm)", "16", options = listOf("8", "10", "12", "16", "20", "25", "32")),
            CalcFieldSpec("gradeSteel", "Steel Grade", "Fe 500", options = listOf("Fe 415", "Fe 500", "Fe 550")),
            CalcFieldSpec("gradeConc", "Concrete Grade", "M25", options = listOf("M20", "M25", "M30", "M35", "M40")),
            CalcFieldSpec("stressState", "Bar Stress Condition", "Tension (Deformed)", options = listOf("Tension (Deformed)", "Compression (Deformed)"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val d = ctx.doubleOrNull("dia") ?: 16.0
            val fy = when (ctx.raw("gradeSteel")) {
                "Fe 415" -> 415.0
                "Fe 550" -> 550.0
                else -> 500.0
            }
            // IS 456 Table 26.2.1.1 plain bar τ_bd (N/mm²)
            val tauPlain = when (ctx.raw("gradeConc")) {
                "M20" -> 1.2
                "M25" -> 1.4
                "M30" -> 1.5
                "M35" -> 1.7
                "M40" -> 1.9
                else -> 1.4
            }
            val isComp = ctx.raw("stressState").startsWith("Compression")
            // Deformed bar +60%, compression additional +25%
            val tauBd = tauPlain * 1.6 * (if (isComp) 1.25 else 1.0)
            val sigmaS = 0.87 * fy
            val ldMm = (d * sigmaS) / (4.0 * tauBd)
            val lapMm = if (isComp) maxOf(ldMm, 24.0 * d) else maxOf(ldMm, 30.0 * d)
            val hook90Mm = 9.0 * d
            val hook135Mm = 10.0 * d
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Development Length (Ld)", "${UnitConverter.fmt(ldMm, 0)} mm (${UnitConverter.fmt(ldMm / d, 1)}d)", "", isPrimary = true),
                        CalcResultItem("Recommended Lap Length", "${UnitConverter.fmt(lapMm, 0)} mm", "", isPrimary = true),
                        CalcResultItem("90° Hook Allowance (9d)", "${UnitConverter.fmt(hook90Mm, 0)} mm", ""),
                        CalcResultItem("135° Stirrup Hook (10d)", "${UnitConverter.fmt(hook135Mm, 0)} mm", ""),
                        CalcResultItem("Bend Deductions (45°/90°/135°)", "1d=${d.toInt()} | 2d=${(2 * d).toInt()} | 3d=${(3 * d).toInt()}", "mm")
                    ),
                    formula = "Ld = (φ × 0.87fy) / (4 × τ_bd); τ_bd increased 60% for deformed bars (IS 456 Cl. 26.2.1)",
                    steps = listOf(
                        "σ_s = 0.87 × $fy = ${UnitConverter.fmt(sigmaS, 1)} N/mm²",
                        "Design Bond Stress τ_bd = ${UnitConverter.fmt(tauBd, 2)} N/mm²",
                        "Ld = (${d.toInt()} × ${UnitConverter.fmt(sigmaS, 1)}) / (4 × ${UnitConverter.fmt(tauBd, 2)}) = ${UnitConverter.fmt(ldMm, 0)} mm"
                    ),
                    assumptions = "Per IS 456:2000 Cl. 26.2.1 & SP 34 bar detailing conventions."
                )
            )
        }
    )

    private fun stirrupCuttingLengthCalculator() = CalcToolSpec(
        id = "steel_stirrup_cutting",
        title = "Stirrup & Tie Cutting Length",
        titleHi = "स्टिरअप (रिंग) कटिंग लंबाई",
        subtitle = "Rectangular 2-Leg, 4-Leg & Circular Ring Cutting Length + Weight",
        category = CalcCategory.STEEL,
        keywords = listOf("stirrup", "tie", "ring", "cutting length", "bend deduction"),
        fields = listOf(
            CalcFieldSpec("type", "Stirrup Type", "Rectangular 2-Legged", options = listOf("Rectangular 2-Legged", "Circular Ring / Spiral")),
            CalcFieldSpec("b", "Member Width B / Diameter (mm)", "300", FieldUnitKind.NONE),
            CalcFieldSpec("d", "Member Depth D (mm, ignored if Circular)", "450", FieldUnitKind.NONE),
            CalcFieldSpec("cover", "Clear Cover (mm)", "25", FieldUnitKind.NONE),
            CalcFieldSpec("barDia", "Stirrup Bar Dia (mm)", "8", options = listOf("6", "8", "10", "12")),
            CalcFieldSpec("count", "Number of Stirrups", "30", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val b = ctx.doubleOrNull("b") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val d = ctx.doubleOrNull("d") ?: 450.0
            val cov = ctx.doubleOrNull("cover") ?: 25.0
            val dia = ctx.doubleOrNull("barDia") ?: 8.0
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (b <= 2 * cov || dia <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Member size must exceed 2×cover."))
            val cutLenMm: Double
            val formula: String
            val step: String
            if (ctx.raw("type").startsWith("Circular")) {
                val coreDia = b - 2.0 * cov - dia
                cutLenMm = PI * coreDia + 2.0 * (10.0 * dia)
                formula = "L_cut = π×(D - 2c - d) + 2×(10d)"
                step = "Core Dia = ${UnitConverter.fmt(coreDia, 1)} mm"
            } else {
                val a = b - 2.0 * cov - dia
                val h = d - 2.0 * cov - dia
                if (h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Depth must exceed 2×cover."))
                // 2*(a+h) + 2*10d hooks - 3*2d (three 90° bends) - 2*3d (two 135° hooks)
                cutLenMm = 2.0 * (a + h) + 2.0 * (10.0 * dia) - 3.0 * (2.0 * dia) - 2.0 * (3.0 * dia)
                formula = "L_cut = 2(a + h) + 2×(10d) - 3×(2d) - 2×(3d)"
                step = "a = ${UnitConverter.fmt(a, 1)} mm, h = ${UnitConverter.fmt(h, 1)} mm"
            }
            val cutLenM = cutLenMm / 1000.0
            val totalLenM = cutLenM * n
            val weightKg = totalLenM * (dia * dia / 162.2)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Single Stirrup Cutting Length", "${UnitConverter.fmt(cutLenM, 3)} m (${UnitConverter.fmt(cutLenMm, 0)} mm)", "", isPrimary = true),
                        CalcResultItem("Total Weight (${n.toInt()} Nos)", UnitConverter.fmt(weightKg, p), "kg", isPrimary = true),
                        CalcResultItem("Total Cutting Length", UnitConverter.fmt(totalLenM, p), "m")
                    ),
                    formula = formula,
                    steps = listOf(step, "Single Cut = ${UnitConverter.fmt(cutLenMm, 0)} mm = ${UnitConverter.fmt(cutLenM, 3)} m"),
                    assumptions = "Centerline method with 135° seismic hooks (10d) and IS 2502 bend deductions (90°=2d, 135°=3d)."
                )
            )
        }
    )

    private fun riseFallLevelCalculator() = CalcToolSpec(
        id = "site_rise_fall",
        title = "Rise, Fall & Reduced Level (RL)",
        titleHi = "लेवल डिफरेंस और रिड्यूस्ड लेवल (RL)",
        subtitle = "Auto-Level / Dumpy Level Staff Reading Check",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("level", "rise", "fall", "rl", "backsight", "foresight", "surveying"),
        fields = listOf(
            CalcFieldSpec("bmRl", "Benchmark / Previous RL (m)", "100.000", FieldUnitKind.NONE),
            CalcFieldSpec("bs", "Backsight Staff Reading (m)", "1.450", FieldUnitKind.NONE),
            CalcFieldSpec("fs", "Foresight Staff Reading (m)", "1.920", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val bm = ctx.doubleOrNull("bmRl") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Benchmark RL."))
            val bs = ctx.doubleOrNull("bs") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Backsight."))
            val fs = ctx.doubleOrNull("fs") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Foresight."))
            if (bs < 0 || fs < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Staff readings cannot be negative."))
            val hi = bm + bs
            val diff = bs - fs // + is Rise, - is Fall
            val newRl = bm + diff
            val status = if (diff >= 0) "RISE (+${UnitConverter.fmt(diff, 3)} m)" else "FALL (${UnitConverter.fmt(diff, 3)} m)"
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("New Point RL", UnitConverter.fmt(newRl, 3), "m", isPrimary = true),
                        CalcResultItem("Rise / Fall", status, "", isPrimary = true),
                        CalcResultItem("Height of Instrument (HI)", UnitConverter.fmt(hi, 3), "m")
                    ),
                    formula = "HI = BM_RL + BS; New RL = HI - FS = BM_RL + (BS - FS)",
                    steps = listOf(
                        "HI = ${UnitConverter.fmt(bm, 3)} + ${UnitConverter.fmt(bs, 3)} = ${UnitConverter.fmt(hi, 3)} m",
                        "BS - FS = ${UnitConverter.fmt(diff, 3)} m"
                    ),
                    assumptions = "Standard Rise & Fall / Height of Collimation surveying arithmetic check."
                )
            )
        }
    )

    private fun slopeGradientDegreeCalculator() = CalcToolSpec(
        id = "site_slope_gradient",
        title = "Slope, Gradient (1:N), % & Degree",
        titleHi = "ढलान (Slope), ग्रेडिएंट और डिग्री",
        subtitle = "Drainage, Ramp, Road & Roof Pitch Conversion",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("slope", "gradient", "percent", "degree", "ramp", "drainage"),
        fields = listOf(
            CalcFieldSpec("rise", "Vertical Rise / Fall", "0.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("run", "Horizontal Run", "10.0", FieldUnitKind.LENGTH, LengthUnit.M)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val rise = ctx.lengthMeters("rise") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter rise."))
            val run = ctx.lengthMeters("run") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter horizontal run."))
            if (rise < 0 || run <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Run must be positive."))
            val pct = (rise / run) * 100.0
            val deg = Math.toDegrees(atan(rise / run))
            val ratioN = if (rise > 0) run / rise else Double.POSITIVE_INFINITY
            val hyp = sqrt(rise * rise + run * run)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Slope Percentage", "${UnitConverter.fmt(pct, p)} %", "", isPrimary = true),
                        CalcResultItem("Angle in Degrees", "${UnitConverter.fmt(deg, p)}°", "", isPrimary = true),
                        CalcResultItem("Gradient Ratio", if (ratioN.isInfinite()) "Flat (0)" else "1 : ${UnitConverter.fmt(ratioN, p)}", ""),
                        CalcResultItem("Inclined Slope Length", UnitConverter.fmt(hyp, p + 1), "m")
                    ),
                    formula = "Slope% = (Rise/Run)×100; θ = arctan(Rise/Run); Ratio = 1 : (Run/Rise)",
                    steps = listOf("tan(θ) = ${UnitConverter.fmt(rise, p)} / ${UnitConverter.fmt(run, p)} = ${UnitConverter.fmt(rise / run, 4)}"),
                    assumptions = "Horizontal run is projected plan distance."
                )
            )
        }
    )

    private fun rightAngleTriangleCalculator() = CalcToolSpec(
        id = "site_right_angle_triangle",
        title = "Right-Angle (3-4-5) & Triangle Layout",
        titleHi = "समकोण (गुण्या / 3-4-5) और त्रिभुज",
        subtitle = "Site Corner Squaring Diagonal Check & Arbitrary Triangle Area",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("right angle", "345", "pythagoras", "diagonal", "triangle", "squaring", "gunia"),
        fields = listOf(
            CalcFieldSpec("mode", "Calculation Mode", "Right-Angle Diagonal (A & B)", options = listOf("Right-Angle Diagonal (A & B)", "3-Side Triangle (Heron A, B, C)")),
            CalcFieldSpec("a", "Side A", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("b", "Side B", "4.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("c", "Side C (for 3-Side Triangle)", "5.0", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val a = ctx.lengthMeters("a") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Side A."))
            val b = ctx.lengthMeters("b") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter Side B."))
            val c = ctx.lengthMeters("c") ?: 5.0
            if (a <= 0 || b <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Sides must be positive."))
            if (ctx.raw("mode").startsWith("Right-Angle")) {
                val diag = sqrt(a * a + b * b)
                val area = 0.5 * a * b
                val angleA = Math.toDegrees(atan2(a, b))
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Check Diagonal (Hypotenuse)", UnitConverter.fmt(diag, p + 1), "m", isPrimary = true),
                            CalcResultItem("Diagonal in Feet-Inches", UnitConverter.fmtFeetInches(diag), "", isPrimary = true),
                            CalcResultItem("Triangle Area", UnitConverter.fmt(area, p), "m²"),
                            CalcResultItem("Angle opposite A", "${UnitConverter.fmt(angleA, p)}°", "")
                        ),
                        formula = "C = √(A² + B²)",
                        steps = listOf("√(${UnitConverter.fmt(a, p)}² + ${UnitConverter.fmt(b, p)}²) = ${UnitConverter.fmt(diag, p + 1)} m"),
                        assumptions = "Use exact diagonal C between baseline pegs to set a true 90° building corner."
                    )
                )
            } else {
                if (c <= 0 || a + b <= c || a + c <= b || b + c <= a) {
                    return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid triangle sides (triangle inequality violated)."))
                }
                val s = (a + b + c) / 2.0
                val area = sqrt(s * (s - a) * (s - b) * (s - c))
                val angleC = Math.toDegrees(acos(((a * a + b * b - c * c) / (2 * a * b)).coerceIn(-1.0, 1.0)))
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Triangle Area", UnitConverter.fmt(area, p), "m²", isPrimary = true),
                            CalcResultItem("Area in Sq.ft", UnitConverter.fmt(area * UnitConverter.SQ_FT_IN_SQ_M, p), "sq.ft", isPrimary = true),
                            CalcResultItem("Perimeter", UnitConverter.fmt(a + b + c, p), "m"),
                            CalcResultItem("Angle C (opp. side C)", "${UnitConverter.fmt(angleC, p)}°", "")
                        ),
                        formula = "s = (A+B+C)/2; Area = √(s(s-A)(s-B)(s-C))",
                        steps = listOf("s = ${UnitConverter.fmt(s, p)} m; Area = ${UnitConverter.fmt(area, p)} m²"),
                        assumptions = "Heron's formula for irregular plot triangulation."
                    )
                )
            }
        }
    )

    private fun coordinateBearingCalculator() = CalcToolSpec(
        id = "site_coord_bearing",
        title = "Coordinate, Distance & Bearing",
        titleHi = "निर्देशांक, दूरी और बियरिंग",
        subtitle = "Total Station ΔN, ΔE, Horizontal Distance & Whole Circle Bearing",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("coordinate", "bearing", "northing", "easting", "distance", "total station", "surveying"),
        fields = listOf(
            CalcFieldSpec("n1", "Point 1 Northing (N₁)", "1000.00", FieldUnitKind.NONE),
            CalcFieldSpec("e1", "Point 1 Easting (E₁)", "500.00", FieldUnitKind.NONE),
            CalcFieldSpec("n2", "Point 2 Northing (N₂)", "1042.50", FieldUnitKind.NONE),
            CalcFieldSpec("e2", "Point 2 Easting (E₂)", "528.20", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val n1 = ctx.doubleOrNull("n1") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter N1."))
            val e1 = ctx.doubleOrNull("e1") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter E1."))
            val n2 = ctx.doubleOrNull("n2") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter N2."))
            val e2 = ctx.doubleOrNull("e2") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter E2."))
            val dN = n2 - n1
            val dE = e2 - e1
            val dist = sqrt(dN * dN + dE * dE)
            var wcb = Math.toDegrees(atan2(dE, dN))
            if (wcb < 0) wcb += 360.0
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Horizontal Distance", UnitConverter.fmt(dist, p + 1), "m", isPrimary = true),
                        CalcResultItem("Whole Circle Bearing (WCB)", "${UnitConverter.fmt(wcb, p)}°", "", isPrimary = true),
                        CalcResultItem("ΔN / ΔE", "${UnitConverter.fmt(dN, p + 1)} / ${UnitConverter.fmt(dE, p + 1)}", "m")
                    ),
                    formula = "D = √(ΔN² + ΔE²); WCB = atan2(ΔE, ΔN) mod 360°",
                    steps = listOf("ΔN = ${UnitConverter.fmt(dN, 3)}, ΔE = ${UnitConverter.fmt(dE, 3)}"),
                    assumptions = "Plane rectangular grid coordinates (North = 0°, East = 90°)."
                )
            )
        }
    )

    private fun trigElevationCalculator() = CalcToolSpec(
        id = "site_trig_height",
        title = "Trigonometric Height / Elevation",
        titleHi = "त्रिकोणमितीय ऊँचाई गणना",
        subtitle = "Determine Building / Tower Height from Distance & Angle",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("trigonometry", "height", "elevation", "angle", "theodolite", "clinometer"),
        fields = listOf(
            CalcFieldSpec("dist", "Horizontal Distance to Base (D)", "25.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("angle", "Vertical Elevation Angle θ (°)", "32.5", FieldUnitKind.ANGLE_DEG),
            CalcFieldSpec("hi", "Instrument / Eye Height (m)", "1.50", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val d = ctx.lengthMeters("dist") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter distance."))
            val deg = ctx.doubleOrNull("angle") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter angle."))
            val hi = ctx.lengthMeters("hi") ?: 0.0
            if (d <= 0 || deg <= -89.0 || deg >= 89.0) return@CalcToolSpec Result.failure(IllegalArgumentException("Angle must be between -89° and 89°."))
            val rad = Math.toRadians(deg)
            val rise = d * tan(rad)
            val totalH = rise + hi
            val slant = d / cos(rad)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Object Height", UnitConverter.fmt(totalH, p), "m", isPrimary = true),
                        CalcResultItem("Height in Feet", UnitConverter.fmt(UnitConverter.fromMeters(totalH, LengthUnit.FT), p), "ft", isPrimary = true),
                        CalcResultItem("Slant Line-of-Sight", UnitConverter.fmt(slant, p), "m")
                    ),
                    formula = "H = D × tan(θ) + Instrument Height",
                    steps = listOf("D×tan(${deg}°) = ${UnitConverter.fmt(rise, p)} m; + HI (${UnitConverter.fmt(hi, p)} m) = ${UnitConverter.fmt(totalH, p)} m"),
                    assumptions = "Flat horizontal baseline between instrument and object plumb line."
                )
            )
        }
    )

    private fun drawingScaleCalculator() = CalcToolSpec(
        id = "site_drawing_scale",
        title = "Drawing Scale & Blueprint Converter",
        titleHi = "ड्राइंग स्केल और ब्लूप्रिंट माप",
        subtitle = "Convert Paper cm/mm Reading at 1:50, 1:100, 1:200 to Actual Site Length",
        category = CalcCategory.SITE_TOOLKIT,
        keywords = listOf("scale", "drawing", "blueprint", "measurement", "1:100", "1:50"),
        fields = listOf(
            CalcFieldSpec("measuredMm", "Measured on Drawing (mm)", "45.0", FieldUnitKind.NONE),
            CalcFieldSpec("scale", "Drawing Scale (1 : N)", "100", options = listOf("20", "25", "50", "100", "150", "200", "250", "500", "1000"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val mm = ctx.doubleOrNull("measuredMm") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter measured mm."))
            val n = ctx.doubleOrNull("scale") ?: 100.0
            if (mm <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Values must be positive."))
            val actualMm = mm * n
            val actualM = actualMm / 1000.0
            val actualFt = UnitConverter.fromMeters(actualM, LengthUnit.FT)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Actual Site Length (m)", UnitConverter.fmt(actualM, p), "m", isPrimary = true),
                        CalcResultItem("Actual Site Length (ft)", UnitConverter.fmt(actualFt, p), "ft", isPrimary = true),
                        CalcResultItem("Architectural Ft-In", UnitConverter.fmtFeetInches(actualM), ""),
                        CalcResultItem("Actual Millimeters", UnitConverter.fmt(actualMm, 0), "mm")
                    ),
                    formula = "Actual = Drawing Measurement × Scale Factor N",
                    steps = listOf("${mm} mm × $n = ${UnitConverter.fmt(actualMm, 0)} mm = ${UnitConverter.fmt(actualM, p)} m"),
                    assumptions = "True unscaled print; verify printed scale bar before relying on direct ruler measurement."
                )
            )
        }
    )
}

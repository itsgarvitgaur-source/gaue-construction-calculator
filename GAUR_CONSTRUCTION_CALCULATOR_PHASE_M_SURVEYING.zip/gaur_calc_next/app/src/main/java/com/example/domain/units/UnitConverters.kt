package com.example.domain.units

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.roundToLong

enum class LengthUnit(val symbol: String, val toMeters: Double) {
    MM("mm", 0.001),
    CM("cm", 0.01),
    M("m", 1.0),
    INCH("in", 0.0254),
    FT("ft", 0.3048),
    YD("yd", 0.9144)
}

enum class AreaUnit(val symbol: String) {
    SQ_MM("mm²"),
    SQ_CM("cm²"),
    SQ_M("m²"),
    SQ_FT("sq.ft"),
    SQ_YD("sq.yd (Gaj)"),
    ACRE("Acre"),
    HECTARE("Hectare"),
    BIGHA("Bigha")
}

enum class VolumeUnit(val symbol: String, val toCubicMeters: Double) {
    CU_M("m³", 1.0),
    CU_FT("CFT (ft³)", 0.028316846592),
    LITERS("Liters", 0.001),
    BRASS("Brass", 2.8316846592),
    CU_YD("yd³", 0.764554857984)
}

object UnitConverter {
    const val SQ_FT_IN_SQ_M = 10.763910416709722
    const val CU_FT_IN_CU_M = 35.31466672148859

    fun toMeters(value: Double, unit: LengthUnit): Double = value * unit.toMeters

    fun fromMeters(meters: Double, unit: LengthUnit): Double = meters / unit.toMeters

    fun convertLength(value: Double, from: LengthUnit, to: LengthUnit): Double =
        fromMeters(toMeters(value, from), to)

    fun areaToSqMeters(value: Double, unit: AreaUnit, bighaSqFt: Double = 27225.0): Double =
        when (unit) {
            AreaUnit.SQ_MM -> value * 1e-6
            AreaUnit.SQ_CM -> value * 1e-4
            AreaUnit.SQ_M -> value
            AreaUnit.SQ_FT -> value * 0.09290304
            AreaUnit.SQ_YD -> value * 0.83612736
            AreaUnit.ACRE -> value * 4046.8564224
            AreaUnit.HECTARE -> value * 10000.0
            AreaUnit.BIGHA -> value * bighaSqFt * 0.09290304
        }

    fun sqMetersToArea(sqMeters: Double, unit: AreaUnit, bighaSqFt: Double = 27225.0): Double =
        when (unit) {
            AreaUnit.SQ_MM -> sqMeters * 1e6
            AreaUnit.SQ_CM -> sqMeters * 1e4
            AreaUnit.SQ_M -> sqMeters
            AreaUnit.SQ_FT -> sqMeters / 0.09290304
            AreaUnit.SQ_YD -> sqMeters / 0.83612736
            AreaUnit.ACRE -> sqMeters / 4046.8564224
            AreaUnit.HECTARE -> sqMeters / 10000.0
            AreaUnit.BIGHA -> (sqMeters / 0.09290304) / bighaSqFt
        }

    fun convertVolume(value: Double, from: VolumeUnit, to: VolumeUnit): Double =
        (value * from.toCubicMeters) / to.toCubicMeters

    fun fmt(value: Double, precision: Int = 2): String {
        if (value.isNaN() || value.isInfinite()) return "—"
        val p = precision.coerceIn(0, 6)
        val factor = 10.0.pow(p)
        val rounded = (value * factor).roundToLong() / factor
        val clean = if (abs(rounded) < 1e-12) 0.0 else rounded
        return "%.${p}f".format(java.util.Locale.US, clean)
    }

    fun fmtFeetInches(meters: Double): String {
        val totalInches = meters / 0.0254
        val sign = if (totalInches < 0) "-" else ""
        val absIn = abs(totalInches)
        val feet = floor(absIn / 12.0).toInt()
        val inches = absIn - feet * 12.0
        return "$sign$feet' ${fmt(inches, 2)}\""
    }

    /**
     * Supports: "12.5", "3/4", "12 3/4", "12' 6\"", "12'6.5"
     * Returns value in feet if feet/inch notation used, else numeric value.
     */
    fun parseFractionOrDecimal(raw: String): Double? {
        val s = raw.trim()
        if (s.isEmpty()) return null
        if (s.contains('\'')) {
            val parts = s.split('\'')
            val ft = parts[0].trim().toDoubleOrNull() ?: 0.0
            val inchPart = parts.getOrNull(1)?.replace("\"", "")?.trim().orEmpty()
            val inches = if (inchPart.isEmpty()) 0.0 else (parseFractionToken(inchPart) ?: return null)
            return ft + inches / 12.0
        }
        return parseFractionToken(s)
    }

    private fun parseFractionToken(token: String): Double? {
        val clean = token.trim()
        clean.toDoubleOrNull()?.let { return it }
        val spaceIdx = clean.indexOf(' ')
        if (spaceIdx > 0) {
            val whole = clean.substring(0, spaceIdx).trim().toDoubleOrNull() ?: return null
            val frac = parseSimpleFraction(clean.substring(spaceIdx + 1).trim()) ?: return null
            return if (whole >= 0) whole + frac else whole - frac
        }
        return parseSimpleFraction(clean)
    }

    private fun parseSimpleFraction(frac: String): Double? {
        val slash = frac.indexOf('/')
        if (slash <= 0 || slash >= frac.length - 1) return null
        val num = frac.substring(0, slash).trim().toDoubleOrNull() ?: return null
        val den = frac.substring(slash + 1).trim().toDoubleOrNull() ?: return null
        if (abs(den) < 1e-12) return null
        return num / den
    }
}

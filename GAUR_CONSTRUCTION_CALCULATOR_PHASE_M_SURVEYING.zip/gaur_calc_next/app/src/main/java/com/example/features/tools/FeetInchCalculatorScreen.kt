package com.example.features.tools

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.units.UnitConverter
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.LocalEngineeringPalette
import com.example.ui.theme.MonoFontFamily
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

internal enum class FiDimKind(val suffix: String) {
    LENGTH("ft"),
    AREA("sq.ft"),
    VOLUME("cu.ft"),
    SCALAR("")
}

internal fun parseFeetInchExpression(raw: String): Double? {
    val s = raw.trim()
    if (s.isEmpty()) return null
    if (s.startsWith("-")) {
        val posVal = UnitConverter.parseFractionOrDecimal(s.removePrefix("-").trim()) ?: return null
        return -posVal
    }
    return UnitConverter.parseFractionOrDecimal(s)
}

internal fun formatFeetInchFraction(feetValue: Double, kind: FiDimKind): String {
    if (feetValue.isNaN() || feetValue.isInfinite()) return "Error"
    return when (kind) {
        FiDimKind.AREA -> "${UnitConverter.fmt(feetValue, 3)} sq.ft (${UnitConverter.fmt(feetValue * 0.09290304, 3)} m²)"
        FiDimKind.VOLUME -> "${UnitConverter.fmt(feetValue, 3)} cu.ft (${UnitConverter.fmt(feetValue * 0.02831685, 3)} m³)"
        FiDimKind.SCALAR -> UnitConverter.fmt(feetValue, 4)
        FiDimKind.LENGTH -> {
            val sign = if (feetValue < 0) "-" else ""
            val totalInches = abs(feetValue) * 12.0
            val wholeFt = floor(totalInches / 12.0).toInt()
            val remIn = totalInches - wholeFt * 12.0
            var wholeIn = floor(remIn).toInt()
            var sixteenths = ((remIn - wholeIn) * 16.0).roundToInt()
            var finalFt = wholeFt
            if (sixteenths >= 16) {
                sixteenths = 0
                wholeIn += 1
            }
            if (wholeIn >= 12) {
                wholeIn = 0
                finalFt += 1
            }
            val fracStr = if (sixteenths == 0) "" else {
                var num = sixteenths
                var den = 16
                while (num % 2 == 0 && den % 2 == 0) {
                    num /= 2; den /= 2
                }
                " $num/$den"
            }
            "$sign$finalFt' $wholeIn$fracStr\""
        }
    }
}

@Composable
fun FeetInchCalculatorScreen(
    onBack: () -> Unit
) {
    val palette = LocalEngineeringPalette.current

    var inputBuf by remember { mutableStateOf("12' 6") }
    var storedVal by remember { mutableStateOf<Double?>(null) }
    var pendingOp by remember { mutableStateOf<String?>(null) }
    var resultKind by remember { mutableStateOf(FiDimKind.LENGTH) }
    var lastNumeric by remember { mutableDoubleStateOf(12.5) }
    var memoryVal by remember { mutableDoubleStateOf(0.0) }
    var statusNote by remember { mutableStateOf("Enter feet ('), inches, and fractions (e.g. 12' 6 3/4)") }
    val tape = remember { mutableStateListOf<String>() }
    var hasCalculated by remember { mutableStateOf(false) }

    fun currentNumericOrLast(): Double? = parseFeetInchExpression(inputBuf) ?: if (hasCalculated) lastNumeric else null

    fun applyBinaryOp(op: String) {
        val cur = currentNumericOrLast() ?: return
        if (storedVal != null && pendingOp != null && !hasCalculated) {
            val prev = storedVal!!
            val (res, outKind) = when (pendingOp) {
                "+" -> (prev + cur) to resultKind
                "-" -> (prev - cur) to resultKind
                "×" -> (prev * cur) to FiDimKind.AREA
                "÷" -> (if (abs(cur) > 1e-12) prev / cur else Double.NaN) to FiDimKind.SCALAR
                else -> cur to FiDimKind.LENGTH
            }
            storedVal = res
            lastNumeric = res
            resultKind = outKind
            inputBuf = formatFeetInchFraction(res, outKind)
            tape.add(0, "$prev $pendingOp $cur = ${formatFeetInchFraction(res, outKind)}")
        } else {
            storedVal = cur
            lastNumeric = cur
        }
        pendingOp = op
        hasCalculated = true
        statusNote = "Stored ${UnitConverter.fmt(storedVal ?: 0.0, 3)} ft  $op"
    }

    fun evaluateEquals() {
        val cur = parseFeetInchExpression(inputBuf) ?: lastNumeric
        val prev = storedVal
        val op = pendingOp
        if (prev != null && op != null) {
            val (res, outKind) = when (op) {
                "+" -> (prev + cur) to resultKind
                "-" -> (prev - cur) to resultKind
                "×" -> (prev * cur) to FiDimKind.AREA
                "÷" -> (if (abs(cur) > 1e-12) prev / cur else Double.NaN) to FiDimKind.SCALAR
                else -> cur to FiDimKind.LENGTH
            }
            lastNumeric = res
            resultKind = outKind
            val fmtOut = formatFeetInchFraction(res, outKind)
            tape.add(0, "${formatFeetInchFraction(prev, FiDimKind.LENGTH)} $op ${formatFeetInchFraction(cur, FiDimKind.LENGTH)} = $fmtOut")
            inputBuf = if (outKind == FiDimKind.LENGTH) fmtOut.replace("\"", "") else UnitConverter.fmt(res, 3)
            storedVal = null
            pendingOp = null
            hasCalculated = true
            statusNote = "$fmtOut  |  ${UnitConverter.fmt(res, 4)} ft  |  ${UnitConverter.fmt(res * 0.3048, 3)} m"
        } else {
            lastNumeric = cur
            resultKind = FiDimKind.LENGTH
            hasCalculated = true
            val fmtOut = formatFeetInchFraction(cur, FiDimKind.LENGTH)
            tape.add(0, "$inputBuf = $fmtOut (${UnitConverter.fmt(cur * 0.3048, 3)} m)")
            statusNote = "$fmtOut  |  ${UnitConverter.fmt(cur, 4)} ft  |  ${UnitConverter.fmt(cur * 0.3048, 3)} m"
        }
    }

    fun applyUnary(mode: String) {
        val v = currentNumericOrLast() ?: return
        val (res, kind, label) = when (mode) {
            "x²" -> Triple(v * v, FiDimKind.AREA, "($v)²")
            "x³" -> Triple(v.pow(3), FiDimKind.VOLUME, "($v)³")
            "√" -> Triple(if (v >= 0) sqrt(v) else Double.NaN, FiDimKind.LENGTH, "√($v)")
            "1/x" -> Triple(if (abs(v) > 1e-12) 1.0 / v else Double.NaN, FiDimKind.SCALAR, "1/($v)")
            "%" -> {
                val base = storedVal ?: 1.0
                Triple(base * (v / 100.0), resultKind, "$v% of $base")
            }
            else -> Triple(v, FiDimKind.LENGTH, "$v")
        }
        lastNumeric = res
        resultKind = kind
        hasCalculated = true
        val formatted = formatFeetInchFraction(res, kind)
        tape.add(0, "$label = $formatted")
        statusNote = formatted
    }

    fun appendToken(tok: String) {
        if (hasCalculated) {
            inputBuf = ""
            hasCalculated = false
            resultKind = FiDimKind.LENGTH
        }
        inputBuf += tok
    }

    val liveParsed = parseFeetInchExpression(inputBuf) ?: lastNumeric

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = "Feet-Inch Construction Calc",
            subtitle = "Fractions (1/16\"), Area, Volume, Memory & Tape",
            onBack = onBack,
            actions = {
                if (tape.isNotEmpty()) {
                    IconButton(onClick = { tape.clear() }) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = "Clear Tape", tint = palette.inkMuted)
                    }
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Readout Display Card
            item {
                EngineeringCard(accentColor = palette.orange) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (pendingOp != null) "Op: $pendingOp (Prev ${UnitConverter.fmt(storedVal ?: 0.0, 2)} ft)" else "Dimension: ${resultKind.name}",
                            style = MaterialTheme.typography.labelSmall,
                            color = palette.skyBlue
                        )
                        if (abs(memoryVal) > 1e-9) {
                            Text("MEM: ${UnitConverter.fmt(memoryVal, 2)} ft", style = MaterialTheme.typography.labelSmall, color = palette.orangeDark)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        color = palette.concreteSurfaceAlt,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, palette.metallicBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                            Text(
                                text = inputBuf.ifEmpty { "0" },
                                fontFamily = MonoFontFamily,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.inkPrimary,
                                textAlign = TextAlign.End,
                                modifier = Modifier.fillMaxWidth().testTag("fi_calc_display")
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "${formatFeetInchFraction(liveParsed, resultKind)}  •  ${UnitConverter.fmt(liveParsed * 0.3048, 3)} m",
                                fontFamily = MonoFontFamily,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.orangeDark
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(statusNote, style = MaterialTheme.typography.labelSmall, color = palette.inkMuted)
                }
            }

            // Keypad
            item {
                EngineeringCard {
                    val memRow = listOf("MC", "MR", "M+", "M-", "AC")
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        memRow.forEach { key ->
                            OutlinedButton(
                                onClick = {
                                    when (key) {
                                        "MC" -> { memoryVal = 0.0; statusNote = "Memory cleared" }
                                        "MR" -> {
                                            inputBuf = formatFeetInchFraction(memoryVal, FiDimKind.LENGTH).replace("\"", "")
                                            hasCalculated = false
                                        }
                                        "M+" -> { memoryVal += liveParsed; statusNote = "Added to Memory (${UnitConverter.fmt(memoryVal, 2)} ft)" }
                                        "M-" -> { memoryVal -= liveParsed; statusNote = "Subtracted from Memory (${UnitConverter.fmt(memoryVal, 2)} ft)" }
                                        "AC" -> {
                                            inputBuf = ""
                                            storedVal = null
                                            pendingOp = null
                                            resultKind = FiDimKind.LENGTH
                                            hasCalculated = false
                                            statusNote = "Cleared"
                                        }
                                    }
                                },
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).height(42.dp)
                            ) {
                                Text(key, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (key == "AC") palette.error else palette.skyBlue)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val sciRow = listOf("x²", "x³", "√", "1/x", "%")
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        sciRow.forEach { key ->
                            OutlinedButton(
                                onClick = { applyUnary(key) },
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).height(42.dp)
                            ) {
                                Text(key, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = palette.inkPrimary)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val fiRow = listOf("Ft (' )" to "' ", "Space" to " ", "/" to "/", "⌫" to "BACK")
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        fiRow.forEach { (label, tok) ->
                            Button(
                                onClick = {
                                    if (tok == "BACK") {
                                        if (inputBuf.isNotEmpty()) inputBuf = inputBuf.dropLast(1)
                                    } else {
                                        appendToken(tok)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.orangeSoft,
                                    contentColor = palette.orangeDark
                                ),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f).height(46.dp)
                            ) {
                                if (tok == "BACK") {
                                    Icon(Icons.AutoMirrored.Rounded.Backspace, contentDescription = "Backspace")
                                } else {
                                    Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    val rows = listOf(
                        listOf("7", "8", "9", "÷"),
                        listOf("4", "5", "6", "×"),
                        listOf("1", "2", "3", "-"),
                        listOf("0", ".", "=", "+")
                    )
                    rows.forEach { r ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            r.forEach { btn ->
                                val isOp = btn in setOf("÷", "×", "-", "+", "=")
                                Button(
                                    onClick = {
                                        when (btn) {
                                            "÷", "×", "-", "+" -> applyBinaryOp(btn)
                                            "=" -> evaluateEquals()
                                            else -> appendToken(btn)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = when (btn) {
                                            "=" -> palette.orange
                                            in setOf("÷", "×", "-", "+") -> palette.skyGlassTint
                                            else -> palette.concreteSurfaceAlt
                                        },
                                        contentColor = when (btn) {
                                            "=" -> MaterialTheme.colorScheme.onPrimary
                                            in setOf("÷", "×", "-", "+") -> palette.skyBlue
                                            else -> palette.inkPrimary
                                        }
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.weight(1f).height(48.dp).testTag("fi_key_$btn")
                                ) {
                                    Text(btn, fontSize = if (isOp) 20.sp else 18.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Running Tape
            if (tape.isNotEmpty()) {
                item {
                    Text("Running Calculation Tape (${tape.size})", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                }
                items(tape) { entry ->
                    Surface(
                        color = palette.concreteCard,
                        border = BorderStroke(1.dp, palette.metallicBorder),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = entry,
                            fontFamily = MonoFontFamily,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.inkSecondary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }
    }
}

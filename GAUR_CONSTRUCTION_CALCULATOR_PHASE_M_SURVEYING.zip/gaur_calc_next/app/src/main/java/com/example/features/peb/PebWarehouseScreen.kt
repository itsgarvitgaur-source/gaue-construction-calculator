package com.example.features.peb

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.core.i18n.LocalAppStrings
import com.example.domain.units.UnitConverter
import com.example.features.diagrams.CadColors
import com.example.features.diagrams.Vec3D
import com.example.features.diagrams.drawAngularArc
import com.example.features.diagrams.drawCadTextPill
import com.example.features.diagrams.drawDashedLine
import com.example.features.diagrams.drawDimensionLine
import com.example.features.diagrams.drawEngineeringGrid
import com.example.features.diagrams.project3DPoint
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.components.PreliminaryDisclaimerBanner
import com.example.ui.theme.LocalEngineeringPalette
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

@Composable
fun PebWarehouseScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    val roofTypes = listOf(
        "Industrial PEB Shed",
        "Double-Slope / Gable Roof",
        "Single-Slope / Shed Roof",
        "Hip Roof",
        "Canopy Roof",
        "Warehouse Roof & Sheet Layout",
        "Flat Roof"
    )
    var selectedRoofType by remember { mutableStateOf("Industrial PEB Shed") }
    var widthStr by remember { mutableStateOf("24.0") }
    var lengthStr by remember { mutableStateOf("48.0") }
    var eaveHStr by remember { mutableStateOf("8.0") }
    var ridgeHStr by remember { mutableStateOf("10.4") }
    var baySpaceStr by remember { mutableStateOf("6.0") }
    var purlinSpaceStr by remember { mutableStateOf("1.5") }
    var mezzanineAreaStr by remember { mutableStateOf("120") }
    var hasCraneBay by remember { mutableStateOf(true) }
    var floorThickMmStr by remember { mutableStateOf("150") }
    var pebSteelFactorStr by remember { mutableStateOf("32") } // kg/m² prelim factor

    val w = (widthStr.toDoubleOrNull() ?: 24.0).coerceAtLeast(4.0)
    val l = (lengthStr.toDoubleOrNull() ?: 48.0).coerceAtLeast(4.0)
    val eaveH = (eaveHStr.toDoubleOrNull() ?: 8.0).coerceAtLeast(3.0)
    val isFlat = selectedRoofType == "Flat Roof"
    val isSingleSlope = selectedRoofType == "Single-Slope / Shed Roof" || selectedRoofType == "Canopy Roof"
    val isHip = selectedRoofType == "Hip Roof"
    val isCanopy = selectedRoofType == "Canopy Roof"
    val ridgeH = if (isFlat) eaveH else max(eaveH + 0.3, ridgeHStr.toDoubleOrNull() ?: 10.4)
    val baySpace = (baySpaceStr.toDoubleOrNull() ?: 6.0).coerceAtLeast(3.0)
    val purlinSpace = (purlinSpaceStr.toDoubleOrNull() ?: 1.5).coerceAtLeast(0.8)
    val mezzArea = (mezzanineAreaStr.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)
    val floorThickM = (floorThickMmStr.toDoubleOrNull() ?: 150.0).coerceAtLeast(75.0) / 1000.0
    val steelFactor = (pebSteelFactorStr.toDoubleOrNull() ?: 32.0).coerceAtLeast(15.0)

    val rise = if (isFlat) 0.0 else (ridgeH - eaveH)
    val pitchSpan = if (isSingleSlope) w else (w / 2.0)
    val roofAngleDeg = if (isFlat) 0.0 else Math.toDegrees(atan(rise / pitchSpan))
    val slopeRatioN = if (rise > 0.01) pitchSpan / rise else 0.0
    val rafterSlopeLen = if (isFlat) w else sqrt(pitchSpan * pitchSpan + rise * rise)
    val roofAreaM2 = when {
        isFlat -> w * l
        isSingleSlope -> rafterSlopeLen * l
        isHip -> (w * l) / kotlin.math.cos(Math.toRadians(roofAngleDeg)).coerceAtLeast(0.5)
        else -> 2.0 * rafterSlopeLen * l
    }
    val wallH = (eaveH - 1.2).coerceAtLeast(1.0)
    val sideCladdingM2 = if (isCanopy) 0.0 else if (isSingleSlope) (l * wallH + l * (wallH + rise)) else (2.0 * l * wallH)
    val endCladdingM2 = if (isCanopy) 0.0 else 2.0 * (w * wallH + 0.5 * w * rise)
    val totalCladdingM2 = sideCladdingM2 + endCladdingM2

    val numBays = max(1, ceil(l / baySpace).toInt())
    val numFrames = numBays + 1
    val numColumns = numFrames * 2
    val slopeSides = if (isFlat || isSingleSlope) 1 else 2
    val purlinRowsPerSlope = ceil(rafterSlopeLen / purlinSpace).toInt() + 1
    val totalPurlinLenM = purlinRowsPerSlope * slopeSides * l

    val floorAreaM2 = w * l
    val trimixVolM3 = floorAreaM2 * floorThickM
    val floorRebarKg = trimixVolM3 * 0.006 * 7850.0 // preliminary 0.6% floor mesh est.

    val anchorBoltsPerBase = 4
    val totalAnchorBolts = numColumns * anchorBoltsPerBase
    val basePlateAreaEachM2 = 0.40 * 0.40 // 400x400x16mm ref
    val pedestalVolM3 = numColumns * (0.6 * 0.6 * 1.0)
    val foundationVolM3 = numColumns * (1.8 * 1.8 * 0.45)

    val craneAllowanceFactor = if (hasCraneBay) 1.15 else 1.0
    val primarySteelKg = floorAreaM2 * steelFactor * craneAllowanceFactor + mezzArea * 38.0
    val estTotalCost = primarySteelKg * 116.0 +
        (roofAreaM2 + totalCladdingM2) * 10.7639 * 67.0 +
        (trimixVolM3 + pedestalVolM3 + foundationVolM3) * 6200.0

    val resultRows = listOf(
        "Floor Footprint" to "${UnitConverter.fmt(floorAreaM2, 1)} m² (${UnitConverter.fmt(floorAreaM2 * 10.7639, 0)} sq.ft)",
        "Roof Slope & Angle" to "1 : ${UnitConverter.fmt(slopeRatioN, 1)}  (${UnitConverter.fmt(roofAngleDeg, 2)}°)",
        "Rafter Slope Length (Each Side)" to "${UnitConverter.fmt(rafterSlopeLen, 2)} m",
        "Roofing Sheet Area" to "${UnitConverter.fmt(roofAreaM2, 1)} m² (${UnitConverter.fmt(roofAreaM2 * 10.7639, 0)} sq.ft)",
        "Side Wall Cladding Area" to "${UnitConverter.fmt(sideCladdingM2, 1)} m²",
        "End-Wall Gable Cladding Area" to "${UnitConverter.fmt(endCladdingM2, 1)} m²",
        "Frames / Columns" to "$numFrames Frames ($numBays Bays) • $numColumns Main Columns",
        "Purlins (Z/C Section)" to "${purlinRowsPerSlope * 2} Lines • ${UnitConverter.fmt(totalPurlinLenM, 1)} m",
        "Prelim. PEB Structural Steel" to "${UnitConverter.fmt(primarySteelKg / 1000.0, 2)} MT (${UnitConverter.fmt(primarySteelKg, 0)} kg)",
        "Mezzanine Area" to "${UnitConverter.fmt(mezzArea, 1)} m²",
        "Trimix Industrial Floor Concrete" to "${UnitConverter.fmt(trimixVolM3, 2)} m³ (Rebar ~${UnitConverter.fmt(floorRebarKg, 0)} kg)",
        "Anchor Bolts (4/Col @ 300×300)" to "$totalAnchorBolts Nos • $numColumns Base Plates (400×400 mm)",
        "Pedestal + Isolated Footing Conc." to "${UnitConverter.fmt(pedestalVolM3, 2)} + ${UnitConverter.fmt(foundationVolM3, 2)} m³",
        "Preliminary Budgetary Cost Est." to "${settings.currencySymbol}${UnitConverter.fmt(estTotalCost, 0)}"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = strings.pebTitle,
            subtitle = "Warehouse Framing, Sheeting, Trimix & Foundations",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                PreliminaryDisclaimerBanner(
                    "Preliminary PEB & Warehouse Quantity Estimate — Not a verified structural design. Wind loads, seismic zone, crane surge & connection plates must be engineered per IS 800 / MBMA."
                )
            }

            // Roof & PEB Type Selector
            item {
                EngineeringCard(accentColor = palette.orange) {
                    Text("Roof & PEB Configuration Type", style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(roofTypes) { rType ->
                            val isSel = selectedRoofType == rType
                            FilterChip(
                                selected = isSel,
                                onClick = { selectedRoofType = rType },
                                label = { Text(rType, style = MaterialTheme.typography.labelMedium) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = palette.orange.copy(alpha = 0.14f),
                                    selectedLabelColor = palette.orangeDark
                                ),
                                border = BorderStroke(1.dp, if (isSel) palette.orange else palette.metallicBorder),
                                modifier = Modifier.testTag("peb_type_${rType}")
                            )
                        }
                    }
                }
            }

            // Live Interactive CAD PEB Figure (Gable Elevation / Bay Plan / 3D Shed View)
            item {
                InteractivePebCadCard(
                    roofType = selectedRoofType,
                    widthM = w,
                    lengthM = l,
                    eaveHM = eaveH,
                    ridgeHM = ridgeH,
                    baySpaceM = baySpace,
                    numBays = numBays,
                    numFrames = numFrames,
                    numColumns = numColumns,
                    roofAngleDeg = roofAngleDeg,
                    slopeRatioN = slopeRatioN,
                    rafterSlopeLenM = rafterSlopeLen,
                    roofAreaM2 = roofAreaM2,
                    hasCraneBay = hasCraneBay
                )
            }

            // Input Parameters
            item {
                EngineeringCard(accentColor = palette.orange) {
                    Text("Warehouse Geometry & Parameters", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = widthStr, onValueChange = { widthStr = it }, label = { Text("Width (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f).testTag("peb_width"))
                        OutlinedTextField(value = lengthStr, onValueChange = { lengthStr = it }, label = { Text("Length (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f).testTag("peb_length"))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = eaveHStr, onValueChange = { eaveHStr = it }, label = { Text("Eave Ht (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = ridgeHStr, onValueChange = { ridgeHStr = it }, label = { Text("Ridge Ht (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = baySpaceStr, onValueChange = { baySpaceStr = it }, label = { Text("Bay Space (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = purlinSpaceStr, onValueChange = { purlinSpaceStr = it }, label = { Text("Purlin Space (m)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = mezzanineAreaStr, onValueChange = { mezzanineAreaStr = it }, label = { Text("Mezzanine (m²)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = floorThickMmStr, onValueChange = { floorThickMmStr = it }, label = { Text("Trimix (mm)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("EOT Crane Bay Allowance (+15% Steel)", style = MaterialTheme.typography.bodyMedium, color = palette.inkPrimary)
                            Text("Includes crane girder & bracket steel allowance", style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                        }
                        Switch(checked = hasCraneBay, onCheckedChange = { hasCraneBay = it })
                    }
                }
            }

            // Computed Breakdown
            item {
                EngineeringCard(accentColor = palette.skyBlue) {
                    Text("PEB Quantity & Cost Breakdown", style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                    Spacer(Modifier.height(10.dp))
                    resultRows.forEach { (k, v) ->
                        Surface(
                            color = palette.concreteSurfaceAlt,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(k, style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary, modifier = Modifier.weight(1f))
                                Spacer(Modifier.width(8.dp))
                                Text(v, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = palette.inkPrimary)
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val report = EngineeringReportData(
                                    title = "PEB Warehouse Preliminary Estimate (${w}m × ${l}m)",
                                    projectName = "Industrial Warehouse",
                                    companyName = settings.companyName,
                                    engineerName = settings.engineerName,
                                    sections = listOf(
                                        ReportSection("PEB Structural & Civil Quantities", rows = resultRows),
                                        ReportSection("Engineering Disclaimer", paragraphs = listOf("Preliminary estimate only. Final PEB frame weight and anchor bolt sizing must be certified per IS 800 / MBMA."))
                                    )
                                )
                                val file = ReportExportEngine.generatePdfFile(context, report)
                                ReportExportEngine.shareFile(context, file, "application/pdf", "PEB_Warehouse_Estimate")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.error)
                            Spacer(Modifier.width(4.dp))
                            Text("Export PDF")
                        }
                        OutlinedButton(
                            onClick = {
                                val file = ReportExportEngine.generateExcelWorkbookFile(
                                    context,
                                    "PEB_Warehouse",
                                    listOf("Parameter", "Quantity / Estimate"),
                                    resultRows.map { listOf(it.first, it.second) }
                                )
                                ReportExportEngine.shareFile(context, file, "application/vnd.ms-excel", "PEB_Warehouse_Estimate")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.success)
                            Spacer(Modifier.width(4.dp))
                            Text("Export Excel")
                        }
                    }
                }
            }
        }
    }
}

private enum class PebCadView(val label: String) {
    GABLE_ELEVATION("Gable Elevation"),
    BAY_PLAN("Bay & Column Plan"),
    SHED_3D("3D Shed View")
}

@Composable
private fun InteractivePebCadCard(
    roofType: String,
    widthM: Double,
    lengthM: Double,
    eaveHM: Double,
    ridgeHM: Double,
    baySpaceM: Double,
    numBays: Int,
    numFrames: Int,
    numColumns: Int,
    roofAngleDeg: Double,
    slopeRatioN: Double,
    rafterSlopeLenM: Double,
    roofAreaM2: Double,
    hasCraneBay: Boolean
) {
    val palette = LocalEngineeringPalette.current
    var selectedView by remember { mutableStateOf(PebCadView.GABLE_ELEVATION) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var yawDeg by remember { mutableFloatStateOf(36f) }
    var pitchDeg by remember { mutableFloatStateOf(24f) }

    fun resetAll() {
        zoom = 1f
        panX = 0f
        panY = 0f
        yawDeg = 36f
        pitchDeg = 24f
    }

    EngineeringCard(accentColor = palette.skyBlue, modifier = Modifier.testTag("peb_cad_card")) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(palette.skyGlassTint)
                    .border(1.dp, palette.skyGlassBorder, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Straighten, contentDescription = null, tint = palette.skyBlue, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.width(8.dp))
            Column {
                Text(
                    "$roofType CAD Drawing",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = palette.inkPrimary
                )
                Text(
                    "Span ${UnitConverter.fmt(widthM, 1)}m × Length ${UnitConverter.fmt(lengthM, 1)}m • Slope ${UnitConverter.fmt(roofAngleDeg, 1)}°",
                    style = MaterialTheme.typography.labelSmall,
                    color = palette.inkMuted
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(PebCadView.entries) { v ->
                FilterChip(
                    selected = selectedView == v,
                    onClick = {
                        selectedView = v
                        zoom = 1f; panX = 0f; panY = 0f
                    },
                    label = { Text(v.label, style = MaterialTheme.typography.labelMedium) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = palette.skyGlassTint,
                        selectedLabelColor = palette.skyBlue
                    ),
                    border = BorderStroke(1.dp, if (selectedView == v) palette.skyBlue else palette.metallicBorder)
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(palette.concreteSurfaceAlt)
                .border(1.dp, palette.metallicBorder, RoundedCornerShape(10.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassBluePill(
                text = "Roof ${UnitConverter.fmt(roofAreaM2, 0)} m² • $numColumns Cols",
                modifier = Modifier.weight(1f, fill = false)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { zoom = (zoom * 1.22f).coerceAtMost(2.8f) }, modifier = Modifier.minimumInteractiveComponentSize().testTag("peb_zoom_in")) {
                    Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom In", tint = palette.skyBlue)
                }
                IconButton(onClick = { zoom = (zoom / 1.22f).coerceAtLeast(0.6f) }, modifier = Modifier.minimumInteractiveComponentSize().testTag("peb_zoom_out")) {
                    Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom Out", tint = palette.skyBlue)
                }
                IconButton(onClick = { zoom = 1f; panX = 0f; panY = 0f }, modifier = Modifier.minimumInteractiveComponentSize().testTag("peb_fit")) {
                    Icon(Icons.Rounded.CenterFocusStrong, contentDescription = "Fit to Screen", tint = palette.inkPrimary)
                }
                IconButton(onClick = { resetAll() }, modifier = Modifier.minimumInteractiveComponentSize().testTag("peb_reset")) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Reset View", tint = palette.orangeDark)
                }
            }
        }

        Spacer(Modifier.height(8.dp))

        Surface(
            color = Color(0xFFFAFBFD),
            border = BorderStroke(1.5.dp, palette.skyGlassBorder),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(265.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .clipToBounds()
                    .testTag("peb_cad_canvas")
                    .pointerInput(selectedView) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            if (selectedView == PebCadView.SHED_3D) {
                                yawDeg = (yawDeg + drag.x * 0.45f) % 360f
                                pitchDeg = (pitchDeg + drag.y * 0.35f).coerceIn(8f, 75f)
                            } else {
                                panX = (panX + drag.x).coerceIn(-280f, 280f)
                                panY = (panY + drag.y).coerceIn(-220f, 220f)
                            }
                        }
                    }
            ) {
                drawEngineeringGrid(spacingPx = 32f)
                withTransform({
                    translate(left = panX, top = panY)
                    scale(scaleX = zoom, scaleY = zoom, pivot = Offset(size.width / 2f, size.height / 2f))
                }) {
                    val w = size.width
                    val h = size.height
                    val isFlatType = roofType == "Flat Roof"
                    val isSingleType = roofType == "Single-Slope / Shed Roof" || roofType == "Canopy Roof"
                    val isHipType = roofType == "Hip Roof"
                    when (selectedView) {
                        PebCadView.GABLE_ELEVATION -> {
                            val pad = 78f
                            val spanPx = w - pad * 2f
                            val scale = min(spanPx / widthM.toFloat(), (h * 0.56f) / ridgeHM.toFloat())
                            val drawSpan = widthM.toFloat() * scale
                            val leftX = w / 2f - drawSpan / 2f
                            val rightX = w / 2f + drawSpan / 2f
                            val midX = w / 2f
                            val baseY = h * 0.78f
                            val eaveY = baseY - eaveHM.toFloat() * scale
                            val ridgeY = baseY - ridgeHM.toFloat() * scale

                            // Concrete Trimix slab & footings
                            drawLine(CadColors.ConcreteStroke, Offset(leftX - 24f, baseY), Offset(rightX + 24f, baseY), 4f)
                            drawRect(CadColors.ConcreteFill, Offset(leftX - 10f, baseY), Size(20f, 16f))
                            drawRect(CadColors.ConcreteFill, Offset(rightX - 10f, baseY), Size(20f, 16f))

                            // Portal frame
                            val framePath = Path().apply {
                                moveTo(leftX, baseY)
                                lineTo(leftX, eaveY)
                                when {
                                    isFlatType -> lineTo(rightX, eaveY)
                                    isSingleType -> lineTo(rightX, ridgeY)
                                    else -> {
                                        lineTo(midX, ridgeY)
                                        lineTo(rightX, eaveY)
                                    }
                                }
                                if (roofType != "Canopy Roof") lineTo(rightX, baseY)
                            }
                            drawPath(framePath, CadColors.DimOrange, style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                            drawDashedLine(Offset(leftX, eaveY), Offset(rightX, eaveY), CadColors.ConcreteDarkFill, 2f)

                            if (hasCraneBay) {
                                val craneY = baseY - (eaveHM.toFloat() * 0.68f) * scale
                                drawDashedLine(Offset(leftX, craneY), Offset(rightX, craneY), CadColors.DimBlue, 3f)
                                drawCadTextPill("EOT Crane Beam", Offset(midX, craneY - 16f), CadColors.DimBlue, textSizePx = 20f)
                            }

                            drawDimensionLine(Offset(leftX, baseY + 16f), Offset(rightX, baseY + 16f), 28f, "Span W = ${UnitConverter.fmt(widthM, 1)} m")
                            drawDimensionLine(Offset(leftX, eaveY), Offset(leftX, baseY), -48f, "Eave=${UnitConverter.fmt(eaveHM, 1)}m", CadColors.DimOrange)
                            if (!isFlatType) {
                                drawDimensionLine(Offset(rightX, ridgeY), Offset(rightX, baseY), -52f, "Ridge=${UnitConverter.fmt(ridgeHM, 1)}m", CadColors.DimBlue)
                                drawAngularArc(Offset(leftX, eaveY), 46f, -roofAngleDeg.toFloat().coerceIn(5f, 45f), roofAngleDeg.toFloat().coerceIn(5f, 45f), "${UnitConverter.fmt(roofAngleDeg, 1)}°")
                            }
                            drawCadTextPill("Rafter=${UnitConverter.fmt(rafterSlopeLenM, 2)}m (${roofType})", Offset(midX, 24f), CadColors.DimOrange, textSizePx = 21f)
                        }
                        PebCadView.BAY_PLAN -> {
                            val pad = 74f
                            val planW = w - pad * 2f
                            val planH = (planW * (widthM / lengthM).toFloat().coerceIn(0.38f, 0.72f)).coerceAtMost(h * 0.56f)
                            val top = h * 0.52f - planH / 2f
                            val bottom = top + planH

                            drawRect(CadColors.GlassFill.copy(alpha = 0.25f), Offset(pad, top), Size(planW, planH))
                            drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(planW, planH), style = Stroke(3f))
                            if (isHipType) {
                                val inset = min(planW * 0.24f, planH * 0.5f)
                                val rL = Offset(pad + inset, top + planH / 2f)
                                val rR = Offset(pad + planW - inset, top + planH / 2f)
                                drawLine(CadColors.DimOrange, rL, rR, 3.5f)
                                drawLine(CadColors.DimOrange, Offset(pad, top), rL, 3f)
                                drawLine(CadColors.DimOrange, Offset(pad, bottom), rL, 3f)
                                drawLine(CadColors.DimOrange, Offset(pad + planW, top), rR, 3f)
                                drawLine(CadColors.DimOrange, Offset(pad + planW, bottom), rR, 3f)
                            } else if (!isFlatType && !isSingleType) {
                                drawDashedLine(Offset(pad, top + planH / 2f), Offset(pad + planW, top + planH / 2f), CadColors.DimOrange, 3f)
                            }

                            val drawnBays = numBays.coerceAtMost(12)
                            for (i in 0..drawnBays) {
                                val fx = pad + (i.toFloat() / drawnBays) * planW
                                drawLine(CadColors.DimOrange, Offset(fx, top), Offset(fx, bottom), 3f)
                                drawCircle(CadColors.ConcreteStroke, 6f, Offset(fx, top))
                                drawCircle(CadColors.ConcreteStroke, 6f, Offset(fx, bottom))
                            }
                            val bayPx = planW / drawnBays
                            drawDimensionLine(Offset(pad, bottom), Offset(pad + planW, bottom), 36f, "Building Length L = ${UnitConverter.fmt(lengthM, 1)} m")
                            drawDimensionLine(Offset(pad, top), Offset(pad, bottom), -48f, "Span ${UnitConverter.fmt(widthM, 1)}m", CadColors.DimOrange)
                            drawDimensionLine(Offset(pad, top), Offset(pad + bayPx, top), -28f, "Bay=${UnitConverter.fmt(baySpaceM, 1)}m")
                            drawCadTextPill("$numFrames Frames • $numColumns Column Positions", Offset(w / 2f, 24f), CadColors.DimBlue, textSizePx = 22f)
                        }
                        PebCadView.SHED_3D -> {
                            val wl = lengthM.toFloat()
                            val ww = widthM.toFloat()
                            val eh = eaveHM.toFloat()
                            val rh = ridgeHM.toFloat()
                            val scale = (min(w, h) * 0.48f) / max(wl, ww)
                            val cRef = Vec3D(wl / 2f, ww / 2f, rh / 2f)
                            val center = Offset(w / 2f, h * 0.58f)
                            val drawnFrames = (numFrames).coerceIn(2, 8)
                            var firstLeft = Offset.Zero
                            var firstRight = Offset.Zero
                            var lastRight = Offset.Zero
                            for (i in 0 until drawnFrames) {
                                val x = wl * i / (drawnFrames - 1)
                                val pBL = project3DPoint(Vec3D(x, 0f, 0f), cRef, center, scale, yawDeg, pitchDeg).first
                                val pEL = project3DPoint(Vec3D(x, 0f, eh), cRef, center, scale, yawDeg, pitchDeg).first
                                val pER = project3DPoint(Vec3D(x, ww, if (isSingleType) rh else eh), cRef, center, scale, yawDeg, pitchDeg).first
                                val pBR = project3DPoint(Vec3D(x, ww, 0f), cRef, center, scale, yawDeg, pitchDeg).first
                                val framePath = Path().apply {
                                    moveTo(pBL.x, pBL.y)
                                    lineTo(pEL.x, pEL.y)
                                    if (!isFlatType && !isSingleType) {
                                        val pR = project3DPoint(Vec3D(x, ww / 2f, rh), cRef, center, scale, yawDeg, pitchDeg).first
                                        lineTo(pR.x, pR.y)
                                    }
                                    lineTo(pER.x, pER.y)
                                    lineTo(pBR.x, pBR.y)
                                }
                                drawPath(framePath, CadColors.DimOrange, style = Stroke(width = 4f, join = StrokeJoin.Round))
                                if (i == 0) {
                                    firstLeft = pBL
                                    firstRight = pBR
                                }
                                if (i == drawnFrames - 1) lastRight = pBR
                            }
                            if (!isFlatType && !isSingleType) {
                                val r0 = project3DPoint(Vec3D(0f, ww / 2f, rh), cRef, center, scale, yawDeg, pitchDeg).first
                                val r1 = project3DPoint(Vec3D(wl, ww / 2f, rh), cRef, center, scale, yawDeg, pitchDeg).first
                                drawLine(CadColors.DimBlue, r0, r1, 3f)
                            }
                            val eL0 = project3DPoint(Vec3D(0f, 0f, eh), cRef, center, scale, yawDeg, pitchDeg).first
                            val eL1 = project3DPoint(Vec3D(wl, 0f, eh), cRef, center, scale, yawDeg, pitchDeg).first
                            val eR0 = project3DPoint(Vec3D(0f, ww, if (isSingleType) rh else eh), cRef, center, scale, yawDeg, pitchDeg).first
                            val eR1 = project3DPoint(Vec3D(wl, ww, if (isSingleType) rh else eh), cRef, center, scale, yawDeg, pitchDeg).first
                            drawLine(CadColors.ConcreteStroke, eL0, eL1, 2.5f)
                            drawLine(CadColors.ConcreteStroke, eR0, eR1, 2.5f)
                            drawDimensionLine(firstLeft, firstRight, 26f, "Span ${UnitConverter.fmt(widthM, 1)}m")
                            drawDimensionLine(firstRight, lastRight, 26f, "L=${UnitConverter.fmt(lengthM, 1)}m")
                            drawCadTextPill("Drag to Orbit 3D $roofType ($numBays Bays)", Offset(w / 2f, 24f), CadColors.DimBlue, textSizePx = 21f)
                        }
                    }
                }
            }
        }
    }
}

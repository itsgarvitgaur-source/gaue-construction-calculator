package com.example.features.calculators

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BookmarkAdd
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.core.preferences.UnitSystemPref
import com.example.data.local.CalculationHistoryEntity
import com.example.domain.calculators.CalcContext
import com.example.domain.calculators.CalcOutcome
import com.example.domain.calculators.CalculatorRegistry
import com.example.domain.calculators.FieldUnitKind
import com.example.domain.units.LengthUnit
import com.example.features.diagrams.DiagramInputSnapshot
import com.example.features.diagrams.InteractiveEngineeringFigureCard
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.PreliminaryDisclaimerBanner
import com.example.ui.theme.LocalEngineeringPalette
import com.example.ui.theme.MonoFontFamily
import org.json.JSONArray
import org.json.JSONObject

private val CalculatorTeal = androidx.compose.ui.graphics.Color(0xFF008C89)
private val CalculatorTealDark = androidx.compose.ui.graphics.Color(0xFF006466)
private val CalculatorTealTint = androidx.compose.ui.graphics.Color(0xFFE2F3F2)
private val CalculatorTealBorder = androidx.compose.ui.graphics.Color(0xFF9CCFCB)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorDetailScreen(
    toolId: String,
    viewModel: MainViewModel,
    breadcrumbPath: String? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteToolIds.collectAsStateWithLifecycle()

    val tool = remember(toolId) { CalculatorRegistry.byId(toolId) }
    if (tool == null) {
        Column(Modifier.fillMaxSize().background(palette.concreteBg)) {
            EngineeringTopBar(title = "Calculator Not Found", onBack = onBack)
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Requested tool '$toolId' was not found.", color = palette.inkMuted)
            }
        }
        return
    }

    val fieldValues = remember(toolId) {
        mutableStateMapOf<String, String>().apply {
            tool.fields.forEach { put(it.key, it.defaultValue) }
        }
    }
    val lengthUnits = remember(toolId, settings.unitSystem) {
        mutableStateMapOf<String, LengthUnit>().apply {
            tool.fields.forEach { f ->
                val defaultUnit = if (settings.unitSystem == UnitSystemPref.IMPERIAL && f.defaultLengthUnit == LengthUnit.M) {
                    LengthUnit.FT
                } else f.defaultLengthUnit
                put(f.key, defaultUnit)
            }
        }
    }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var outcome by remember(toolId) { mutableStateOf<CalcOutcome?>(null) }
    var showSaveDialog by remember { mutableStateOf(false) }

    fun runCalculation() {
        val ctx = CalcContext(
            inputs = fieldValues.toMap(),
            lengthUnits = lengthUnits.toMap(),
            settings = settings,
            ratesByKeyword = viewModel.getRatesKeywordMap()
        )
        tool.compute(ctx)
            .onSuccess {
                outcome = it
                errorMessage = null
            }
            .onFailure {
                errorMessage = it.message ?: "Invalid engineering inputs."
            }
    }

    LaunchedEffect(toolId, fieldValues.toMap(), lengthUnits.toMap(), settings) {
        runCalculation()
    }

    fun buildReport(out: CalcOutcome): EngineeringReportData {
        val currentMap = fieldValues.toMap()
        val inputPairs = tool.fields
            .filter { f -> f.visibleWhen?.invoke(currentMap) ?: true }
            .map { f ->
                val u = if (f.unitKind == FieldUnitKind.LENGTH) " (${(lengthUnits[f.key] ?: f.defaultLengthUnit).symbol})" else ""
                val lbl = f.dynamicLabel?.invoke(currentMap) ?: f.label
                "$lbl$u" to (fieldValues[f.key] ?: "")
            }
        val resultPairs = out.results.map { r ->
            r.label to "${r.value} ${r.unit}".trim()
        }
        return EngineeringReportData(
            title = tool.title,
            projectName = "Site Calculation",
            companyName = settings.companyName,
            engineerName = settings.engineerName,
            subtitle = tool.subtitle,
            sections = listOf(
                ReportSection("Input Parameters", rows = inputPairs),
                ReportSection("Calculated Results", rows = resultPairs),
                ReportSection("Formula & Step-by-Step Breakdown", paragraphs = listOf("Formula: ${out.formula}") + out.steps),
                ReportSection("Engineering Assumptions", paragraphs = listOf(out.assumptions) + out.warnings)
            )
        )
    }

    val isFav = favoriteIds.contains(tool.id)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = if (settings.language == AppLanguage.HINDI) tool.titleHi else tool.title,
            subtitle = breadcrumbPath?.takeIf { it.isNotBlank() } ?: tool.category.titleEn,
            onBack = onBack,
            actions = {
                IconButton(
                    onClick = { viewModel.toggleFavorite(tool.id) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("calc_fav_btn")
                ) {
                    Icon(
                        imageVector = if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (isFav) CalculatorTeal else palette.inkMuted
                    )
                }
            }
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (tool.isPreliminaryStructural) {
                item {
                    PreliminaryDisclaimerBanner(strings.preliminaryNotice)
                }
            }

            // Live Input-Linked Engineering Figure & Dimensioned Drawing
            item {
                val diagramSnapshot = DiagramInputSnapshot(
                    toolId = tool.id,
                    inputs = fieldValues.toMap(),
                    lengthUnits = lengthUnits.toMap(),
                    settings = settings
                )
                InteractiveEngineeringFigureCard(snapshot = diagramSnapshot)
            }

            // Input Card
            item {
                EngineeringCard(accentColor = CalculatorTeal) {
                    Text(
                        text = tool.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = palette.inkSecondary
                    )
                    Spacer(Modifier.height(12.dp))

                    val currentMap = fieldValues.toMap()
                    val typeField = tool.typeFieldKey?.let { key ->
                        tool.fields.firstOrNull { it.key == key }
                    }
                    if (typeField != null && typeField.options.isNotEmpty()) {
                        val selectedType = fieldValues[typeField.key] ?: typeField.defaultValue
                        var typeMenuOpen by remember { mutableStateOf(false) }
                        Text(
                            text = "${typeField.label} (${typeField.options.size} Configurations)",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = CalculatorTealDark
                        )
                        Spacer(Modifier.height(6.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                        ) {
                            items(typeField.options) { opt ->
                                val isSelected = selectedType == opt
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        fieldValues[typeField.key] = opt
                                        if (outcome != null) runCalculation()
                                    },
                                    label = {
                                        Text(
                                            text = opt,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = CalculatorTeal.copy(alpha = 0.14f),
                                        selectedLabelColor = CalculatorTealDark
                                    ),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) CalculatorTeal else palette.metallicBorder
                                    ),
                                    modifier = Modifier.testTag("type_chip_${opt}")
                                )
                            }
                        }
                        ExposedDropdownMenuBox(
                            expanded = typeMenuOpen,
                            onExpandedChange = { typeMenuOpen = !typeMenuOpen },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            OutlinedTextField(
                                value = selectedType,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text(typeField.label) },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeMenuOpen) },
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                                    .testTag("field_${typeField.key}"),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CalculatorTeal,
                                    unfocusedBorderColor = CalculatorTeal.copy(alpha = 0.55f)
                                )
                            )
                            ExposedDropdownMenu(expanded = typeMenuOpen, onDismissRequest = { typeMenuOpen = false }) {
                                typeField.options.forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(opt) },
                                        onClick = {
                                            fieldValues[typeField.key] = opt
                                            typeMenuOpen = false
                                            if (outcome != null) runCalculation()
                                        }
                                    )
                                }
                            }
                        }
                    }

                    tool.fields.forEach { field ->
                        if (field.key == tool.typeFieldKey) return@forEach
                        val isVisible = field.visibleWhen?.invoke(currentMap) ?: true
                        if (!isVisible) return@forEach
                        val fieldLabel = field.dynamicLabel?.invoke(currentMap) ?: field.label

                        if (field.options.isNotEmpty()) {
                            var expanded by remember(field.key) { mutableStateOf(false) }
                            ExposedDropdownMenuBox(
                                expanded = expanded,
                                onExpandedChange = { expanded = !expanded },
                                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                            ) {
                                OutlinedTextField(
                                    value = fieldValues[field.key] ?: field.defaultValue,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text(fieldLabel) },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .fillMaxWidth()
                                        .testTag("field_${field.key}"),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    field.options.forEach { opt ->
                                        DropdownMenuItem(
                                            text = { Text(opt) },
                                            onClick = {
                                                fieldValues[field.key] = opt
                                                expanded = false
                                                if (outcome != null) runCalculation()
                                            }
                                        )
                                    }
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = fieldValues[field.key] ?: "",
                                    onValueChange = { fieldValues[field.key] = it },
                                    label = { Text(fieldLabel) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = if (tool.id == "basic_fraction_calc") KeyboardType.Text else KeyboardType.Decimal
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("field_${field.key}"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CalculatorTeal,
                                        unfocusedBorderColor = palette.metallicBorder
                                    )
                                )
                                if (field.unitKind == FieldUnitKind.LENGTH) {
                                    Spacer(Modifier.width(8.dp))
                                    var unitOpen by remember { mutableStateOf(false) }
                                    val selectedUnit = lengthUnits[field.key] ?: field.defaultLengthUnit
                                    ExposedDropdownMenuBox(
                                        expanded = unitOpen,
                                        onExpandedChange = { unitOpen = !unitOpen },
                                        modifier = Modifier.width(102.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = selectedUnit.symbol,
                                            onValueChange = {},
                                            readOnly = true,
                                            singleLine = true,
                                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitOpen) },
                                            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable),
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        ExposedDropdownMenu(expanded = unitOpen, onDismissRequest = { unitOpen = false }) {
                                            LengthUnit.entries.forEach { u ->
                                                DropdownMenuItem(
                                                    text = { Text(u.symbol) },
                                                    onClick = {
                                                        lengthUnits[field.key] = u
                                                        unitOpen = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (errorMessage != null) {
                        Surface(
                            color = palette.errorBg,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = palette.error,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { runCalculation() },
                            colors = ButtonDefaults.buttonColors(containerColor = CalculatorTeal),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1.4f)
                                .height(48.dp)
                                .testTag("calculate_btn")
                        ) {
                            Icon(Icons.Rounded.Calculate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(strings.calculate, fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = {
                                tool.fields.forEach { fieldValues[it.key] = it.defaultValue }
                                outcome = null
                                errorMessage = null
                            },
                            border = BorderStroke(1.dp, palette.metallicBorder),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(0.9f)
                                .height(48.dp)
                                .testTag("reset_btn")
                        ) {
                            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(strings.reset)
                        }
                    }
                }
            }

            // Results Section
            outcome?.let { out ->
                if (out.warnings.isNotEmpty()) {
                    item {
                        PreliminaryDisclaimerBanner(out.warnings.joinToString("\n"))
                    }
                }

                item {
                    EngineeringCard(accentColor = CalculatorTeal, modifier = Modifier.testTag("results_card")) {
                        Text(strings.results, style = MaterialTheme.typography.titleMedium, color = palette.inkPrimary)
                        Spacer(Modifier.height(10.dp))
                        out.results.forEach { res ->
                            Surface(
                                color = if (res.isPrimary) CalculatorTealTint else palette.concreteSurfaceAlt,
                                border = if (res.isPrimary) BorderStroke(1.dp, CalculatorTealBorder) else null,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = res.label,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = palette.inkSecondary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = "${res.value} ${res.unit}".trim(),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (res.isPrimary) CalculatorTeal else palette.inkPrimary
                                    )
                                }
                            }
                        }

                        // Action Bar: Save, PDF, Excel/CSV, Print, Share
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showSaveDialog = true },
                                modifier = Modifier.weight(1f).testTag("save_calc_btn"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Rounded.BookmarkAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.save, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = {
                                    val file = ReportExportEngine.generatePdfFile(context, buildReport(out))
                                    ReportExportEngine.shareFile(context, file, "application/pdf", tool.title)
                                },
                                modifier = Modifier.weight(1f).testTag("pdf_calc_btn"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.error)
                                Spacer(Modifier.width(4.dp))
                                Text("PDF", maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = {
                                    val rows = out.results.map { listOf(it.label, it.value, it.unit) }
                                    val file = ReportExportEngine.generateExcelWorkbookFile(
                                        context,
                                        tool.title,
                                        listOf("Parameter", "Value", "Unit"),
                                        rows
                                    )
                                    ReportExportEngine.shareFile(context, file, "application/vnd.ms-excel", tool.title)
                                },
                                modifier = Modifier.weight(1f).testTag("excel_calc_btn"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Rounded.TableChart, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.success)
                                Spacer(Modifier.width(4.dp))
                                Text("Excel", maxLines = 1)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val file = ReportExportEngine.generatePdfFile(context, buildReport(out))
                                    ReportExportEngine.printPdfFile(context, file, tool.title)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.printReport)
                            }
                            OutlinedButton(
                                onClick = {
                                    val summary = buildString {
                                        appendLine("Gaur Construction Calculator — ${tool.title}")
                                        out.results.forEach { appendLine("• ${it.label}: ${it.value} ${it.unit}") }
                                        appendLine("Formula: ${out.formula}")
                                    }
                                    ReportExportEngine.sharePlainText(context, tool.title, summary)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(strings.share)
                            }
                        }
                    }
                }

                // Formula & Steps
                item {
                    EngineeringCard {
                        Text(strings.formula, style = MaterialTheme.typography.titleSmall, color = CalculatorTealDark)
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            color = palette.concreteSurfaceAlt,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = out.formula,
                                fontFamily = MonoFontFamily,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkPrimary,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(strings.calculationSteps, style = MaterialTheme.typography.titleSmall, color = CalculatorTeal)
                        Spacer(Modifier.height(4.dp))
                        out.steps.forEachIndexed { idx, s ->
                            Text(
                                text = "${idx + 1}. $s",
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkSecondary,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(strings.assumptions, style = MaterialTheme.typography.titleSmall, color = palette.inkPrimary)
                        Text(
                            text = out.assumptions,
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.inkMuted
                        )
                    }
                }
            }
        }
    }

    if (showSaveDialog && outcome != null) {
        val projects by viewModel.projects.collectAsStateWithLifecycle()
        var customName by remember { mutableStateOf(tool.title) }
        var isTemplate by remember { mutableStateOf(false) }
        var selectedProjectId by remember(projects) { mutableStateOf<Long?>(null) }
        var projectMenuOpen by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Calculation") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = customName,
                        onValueChange = { customName = it },
                        label = { Text("Calculation Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (projects.isNotEmpty()) {
                        val selectedLabel = projects.firstOrNull { it.id == selectedProjectId }?.name ?: "Standalone (No Project)"
                        ExposedDropdownMenuBox(
                            expanded = projectMenuOpen,
                            onExpandedChange = { projectMenuOpen = !projectMenuOpen }
                        ) {
                            OutlinedTextField(
                                value = selectedLabel,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Link to Project (Optional)") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = projectMenuOpen) },
                                modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = projectMenuOpen, onDismissRequest = { projectMenuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Standalone (No Project)") },
                                    onClick = { selectedProjectId = null; projectMenuOpen = false }
                                )
                                projects.forEach { proj ->
                                    DropdownMenuItem(
                                        text = { Text(proj.name) },
                                        onClick = { selectedProjectId = proj.id; projectMenuOpen = false }
                                    )
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Checkbox(checked = isTemplate, onCheckedChange = { isTemplate = it })
                        Text("Save as reusable template", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val out = outcome ?: return@Button
                        val inJson = JSONObject().apply { fieldValues.forEach { (k, v) -> put(k, v) } }.toString()
                        val resArr = JSONArray().apply {
                            out.results.forEach { r ->
                                put(JSONObject().apply {
                                    put("label", r.label)
                                    put("value", r.value)
                                    put("unit", r.unit)
                                })
                            }
                        }.toString()
                        val stepsArr = JSONArray(out.steps).toString()
                        viewModel.saveCalculation(
                            CalculationHistoryEntity(
                                projectId = selectedProjectId,
                                toolId = tool.id,
                                toolName = tool.title,
                                category = tool.category.titleEn,
                                customName = customName.ifBlank { tool.title },
                                isTemplate = isTemplate,
                                inputsJson = inJson,
                                resultsJson = resArr,
                                formula = out.formula,
                                stepsJson = stepsArr,
                                assumptions = out.assumptions,
                                totalCost = out.estimatedCost
                            )
                        )
                        showSaveDialog = false
                        Toast.makeText(context, "Saved to Calculation History", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CalculatorTeal)
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) { Text("Cancel") }
            }
        )
    }
}

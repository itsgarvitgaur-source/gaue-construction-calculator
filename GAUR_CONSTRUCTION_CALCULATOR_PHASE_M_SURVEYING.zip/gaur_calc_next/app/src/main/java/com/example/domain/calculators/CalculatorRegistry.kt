package com.example.domain.calculators

object CalculatorRegistry {

    val allTools: List<CalcToolSpec> by lazy {
        BasicAndEarthworkCalculators.all() +
            ConcreteAndStructuralCalculators.all() +
            ConcreteCivilAndPlumbingCalculators.all() +
            MasonryAndFinishingCalculators.all() +
            MasonryWoodRoadCalculators.all() +
            SteelAndSiteCalculators.all() +
            SteelEarthSiteExtraCalculators.all() +
            RoadAndBridgeCalculators.all() +
            PhaseCConcreteCalculators.all() +
            PhaseCSteelCalculators.all() +
            PhaseCFoundationSoilCalculators.all() +
            PhaseCMasonryFinishingCalculators.all() +
            PhaseCElectricalHighRiseCostCalculators.all() +
            PhaseDConcreteCalculators.all() +
            PhaseFSteelBbsCalculators.all() +
            PhaseGStructuralGeometryCalculators.all() +
            PhaseHEarthworkCalculators.all() +
            PhaseIMasonryFinishingCalculators.all() +
            PhaseJRoadHighwayCalculators.all() +
            PhaseKPlumbingWaterCalculators.all() +
            PhaseLElectricalSolarCalculators.all() +
            PhaseMSurveyingCalculators.all() +
            UnitConverterCalculators.all()
    }

    fun byId(id: String): CalcToolSpec? = allTools.firstOrNull { it.id == id }

    fun byCategory(category: CalcCategory): List<CalcToolSpec> =
        allTools.filter { it.category == category }

    fun search(query: String): List<CalcToolSpec> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return allTools
        return allTools.filter { tool ->
            tool.title.lowercase().contains(q) ||
                tool.titleHi.lowercase().contains(q) ||
                tool.subtitle.lowercase().contains(q) ||
                tool.category.titleEn.lowercase().contains(q) ||
                tool.keywords.any { it.contains(q) }
        }
    }
}

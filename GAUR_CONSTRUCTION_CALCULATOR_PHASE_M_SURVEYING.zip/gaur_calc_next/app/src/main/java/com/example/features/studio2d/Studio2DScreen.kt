package com.example.features.studio2d

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GridOn
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.export.EngineeringReportData
import com.example.core.export.ReportExportEngine
import com.example.core.export.ReportSection
import com.example.core.i18n.LocalAppStrings
import com.example.data.local.StudioDrawingEntity
import com.example.domain.units.UnitConverter
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.BlueprintGrid
import com.example.ui.theme.BlueprintNavy
import com.example.ui.theme.BlueprintPaper
import com.example.ui.theme.BlueprintPaperGrid
import com.example.ui.theme.LocalEngineeringPalette
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.round
import kotlin.math.sin

enum class Tool2D(val label: String, val defaultLayer: String) {
    SELECT("Select/Move", "Architecture"),
    LINE("Line", "Architecture"),
    RECT("Rectangle", "Architecture"),
    CIRCLE("Circle", "Architecture"),
    ARC("Arc", "Architecture"),
    POLYLINE("Polyline", "Architecture"),
    POLYGON("Polygon", "Architecture"),
    WALL("Wall", "Architecture"),
    COLUMN("Column", "Structural"),
    BEAM("Beam", "Structural"),
    SLAB("Slab", "Structural"),
    FOOTING("Footing", "Structural"),
    STAIRCASE("Staircase", "Architecture"),
    DOOR("Door", "Architecture"),
    WINDOW("Window", "Architecture"),
    GRID_LINE("Grid Line", "Dimensions"),
    DIMENSION("Dimension", "Dimensions"),
    TEXT("Text", "Annotations"),
    AREA_BOUNDARY("Area Boundary", "Dimensions")
}

data class Element2D(
    val id: Long,
    val type: Tool2D,
    val x: Float, // meters in world space
    val y: Float,
    val w: Float,
    val h: Float,
    val rotationDeg: Float = 0f,
    val label: String = "",
    val layer: String = type.defaultLayer
)

private fun template2DElements(templateName: String): List<Element2D> = when (templateName) {
    "Foundation Plan" -> listOf(
        Element2D(1, Tool2D.FOOTING, 1f, 1f, 1.8f, 1.8f, label = "F1"),
        Element2D(2, Tool2D.FOOTING, 5f, 1f, 1.8f, 1.8f, label = "F2"),
        Element2D(3, Tool2D.FOOTING, 1f, 5f, 1.8f, 1.8f, label = "F3"),
        Element2D(4, Tool2D.FOOTING, 5f, 5f, 1.8f, 1.8f, label = "F4"),
        Element2D(5, Tool2D.COLUMN, 1.7f, 1.7f, 0.4f, 0.4f, label = "C1"),
        Element2D(6, Tool2D.COLUMN, 5.7f, 1.7f, 0.4f, 0.4f, label = "C2"),
        Element2D(7, Tool2D.COLUMN, 1.7f, 5.7f, 0.4f, 0.4f, label = "C3"),
        Element2D(8, Tool2D.COLUMN, 5.7f, 5.7f, 0.4f, 0.4f, label = "C4"),
        Element2D(9, Tool2D.BEAM, 1.9f, 1.8f, 4.0f, 0.25f, label = "PB1"),
        Element2D(10, Tool2D.DIMENSION, 1.9f, 0.5f, 4.0f, 0f, label = "4.00 m")
    )
    "Column Layout" -> listOf(
        Element2D(1, Tool2D.GRID_LINE, 1f, 0.5f, 0f, 8f, label = "Grid A"),
        Element2D(2, Tool2D.GRID_LINE, 5f, 0.5f, 0f, 8f, label = "Grid B"),
        Element2D(3, Tool2D.GRID_LINE, 9f, 0.5f, 0f, 8f, label = "Grid C"),
        Element2D(4, Tool2D.COLUMN, 0.8f, 1.5f, 0.4f, 0.45f, label = "C1"),
        Element2D(5, Tool2D.COLUMN, 4.8f, 1.5f, 0.4f, 0.45f, label = "C2"),
        Element2D(6, Tool2D.COLUMN, 8.8f, 1.5f, 0.4f, 0.45f, label = "C3"),
        Element2D(7, Tool2D.COLUMN, 0.8f, 5.5f, 0.4f, 0.45f, label = "C4"),
        Element2D(8, Tool2D.COLUMN, 4.8f, 5.5f, 0.4f, 0.45f, label = "C5"),
        Element2D(9, Tool2D.COLUMN, 8.8f, 5.5f, 0.4f, 0.45f, label = "C6")
    )
    "Warehouse Plan" -> listOf(
        Element2D(1, Tool2D.SLAB, 1f, 1f, 12f, 7f, label = "Trimix Floor 12×7m"),
        Element2D(2, Tool2D.COLUMN, 1f, 1f, 0.4f, 0.4f, label = "PEB C1"),
        Element2D(3, Tool2D.COLUMN, 5f, 1f, 0.4f, 0.4f, label = "PEB C2"),
        Element2D(4, Tool2D.COLUMN, 9f, 1f, 0.4f, 0.4f, label = "PEB C3"),
        Element2D(5, Tool2D.COLUMN, 12.6f, 1f, 0.4f, 0.4f, label = "PEB C4"),
        Element2D(6, Tool2D.COLUMN, 1f, 7.6f, 0.4f, 0.4f, label = "PEB C5"),
        Element2D(7, Tool2D.COLUMN, 5f, 7.6f, 0.4f, 0.4f, label = "PEB C6"),
        Element2D(8, Tool2D.COLUMN, 9f, 7.6f, 0.4f, 0.4f, label = "PEB C7"),
        Element2D(9, Tool2D.COLUMN, 12.6f, 7.6f, 0.4f, 0.4f, label = "PEB C8"),
        Element2D(10, Tool2D.DOOR, 6f, 7.8f, 2.4f, 0.25f, label = "Rolling Shutter")
    )
    else -> listOf(
        Element2D(1, Tool2D.SLAB, 1f, 1f, 9f, 6.5f, label = "Main Slab 9×6.5m"),
        Element2D(2, Tool2D.WALL, 1f, 1f, 9f, 0.23f, label = "North Wall"),
        Element2D(3, Tool2D.WALL, 1f, 7.27f, 9f, 0.23f, label = "South Wall"),
        Element2D(4, Tool2D.WALL, 1f, 1f, 0.23f, 6.5f, label = "West Wall"),
        Element2D(5, Tool2D.WALL, 9.77f, 1f, 0.23f, 6.5f, label = "East Wall"),
        Element2D(6, Tool2D.WALL, 5.2f, 1f, 0.15f, 6.5f, label = "Partition"),
        Element2D(7, Tool2D.COLUMN, 0.9f, 0.9f, 0.35f, 0.35f, label = "C1"),
        Element2D(8, Tool2D.COLUMN, 5.05f, 0.9f, 0.35f, 0.35f, label = "C2"),
        Element2D(9, Tool2D.COLUMN, 9.75f, 0.9f, 0.35f, 0.35f, label = "C3"),
        Element2D(10, Tool2D.COLUMN, 0.9f, 7.2f, 0.35f, 0.35f, label = "C4"),
        Element2D(11, Tool2D.COLUMN, 5.05f, 7.2f, 0.35f, 0.35f, label = "C5"),
        Element2D(12, Tool2D.COLUMN, 9.75f, 7.2f, 0.35f, 0.35f, label = "C6"),
        Element2D(13, Tool2D.DOOR, 2.5f, 7.25f, 1.1f, 0.25f, label = "D1"),
        Element2D(14, Tool2D.WINDOW, 6.8f, 0.98f, 1.5f, 0.25f, label = "W1"),
        Element2D(15, Tool2D.STAIRCASE, 7.5f, 4.5f, 2.1f, 2.6f, label = "Stair"),
        Element2D(16, Tool2D.DIMENSION, 1f, 0.4f, 9f, 0f, label = "9.00 m")
    )
}

@Composable
fun Studio2DScreen(
    viewModel: MainViewModel,
    onOpen3DWithModel: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val savedDrawings by viewModel.drawings2D.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()

    val templates = listOf("Floor Plan", "Foundation Plan", "Column Layout", "Beam Layout", "Slab Layout", "Elevation", "Section", "Site Layout", "Warehouse Plan")
    var drawingTitle by remember { mutableStateOf("Ground Floor Plan") }
    var selectedTemplate by remember { mutableStateOf("Floor Plan") }
    var activeTool by remember { mutableStateOf(Tool2D.SELECT) }
    var blueprintMode by remember { mutableStateOf(true) }
    var snapToGrid by remember { mutableStateOf(true) }
    var scaleRatio by remember { mutableStateOf(100) }
    var unitLabel by remember { mutableStateOf("m") }

    var zoomPxPerM by remember { mutableFloatStateOf(46f) }
    var panX by remember { mutableFloatStateOf(30f) }
    var panY by remember { mutableFloatStateOf(30f) }

    val elements = remember { mutableStateListOf<Element2D>().apply { addAll(template2DElements("Floor Plan")) } }
    val undoStack = remember { mutableStateListOf<List<Element2D>>() }
    val redoStack = remember { mutableStateListOf<List<Element2D>>() }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    val visibleLayers = remember {
        mutableStateListOf("Architecture", "Structural", "Dimensions", "Annotations")
    }
    var showPropsDialog by remember { mutableStateOf(false) }

    fun pushUndo() {
        undoStack.add(elements.toList())
        if (undoStack.size > 30) undoStack.removeAt(0)
        redoStack.clear()
    }

    fun snap(v: Float): Float = if (snapToGrid) (round(v * 4f) / 4f) else v

    fun exportTo3D() {
        val arr = JSONArray()
        elements.forEach { el ->
            val objType = when (el.type) {
                Tool2D.WALL -> "Wall"
                Tool2D.COLUMN -> "Column"
                Tool2D.BEAM -> "Beam"
                Tool2D.SLAB, Tool2D.AREA_BOUNDARY -> "Slab"
                Tool2D.FOOTING -> "Footing"
                Tool2D.STAIRCASE -> "Staircase"
                Tool2D.DOOR -> "Door"
                Tool2D.WINDOW -> "Window"
                else -> null
            } ?: return@forEach

            val (z, h) = when (objType) {
                "Footing" -> -0.5f to 0.45f
                "Slab" -> 0f to 0.15f
                "Beam" -> 2.8f to 0.40f
                "Door" -> 0.15f to 2.1f
                "Window" -> 0.9f to 1.2f
                "Staircase" -> 0.15f to 3.0f
                else -> 0.15f to 3.0f
            }
            arr.put(JSONObject().apply {
                put("type", objType)
                put("label", el.label.ifBlank { objType })
                put("x", el.x.toDouble())
                put("y", el.y.toDouble())
                put("z", z.toDouble())
                put("l", maxOf(0.25f, el.w).toDouble())
                put("w", maxOf(0.25f, el.h).toDouble())
                put("h", h.toDouble())
                put("visible", true)
            })
        }
        viewModel.setPending3DFrom2D(arr.toString())
        onOpen3DWithModel()
    }

    fun renderToBitmap(): Bitmap {
        val bmp = Bitmap.createBitmap(1200, 840, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(bmp)
        c.drawColor(if (blueprintMode) android.graphics.Color.rgb(11, 59, 104) else android.graphics.Color.WHITE)
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = if (blueprintMode) android.graphics.Color.WHITE else android.graphics.Color.rgb(15, 23, 42)
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = 3f
            textSize = 24f
        }
        val scale = 80f
        elements.filter { visibleLayers.contains(it.layer) }.forEach { el ->
            val sx = 60f + el.x * scale
            val sy = 60f + el.y * scale
            val sw = el.w * scale
            val sh = el.h * scale
            c.drawRect(sx, sy, sx + sw, sy + sh, p)
            if (el.label.isNotBlank()) {
                p.style = android.graphics.Paint.Style.FILL
                c.drawText(el.label, sx + 6f, sy + 24f, p)
                p.style = android.graphics.Paint.Style.STROKE
            }
        }
        return bmp
    }

    val selectedElement = elements.firstOrNull { it.id == selectedId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = strings.studio2D,
            subtitle = "1:$scaleRatio • ${if (blueprintMode) "Blueprint" else "Drafting"} • ${elements.size} objects",
            onBack = onBack,
            actions = {
                IconButton(onClick = {
                    if (undoStack.isNotEmpty()) {
                        redoStack.add(elements.toList())
                        val prev = undoStack.removeAt(undoStack.lastIndex)
                        elements.clear()
                        elements.addAll(prev)
                    }
                }) { Icon(Icons.AutoMirrored.Rounded.Undo, contentDescription = "Undo") }
                IconButton(onClick = {
                    if (redoStack.isNotEmpty()) {
                        undoStack.add(elements.toList())
                        val next = redoStack.removeAt(redoStack.lastIndex)
                        elements.clear()
                        elements.addAll(next)
                    }
                }) { Icon(Icons.AutoMirrored.Rounded.Redo, contentDescription = "Redo") }
                IconButton(
                    onClick = { exportTo3D() },
                    modifier = Modifier.testTag("studio2d_to_3d_btn")
                ) {
                    Icon(Icons.Rounded.ViewInAr, contentDescription = "Switch to 3D", tint = palette.orangeDark)
                }
                IconButton(
                    onClick = {
                        val arr = JSONArray().apply {
                            elements.forEach { el ->
                                put(JSONObject().apply {
                                    put("type", el.type.name)
                                    put("x", el.x); put("y", el.y); put("w", el.w); put("h", el.h)
                                    put("rot", el.rotationDeg); put("label", el.label); put("layer", el.layer)
                                })
                            }
                        }.toString()
                        viewModel.saveDrawing2D(
                            StudioDrawingEntity(
                                projectId = projects.firstOrNull()?.id,
                                title = drawingTitle,
                                drawingType = selectedTemplate,
                                scaleRatio = scaleRatio,
                                unitLabel = unitLabel,
                                blueprintMode = blueprintMode,
                                elementsJson = arr
                            )
                        )
                        Toast.makeText(context, "2D Drawing saved", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("studio2d_save_btn")
                ) {
                    Icon(Icons.Rounded.Save, contentDescription = "Save Drawing", tint = palette.skyBlue)
                }
            }
        )

        // Templates & Layers / Mode Controls
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            item {
                FilterChip(
                    selected = blueprintMode,
                    onClick = { blueprintMode = !blueprintMode },
                    label = { Text(if (blueprintMode) "Blueprint ON" else "Paper Mode") }
                )
            }
            item {
                FilterChip(
                    selected = snapToGrid,
                    onClick = { snapToGrid = !snapToGrid },
                    leadingIcon = { Icon(Icons.Rounded.GridOn, contentDescription = null, modifier = Modifier.size(16.dp)) },
                    label = { Text("Snap") }
                )
            }
            items(listOf("Architecture", "Structural", "Dimensions", "Annotations")) { layer ->
                val vis = visibleLayers.contains(layer)
                FilterChip(
                    selected = vis,
                    onClick = {
                        if (vis) visibleLayers.remove(layer) else visibleLayers.add(layer)
                    },
                    label = { Text(layer) }
                )
            }
            items(templates) { tpl ->
                FilterChip(
                    selected = selectedTemplate == tpl,
                    onClick = {
                        pushUndo()
                        selectedTemplate = tpl
                        drawingTitle = tpl
                        elements.clear()
                        elements.addAll(template2DElements(tpl))
                    },
                    label = { Text(tpl) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = palette.orangeSoft, selectedLabelColor = palette.orangeDark)
                )
            }
        }

        // Interactive 2D CAD Canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
        ) {
            val bgColor = if (blueprintMode) BlueprintNavy else BlueprintPaper
            val gridColor = if (blueprintMode) BlueprintGrid else BlueprintPaperGrid
            val lineColor = if (blueprintMode) Color.White else palette.inkPrimary

            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .background(bgColor, RoundedCornerShape(14.dp))
                    .pointerInput(activeTool, snapToGrid, zoomPxPerM, panX, panY) {
                        detectTapGestures { offset ->
                            val wx = (offset.x - panX) / zoomPxPerM
                            val wy = (offset.y - panY) / zoomPxPerM
                            if (activeTool == Tool2D.SELECT) {
                                val hit = elements.lastOrNull { el ->
                                    visibleLayers.contains(el.layer) &&
                                        wx >= el.x - 0.3f && wx <= el.x + maxOf(0.5f, el.w) + 0.3f &&
                                        wy >= el.y - 0.3f && wy <= el.y + maxOf(0.5f, el.h) + 0.3f
                                }
                                selectedId = hit?.id
                            } else {
                                pushUndo()
                                val sx = snap(wx)
                                val sy = snap(wy)
                                val (dw, dh) = when (activeTool) {
                                    Tool2D.COLUMN -> 0.4f to 0.4f
                                    Tool2D.FOOTING -> 1.6f to 1.6f
                                    Tool2D.DOOR -> 1.0f to 0.25f
                                    Tool2D.WINDOW -> 1.5f to 0.25f
                                    Tool2D.WALL -> 4.0f to 0.23f
                                    Tool2D.BEAM -> 4.0f to 0.30f
                                    Tool2D.SLAB, Tool2D.AREA_BOUNDARY -> 4.0f to 3.5f
                                    Tool2D.STAIRCASE -> 2.0f to 2.5f
                                    Tool2D.GRID_LINE -> 0f to 6.0f
                                    Tool2D.DIMENSION -> 3.0f to 0f
                                    Tool2D.CIRCLE, Tool2D.ARC -> 2.0f to 2.0f
                                    else -> 3.0f to 2.0f
                                }
                                val newId = System.nanoTime()
                                val newEl = Element2D(
                                    id = newId,
                                    type = activeTool,
                                    x = sx,
                                    y = sy,
                                    w = dw,
                                    h = dh,
                                    label = "${activeTool.label} (${UnitConverter.fmt(dw.toDouble(), 1)}×${UnitConverter.fmt(dh.toDouble(), 1)}$unitLabel)"
                                )
                                elements.add(newEl)
                                selectedId = newId
                            }
                        }
                    }
                    .pointerInput(selectedId, activeTool, zoomPxPerM) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val sel = elements.indexOfFirst { it.id == selectedId }
                            if (activeTool == Tool2D.SELECT && sel >= 0) {
                                val el = elements[sel]
                                elements[sel] = el.copy(
                                    x = el.x + dragAmount.x / zoomPxPerM,
                                    y = el.y + dragAmount.y / zoomPxPerM
                                )
                            } else {
                                panX += dragAmount.x
                                panY += dragAmount.y
                            }
                        }
                    }
            ) {
                // Draw 1m & 0.5m Grid
                val step = zoomPxPerM
                var gx = (panX % step)
                while (gx < size.width) {
                    drawLine(gridColor, Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 1.2f)
                    gx += step
                }
                var gy = (panY % step)
                while (gy < size.height) {
                    drawLine(gridColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1.2f)
                    gy += step
                }

                // Draw Elements
                elements.filter { visibleLayers.contains(it.layer) }.forEach { el ->
                    val sx = panX + el.x * zoomPxPerM
                    val sy = panY + el.y * zoomPxPerM
                    val sw = el.w * zoomPxPerM
                    val sh = el.h * zoomPxPerM
                    val isSel = el.id == selectedId
                    val strokeColor = when {
                        isSel -> Color(0xFFFF9800)
                        el.type == Tool2D.COLUMN || el.type == Tool2D.FOOTING -> Color(0xFFF57C00)
                        el.type == Tool2D.BEAM || el.type == Tool2D.SLAB -> Color(0xFF38BDF8)
                        el.type == Tool2D.DIMENSION || el.type == Tool2D.GRID_LINE -> Color(0xFFFDE047)
                        else -> lineColor
                    }

                    rotate(degrees = el.rotationDeg, pivot = Offset(sx + sw / 2f, sy + sh / 2f)) {
                        when (el.type) {
                            Tool2D.CIRCLE -> drawOval(strokeColor, Offset(sx, sy), Size(sw, sh), style = Stroke(3f))
                            Tool2D.ARC -> drawArc(strokeColor, 0f, 180f, false, Offset(sx, sy), Size(sw, sh), style = Stroke(3f))
                            Tool2D.LINE, Tool2D.DIMENSION, Tool2D.GRID_LINE -> {
                                val effect = if (el.type == Tool2D.GRID_LINE) PathEffect.dashPathEffect(floatArrayOf(12f, 8f)) else null
                                drawLine(strokeColor, Offset(sx, sy), Offset(sx + sw, sy + sh), strokeWidth = 3f, pathEffect = effect)
                            }
                            Tool2D.POLYLINE, Tool2D.POLYGON -> {
                                val path = Path().apply {
                                    moveTo(sx, sy + sh)
                                    lineTo(sx + sw * 0.5f, sy)
                                    lineTo(sx + sw, sy + sh)
                                    if (el.type == Tool2D.POLYGON) close()
                                }
                                drawPath(path, strokeColor, style = Stroke(3f))
                            }
                            Tool2D.COLUMN -> {
                                drawRect(strokeColor.copy(alpha = 0.65f), Offset(sx, sy), Size(sw, sh))
                                drawRect(strokeColor, Offset(sx, sy), Size(sw, sh), style = Stroke(3f))
                            }
                            Tool2D.STAIRCASE -> {
                                drawRect(strokeColor, Offset(sx, sy), Size(sw, sh), style = Stroke(3f))
                                for (i in 1..7) {
                                    val yStep = sy + sh * (i / 8f)
                                    drawLine(strokeColor, Offset(sx, yStep), Offset(sx + sw, yStep), 2f)
                                }
                            }
                            else -> {
                                val alphaFill = if (el.type == Tool2D.SLAB || el.type == Tool2D.AREA_BOUNDARY) 0.14f else 0.25f
                                drawRect(strokeColor.copy(alpha = alphaFill), Offset(sx, sy), Size(maxOf(8f, sw), maxOf(8f, sh)))
                                drawRect(strokeColor, Offset(sx, sy), Size(maxOf(8f, sw), maxOf(8f, sh)), style = Stroke(if (isSel) 4.5f else 2.8f))
                            }
                        }
                    }

                    if (el.label.isNotBlank()) {
                        drawContext.canvas.nativeCanvas.drawText(
                            el.label,
                            sx + 4f,
                            sy - 4f,
                            android.graphics.Paint().apply {
                                color = if (blueprintMode) android.graphics.Color.WHITE else android.graphics.Color.BLACK
                                textSize = 24f
                                isAntiAlias = true
                            }
                        )
                    }
                }
            }

            // Zoom & Quick Actions Overlay
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(color = palette.concreteCard.copy(alpha = 0.92f), shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, palette.metallicBorder)) {
                    Row {
                        IconButton(onClick = { zoomPxPerM = (zoomPxPerM * 1.2f).coerceAtMost(140f) }) {
                            Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom In")
                        }
                        IconButton(onClick = { zoomPxPerM = (zoomPxPerM / 1.2f).coerceAtLeast(18f) }) {
                            Icon(Icons.Rounded.ZoomOut, contentDescription = "Zoom Out")
                        }
                        IconButton(onClick = {
                            val bmp = renderToBitmap()
                            val pngFile = ReportExportEngine.saveBitmapPng(context, drawingTitle, bmp)
                            val pdfFile = ReportExportEngine.generatePdfFile(
                                context,
                                EngineeringReportData(
                                    title = "2D Drawing — $drawingTitle",
                                    projectName = selectedTemplate,
                                    sections = listOf(
                                        ReportSection(
                                            "Drawing Elements (${elements.size})",
                                            rows = elements.map { it.label.ifBlank { it.type.label } to "${UnitConverter.fmt(it.w.toDouble(), 2)} × ${UnitConverter.fmt(it.h.toDouble(), 2)} $unitLabel" }
                                        )
                                    )
                                )
                            )
                            ReportExportEngine.shareFile(context, pdfFile, "application/pdf", drawingTitle)
                            Toast.makeText(context, "PNG & PDF exported (${pngFile.name})", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = "Export PDF", tint = palette.error)
                        }
                    }
                }
            }
        }

        // Selected Object Inspector Bar
        if (selectedElement != null) {
            val area = abs(selectedElement.w * selectedElement.h)
            val perim = 2f * (abs(selectedElement.w) + abs(selectedElement.h))
            Surface(
                color = palette.skyGlassTint,
                border = BorderStroke(1.dp, palette.skyGlassBorder),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(selectedElement.label.ifBlank { selectedElement.type.label }, style = MaterialTheme.typography.labelLarge, color = palette.skyBlue)
                        Text(
                            "W:${UnitConverter.fmt(selectedElement.w.toDouble(), 2)} H:${UnitConverter.fmt(selectedElement.h.toDouble(), 2)} | Area:${UnitConverter.fmt(area.toDouble(), 2)} $unitLabel² | Perim:${UnitConverter.fmt(perim.toDouble(), 2)}$unitLabel",
                            style = MaterialTheme.typography.bodySmall,
                            color = palette.inkPrimary
                        )
                    }
                    IconButton(onClick = { showPropsDialog = true }) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Edit Properties", tint = palette.skyBlue)
                    }
                    IconButton(onClick = {
                        val idx = elements.indexOfFirst { it.id == selectedElement.id }
                        if (idx >= 0) {
                            pushUndo()
                            elements[idx] = selectedElement.copy(rotationDeg = (selectedElement.rotationDeg + 15f) % 360f)
                        }
                    }) {
                        Icon(Icons.Rounded.RotateRight, contentDescription = "Rotate", tint = palette.orangeDark)
                    }
                    IconButton(onClick = {
                        pushUndo()
                        elements.removeAll { it.id == selectedElement.id }
                        selectedId = null
                    }) {
                        Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = palette.error)
                    }
                }
            }
        }

        // Drawing Tools Palette
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(Tool2D.entries) { tool ->
                FilterChip(
                    selected = activeTool == tool,
                    onClick = { activeTool = tool },
                    label = { Text(tool.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = palette.orange,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("tool2d_${tool.name}")
                )
            }
        }
    }

    if (showPropsDialog && selectedElement != null) {
        var label by remember { mutableStateOf(selectedElement.label) }
        var wStr by remember { mutableStateOf(selectedElement.w.toString()) }
        var hStr by remember { mutableStateOf(selectedElement.h.toString()) }
        var xStr by remember { mutableStateOf(selectedElement.x.toString()) }
        var yStr by remember { mutableStateOf(selectedElement.y.toString()) }
        AlertDialog(
            onDismissRequest = { showPropsDialog = false },
            title = { Text("Object Properties (${selectedElement.type.label})") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Label / Dimension Tag") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = xStr, onValueChange = { xStr = it }, label = { Text("X ($unitLabel)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = yStr, onValueChange = { yStr = it }, label = { Text("Y ($unitLabel)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = wStr, onValueChange = { wStr = it }, label = { Text("Width ($unitLabel)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = hStr, onValueChange = { hStr = it }, label = { Text("Height ($unitLabel)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val idx = elements.indexOfFirst { it.id == selectedElement.id }
                    if (idx >= 0) {
                        pushUndo()
                        elements[idx] = selectedElement.copy(
                            label = label,
                            x = xStr.toFloatOrNull() ?: selectedElement.x,
                            y = yStr.toFloatOrNull() ?: selectedElement.y,
                            w = (wStr.toFloatOrNull() ?: selectedElement.w).coerceAtLeast(0.05f),
                            h = (hStr.toFloatOrNull() ?: selectedElement.h).coerceAtLeast(0.05f)
                        )
                    }
                    showPropsDialog = false
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { showPropsDialog = false }) { Text("Cancel") } }
        )
    }
}

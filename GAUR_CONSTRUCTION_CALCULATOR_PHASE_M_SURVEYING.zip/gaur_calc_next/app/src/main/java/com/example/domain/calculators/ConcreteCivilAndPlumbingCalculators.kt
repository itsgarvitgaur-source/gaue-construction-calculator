package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.pow
import kotlin.math.sqrt

object ConcreteCivilAndPlumbingCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        mortarMixCalculator(),
        waterCementAdmixtureCalculator(),
        concreteTubeAndCurbCalculator(),
        archAndDomeCalculator(),
        waterTankCalculator(),
        septicTankAndSoakPitCalculator(),
        rainwaterHarvestingCalculator(),
        plumbingPipeFlowCalculator(),
        electricalAcSolarCalculator()
    )

    private fun mortarMixCalculator() = CalcToolSpec(
        id = "conc_cement_mortar",
        title = "Cement Mortar Calculator",
        titleHi = "सीमेंट मसाला (मोर्टार) कैलकुलेटर",
        subtitle = "1:3, 1:4, 1:5, 1:6 & 1:8 Mortar Volume, Cement Bags & Sand",
        category = CalcCategory.CONCRETE,
        keywords = listOf("mortar", "cement", "sand", "ratio", "bedding", "pointing", "1:4", "1:6"),
        fields = listOf(
            CalcFieldSpec("vol", "Wet Mortar Volume (m³)", "2.5", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("ratio", "Mortar Ratio (Cement : Sand)", "1:5", options = listOf("1:2", "1:3", "1:4", "1:5", "1:6", "1:8")),
            CalcFieldSpec("dryFactor", "Dry Bulking Factor", "1.33", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val wet = ctx.doubleOrNull("vol") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter wet mortar volume."))
            val df = ctx.doubleOrNull("dryFactor") ?: 1.33
            if (wet <= 0 || df <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Values must be positive."))
            val sandPart = ctx.raw("ratio").substringAfter(":").toDoubleOrNull() ?: 5.0
            val sum = 1.0 + sandPart
            val dry = wet * df
            val cementVol = dry / sum
            val bags = cementVol / 0.0347
            val sandCft = dry * (sandPart / sum) * UnitConverter.CU_FT_IN_CU_M
            val waterL = bags * 50.0 * 0.55
            val cost = bags * (ctx.ratesByKeyword["cement"] ?: 390.0) + sandCft * (ctx.ratesByKeyword["sand"] ?: 62.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Cement (50 kg bags)", UnitConverter.fmt(bags, p), "Bags", isPrimary = true),
                        CalcResultItem("Sand Quantity", UnitConverter.fmt(sandCft, p), "CFT", isPrimary = true),
                        CalcResultItem("Dry Mortar Volume", UnitConverter.fmt(dry, p), "m³"),
                        CalcResultItem("Mixing Water (est.)", UnitConverter.fmt(waterL, 0), "Liters"),
                        CalcResultItem("Est. Material Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 0)}", "")
                    ),
                    formula = "Dry Vol = Wet Vol × $df; Cement = Dry/(1+$sandPart) ÷ 0.0347",
                    steps = listOf("Dry Vol = ${UnitConverter.fmt(wet, p)} × $df = ${UnitConverter.fmt(dry, p)} m³"),
                    assumptions = "1 cement bag = 50 kg = 0.0347 m³; standard dry-to-wet mortar factor = 1.33.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun waterCementAdmixtureCalculator() = CalcToolSpec(
        id = "conc_water_cement",
        title = "Water-Cement Ratio & Admixture",
        titleHi = "वॉटर-सीमेंट अनुपात और एडमिक्सचर",
        subtitle = "Water Liters, Plasticizer Dosage & Moisture Adjustment per Batch",
        category = CalcCategory.CONCRETE,
        keywords = listOf("water", "cement", "ratio", "w/c", "admixture", "plasticizer", "slump"),
        fields = listOf(
            CalcFieldSpec("bags", "Cement Quantity (50 kg Bags)", "10", FieldUnitKind.COUNT),
            CalcFieldSpec("wc", "Target W/C Ratio", "0.45", FieldUnitKind.NONE),
            CalcFieldSpec("admixPct", "Admixture Dosage (% by cement wt)", "0.8", FieldUnitKind.PERCENT, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val bags = ctx.doubleOrNull("bags") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter cement bags."))
            val wc = ctx.doubleOrNull("wc") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter W/C ratio."))
            val admix = ctx.doubleOrNull("admixPct") ?: 0.8
            if (bags <= 0 || wc <= 0.2 || wc > 0.8 || admix < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("W/C must be between 0.2 and 0.8."))
            val cementKg = bags * 50.0
            val waterL = cementKg * wc
            val waterPerBag = 50.0 * wc
            val admixL = (cementKg * admix / 100.0) / 1.1 // ~1.10 sp.gr.
            val warn = if (wc > 0.55) listOf("W/C > 0.55 reduces durability and strength per IS 456 Table 5.") else emptyList()
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Mixing Water", UnitConverter.fmt(waterL, p), "Liters", isPrimary = true),
                        CalcResultItem("Water per 50kg Bag", UnitConverter.fmt(waterPerBag, p), "L/Bag", isPrimary = true),
                        CalcResultItem("Admixture Required", UnitConverter.fmt(admixL, p + 1), "Liters"),
                        CalcResultItem("Total Cement Weight", UnitConverter.fmt(cementKg, 0), "kg")
                    ),
                    formula = "Water (L) = Cement Weight (kg) × W/C; Admixture = (Wt × %)/1.10",
                    steps = listOf("$cementKg kg × $wc = ${UnitConverter.fmt(waterL, p)} L"),
                    assumptions = "Assumes SSD (Saturated Surface Dry) aggregates and admixture specific gravity 1.10.",
                    warnings = warn
                )
            )
        }
    )

    private fun concreteTubeAndCurbCalculator() = CalcToolSpec(
        id = "conc_tube_curb",
        title = "Concrete Pipe, Well Ring & Curbstone",
        titleHi = "कंक्रीट पाइप, रिंग और कर्बस्टोन",
        subtitle = "Precast Hume Pipe / Well Ring & Road Kerbstone Concrete Volume",
        category = CalcCategory.CONCRETE,
        typeFieldKey = "elemType",
        keywords = listOf("pipe", "tube", "ring", "culvert", "curb", "kerb", "curbstone", "concrete"),
        fields = listOf(
            CalcFieldSpec("elemType", "Element Type", "Concrete Pipe / Well Ring", options = listOf("Concrete Pipe / Well Ring", "Road Kerbstone / Curb")),
            CalcFieldSpec("od", "Outer Diameter (OD)", "1.2", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["elemType"] != "Road Kerbstone / Curb" }),
            CalcFieldSpec("id", "Inner Diameter (ID)", "1.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["elemType"] != "Road Kerbstone / Curb" }),
            CalcFieldSpec("l", "Length / Height", "2.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("curbW", "Curb Width (B)", "0.15", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["elemType"] == "Road Kerbstone / Curb" }),
            CalcFieldSpec("curbH", "Curb Height (H)", "0.30", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["elemType"] == "Road Kerbstone / Curb" }),
            CalcFieldSpec("count", "Number of Units", "10", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val n = ctx.doubleOrNull("count") ?: 1.0
            if (l <= 0 || n <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be positive."))
            val singleVol: Double
            val formula: String
            if (ctx.raw("elemType") == "Road Kerbstone / Curb") {
                val w = ctx.lengthMeters("curbW") ?: 0.15
                val h = ctx.lengthMeters("curbH") ?: 0.30
                if (w <= 0 || h <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive curb width and height."))
                singleVol = w * h * l
                formula = "V = Width × Height × Length × N"
            } else {
                val od = ctx.lengthMeters("od") ?: 1.2
                val id = ctx.lengthMeters("id") ?: 1.0
                if (od <= id || id <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Outer dia must exceed inner dia."))
                singleVol = (PI / 4.0) * (od * od - id * id) * l
                formula = "V = (π/4)(OD² - ID²) × Length × N"
            }
            val totalVol = singleVol * n
            val dry = totalVol * 1.54
            val bags = (dry / 5.5) / 0.0347 // M20 ref
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Total Concrete Volume", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                        CalcResultItem("Volume in CFT", UnitConverter.fmt(totalVol * UnitConverter.CU_FT_IN_CU_M, p), "CFT", isPrimary = true),
                        CalcResultItem("Single Unit Volume", UnitConverter.fmt(singleVol, p + 1), "m³"),
                        CalcResultItem("Cement Est. (M20)", UnitConverter.fmt(bags, p), "Bags")
                    ),
                    formula = formula,
                    steps = listOf("Total = ${UnitConverter.fmt(singleVol, p + 1)} × ${n.toInt()} = ${UnitConverter.fmt(totalVol, p)} m³"),
                    assumptions = "Cement estimate assumes M20 (1:1.5:3) concrete mix."
                )
            )
        }
    )

    private fun archAndDomeCalculator() = CalcToolSpec(
        id = "struct_arch_dome",
        title = "Concrete Arch & Dome Calculator",
        titleHi = "आर्च (मेहराब) और गुंबद कैलकुलेटर",
        subtitle = "Semicircular Arch, Segmental Arch & Hemispherical Shell Dome Volume",
        category = CalcCategory.STRUCTURAL,
        typeFieldKey = "archType",
        isPreliminaryStructural = true,
        keywords = listOf("arch", "dome", "hemisphere", "vault", "shell", "concrete"),
        fields = listOf(
            CalcFieldSpec("archType", "Structure Type", "Semicircular Arch", options = listOf("Semicircular Arch", "Hemispherical Dome")),
            CalcFieldSpec("span", "Clear Span / Inner Diameter (D)", "4.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("thick", "Shell / Ring Thickness (t)", "0.25", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("depth", "Arch Depth / Width (W)", "0.45", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["archType"] != "Hemispherical Dome" })
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val dIn = ctx.lengthMeters("span") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter clear span."))
            val t = ctx.lengthMeters("thick") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter thickness."))
            if (dIn <= 0 || t <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val rIn = dIn / 2.0
            val rOut = rIn + t
            val vol: Double
            val surface: Double
            val formula: String
            if (ctx.raw("archType") == "Hemispherical Dome") {
                vol = (2.0 / 3.0) * PI * (rOut.pow(3) - rIn.pow(3))
                surface = 2.0 * PI * rOut * rOut
                formula = "V_dome = (2/3)π(R_out³ - R_in³); Outer Surface = 2πR_out²"
            } else {
                val w = ctx.lengthMeters("depth") ?: 0.45
                if (w <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive arch width."))
                vol = 0.5 * PI * (rOut * rOut - rIn * rIn) * w
                surface = PI * rIn * w
                formula = "V_arch = 0.5π(R_out² - R_in²) × Width"
            }
            val bags = (vol * 1.54 / 5.5) / 0.0347
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Concrete Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Surface / Soffit Area", UnitConverter.fmt(surface, p), "m²", isPrimary = true),
                        CalcResultItem("Cement (M20 Est.)", UnitConverter.fmt(bags, p), "Bags")
                    ),
                    formula = formula,
                    steps = listOf("r_in=${UnitConverter.fmt(rIn, p)} m, R_out=${UnitConverter.fmt(rOut, p)} m"),
                    assumptions = "Uniform shell thickness; M20 nominal concrete reference."
                )
            )
        }
    )

    private fun waterTankCalculator() = CalcToolSpec(
        id = "util_water_tank",
        title = "Water Tank Capacity & RCC Sump",
        titleHi = "पानी की टंकी क्षमता और RCC टैंक",
        subtitle = "Rectangular Sump/OHT & Cylindrical Tank (Liters, Gallons, RCC & Plaster)",
        category = CalcCategory.UTILITIES,
        typeFieldKey = "tankShape",
        keywords = listOf("water tank", "sump", "overhead", "liters", "gallons", "capacity", "reservoir"),
        fields = listOf(
            CalcFieldSpec("tankShape", "Tank Shape", "Rectangular Tank / Sump", options = listOf("Rectangular Tank / Sump", "Cylindrical / Circular Tank")),
            CalcFieldSpec("l", "Inner Length (L)", "4.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["tankShape"] != "Cylindrical / Circular Tank" }),
            CalcFieldSpec("w", "Inner Width (W)", "3.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["tankShape"] != "Cylindrical / Circular Tank" }),
            CalcFieldSpec("dia", "Inner Diameter (Ø)", "3.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["tankShape"] == "Cylindrical / Circular Tank" }),
            CalcFieldSpec("h", "Water Depth / Height (H)", "2.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("wallT", "RCC Wall Thickness (mm)", "200", FieldUnitKind.LENGTH, LengthUnit.MM)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val h = ctx.lengthMeters("h") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter tank height."))
            val wt = ctx.lengthMeters("wallT") ?: 0.2
            if (h <= 0 || wt <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val volM3: Double
            val innerArea: Double
            val rccVol: Double
            val formula: String
            if (ctx.raw("tankShape") == "Cylindrical / Circular Tank") {
                val dia = ctx.lengthMeters("dia") ?: 3.0
                if (dia <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive diameter."))
                val r = dia / 2.0
                val rOut = r + wt
                volM3 = PI * r * r * h
                innerArea = PI * r * r + 2.0 * PI * r * h
                rccVol = PI * (rOut * rOut - r * r) * h + 2.0 * PI * rOut * rOut * wt
                formula = "Capacity = πr²h × 1000 L"
            } else {
                val l = ctx.lengthMeters("l") ?: 4.0
                val w = ctx.lengthMeters("w") ?: 3.0
                if (l <= 0 || w <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Enter positive L and W."))
                volM3 = l * w * h
                innerArea = l * w + 2.0 * (l + w) * h
                val outerVol = (l + 2 * wt) * (w + 2 * wt) * (h + 2 * wt)
                rccVol = outerVol - volM3
                formula = "Capacity = (L × W × H) × 1000 L"
            }
            val liters = volM3 * 1000.0
            val usGal = liters / 3.78541
            val ukGal = liters / 4.54609
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Water Capacity", UnitConverter.fmt(liters, 0), "Liters", isPrimary = true),
                        CalcResultItem("Volume (m³ / CFT)", "${UnitConverter.fmt(volM3, p)} m³ | ${UnitConverter.fmt(volM3 * UnitConverter.CU_FT_IN_CU_M, p)} CFT", "", isPrimary = true),
                        CalcResultItem("US / UK Gallons", "${UnitConverter.fmt(usGal, 0)} US | ${UnitConverter.fmt(ukGal, 0)} UK", "gal"),
                        CalcResultItem("RCC Concrete (Walls+Slabs)", UnitConverter.fmt(rccVol, p), "m³"),
                        CalcResultItem("Internal Waterproof Plaster", UnitConverter.fmt(innerArea, p), "m²")
                    ),
                    formula = formula,
                    steps = listOf("Net Water Vol = ${UnitConverter.fmt(volM3, p)} m³ = ${UnitConverter.fmt(liters, 0)} Liters"),
                    assumptions = "RCC estimate includes base raft, walls, and top cover slab of uniform thickness."
                )
            )
        }
    )

    private fun septicTankAndSoakPitCalculator() = CalcToolSpec(
        id = "util_septic_tank",
        title = "Septic Tank & Soak Pit Estimator",
        titleHi = "सेप्टिक टैंक और सोक पिट",
        subtitle = "IS 2470 Sizing by Users Count or Dimensions + Brick/Plaster Est.",
        category = CalcCategory.UTILITIES,
        typeFieldKey = "mode",
        keywords = listOf("septic tank", "soak pit", "sewage", "is 2470", "brick", "sanitation"),
        fields = listOf(
            CalcFieldSpec("mode", "Input Mode", "By Number of Users", options = listOf("By Number of Users", "Custom Dimensions")),
            CalcFieldSpec("users", "Number of Users / Occupants", "15", FieldUnitKind.COUNT, visibleWhen = { it["mode"] != "Custom Dimensions" }),
            CalcFieldSpec("cleanYears", "Desludging Interval (Years)", "2", options = listOf("1", "2", "3"), visibleWhen = { it["mode"] != "Custom Dimensions" }),
            CalcFieldSpec("l", "Inner Length (L)", "3.0", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["mode"] == "Custom Dimensions" }),
            CalcFieldSpec("w", "Inner Width (W)", "1.2", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["mode"] == "Custom Dimensions" }),
            CalcFieldSpec("d", "Liquid Depth (D)", "1.4", FieldUnitKind.LENGTH, LengthUnit.M, visibleWhen = { it["mode"] == "Custom Dimensions" })
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l: Double
            val w: Double
            val d: Double
            if (ctx.raw("mode") != "Custom Dimensions") {
                val users = (ctx.doubleOrNull("users") ?: 15.0).coerceAtLeast(5.0)
                val yrs = (ctx.doubleOrNull("cleanYears") ?: 2.0)
                val volNeed = (users * 0.12 + users * 0.04 * yrs).coerceAtLeast(1.8)
                d = 1.4
                w = sqrt(volNeed / (2.5 * d)).coerceAtLeast(0.9)
                l = (w * 2.5).coerceAtLeast(2.0)
            } else {
                l = ctx.lengthMeters("l") ?: 3.0
                w = ctx.lengthMeters("w") ?: 1.2
                d = ctx.lengthMeters("d") ?: 1.4
                if (l <= 0 || w <= 0 || d <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            }
            val totalD = d + 0.30 // 300mm freeboard
            val capL = l * w * d * 1000.0
            val wallArea = 2.0 * (l + w) * totalD
            val bricks = ceil(wallArea * 0.23 * 500.0).toLong()
            val soakDia = 1.2
            val soakDepth = 2.2
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Recommended Tank Size (L×W×D)", "${UnitConverter.fmt(l, 2)} × ${UnitConverter.fmt(w, 2)} × ${UnitConverter.fmt(totalD, 2)}", "m", isPrimary = true),
                        CalcResultItem("Liquid Capacity", UnitConverter.fmt(capL, 0), "Liters", isPrimary = true),
                        CalcResultItem("230mm Wall Bricks (est.)", "$bricks", "Nos"),
                        CalcResultItem("Soak Pit Size (Ø × Depth)", "${UnitConverter.fmt(soakDia, 1)} m × ${UnitConverter.fmt(soakDepth, 1)} m", ""),
                        CalcResultItem("RCC Cover Slab Area", UnitConverter.fmt((l + 0.46) * (w + 0.46), p), "m²")
                    ),
                    formula = "L ≈ 2.5×W; Total Depth = Liquid Depth + 0.30 m Freeboard",
                    steps = listOf("Liquid Vol = ${UnitConverter.fmt(l * w * d, p)} m³ = ${UnitConverter.fmt(capL, 0)} L"),
                    assumptions = "Per IS 2470 Part 1 guidelines (min width 0.9 m, freeboard 300 mm)."
                )
            )
        }
    )

    private fun rainwaterHarvestingCalculator() = CalcToolSpec(
        id = "util_rainwater_harvest",
        title = "Rainwater Harvesting & Recharge Pit",
        titleHi = "वर्षा जल संचयन और रिचार्ज पिट",
        subtitle = "Roof Catchment Annual Yield, Peak Runoff & Recharge Pit Volume",
        category = CalcCategory.UTILITIES,
        keywords = listOf("rainwater", "harvesting", "recharge", "pit", "catchment", "runoff"),
        fields = listOf(
            CalcFieldSpec("area", "Roof Catchment Area (m²)", "150", FieldUnitKind.AREA_SQ_M),
            CalcFieldSpec("rain", "Annual Rainfall (mm/year)", "850", FieldUnitKind.NONE),
            CalcFieldSpec("coeff", "Surface Type", "RCC Roof (0.85)", options = listOf("RCC Roof (0.85)", "Metal / GI Sheet (0.90)", "Paved Courtyard (0.75)", "Garden / Soil (0.30)"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter roof area."))
            val rain = ctx.doubleOrNull("rain") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter rainfall."))
            if (area <= 0 || rain <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Inputs must be positive."))
            val c = when (ctx.raw("coeff")) {
                "Metal / GI Sheet (0.90)" -> 0.90
                "Paved Courtyard (0.75)" -> 0.75
                "Garden / Soil (0.30)" -> 0.30
                else -> 0.85
            }
            val annualLiters = area * (rain / 1000.0) * c * 1000.0
            val pitVolM3 = (area * 0.025 * c).coerceAtLeast(1.5) // 25mm intense storm capture
            val side = sqrt(pitVolM3 / 2.0).coerceAtLeast(1.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Annual Harvestable Water", UnitConverter.fmt(annualLiters, 0), "Liters/yr", isPrimary = true),
                        CalcResultItem("Recommended Recharge Pit", UnitConverter.fmt(pitVolM3, p), "m³", isPrimary = true),
                        CalcResultItem("Pit Dimensions (L×W×D)", "${UnitConverter.fmt(side, 2)} × ${UnitConverter.fmt(side, 2)} × 2.00", "m"),
                        CalcResultItem("Peak 25mm Storm Yield", UnitConverter.fmt(area * 25.0 * c, 0), "Liters")
                    ),
                    formula = "Yield (L) = Area (m²) × Rainfall (mm) × Runoff Coeff",
                    steps = listOf("${UnitConverter.fmt(area, 1)} × $rain × $c = ${UnitConverter.fmt(annualLiters, 0)} L/yr"),
                    assumptions = "Recharge pit sized for 25 mm single-hour cloudburst retention."
                )
            )
        }
    )

    private fun plumbingPipeFlowCalculator() = CalcToolSpec(
        id = "util_plumbing_pipe",
        title = "Pipe Flow, Velocity & Drain Slope",
        titleHi = "पाइप प्रवाह और ड्रेनेज ढलान",
        subtitle = "Manning's Full-Pipe Flow Rate (LPS / GPM), Velocity & PVC Sizing",
        category = CalcCategory.UTILITIES,
        keywords = listOf("pipe", "plumbing", "flow", "manning", "drain", "pvc", "velocity", "slope"),
        fields = listOf(
            CalcFieldSpec("diaMm", "Inner Pipe Diameter (mm)", "110", options = listOf("50", "75", "110", "160", "200", "250", "300")),
            CalcFieldSpec("slopePct", "Pipe Gradient / Slope (%)", "1.5", FieldUnitKind.PERCENT),
            CalcFieldSpec("mat", "Pipe Material (Manning n)", "PVC / HDPE (n=0.009)", options = listOf("PVC / HDPE (n=0.009)", "Cast Iron (n=0.012)", "Concrete RCC (n=0.013)"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val dMm = ctx.doubleOrNull("diaMm") ?: 110.0
            val sPct = ctx.doubleOrNull("slopePct") ?: 1.5
            if (dMm <= 0 || sPct <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Diameter and slope must be positive."))
            val n = when (ctx.raw("mat")) {
                "Cast Iron (n=0.012)" -> 0.012
                "Concrete RCC (n=0.013)" -> 0.013
                else -> 0.009
            }
            val d = dMm / 1000.0
            val rH = d / 4.0
            val s = sPct / 100.0
            val vel = (1.0 / n) * rH.pow(2.0 / 3.0) * sqrt(s)
            val area = PI * (d / 2.0).pow(2)
            val qM3s = area * vel
            val qLps = qM3s * 1000.0
            val qGpm = qLps * 15.8503
            val warn = if (vel < 0.6) listOf("Velocity < 0.6 m/s may cause silt deposition in sewer lines.") else emptyList()
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Flow Rate (LPS)", UnitConverter.fmt(qLps, p), "L/s", isPrimary = true),
                        CalcResultItem("Flow Velocity", UnitConverter.fmt(vel, p), "m/s", isPrimary = true),
                        CalcResultItem("Flow Rate (GPM / LPM)", "${UnitConverter.fmt(qGpm, 1)} GPM | ${UnitConverter.fmt(qLps * 60.0, 0)} LPM", ""),
                        CalcResultItem("Gradient Ratio", "1 : ${UnitConverter.fmt(100.0 / sPct, 1)}", "")
                    ),
                    formula = "V = (1/n) × R^(2/3) × S^(1/2); Q = A × V",
                    steps = listOf("R = D/4 = ${UnitConverter.fmt(rH, 4)} m; V = ${UnitConverter.fmt(vel, p)} m/s"),
                    assumptions = "Full-bore gravity flow using Manning's equation; self-cleansing velocity ≥ 0.6 m/s.",
                    warnings = warn
                )
            )
        }
    )

    private fun electricalAcSolarCalculator() = CalcToolSpec(
        id = "util_electrical_ac_solar",
        title = "AC Tonnage, Electrical Load & Solar",
        titleHi = "AC टनेज, इलेक्ट्रिकल लोड और सोलर",
        subtitle = "Room AC BTU/Ton Sizing, Connected kW Load & Rooftop Solar kWp",
        category = CalcCategory.UTILITIES,
        typeFieldKey = "mode",
        keywords = listOf("ac", "btu", "ton", "electrical", "solar", "kw", "load", "panel"),
        fields = listOf(
            CalcFieldSpec("mode", "Utility Estimator", "Room AC Tonnage", options = listOf("Room AC Tonnage", "Building Electrical & Solar")),
            CalcFieldSpec("l", "Room / Roof Length", "5.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Room / Roof Width", "4.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("occupants", "Occupants / Connected kW", "3", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val occ = ctx.doubleOrNull("occupants") ?: 3.0
            if (l <= 0 || w <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Dimensions must be positive."))
            val areaM2 = l * w
            val areaSqFt = areaM2 * UnitConverter.SQ_FT_IN_SQ_M
            if (ctx.raw("mode") == "Building Electrical & Solar") {
                val loadKw = (areaSqFt * 0.008).coerceAtLeast(1.0)
                val solarKwp = (areaM2 * 0.70 / 10.0).coerceAtLeast(1.0) // ~10 m² per kWp on 70% usable roof
                val panels540 = ceil(solarKwp * 1000.0 / 540.0).toInt()
                val dailyKwh = solarKwp * 4.2
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Max Rooftop Solar", UnitConverter.fmt(solarKwp, p), "kWp", isPrimary = true),
                            CalcResultItem("540W Solar Panels", "$panels540", "Panels", isPrimary = true),
                            CalcResultItem("Daily Generation Est.", UnitConverter.fmt(dailyKwh, p), "kWh/day"),
                            CalcResultItem("Est. Connected Load", UnitConverter.fmt(loadKw, p), "kW")
                        ),
                        formula = "Solar kWp ≈ (0.70 × Roof Area m²) / 10; Daily Units ≈ kWp × 4.2",
                        steps = listOf("Roof Area = ${UnitConverter.fmt(areaM2, p)} m²; 70% usable = ${UnitConverter.fmt(areaM2 * 0.7, p)} m²"),
                        assumptions = "Assumes 10 m² shadow-free roof area per 1 kWp using 540Wp monocrystalline modules."
                    )
                )
            } else {
                val btu = areaSqFt * 25.0 + (occ - 2).coerceAtLeast(0.0) * 600.0
                val tons = btu / 12000.0
                val recTon = when {
                    tons <= 1.0 -> "1.0 Ton"
                    tons <= 1.5 -> "1.5 Ton"
                    tons <= 2.0 -> "2.0 Ton"
                    else -> "${UnitConverter.fmt(tons, 1)} Ton"
                }
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Recommended AC Size", recTon, "", isPrimary = true),
                            CalcResultItem("Cooling Capacity", UnitConverter.fmt(btu, 0), "BTU/hr", isPrimary = true),
                            CalcResultItem("Exact Tonnage", UnitConverter.fmt(tons, p), "TR"),
                            CalcResultItem("Room Area", UnitConverter.fmt(areaSqFt, p), "sq.ft")
                        ),
                        formula = "BTU/hr ≈ Area(sq.ft) × 25 + Extra Occupants × 600; 1 TR = 12,000 BTU/hr",
                        steps = listOf("Area = ${UnitConverter.fmt(areaSqFt, p)} sq.ft → ${UnitConverter.fmt(btu, 0)} BTU/hr"),
                        assumptions = "Standard 10 ft ceiling height; add 15% for heavy top-floor sun exposure."
                    )
                )
            }
        }
    )
}

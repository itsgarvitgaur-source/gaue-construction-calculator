package com.example.features.diagrams

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.domain.units.UnitConverter
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

fun DrawScope.drawMasonrySteelOrSiteDiagram(
    s: DiagramInputSnapshot,
    mode: DiagramViewMode,
    yaw: Float,
    pitch: Float
): Boolean {
    when (s.toolId) {
        "masonry_bricks", "masonry_blocks" -> drawMasonryWallDiagram(s, mode, yaw, pitch)
        "finish_plaster", "finish_paint_putty", "finish_waterproofing", "finish_tiles_flooring", "finish_trimix_epoxy" ->
            drawFinishingDiagram(s, mode)
        "earth_excavation_pit", "earth_sloped_excavation", "earth_backfill", "earth_cut_fill" ->
            drawEarthworkDiagram(s, mode, yaw, pitch)
        "steel_rebar_weight", "steel_multi_dia", "steel_member_reinf", "steel_hook_bend_ld", "steel_stirrup_cutting" ->
            drawSteelDiagram(s, mode)
        "basic_perimeter_rft", "basic_land_converter",
        "basic_length_converter", "basic_volume_converter", "basic_fraction_calc" ->
            drawBasicDiagram(s, mode, yaw, pitch)
        "site_rise_fall", "site_slope_gradient", "site_right_angle_triangle",
        "site_coord_bearing", "site_trig_height", "site_drawing_scale" ->
            drawSiteToolkitDiagram(s)
        else -> return false
    }
    return true
}

private fun DrawScope.drawMasonryWallDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    val isBlock = s.toolId == "masonry_blocks"
    val shape = s.raw("wallShape", "Straight Wall")
    val isL = shape == "L-Shaped Wall"
    val isCurved = shape == "Curved / Circular Wall"
    val isCavity = shape == "Cavity Wall (Double Leaf)"
    val isBoundary = shape.startsWith("Boundary Wall")
    val isPartition = shape.startsWith("Partition Wall")

    val l1 = s.lenMeters("wallL", if (isBlock) 10.0 else 12.0).toFloat().coerceAtLeast(1f)
    val l2 = s.lenMeters("wallL2", 6.0).toFloat().coerceAtLeast(1f)
    val dia = s.lenMeters("dia", 5.0).toFloat().coerceAtLeast(1f)
    val h = s.lenMeters("wallH", 3.0).toFloat().coerceAtLeast(0.8f)
    val t = when {
        isPartition -> 0.115f
        isBlock -> 0.15f
        else -> s.lenMeters("wallT", 0.23).toFloat().coerceAtLeast(0.1f)
    }
    val deduct = s.dbl("deductArea", 2.5).toFloat().coerceAtLeast(0f)

    val lLbl = when {
        isCurved -> "Ø=${s.lenLabel("dia", 5.0)}"
        isL -> "L1=${s.lenLabel("wallL", 12.0)}"
        else -> "L=${s.lenLabel("wallL", if (isBlock) 10.0 else 12.0)}"
    }
    val hLbl = "H=${s.lenLabel("wallH", 3.0)}"
    val tLbl = if (isBlock) "Block" else "T=${UnitConverter.fmt(t * 1000.0, 0)}mm"
    val fill = if (isBlock) CadColors.ConcreteFill else CadColors.MasonryFill
    val stroke = if (isBlock) CadColors.ConcreteStroke else CadColors.MasonryStroke

    when (mode) {
        DiagramViewMode.VIEW_3D -> {
            val scale = (min(size.width, size.height) * 0.48f) / max(l1, h)
            val center = Offset(size.width / 2f, size.height * 0.58f)
            if (isCurved) {
                draw3DCylinder(Offset(0f, 0f), 0f, h, dia / 2f, Vec3D(0f, 0f, h / 2f), center, scale, yaw, pitch, fill, stroke)
            } else if (isL) {
                val cRef = Vec3D(l1 / 2f, l2 / 2f, h / 2f)
                val visT = max(t, l1 * 0.05f)
                draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l1, visT, h), cRef, center, scale, yaw, pitch, fill, stroke)
                draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(visT, l2, h), cRef, center, scale, yaw, pitch, fill, stroke)
            } else {
                val visT = max(t, l1 * 0.06f)
                val pts = draw3DPrism(
                    Vec3D(0f, 0f, 0f), Vec3D(l1, visT, h),
                    Vec3D(l1 / 2f, visT / 2f, h / 2f),
                    center, scale, yaw, pitch, fill, stroke
                )
                drawDimensionLine(pts[0], pts[1], 28f, lLbl)
                drawDimensionLine(pts[1], pts[5], -38f, hLbl, CadColors.DimOrange)
            }
            drawCadTextPill(shape, Offset(size.width / 2f, 26f), stroke)
        }
        DiagramViewMode.PLAN_2D -> {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val pad = 74f
            when {
                isCurved -> {
                    val rOut = min(size.width, size.height) * 0.29f
                    val rIn = rOut * 0.80f
                    drawCircle(fill, rOut, Offset(cx, cy))
                    drawCircle(Color.White, rIn, Offset(cx, cy))
                    drawCircle(stroke, rOut, Offset(cx, cy), style = Stroke(3f))
                    drawCircle(stroke, rIn, Offset(cx, cy), style = Stroke(2.5f))
                    drawDimensionLine(Offset(cx - rOut, cy + rOut), Offset(cx + rOut, cy + rOut), 32f, lLbl)
                }
                isL -> {
                    val wPx = size.width * 0.56f
                    val hPx = size.height * 0.52f
                    val left = cx - wPx / 2f
                    val top = cy - hPx / 2f
                    val wt = 34f
                    val p = Path().apply {
                        moveTo(left, top)
                        lineTo(left + wPx, top)
                        lineTo(left + wPx, top + wt)
                        lineTo(left + wt, top + wt)
                        lineTo(left + wt, top + hPx)
                        lineTo(left, top + hPx)
                        close()
                    }
                    drawPath(p, fill)
                    drawPath(p, stroke, style = Stroke(3f))
                    drawDimensionLine(Offset(left, top), Offset(left + wPx, top), -26f, lLbl)
                    drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -44f, "L2=${s.lenLabel("wallL2", 6.0)}", CadColors.DimOrange)
                }
                isCavity -> {
                    val wallW = size.width - pad * 2f
                    drawRect(fill, Offset(pad, cy - 30f), Size(wallW, 18f))
                    drawRect(stroke, Offset(pad, cy - 30f), Size(wallW, 18f), style = Stroke(2.5f))
                    drawRect(fill, Offset(pad, cy + 12f), Size(wallW, 18f))
                    drawRect(stroke, Offset(pad, cy + 12f), Size(wallW, 18f), style = Stroke(2.5f))
                    drawCadTextPill("Double Leaf + Cavity", Offset(cx, cy), CadColors.DimOrange, textSizePx = 20f)
                    drawDimensionLine(Offset(pad, cy + 30f), Offset(pad + wallW, cy + 30f), 32f, lLbl)
                }
                else -> {
                    val wallW = size.width - pad * 2f
                    val wallT = if (isPartition) 24f else 44f
                    val top = cy - wallT / 2f
                    drawRect(fill, Offset(pad, top), Size(wallW, wallT))
                    drawRect(stroke, Offset(pad, top), Size(wallW, wallT), style = Stroke(3f))
                    if (isBoundary) {
                        for (i in 0..3) {
                            val px = pad + wallW * i / 3f - 12f
                            drawRect(CadColors.ConcreteDarkFill, Offset(px, top - 8f), Size(24f, wallT + 16f))
                            drawRect(CadColors.ConcreteStroke, Offset(px, top - 8f), Size(24f, wallT + 16f), style = Stroke(2f))
                        }
                    }
                    drawDimensionLine(Offset(pad, top + wallT), Offset(pad + wallW, top + wallT), 32f, lLbl)
                    drawDimensionLine(Offset(pad + wallW, top), Offset(pad + wallW, top + wallT), -44f, tLbl, CadColors.DimOrange)
                }
            }
            drawCadTextPill(shape, Offset(cx, 26f), stroke)
        }
        else -> {
            val pad = 74f
            val wallW = size.width - pad * 2f
            val wallH = (wallW * (h / l1).coerceIn(0.25f, 0.58f)).coerceAtMost(size.height * 0.56f)
            val top = (size.height - wallH) / 2f
            drawRect(fill, Offset(pad, top), Size(wallW, wallH))

            val rows = if (isBlock) 6 else 10
            val cols = if (isBlock) 8 else 12
            for (r in 1 until rows) {
                val y = top + wallH * r / rows
                drawLine(stroke.copy(alpha = 0.45f), Offset(pad, y), Offset(pad + wallW, y), 1.4f)
            }
            for (r in 0 until rows) {
                val y0 = top + wallH * r / rows
                val y1 = top + wallH * (r + 1) / rows
                val shift = if (r % 2 == 1) (wallW / cols) * 0.5f else 0f
                for (c in 1 until cols) {
                    val x = pad + (wallW * c / cols) + shift
                    if (x < pad + wallW - 4f) drawLine(stroke.copy(alpha = 0.4f), Offset(x, y0), Offset(x, y1), 1.2f)
                }
            }
            drawRect(stroke, Offset(pad, top), Size(wallW, wallH), style = Stroke(3f))

            if (isBoundary) {
                for (i in 0..3) {
                    val px = pad + (wallW - 18f) * i / 3f
                    drawRect(CadColors.ConcreteFill, Offset(px, top - 12f), Size(18f, wallH + 12f))
                    drawRect(CadColors.ConcreteStroke, Offset(px, top - 12f), Size(18f, wallH + 12f), style = Stroke(2f))
                }
            } else if (deduct > 0f) {
                val winW = (wallW * 0.22f).coerceIn(48f, 96f)
                val winH = (wallH * 0.52f).coerceIn(42f, 96f)
                val wx = pad + wallW * 0.62f
                val wy = top + wallH * 0.22f
                drawRect(CadColors.GlassFill, Offset(wx, wy), Size(winW, winH))
                drawRect(CadColors.DimBlue, Offset(wx, wy), Size(winW, winH), style = Stroke(2.5f))
                drawCadTextPill("Opening -${UnitConverter.fmt(deduct.toDouble(), 1)}m²", Offset(wx + winW / 2f, wy + winH / 2f), CadColors.DimBlue, textSizePx = 20f)
            }
            drawDimensionLine(Offset(pad, top + wallH), Offset(pad + wallW, top + wallH), 34f, lLbl)
            drawDimensionLine(Offset(pad, top), Offset(pad, top + wallH), -48f, hLbl, CadColors.DimOrange)
            drawCadTextPill(shape, Offset(size.width / 2f, 26f), stroke)
        }
    }
}

private fun DrawScope.drawFinishingDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode) {
    when (s.toolId) {
        "finish_tiles_flooring" -> {
            val rl = s.lenMeters("roomL", 5.0).toFloat().coerceAtLeast(0.8f)
            val rw = s.lenMeters("roomW", 4.0).toFloat().coerceAtLeast(0.8f)
            val tl = (s.dbl("tileL", 600.0) / 1000.0).toFloat().coerceAtLeast(0.15f)
            val tw = (s.dbl("tileW", 600.0) / 1000.0).toFloat().coerceAtLeast(0.15f)
            val skH = s.dbl("skirtingH", 100.0)

            val maxS = min(size.width, size.height) * 0.56f
            val aspect = (rl / rw).coerceIn(0.45f, 2.0f)
            val wPx = if (aspect >= 1f) maxS else maxS * aspect
            val hPx = if (aspect >= 1f) maxS / aspect else maxS
            val left = (size.width - wPx) / 2f
            val top = (size.height - hPx) / 2f

            if (mode == DiagramViewMode.SECTION) {
                drawRect(CadColors.SoilFill, Offset(left, top + hPx * 0.5f), Size(wPx, 24f))
                drawRect(CadColors.ConcreteFill, Offset(left, top + hPx * 0.5f - 28f), Size(wPx, 28f))
                drawRect(CadColors.DimOrange, Offset(left, top + hPx * 0.5f - 40f), Size(wPx, 12f))
                drawCadTextPill("Tile (${s.raw("tileL", "600")}×${s.raw("tileW", "600")}mm) + 40mm Bedding", Offset(size.width / 2f, top + hPx * 0.5f - 70f), CadColors.DimOrange)
                drawDimensionLine(Offset(left, top + hPx * 0.5f + 24f), Offset(left + wPx, top + hPx * 0.5f + 24f), 28f, "L=${s.lenLabel("roomL", 5.0)}")
            } else {
                drawRect(Color(0xFFF8FAFC), Offset(left, top), Size(wPx, hPx))
                val nx = (rl / tl).coerceIn(2f, 16f)
                val ny = (rw / tw).coerceIn(2f, 16f)
                for (i in 1 until nx.toInt()) {
                    val x = left + wPx * (i / nx)
                    drawLine(CadColors.ConcreteDarkFill, Offset(x, top), Offset(x, top + hPx), 1.5f)
                }
                for (j in 1 until ny.toInt()) {
                    val y = top + hPx * (j / ny)
                    drawLine(CadColors.ConcreteDarkFill, Offset(left, y), Offset(left + wPx, y), 1.5f)
                }
                // Skirting border highlight
                drawRect(CadColors.DimOrange, Offset(left, top), Size(wPx, hPx), style = Stroke(4f))
                drawDimensionLine(Offset(left, top + hPx), Offset(left + wPx, top + hPx), 34f, "L=${s.lenLabel("roomL", 5.0)}")
                drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -48f, "W=${s.lenLabel("roomW", 4.0)}")
                drawCadTextPill("Tile ${s.raw("tileL", "600")}×${s.raw("tileW", "600")}mm • Skirting ${skH.toInt()}mm", Offset(size.width / 2f, 26f), CadColors.DimOrange)
            }
        }
        "finish_trimix_epoxy" -> {
            val l = s.lenMeters("l", 30.0).toFloat().coerceAtLeast(1f)
            val w = s.lenMeters("w", 20.0).toFloat().coerceAtLeast(1f)
            val pad = 74f
            val rw = size.width - pad * 2f
            val rh = (rw * (w / l).coerceIn(0.4f, 0.75f)).coerceAtMost(size.height * 0.54f)
            val top = (size.height - rh) / 2f
            drawRect(CadColors.ConcreteFill, Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            // Saw-cut control joint grid
            for (i in 1..4) drawLine(CadColors.ConcreteStroke.copy(alpha = 0.45f), Offset(pad + rw * i / 5f, top), Offset(pad + rw * i / 5f, top + rh), 1.5f)
            for (j in 1..3) drawLine(CadColors.ConcreteStroke.copy(alpha = 0.45f), Offset(pad, top + rh * j / 4f), Offset(pad + rw, top + rh * j / 4f), 1.5f)
            drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 34f, "L=${s.lenLabel("l", 30.0)}")
            drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -48f, "W=${s.lenLabel("w", 20.0)}")
            drawCadTextPill("Trimix ${s.lenLabel("thick", 0.15)} + Hardener + Epoxy", Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
        else -> {
            // Plaster / Paint / Waterproofing surface
            val isPaint = s.toolId == "finish_paint_putty"
            val l = if (isPaint) sqrt(s.dbl("area", 1200.0)).toFloat().coerceAtLeast(1f) else s.lenMeters("l", 10.0).toFloat().coerceAtLeast(0.5f)
            val h = if (isPaint) l * 0.75f else s.lenMeters(if (s.toolId == "finish_waterproofing") "w" else "h", 3.0).toFloat().coerceAtLeast(0.5f)
            val deduct = s.dbl("deduct", 0.0)
            val pad = 74f
            val rw = size.width - pad * 2f
            val rh = (rw * (h / l).coerceIn(0.35f, 0.75f)).coerceAtMost(size.height * 0.54f)
            val top = (size.height - rh) / 2f
            drawRect(CadColors.GlassFill.copy(alpha = 0.45f), Offset(pad, top), Size(rw, rh))
            drawDiagonalHatch(Offset(pad, top), Size(rw, rh), CadColors.DimBlue.copy(alpha = 0.25f), 18f)
            drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
            if (deduct > 0) {
                val dx = pad + rw * 0.6f
                val dy = top + rh * 0.22f
                drawRect(Color.White, Offset(dx, dy), Size(rw * 0.24f, rh * 0.5f))
                drawRect(CadColors.DimOrange, Offset(dx, dy), Size(rw * 0.24f, rh * 0.5f), style = Stroke(2f))
                drawCadTextPill("-${UnitConverter.fmt(deduct, 1)}", Offset(dx + rw * 0.12f, dy + rh * 0.25f), CadColors.DimOrange, textSizePx = 20f)
            }
            if (isPaint) {
                drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, "Area=${s.raw("area", "1200")} sq.ft")
            } else {
                drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, "L=${s.lenLabel("l", 10.0)}")
                drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -48f, if (s.toolId == "finish_waterproofing") "W=${s.lenLabel("w", 8.0)}" else "H=${s.lenLabel("h", 3.0)}", CadColors.DimOrange)
            }
        }
    }
}

private fun DrawScope.drawEarthworkDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    when (s.toolId) {
        "earth_sloped_excavation" -> {
            val l = s.lenMeters("l", 6.0).toFloat().coerceAtLeast(0.8f)
            val w = s.lenMeters("w", 4.0).toFloat().coerceAtLeast(0.8f)
            val d = s.lenMeters("d", 3.0).toFloat().coerceAtLeast(0.5f)
            val slope = s.dbl("slope", 0.5).toFloat().coerceAtLeast(0f)
            val topW = w + 2f * slope * d

            val pad = 74f
            val topSpan = size.width - pad * 2f
            val botSpan = (topSpan * (w / topW).coerceIn(0.35f, 1.0f))
            val pitH = (size.height * 0.52f)
            val yTop = size.height * 0.24f
            val yBot = yTop + pitH
            val cx = size.width / 2f

            val path = Path().apply {
                moveTo(cx - topSpan / 2f, yTop)
                lineTo(cx + topSpan / 2f, yTop)
                lineTo(cx + botSpan / 2f, yBot)
                lineTo(cx - botSpan / 2f, yBot)
                close()
            }
            drawPath(path, CadColors.SoilFill)
            drawPath(path, CadColors.SoilStroke, style = Stroke(3f))
            drawDimensionLine(Offset(cx - topSpan / 2f, yTop), Offset(cx + topSpan / 2f, yTop), -28f, "Top=${UnitConverter.fmt(topW.toDouble(), s.p)}m")
            drawDimensionLine(Offset(cx - botSpan / 2f, yBot), Offset(cx + botSpan / 2f, yBot), 28f, "Bot=${s.lenLabel("w", 4.0)}")
            drawDimensionLine(Offset(cx + topSpan / 2f, yTop), Offset(cx + topSpan / 2f, yBot), -48f, "D=${s.lenLabel("d", 3.0)}", CadColors.DimOrange)
            drawCadTextPill("Side Slope $slope:1 • L=${s.lenLabel("l", 6.0)}", Offset(cx, 26f), CadColors.SoilStroke)
        }
        "earth_cut_fill" -> {
            val egl = s.dbl("egl", 100.65)
            val fgl = s.dbl("fgl", 100.00)
            val pad = 64f
            val w = size.width - pad * 2f
            val midY = size.height * 0.54f
            val diffPx = ((egl - fgl).toFloat() * 45f).coerceIn(-65f, 65f)
            val eglY = midY - diffPx
            drawRect(if (egl >= fgl) Color(0xFFFEE2E2) else Color(0xFFDCFCE7), Offset(pad, min(eglY, midY)), Size(w, kotlin.math.abs(diffPx).coerceAtLeast(16f)))
            drawDashedLine(Offset(pad, eglY), Offset(pad + w, eglY), CadColors.SoilStroke, 3f)
            drawLine(CadColors.DimBlue, Offset(pad, midY), Offset(pad + w, midY), 3.5f)
            drawCadTextPill("EGL: ${UnitConverter.fmt(egl, 2)}m", Offset(pad + 68f, eglY - 22f), CadColors.SoilStroke)
            drawCadTextPill("FGL: ${UnitConverter.fmt(fgl, 2)}m", Offset(pad + w - 68f, midY + 24f), CadColors.DimBlue)
            drawCadTextPill(if (egl >= fgl) "CUTTING" else "FILLING", Offset(size.width / 2f, 26f), CadColors.DimOrange)
        }
        "earth_backfill" -> {
            val exc = s.dbl("excavated", 45.0).toFloat().coerceAtLeast(1f)
            val sub = s.dbl("substructure", 14.0).toFloat().coerceIn(0f, exc)
            val pad = 74f
            val pitW = size.width - pad * 2f
            val pitH = size.height * 0.54f
            val top = size.height * 0.24f
            val subFrac = (sub / exc).coerceIn(0.08f, 0.9f)
            drawRect(CadColors.SoilFill, Offset(pad, top), Size(pitW, pitH))
            drawRect(CadColors.ConcreteFill, Offset(size.width / 2f - pitW * subFrac * 0.4f, top + pitH * (1f - subFrac)), Size(pitW * subFrac * 0.8f, pitH * subFrac))
            drawRect(CadColors.SoilStroke, Offset(pad, top), Size(pitW, pitH), style = Stroke(3f))
            drawCadTextPill("Excavated=${UnitConverter.fmt(exc.toDouble(), s.p)}m³ | Sub=${UnitConverter.fmt(sub.toDouble(), s.p)}m³", Offset(size.width / 2f, 26f), CadColors.SoilStroke)
            drawCadTextPill("Net Backfill = ${UnitConverter.fmt((exc - sub).toDouble(), s.p)} m³", Offset(size.width / 2f, top + pitH + 30f), CadColors.DimOrange)
        }
        else -> {
            // Pit / Trench 3D & Section
            val l = s.lenMeters("l", 2.5).toFloat().coerceAtLeast(0.5f)
            val w = s.lenMeters("w", 2.0).toFloat().coerceAtLeast(0.5f)
            val d = s.lenMeters("d", 1.8).toFloat().coerceAtLeast(0.4f)
            val lLbl = "L=${s.lenLabel("l", 2.5)}"
            val wLbl = "W=${s.lenLabel("w", 2.0)}"
            val dLbl = "D=${s.lenLabel("d", 1.8)}"
            if (mode == DiagramViewMode.VIEW_3D) {
                val scale = (min(size.width, size.height) * 0.46f) / max(max(l, w), d)
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l, w, d), Vec3D(l / 2f, w / 2f, d / 2f), Offset(size.width / 2f, size.height * 0.54f), scale, yaw, pitch, CadColors.SoilFill, CadColors.SoilStroke)
                drawDimensionLine(pts[0], pts[1], 28f, lLbl)
                drawDimensionLine(pts[1], pts[2], 28f, wLbl)
                drawDimensionLine(pts[2], pts[6], -40f, dLbl, CadColors.DimOrange)
            } else {
                val pad = 74f
                val rw = size.width - pad * 2f
                val rh = size.height * 0.52f
                val top = size.height * 0.24f
                drawRect(CadColors.SoilFill, Offset(pad, top), Size(rw, rh))
                drawRect(CadColors.SoilStroke, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, lLbl)
                drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -46f, dLbl, CadColors.DimOrange)
            }
        }
    }
}

private fun DrawScope.drawSteelDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode) {
    when (s.toolId) {
        "steel_stirrup_cutting" -> {
            val b = s.dbl("b", 300.0).toFloat().coerceAtLeast(80f)
            val d = s.dbl("d", 450.0).toFloat().coerceAtLeast(80f)
            val cov = s.dbl("cover", 25.0).toFloat().coerceAtLeast(0f)
            val dia = s.dbl("barDia", 8.0)
            val isCirc = s.raw("type").startsWith("Circular")
            val cx = size.width / 2f
            val cy = size.height / 2f
            if (isCirc) {
                val r = min(size.width, size.height) * 0.28f
                drawCircle(CadColors.ConcreteFill.copy(alpha = 0.4f), r, Offset(cx, cy))
                drawCircle(CadColors.ConcreteStroke, r, Offset(cx, cy), style = Stroke(2f))
                drawCircle(CadColors.SteelBar, r - 18f, Offset(cx, cy), style = Stroke(5f))
                drawDimensionLine(Offset(cx - r, cy + r), Offset(cx + r, cy + r), 34f, "Ø=${b.toInt()}mm | Cover=${cov.toInt()}mm")
                drawCadTextPill("Stirrup Ø${dia.toInt()}mm • 10d Hooks", Offset(cx, 26f), CadColors.SteelBar)
            } else {
                val maxS = min(size.width, size.height) * 0.54f
                val ratio = (b / d).coerceIn(0.45f, 1.8f)
                val wPx = if (ratio >= 1f) maxS else maxS * ratio
                val hPx = if (ratio >= 1f) maxS / ratio else maxS
                val left = cx - wPx / 2f
                val top = cy - hPx / 2f
                drawRect(CadColors.ConcreteFill.copy(alpha = 0.35f), Offset(left, top), Size(wPx, hPx))
                drawRect(CadColors.ConcreteStroke, Offset(left, top), Size(wPx, hPx), style = Stroke(2f))
                drawRect(CadColors.SteelBar, Offset(left + 16f, top + 16f), Size(wPx - 32f, hPx - 32f), style = Stroke(5f))
                // 135° seismic hooks
                drawLine(CadColors.SteelBar, Offset(left + 16f, top + 16f), Offset(left + 44f, top + 44f), 5f)
                drawLine(CadColors.SteelBar, Offset(left + 24f, top + 16f), Offset(left + 52f, top + 40f), 5f)
                drawDimensionLine(Offset(left, top + hPx), Offset(left + wPx, top + hPx), 34f, "B=${b.toInt()}mm")
                drawDimensionLine(Offset(left, top), Offset(left, top + hPx), -48f, "D=${d.toInt()}mm", CadColors.DimOrange)
                drawCadTextPill("Ø${dia.toInt()}mm Stirrup • Cover=${cov.toInt()}mm", Offset(cx, 26f), CadColors.SteelBar)
            }
        }
        "steel_hook_bend_ld" -> {
            val dia = s.dbl("dia", 16.0)
            val pad = 74f
            val y = size.height * 0.58f
            val lenPx = size.width - pad * 2f
            val hookH = 56f
            val path = Path().apply {
                moveTo(pad, y - hookH)
                lineTo(pad, y)
                lineTo(pad + lenPx, y)
                lineTo(pad + lenPx, y - hookH)
            }
            drawPath(path, CadColors.SteelBar, style = Stroke(7f))
            drawDimensionLine(Offset(pad, y), Offset(pad + lenPx, y), 36f, "Ld / Lap Zone (Ø${dia.toInt()}mm)")
            drawDimensionLine(Offset(pad, y - hookH), Offset(pad, y), -44f, "Hook 9d=${(9 * dia).toInt()}mm", CadColors.DimOrange)
            drawCadTextPill("Bend Ded.: 90°=2d | 135°=3d", Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
        "steel_member_reinf" -> {
            val lx = s.lenMeters("lx", 4.0).toFloat().coerceAtLeast(0.5f)
            val ly = s.lenMeters("ly", 5.0).toFloat().coerceAtLeast(0.5f)
            val mDia = s.dbl("mainDia", 10.0).toInt()
            val mSp = s.dbl("mainSpace", 150.0).toInt()
            val dDia = s.dbl("distDia", 8.0).toInt()
            val dSp = s.dbl("distSpace", 200.0).toInt()
            val pad = 74f
            val wPx = size.width - pad * 2f
            val hPx = (wPx * (ly / lx).coerceIn(0.45f, 0.8f)).coerceAtMost(size.height * 0.56f)
            val top = (size.height - hPx) / 2f
            drawRect(Color(0xFFF8FAFC), Offset(pad, top), Size(wPx, hPx))
            drawRect(CadColors.ConcreteStroke, Offset(pad, top), Size(wPx, hPx), style = Stroke(3f))
            for (i in 1..6) drawLine(CadColors.SteelBar, Offset(pad + wPx * i / 7f, top + 8f), Offset(pad + wPx * i / 7f, top + hPx - 8f), 3f)
            for (j in 1..5) drawLine(CadColors.DimOrange, Offset(pad + 8f, top + hPx * j / 6f), Offset(pad + wPx - 8f, top + hPx * j / 6f), 2.2f)
            drawDimensionLine(Offset(pad, top + hPx), Offset(pad + wPx, top + hPx), 34f, "Lx=${s.lenLabel("lx", 4.0)}")
            drawDimensionLine(Offset(pad, top), Offset(pad, top + hPx), -48f, "Ly=${s.lenLabel("ly", 5.0)}")
            drawCadTextPill("Main Ø${mDia}@${mSp}mm | Dist Ø${dDia}@${dSp}mm", Offset(size.width / 2f, 26f), CadColors.SteelBar)
        }
        else -> {
            // Rebar Weight or Multi-Dia
            val dia = s.dbl("dia", 12.0).toInt()
            val lenLbl = s.lenLabel("len", 12.0)
            val pad = 68f
            val y = size.height / 2f
            drawLine(CadColors.SteelBar, Offset(pad, y), Offset(size.width - pad, y), 14f)
            // Ribbed pattern
            var rx = pad + 12f
            while (rx < size.width - pad - 10f) {
                drawLine(Color.White.copy(alpha = 0.65f), Offset(rx, y - 7f), Offset(rx + 6f, y + 7f), 2f)
                rx += 18f
            }
            drawDimensionLine(Offset(pad, y + 10f), Offset(size.width - pad, y + 10f), 38f, "Bar Length L = $lenLbl")
            drawCadTextPill("TMT Rebar Ø = $dia mm  •  Unit Wt = ${UnitConverter.fmt(dia * dia / 162.2, 3)} kg/m", Offset(size.width / 2f, 34f), CadColors.SteelBar)
        }
    }
}

private fun DrawScope.drawBasicDiagram(s: DiagramInputSnapshot, mode: DiagramViewMode, yaw: Float, pitch: Float) {
    when (s.toolId) {
        "basic_area" -> {
            val shape = s.raw("shape", "Rectangle")
            val a = s.lenMeters("a", 10.0).toFloat().coerceAtLeast(0.2f)
            val b = s.lenMeters("b", 8.0).toFloat().coerceAtLeast(0.2f)
            val h = s.lenMeters("h", 6.0).toFloat().coerceAtLeast(0.2f)
            val cx = size.width / 2f
            val cy = size.height / 2f
            val pad = 74f
            when (shape) {
                "Circle" -> {
                    val r = min(size.width, size.height) * 0.28f
                    drawCircle(CadColors.GlassFill, r, Offset(cx, cy))
                    drawCircle(CadColors.DimBlue, r, Offset(cx, cy), style = Stroke(3f))
                    drawLine(CadColors.DimOrange, Offset(cx, cy), Offset(cx + r, cy), 3f)
                    drawCadTextPill("r = ${s.lenLabel("a", 10.0)}", Offset(cx + r * 0.5f, cy - 22f), CadColors.DimOrange)
                }
                "Triangle (Base & Height)" -> {
                    val bw = size.width - pad * 2f
                    val th = size.height * 0.54f
                    val p = Path().apply {
                        moveTo(pad, cy + th / 2f)
                        lineTo(pad + bw, cy + th / 2f)
                        lineTo(cx, cy - th / 2f)
                        close()
                    }
                    drawPath(p, CadColors.GlassFill)
                    drawPath(p, CadColors.DimBlue, style = Stroke(3f))
                    drawDashedLine(Offset(cx, cy - th / 2f), Offset(cx, cy + th / 2f), CadColors.DimOrange, 2.5f)
                    drawDimensionLine(Offset(pad, cy + th / 2f), Offset(pad + bw, cy + th / 2f), 32f, "Base=${s.lenLabel("a", 10.0)}")
                    drawCadTextPill("H=${s.lenLabel("b", 8.0)}", Offset(cx + 48f, cy), CadColors.DimOrange)
                }
                "Trapezoid" -> {
                    val b1 = size.width - pad * 2f
                    val b2 = (b1 * (b / a).coerceIn(0.35f, 0.95f))
                    val th = size.height * 0.50f
                    val p = Path().apply {
                        moveTo(cx - b1 / 2f, cy + th / 2f)
                        lineTo(cx + b1 / 2f, cy + th / 2f)
                        lineTo(cx + b2 / 2f, cy - th / 2f)
                        lineTo(cx - b2 / 2f, cy - th / 2f)
                        close()
                    }
                    drawPath(p, CadColors.GlassFill)
                    drawPath(p, CadColors.DimBlue, style = Stroke(3f))
                    drawDimensionLine(Offset(cx - b1 / 2f, cy + th / 2f), Offset(cx + b1 / 2f, cy + th / 2f), 32f, "B1=${s.lenLabel("a", 10.0)}")
                    drawDimensionLine(Offset(cx - b2 / 2f, cy - th / 2f), Offset(cx + b2 / 2f, cy - th / 2f), -26f, "B2=${s.lenLabel("b", 8.0)}")
                    drawDimensionLine(Offset(cx + b1 / 2f, cy - th / 2f), Offset(cx + b1 / 2f, cy + th / 2f), -44f, "H=${s.lenLabel("h", 6.0)}", CadColors.DimOrange)
                }
                else -> {
                    val rw = size.width - pad * 2f
                    val rh = (rw * (b / a).coerceIn(0.35f, 0.8f)).coerceAtMost(size.height * 0.54f)
                    val top = cy - rh / 2f
                    drawRect(CadColors.GlassFill, Offset(pad, top), Size(rw, rh))
                    drawRect(CadColors.DimBlue, Offset(pad, top), Size(rw, rh), style = Stroke(3f))
                    drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, "L=${s.lenLabel("a", 10.0)}")
                    drawDimensionLine(Offset(pad, top), Offset(pad, top + rh), -48f, "W=${s.lenLabel("b", 8.0)}", CadColors.DimOrange)
                }
            }
        }
        "basic_volume_surface" -> {
            val l = s.lenMeters("l", 5.0).toFloat().coerceAtLeast(0.5f)
            val w = s.lenMeters("w", 4.0).toFloat().coerceAtLeast(0.5f)
            val h = s.lenMeters("h", 3.0).toFloat().coerceAtLeast(0.5f)
            val scale = (min(size.width, size.height) * 0.45f) / max(max(l, w), h)
            val center = Offset(size.width / 2f, size.height * 0.55f)
            if (s.raw("shape") == "Cylinder" || s.raw("shape") == "Cone") {
                draw3DCylinder(Offset(0f, 0f), 0f, h, l / 2f, Vec3D(0f, 0f, h / 2f), center, scale, yaw, pitch, CadColors.GlassFill, CadColors.DimBlue)
                drawCadTextPill("Ø=${s.lenLabel("l", 5.0)} • H=${s.lenLabel("h", 3.0)}", Offset(size.width / 2f, 28f), CadColors.DimOrange)
            } else {
                val pts = draw3DPrism(Vec3D(0f, 0f, 0f), Vec3D(l, w, h), Vec3D(l / 2f, w / 2f, h / 2f), center, scale, yaw, pitch, CadColors.GlassFill, CadColors.DimBlue)
                drawDimensionLine(pts[0], pts[1], 28f, "L=${s.lenLabel("l", 5.0)}")
                drawDimensionLine(pts[1], pts[2], 28f, "W=${s.lenLabel("w", 4.0)}")
                drawDimensionLine(pts[2], pts[6], -38f, "H=${s.lenLabel("h", 3.0)}", CadColors.DimOrange)
            }
        }
        else -> {
            // Perimeter / Land / Length / Volume / Fraction converter visual
            val pad = 74f
            val rw = size.width - pad * 2f
            val rh = size.height * 0.46f
            val top = size.height * 0.27f
            drawRect(CadColors.GlassFill.copy(alpha = 0.5f), Offset(pad, top), Size(rw, rh))
            drawRect(CadColors.DimOrange, Offset(pad, top), Size(rw, rh), style = Stroke(3.5f))
            val labelMain = when (s.toolId) {
                "basic_land_converter" -> "${s.raw("val", "1")} ${s.raw("unit", "Bigha")}"
                "basic_length_converter" -> "L = ${s.lenLabel("val", 10.0)}"
                "basic_volume_converter" -> "${s.raw("val", "1")} ${s.raw("unit", "m³")}"
                "basic_fraction_calc" -> "${s.raw("a", "12' 6")} ${s.raw("op", "+")} ${s.raw("b", "4' 3")}"
                else -> "L=${s.lenLabel("l", 15.0)} | W=${s.lenLabel("w", 10.0)}"
            }
            drawDimensionLine(Offset(pad, top + rh), Offset(pad + rw, top + rh), 32f, labelMain)
            drawCadTextPill("Scaled Conversion & Boundary Reference", Offset(size.width / 2f, 26f), CadColors.DimBlue)
        }
    }
}

private fun DrawScope.drawSiteToolkitDiagram(s: DiagramInputSnapshot) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    when (s.toolId) {
        "site_slope_gradient", "site_trig_height" -> {
            val isTrig = s.toolId == "site_trig_height"
            val rise = if (isTrig) 1f else s.lenMeters("rise", 0.5).toFloat().coerceAtLeast(0.1f)
            val run = if (isTrig) s.lenMeters("dist", 25.0).toFloat().coerceAtLeast(0.5f) else s.lenMeters("run", 10.0).toFloat().coerceAtLeast(0.5f)
            val deg = if (isTrig) s.dbl("angle", 32.5) else Math.toDegrees(atan2(rise.toDouble(), run.toDouble()))

            val pad = 74f
            val baseW = size.width - pad * 2f
            val baseY = size.height * 0.78f
            val riseH = size.height * 0.48f
            val path = Path().apply {
                moveTo(pad, baseY)
                lineTo(pad + baseW, baseY)
                lineTo(pad + baseW, baseY - riseH)
                close()
            }
            drawPath(path, CadColors.GlassFill.copy(alpha = 0.55f))
            drawPath(path, CadColors.DimBlue, style = Stroke(3f))
            drawDimensionLine(Offset(pad, baseY), Offset(pad + baseW, baseY), 32f, if (isTrig) "D=${s.lenLabel("dist", 25.0)}" else "Run=${s.lenLabel("run", 10.0)}")
            drawDimensionLine(Offset(pad + baseW, baseY - riseH), Offset(pad + baseW, baseY), -46f, if (isTrig) "H (Rise)" else "Rise=${s.lenLabel("rise", 0.5)}", CadColors.DimOrange)
            drawAngularArc(Offset(pad, baseY), 48f, -deg.toFloat().coerceIn(5f, 75f), deg.toFloat().coerceIn(5f, 75f), "${UnitConverter.fmt(deg, 1)}°")
        }
        "site_right_angle_triangle" -> {
            val pad = 74f
            val baseW = size.width - pad * 2f
            val baseY = size.height * 0.78f
            val h = size.height * 0.48f
            val p = Path().apply {
                moveTo(pad, baseY)
                lineTo(pad + baseW, baseY)
                lineTo(pad, baseY - h)
                close()
            }
            drawPath(p, CadColors.GlassFill.copy(alpha = 0.5f))
            drawPath(p, CadColors.DimBlue, style = Stroke(3f))
            // 90° square marker
            drawRect(CadColors.DimOrange, Offset(pad, baseY - 22f), Size(22f, 22f), style = Stroke(2.5f))
            drawDimensionLine(Offset(pad, baseY), Offset(pad + baseW, baseY), 32f, "B=${s.lenLabel("b", 4.0)}")
            drawDimensionLine(Offset(pad, baseY - h), Offset(pad, baseY), -46f, "A=${s.lenLabel("a", 3.0)}", CadColors.DimOrange)
            drawCadTextPill("Diagonal C (Check)", Offset(cx + 24f, baseY - h * 0.55f), CadColors.SteelBar)
        }
        "site_coord_bearing" -> {
            val n1 = s.dbl("n1", 1000.0)
            val e1 = s.dbl("e1", 500.0)
            val n2 = s.dbl("n2", 1042.5)
            val e2 = s.dbl("e2", 528.2)
            val dN = n2 - n1
            val dE = e2 - e1
            var wcb = Math.toDegrees(atan2(dE, dN))
            if (wcb < 0) wcb += 360.0
            val r = min(size.width, size.height) * 0.32f
            drawCircle(CadColors.DimBlue.copy(alpha = 0.35f), r, Offset(cx, cy), style = Stroke(2f))
            drawLine(CadColors.ConcreteDarkFill, Offset(cx, cy - r - 12f), Offset(cx, cy + r + 12f), 2f)
            drawLine(CadColors.ConcreteDarkFill, Offset(cx - r - 12f, cy), Offset(cx + r + 12f, cy), 2f)
            val rad = Math.toRadians(wcb)
            val target = Offset(cx + (r * sin(rad)).toFloat(), cy - (r * cos(rad)).toFloat())
            drawLine(CadColors.DimOrange, Offset(cx, cy), target, 4f)
            drawCircle(CadColors.SteelBar, 7f, target)
            drawCadTextPill("N", Offset(cx, cy - r - 20f), CadColors.ConcreteStroke, textSizePx = 22f)
            drawCadTextPill("WCB ${UnitConverter.fmt(wcb, 1)}° • D=${UnitConverter.fmt(sqrt(dN * dN + dE * dE), 2)}m", Offset(cx, size.height - 24f), CadColors.DimOrange)
        }
        else -> {
            // Rise & Fall or Scale
            val pad = 68f
            val y1 = size.height * 0.62f
            val y2 = size.height * 0.42f
            drawLine(CadColors.SoilStroke, Offset(pad, y1), Offset(size.width - pad, y1), 4f)
            drawLine(CadColors.DimBlue, Offset(pad + 30f, y2), Offset(size.width - pad - 30f, y2), 3f)
            drawRect(CadColors.DimOrange, Offset(pad + 20f, y2), Size(18f, y1 - y2))
            drawRect(CadColors.DimOrange, Offset(size.width - pad - 40f, y2), Size(18f, y1 - y2))
            val label = if (s.toolId == "site_rise_fall") {
                "BS=${s.raw("bs", "1.45")}m  |  FS=${s.raw("fs", "1.92")}m  |  BM=${s.raw("bmRl", "100.0")}"
            } else {
                "Drawing ${s.raw("measuredMm", "45")}mm @ Scale 1:${s.raw("scale", "100")}"
            }
            drawCadTextPill(label, Offset(cx, 28f), CadColors.DimBlue)
        }
    }
}

package com.example.domain.calculators

import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import kotlin.math.PI

object RoadAndBridgeCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        roadPavementLayersCalculator(),
        bridgeCulvertPierCalculator()
    )

    private fun roadPavementLayersCalculator() = CalcToolSpec(
        id = "infra_road_layers",
        title = "Road Pavement Layers (GSB, WMM, DBM, BC)",
        titleHi = "सड़क परतें (GSB, WMM, DBM, BC) कैलकुलेटर",
        subtitle = "Subgrade, Granular Sub-Base, Wet Mix Macadam & Bituminous Layers",
        category = CalcCategory.FINISHING,
        keywords = listOf("road", "gsb", "wmm", "dbm", "bc", "subgrade", "pavement", "morth", "highway", "infrastructure"),
        fields = listOf(
            CalcFieldSpec("len", "Road Length", "500", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("width", "Carriageway Width", "7.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("subgradeMm", "Subgrade Compaction Depth (mm)", "300", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("gsbMm", "GSB Thickness (mm)", "200", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("wmmMm", "WMM Thickness (mm)", "250", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("dbmMm", "DBM Thickness (mm)", "60", FieldUnitKind.NONE, allowZero = true),
            CalcFieldSpec("bcMm", "BC Wearing Coat Thickness (mm)", "40", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("len") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length."))
            val w = ctx.lengthMeters("width") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter width."))
            val sg = (ctx.doubleOrNull("subgradeMm") ?: 300.0).coerceAtLeast(0.0)
            val gsb = (ctx.doubleOrNull("gsbMm") ?: 200.0).coerceAtLeast(0.0)
            val wmm = (ctx.doubleOrNull("wmmMm") ?: 250.0).coerceAtLeast(0.0)
            val dbm = (ctx.doubleOrNull("dbmMm") ?: 60.0).coerceAtLeast(0.0)
            val bc = (ctx.doubleOrNull("bcMm") ?: 40.0).coerceAtLeast(0.0)
            if (l <= 0 || w <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Length and width must be positive."))

            val areaM2 = l * w
            val subVol = areaM2 * (sg / 1000.0)
            val gsbVol = areaM2 * (gsb / 1000.0)
            val wmmVol = areaM2 * (wmm / 1000.0)
            val dbmMt = areaM2 * (dbm / 1000.0) * 2.32
            val bcMt = areaM2 * (bc / 1000.0) * 2.36
            val primeKg = if (wmm > 0) areaM2 * 0.75 else 0.0
            val tackKg = (if (dbm > 0) areaM2 * 0.25 else 0.0) + (if (bc > 0) areaM2 * 0.25 else 0.0)

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("GSB Compacted / Loose", "${UnitConverter.fmt(gsbVol, p)} m³ / ${UnitConverter.fmt(gsbVol * 1.28, p)} m³", "", isPrimary = true),
                        CalcResultItem("WMM Compacted / Loose", "${UnitConverter.fmt(wmmVol, p)} m³ / ${UnitConverter.fmt(wmmVol * 1.32, p)} m³", "", isPrimary = true),
                        CalcResultItem("DBM + BC Bituminous Mix", "${UnitConverter.fmt(dbmMt + bcMt, p)} MT (DBM ${UnitConverter.fmt(dbmMt, 1)} + BC ${UnitConverter.fmt(bcMt, 1)})", ""),
                        CalcResultItem("Subgrade Earthwork", UnitConverter.fmt(subVol, p), "m³"),
                        CalcResultItem("Prime + Tack Emulsion", "${UnitConverter.fmt(primeKg, 0)} + ${UnitConverter.fmt(tackKg, 0)} kg", ""),
                        CalcResultItem("Pavement Plan Area", UnitConverter.fmt(areaM2, p), "m²")
                    ),
                    formula = "Layer Vol = L × W × t; Bituminous MT = Vol × Compacted Density (~2.32–2.36 t/m³)",
                    steps = listOf(
                        "Area = ${UnitConverter.fmt(l, p)}×${UnitConverter.fmt(w, p)} = ${UnitConverter.fmt(areaM2, p)} m²",
                        "GSB loose allowance ~28%, WMM ~32% per MoRTH field compaction"
                    ),
                    assumptions = "Compacted densities: DBM 2.32 t/m³, BC 2.36 t/m³; Prime coat 0.75 kg/m², Tack coat 0.25 kg/m²."
                )
            )
        }
    )

    private fun bridgeCulvertPierCalculator() = CalcToolSpec(
        id = "infra_culvert_pier",
        title = "Bridge Pier, Box Culvert & Deck Slab",
        titleHi = "ब्रिज पियर, बॉक्स कल्वर्ट और डेक स्लैब",
        subtitle = "Preliminary Concrete, Shuttering & Steel Est. for Culverts & Bridge Piers",
        category = CalcCategory.STRUCTURAL,
        isPreliminaryStructural = true,
        typeFieldKey = "infraType",
        keywords = listOf("bridge", "pier", "abutment", "culvert", "box culvert", "deck slab", "pile cap", "highway"),
        fields = listOf(
            CalcFieldSpec(
                "infraType", "Structure Type", "RCC Box Culvert (Single/Double Cell)",
                options = listOf("RCC Box Culvert (Single/Double Cell)", "Bridge Circular Pier + Cap + Deck")
            ),
            CalcFieldSpec("span", "Clear Span / Deck Span", "4.0", FieldUnitKind.LENGTH, LengthUnit.M, dynamicLabel = { m ->
                if (m["infraType"]?.startsWith("Bridge") == true) "Bridge Deck Span (L)" else "Culvert Cell Width (B)"
            }),
            CalcFieldSpec("height", "Cell Height / Pier Height", "3.0", FieldUnitKind.LENGTH, LengthUnit.M, dynamicLabel = { m ->
                if (m["infraType"]?.startsWith("Bridge") == true) "Pier Column Height (H)" else "Culvert Clear Height (H)"
            }),
            CalcFieldSpec("barrel", "Barrel Length / Deck Width", "10.0", FieldUnitKind.LENGTH, LengthUnit.M, dynamicLabel = { m ->
                if (m["infraType"]?.startsWith("Bridge") == true) "Bridge Deck Width (W)" else "Culvert Barrel / Road Width (L)"
            }),
            CalcFieldSpec("wallT", "Slab/Wall Thick OR Pier Dia", "0.35", FieldUnitKind.LENGTH, LengthUnit.M, dynamicLabel = { m ->
                if (m["infraType"]?.startsWith("Bridge") == true) "Circular Pier Diameter (Ø)" else "Wall / Slab Thickness (t)"
            }),
            CalcFieldSpec("cells", "Number of Cells / Piers", "1", FieldUnitKind.COUNT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val span = ctx.lengthMeters("span") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter span/width."))
            val h = ctx.lengthMeters("height") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter height."))
            val barrel = ctx.lengthMeters("barrel") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter length/width."))
            val wt = ctx.lengthMeters("wallT") ?: 0.35
            val n = (ctx.doubleOrNull("cells") ?: 1.0).coerceIn(1.0, 20.0)
            if (span <= 0 || h <= 0 || barrel <= 0 || wt <= 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions must be positive."))
            }

            if (ctx.raw("infraType").startsWith("Bridge")) {
                val r = wt / 2.0
                val pierVol = PI * r * r * h * n
                val capVol = (wt * 2.2) * (wt * 1.4) * 1.0 * n // prelim pier cap 1m deep
                val deckVol = span * barrel * 0.30 // prelim 300mm deck slab
                val totalVol = pierVol + capVol + deckVol
                val steelKg = totalVol * 125.0 // approx 125 kg/m³ for heavy bridge substructure/deck
                val shutterM2 = (2.0 * PI * r * h * n) + (span * barrel)
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Total Bridge Concrete", UnitConverter.fmt(totalVol, p), "m³", isPrimary = true),
                            CalcResultItem("Prelim. Reinforcement (~125 kg/m³)", UnitConverter.fmt(steelKg, 0), "kg", isPrimary = true),
                            CalcResultItem("Piers (${n.toInt()}) + Caps Concrete", "${UnitConverter.fmt(pierVol, p)} + ${UnitConverter.fmt(capVol, p)} m³", ""),
                            CalcResultItem("Deck Slab Concrete (300mm)", UnitConverter.fmt(deckVol, p), "m³"),
                            CalcResultItem("Approx. Formwork Area", UnitConverter.fmt(shutterM2, p), "m²")
                        ),
                        formula = "V_pier = N×πr²H; V_deck = Span × W × 0.30m; V_cap = Prelim Cap",
                        steps = listOf("Pier Vol = ${UnitConverter.fmt(pierVol, p)} m³, Cap = ${UnitConverter.fmt(capVol, p)} m³, Deck = ${UnitConverter.fmt(deckVol, p)} m³"),
                        assumptions = "Preliminary quantity estimate only; verify IRC-6 / IRC-112 hydraulic, scour & seismic bridge design."
                    )
                )
            } else {
                val outerW = n * span + (n + 1.0) * wt
                val outerH = h + 2.0 * wt
                val boxArea = (outerW * outerH) - n * (span * h)
                val vol = boxArea * barrel
                val steelKg = vol * 105.0
                val shutterM2 = (2.0 * h * (n + 1.0) + n * span) * barrel
                Result.success(
                    CalcOutcome(
                        results = listOf(
                            CalcResultItem("Box Culvert Concrete", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                            CalcResultItem("Prelim. Rebar Steel (~105 kg/m³)", UnitConverter.fmt(steelKg, 0), "kg", isPrimary = true),
                            CalcResultItem("Inner & Outer Formwork", UnitConverter.fmt(shutterM2, p), "m²"),
                            CalcResultItem("Outer Frame (W × H)", "${UnitConverter.fmt(outerW, p)} × ${UnitConverter.fmt(outerH, p)} m", "")
                        ),
                        formula = "A_cs = (OuterW × OuterH) - N×(Span × H); Vol = A_cs × Barrel Length",
                        steps = listOf("CS Concrete Area = ${UnitConverter.fmt(boxArea, p)} m² × ${UnitConverter.fmt(barrel, p)}m = ${UnitConverter.fmt(vol, p)} m³"),
                        assumptions = "Uniform slab/wall thickness; haunches and wing walls estimated separately per IRC specs."
                    )
                )
            }
        }
    )
}

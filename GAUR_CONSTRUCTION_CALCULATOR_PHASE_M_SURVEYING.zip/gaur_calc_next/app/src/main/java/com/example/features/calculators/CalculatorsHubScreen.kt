package com.example.features.calculators

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Engineering
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Warehouse
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.core.i18n.LocalAppStrings
import com.example.domain.calculators.CalcCategory
import com.example.domain.calculators.CalculatorRegistry
import com.example.features.dashboard.DashboardCategoryCatalog
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.components.GlassBluePill
import com.example.ui.theme.LocalEngineeringPalette

@Composable
fun CalculatorsHubScreen(
    viewModel: MainViewModel,
    initialCategoryId: String? = null,
    onBack: (() -> Unit)? = null,
    onOpenCalculator: (String) -> Unit,
    onNavigateRoute: (String) -> Unit = {}
) {
    val palette = LocalEngineeringPalette.current
    val strings = LocalAppStrings.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteToolIds.collectAsStateWithLifecycle()

    val isSubGroup = initialCategoryId?.startsWith("group:") == true
    var selectedCategoryId by remember(initialCategoryId) {
        mutableStateOf(if (isSubGroup) "all" else (initialCategoryId ?: "all"))
    }
    var query by remember { mutableStateOf("") }

    val (headerTitle, groupTools) = remember(initialCategoryId) {
        if (isSubGroup) {
            DashboardCategoryCatalog.filterToolsForGroup(initialCategoryId!!)
        } else {
            val cat = CalcCategory.entries.firstOrNull { it.id == initialCategoryId }
            val title = when {
                cat != null && settings.language == AppLanguage.HINDI -> cat.titleHi
                cat != null -> cat.titleEn
                else -> strings.allTools
            }
            title to CalculatorRegistry.allTools
        }
    }

    val filteredTools = remember(selectedCategoryId, query, initialCategoryId, groupTools) {
        val base = if (isSubGroup) {
            if (query.isBlank()) groupTools else groupTools.filter { tool ->
                val q = query.trim().lowercase()
                tool.title.lowercase().contains(q) ||
                    tool.titleHi.lowercase().contains(q) ||
                    tool.subtitle.lowercase().contains(q) ||
                    tool.keywords.any { it.contains(q) }
            }
        } else {
            val searched = if (query.isBlank()) CalculatorRegistry.allTools else CalculatorRegistry.search(query)
            if (selectedCategoryId == "all") searched else searched.filter { it.category.id == selectedCategoryId }
        }
        base
    }

    val companionBanner: Triple<String, String, Pair<String, ImageVector>>? = when (initialCategoryId) {
        "steel" -> Triple("Bar Bending Schedule (BBS) Studio", "Multi-dia BBS, shapes, PDF & Excel export", "bbs" to Icons.Rounded.Layers)
        "group:roofing" -> Triple("PEB & Warehouse Engineering Studio", "Portal frames, rafters, purlins, sheeting & bolts", "peb" to Icons.Rounded.Warehouse)
        "group:bridge" -> Triple("Bridge Components & Methods Guide", "Piers, abutments, bearings & IRC construction notes", "knowledge/Bridge Engg" to Icons.Rounded.MenuBook)
        "site" -> Triple("Site Diary (DPR), MB Book & Checklists", "Log progress, measurement book & QA/QC safety", "site_diary" to Icons.Rounded.Engineering)
        else -> null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.concreteBg)
    ) {
        EngineeringTopBar(
            title = headerTitle,
            subtitle = "${filteredTools.size} Engineering Calculators",
            onBack = onBack
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calculators_search_input"),
                placeholder = { Text(strings.searchPlaceholder, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.orange) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = palette.concreteCard,
                    unfocusedContainerColor = palette.concreteCard,
                    focusedBorderColor = palette.orange,
                    unfocusedBorderColor = palette.metallicBorder
                )
            )
        }

        if (!isSubGroup) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedCategoryId == "all",
                        onClick = { selectedCategoryId = "all" },
                        label = { Text("All (${CalculatorRegistry.allTools.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = palette.orangeSoft,
                            selectedLabelColor = palette.orangeDark
                        ),
                        border = BorderStroke(1.dp, palette.metallicBorder)
                    )
                }
                items(CalcCategory.entries, key = { it.id }) { cat ->
                    FilterChip(
                        selected = selectedCategoryId == cat.id,
                        onClick = { selectedCategoryId = cat.id },
                        label = {
                            Text(if (settings.language == AppLanguage.HINDI) cat.titleHi else cat.titleEn)
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = palette.orangeSoft,
                            selectedLabelColor = palette.orangeDark
                        ),
                        border = BorderStroke(1.dp, palette.metallicBorder)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (companionBanner != null) {
                val (bTitle, bSub, routeIcon) = companionBanner
                item {
                    EngineeringCard(
                        accentColor = palette.skyBlue,
                        onClick = { onNavigateRoute(routeIcon.first) },
                        modifier = Modifier.testTag("companion_studio_banner")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Icon(routeIcon.second, contentDescription = null, tint = palette.skyBlue, modifier = Modifier.size(26.dp))
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(bTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = palette.skyBlue)
                                    Text(bSub, style = MaterialTheme.typography.bodySmall, color = palette.inkSecondary)
                                }
                            }
                            Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = "Open", tint = palette.orangeDark)
                        }
                    }
                }
            }

            items(filteredTools, key = { it.id }) { tool ->
                val isFav = favoriteIds.contains(tool.id)
                EngineeringCard(
                    accentColor = if (tool.isPreliminaryStructural) palette.skyBlue else palette.orange,
                    onClick = {
                        viewModel.onToolOpened(tool.id)
                        onOpenCalculator(tool.id)
                    },
                    modifier = Modifier.testTag("tool_card_${tool.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (settings.language == AppLanguage.HINDI) tool.titleHi else tool.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = palette.inkPrimary
                            )
                            Text(
                                text = tool.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkMuted,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(modifier = Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                GlassBluePill(text = tool.category.titleEn)
                                if (tool.isPreliminaryStructural) {
                                    GlassBluePill(text = "Preliminary Est.")
                                }
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = { viewModel.toggleFavorite(tool.id) },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("fav_btn_${tool.id}")
                        ) {
                            Icon(
                                imageVector = if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                contentDescription = "Toggle Favorite",
                                tint = if (isFav) palette.orange else palette.inkMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

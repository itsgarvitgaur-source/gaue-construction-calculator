package com.example.domain.calculators

import com.example.domain.units.AreaUnit
import com.example.domain.units.LengthUnit
import com.example.domain.units.UnitConverter
import com.example.domain.units.VolumeUnit
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sqrt

object BasicAndEarthworkCalculators {

    fun all(): List<CalcToolSpec> = listOf(
        areaCalculator(),
        volumeAndSurfaceAreaCalculator(),
        perimeterAndRftCalculator(),
        landAreaConverter(),
        lengthAndFeetInchConverter(),
        volumeConverter(),
        fractionDecimalCalculator(),
        pitTrenchExcavation(),
        slopedExcavation(),
        backfillingAndCompaction(),
        cutAndFillEarthwork()
    )

    private fun areaCalculator() = GeometryShapeCalculators.areaCalculator()

    private fun volumeAndSurfaceAreaCalculator() = GeometryShapeCalculators.volumeAndSurfaceAreaCalculator()

    private fun perimeterAndRftCalculator() = CalcToolSpec(
        id = "basic_perimeter_rft",
        title = "Perimeter & Running Feet (RFT / RMT)",
        titleHi = "परिमाप और रनिंग फीट (RFT)",
        subtitle = "Skirting, Boundary, Compound Wall & Piping Run",
        category = CalcCategory.BASIC,
        keywords = listOf("perimeter", "rft", "rmt", "running feet", "running meter", "skirting", "boundary"),
        fields = listOf(
            CalcFieldSpec("l", "Length", "15", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Width (0 for straight run)", "10", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true),
            CalcFieldSpec("deduct", "Deduction (Gates/Openings)", "1.2", FieldUnitKind.LENGTH, LengthUnit.M, allowZero = true),
            CalcFieldSpec("rate", "Rate per RFT (Optional)", "0", FieldUnitKind.RATE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid length."))
            val w = ctx.lengthMeters("w") ?: 0.0
            val deduct = ctx.lengthMeters("deduct") ?: 0.0
            val rate = ctx.doubleOrNull("rate") ?: 0.0
            if (l <= 0 || w < 0 || deduct < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid negative dimensions."))
            val grossM = if (w > 0) 2.0 * (l + w) else l
            val netM = (grossM - deduct).coerceAtLeast(0.0)
            val rft = UnitConverter.fromMeters(netM, LengthUnit.FT)
            val cost = if (rate > 0) rft * rate else null
            Result.success(
                CalcOutcome(
                    results = buildList {
                        add(CalcResultItem("Net Running Meters", UnitConverter.fmt(netM, p), "RMT", isPrimary = true))
                        add(CalcResultItem("Net Running Feet", UnitConverter.fmt(rft, p), "RFT", isPrimary = true))
                        add(CalcResultItem("Gross Perimeter", UnitConverter.fmt(grossM, p), "m"))
                        if (cost != null) add(CalcResultItem("Estimated Cost", "${ctx.settings.currencySymbol}${UnitConverter.fmt(cost, 2)}", ""))
                    },
                    formula = if (w > 0) "Net RMT = 2(L + W) - Deduction; RFT = RMT × 3.28084" else "Net RMT = L - Deduction",
                    steps = listOf(
                        "Gross Run = ${UnitConverter.fmt(grossM, p)} m",
                        "Net Run = ${UnitConverter.fmt(grossM, p)} - ${UnitConverter.fmt(deduct, p)} = ${UnitConverter.fmt(netM, p)} m",
                        "RFT = ${UnitConverter.fmt(netM, p)} × 3.28084 = ${UnitConverter.fmt(rft, p)} ft"
                    ),
                    assumptions = "If Width = 0, calculates straight linear run.",
                    estimatedCost = cost
                )
            )
        }
    )

    private fun landAreaConverter() = CalcToolSpec(
        id = "basic_land_converter",
        title = "Land & Area Converter (All Units)",
        titleHi = "भूमि क्षेत्रफल कनवर्टर (बीघा/एकड़/सेंट)",
        subtitle = "Sq.ft, Sq.m, Gaj, Acre, Hectare, Bigha, Cent, Guntha, Kanal & Marla",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("land", "acre", "hectare", "bigha", "gaj", "sqyd", "sqft", "sqm", "cent", "guntha", "kanal", "marla", "conversion"),
        fields = listOf(
            CalcFieldSpec("val", "Area Value", "1", FieldUnitKind.NONE),
            CalcFieldSpec("unit", "From Unit", "Bigha", options = AreaUnit.entries.map { it.symbol } + listOf("Cent", "Guntha", "Marla", "Kanal"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid area value."))
            if (v < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Area cannot be negative."))
            val unitStr = ctx.raw("unit")
            val sqM = when (unitStr) {
                "Cent" -> v * 40.468564224
                "Guntha" -> v * 101.17141056
                "Marla" -> v * 25.29285264
                "Kanal" -> v * 505.8570528
                else -> {
                    val fromUnit = AreaUnit.entries.firstOrNull { it.symbol == unitStr } ?: AreaUnit.BIGHA
                    UnitConverter.areaToSqMeters(v, fromUnit, ctx.settings.bighaSqFt)
                }
            }
            val sqFt = UnitConverter.sqMetersToArea(sqM, AreaUnit.SQ_FT, ctx.settings.bighaSqFt)
            val sqYd = UnitConverter.sqMetersToArea(sqM, AreaUnit.SQ_YD, ctx.settings.bighaSqFt)
            val acre = UnitConverter.sqMetersToArea(sqM, AreaUnit.ACRE, ctx.settings.bighaSqFt)
            val hectare = UnitConverter.sqMetersToArea(sqM, AreaUnit.HECTARE, ctx.settings.bighaSqFt)
            val bigha = UnitConverter.sqMetersToArea(sqM, AreaUnit.BIGHA, ctx.settings.bighaSqFt)
            val cent = sqM / 40.468564224
            val guntha = sqM / 101.17141056
            val marla = sqM / 25.29285264
            val kanal = sqM / 505.8570528

            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Square Feet", UnitConverter.fmt(sqFt, p), "sq.ft", isPrimary = true),
                        CalcResultItem("Square Meters", UnitConverter.fmt(sqM, p), "m²", isPrimary = true),
                        CalcResultItem("Square Yards (Gaj)", UnitConverter.fmt(sqYd, p), "sq.yd"),
                        CalcResultItem("Acre / Cent", "${UnitConverter.fmt(acre, 4)} Ac | ${UnitConverter.fmt(cent, 2)} Cent", ""),
                        CalcResultItem("Hectare", UnitConverter.fmt(hectare, 4), "Ha"),
                        CalcResultItem("Guntha / Marla / Kanal", "${UnitConverter.fmt(guntha, 2)} G | ${UnitConverter.fmt(marla, 2)} M | ${UnitConverter.fmt(kanal, 3)} K", ""),
                        CalcResultItem("Bigha (${ctx.settings.bighaRegionName.substringBefore(" (")})", UnitConverter.fmt(bigha, 4), "Bigha")
                    ),
                    formula = "1 Acre = 43,560 sq.ft = 100 Cent = 40 Guntha = 8 Kanal",
                    steps = listOf(
                        "Converted ${UnitConverter.fmt(v, p)} $unitStr → ${UnitConverter.fmt(sqM, p)} m²",
                        "1 Bigha configured as ${UnitConverter.fmt(ctx.settings.bighaSqFt, 0)} sq.ft in Settings"
                    ),
                    assumptions = "Bigha varies by Indian state; configure regional value in Settings."
                )
            )
        }
    )

    private fun lengthAndFeetInchConverter() = CalcToolSpec(
        id = "basic_length_converter",
        title = "Length & Distance Converter",
        titleHi = "लंबाई और दूरी कनवर्टर",
        subtitle = "mm, cm, m, km, Inch, Feet, Yard, Mile & Architectural Ft-In",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("length", "feet", "meters", "inches", "mm", "cm", "yd", "km", "mile", "convert"),
        fields = listOf(
            CalcFieldSpec("val", "Length Value", "10", FieldUnitKind.LENGTH, LengthUnit.FT)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val meters = ctx.lengthMeters("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid length."))
            if (meters < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Length cannot be negative."))
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Meters", UnitConverter.fmt(meters, p + 1), "m", isPrimary = true),
                        CalcResultItem("Feet (Decimal)", UnitConverter.fmt(UnitConverter.fromMeters(meters, LengthUnit.FT), p + 1), "ft", isPrimary = true),
                        CalcResultItem("Architectural Ft-In", UnitConverter.fmtFeetInches(meters), ""),
                        CalcResultItem("Millimeters", UnitConverter.fmt(UnitConverter.fromMeters(meters, LengthUnit.MM), p), "mm"),
                        CalcResultItem("Centimeters", UnitConverter.fmt(UnitConverter.fromMeters(meters, LengthUnit.CM), p), "cm"),
                        CalcResultItem("Inches", UnitConverter.fmt(UnitConverter.fromMeters(meters, LengthUnit.INCH), p), "in"),
                        CalcResultItem("Yards", UnitConverter.fmt(UnitConverter.fromMeters(meters, LengthUnit.YD), p), "yd"),
                        CalcResultItem("Kilometers / Miles", "${UnitConverter.fmt(meters / 1000.0, 4)} km | ${UnitConverter.fmt(meters / 1609.344, 4)} mi", "")
                    ),
                    formula = "1 ft = 0.3048 m = 304.8 mm | 1 in = 25.4 mm | 1 yd = 3 ft",
                    steps = listOf("Base SI value = ${UnitConverter.fmt(meters, 4)} m"),
                    assumptions = "Uses exact international foot (0.3048 m)."
                )
            )
        }
    )

    private fun volumeConverter() = CalcToolSpec(
        id = "basic_volume_converter",
        title = "Volume & Capacity Converter",
        titleHi = "आयतन और क्षमता कनवर्टर",
        subtitle = "m³, CFT, Brass, Liters, Cubic Yards, US & UK Gallons",
        category = CalcCategory.CONVERTERS,
        keywords = listOf("volume", "cft", "cum", "brass", "liters", "cubic", "gallon"),
        fields = listOf(
            CalcFieldSpec("val", "Volume Value", "1", FieldUnitKind.NONE),
            CalcFieldSpec("unit", "From Unit", VolumeUnit.CU_M.symbol, options = VolumeUnit.entries.map { it.symbol } + listOf("US Gallons", "UK Gallons"))
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val v = ctx.doubleOrNull("val") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid volume."))
            if (v < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Volume cannot be negative."))
            val unitStr = ctx.raw("unit")
            val cum = when (unitStr) {
                "US Gallons" -> v * 0.003785411784
                "UK Gallons" -> v * 0.00454609
                else -> {
                    val from = VolumeUnit.entries.firstOrNull { it.symbol == unitStr } ?: VolumeUnit.CU_M
                    UnitConverter.convertVolume(v, from, VolumeUnit.CU_M)
                }
            }
            val cft = UnitConverter.convertVolume(cum, VolumeUnit.CU_M, VolumeUnit.CU_FT)
            val brass = UnitConverter.convertVolume(cum, VolumeUnit.CU_M, VolumeUnit.BRASS)
            val liters = cum * 1000.0
            val cuyd = UnitConverter.convertVolume(cum, VolumeUnit.CU_M, VolumeUnit.CU_YD)
            val usGal = cum / 0.003785411784
            val ukGal = cum / 0.00454609
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Cubic Meters", UnitConverter.fmt(cum, p + 1), "m³", isPrimary = true),
                        CalcResultItem("Cubic Feet", UnitConverter.fmt(cft, p), "CFT", isPrimary = true),
                        CalcResultItem("Liters", UnitConverter.fmt(liters, p), "L"),
                        CalcResultItem("Brass (100 CFT)", UnitConverter.fmt(brass, p), "Brass"),
                        CalcResultItem("Cubic Yards", UnitConverter.fmt(cuyd, p), "yd³"),
                        CalcResultItem("US / UK Gallons", "${UnitConverter.fmt(usGal, p)} US | ${UnitConverter.fmt(ukGal, p)} UK", "gal")
                    ),
                    formula = "1 m³ = 35.3147 CFT = 0.3531 Brass = 1000 L = 264.172 US Gal",
                    steps = listOf("${UnitConverter.fmt(v, p)} $unitStr = ${UnitConverter.fmt(cum, 4)} m³"),
                    assumptions = "1 Brass = 100 CFT (standard Indian aggregate/sand measure)."
                )
            )
        }
    )

    private fun fractionDecimalCalculator() = CalcToolSpec(
        id = "basic_fraction_calc",
        title = "Fraction & Feet-Inch Calculator",
        titleHi = "भिन्न और फीट-इंच कैलकुलेटर",
        subtitle = "Compute +, -, ×, ÷ on Feet-Inches (e.g. 12' 6) or Fractions (3/4)",
        category = CalcCategory.BASIC,
        keywords = listOf("fraction", "decimal", "feet", "inch", "arithmetic", "construction"),
        fields = listOf(
            CalcFieldSpec("a", "Value A (e.g. 12' 6 or 12 3/4 or 10.5)", "12' 6"),
            CalcFieldSpec("op", "Operation", "+", options = listOf("+", "-", "×", "÷")),
            CalcFieldSpec("b", "Value B (e.g. 4' 3 or 2 1/2 or 2)", "4' 3")
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val a = UnitConverter.parseFractionOrDecimal(ctx.raw("a"))
                ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid Value A. Try 12' 6 or 12 3/4 or 10.5"))
            val b = UnitConverter.parseFractionOrDecimal(ctx.raw("b"))
                ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid Value B."))
            val op = ctx.raw("op")
            val res = when (op) {
                "+" -> a + b
                "-" -> a - b
                "×" -> a * b
                "÷" -> {
                    if (abs(b) < 1e-12) return@CalcToolSpec Result.failure(IllegalArgumentException("Cannot divide by zero."))
                    a / b
                }
                else -> a + b
            }
            val meters = res * 0.3048
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Decimal Result", UnitConverter.fmt(res, p + 2), "ft / unit", isPrimary = true),
                        CalcResultItem("Feet-Inch Format", UnitConverter.fmtFeetInches(meters), "", isPrimary = true),
                        CalcResultItem("In Meters (if ft)", UnitConverter.fmt(meters, p + 1), "m"),
                        CalcResultItem("In Millimeters", UnitConverter.fmt(meters * 1000.0, p), "mm")
                    ),
                    formula = "A $op B = ${UnitConverter.fmt(res, 4)}",
                    steps = listOf(
                        "Parsed A = ${UnitConverter.fmt(a, 4)}",
                        "Parsed B = ${UnitConverter.fmt(b, 4)}",
                        "Result = ${UnitConverter.fmt(a, 4)} $op ${UnitConverter.fmt(b, 4)} = ${UnitConverter.fmt(res, 4)}"
                    ),
                    assumptions = "Feet-inch notation (e.g. 12' 6) is converted to decimal feet before arithmetic."
                )
            )
        }
    )

    private fun pitTrenchExcavation() = CalcToolSpec(
        id = "earth_excavation_pit",
        title = "Pit / Trench / Foundation Excavation",
        titleHi = "नींव और गड्ढा खुदाई",
        subtitle = "Excavation Volume, Swell Factor & Soil Disposal Trips",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("excavation", "pit", "trench", "foundation", "earthwork", "soil", "loose", "disposal"),
        fields = listOf(
            CalcFieldSpec("l", "Length", "2.5", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Width", "2.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("d", "Depth", "1.8", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("count", "Number of Pits / Trenches", "6", FieldUnitKind.COUNT),
            CalcFieldSpec("swell", "Loose Soil Swell Factor (%)", "25", FieldUnitKind.PERCENT, allowZero = true),
            CalcFieldSpec("truckCap", "Dumper Capacity (m³)", "6.0", FieldUnitKind.VOLUME_CU_M)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid width."))
            val d = ctx.lengthMeters("d") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid depth."))
            val n = ctx.doubleOrNull("count") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter pit count."))
            val swell = ctx.doubleOrNull("swell") ?: 25.0
            val truck = ctx.doubleOrNull("truckCap") ?: 6.0
            if (l <= 0 || w <= 0 || d <= 0 || n <= 0 || truck <= 0 || swell < 0) {
                return@CalcToolSpec Result.failure(IllegalArgumentException("All dimensions and counts must be positive."))
            }
            val bankVol = l * w * d * n
            val looseVol = bankVol * (1.0 + swell / 100.0)
            val cftBank = bankVol * UnitConverter.CU_FT_IN_CU_M
            val trips = kotlin.math.ceil(looseVol / truck).toInt()
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Bank Excavation Volume", UnitConverter.fmt(bankVol, p), "m³", isPrimary = true),
                        CalcResultItem("Loose Soil Volume", UnitConverter.fmt(looseVol, p), "m³", isPrimary = true),
                        CalcResultItem("Volume in CFT", UnitConverter.fmt(cftBank, p), "CFT"),
                        CalcResultItem("Dumper Disposal Trips", "$trips", "Trips")
                    ),
                    formula = "Bank Vol = L × W × D × N; Loose Vol = Bank × (1 + Swell%)",
                    steps = listOf(
                        "Single Pit = ${UnitConverter.fmt(l, p)}×${UnitConverter.fmt(w, p)}×${UnitConverter.fmt(d, p)} = ${UnitConverter.fmt(l * w * d, p)} m³",
                        "Total Bank Vol = ${UnitConverter.fmt(bankVol, p)} m³",
                        "Loose Soil (+${UnitConverter.fmt(swell, 1)}%) = ${UnitConverter.fmt(looseVol, p)} m³"
                    ),
                    assumptions = "Typical soil swell factor ranges 20–30% upon excavation."
                )
            )
        }
    )

    private fun slopedExcavation() = CalcToolSpec(
        id = "earth_sloped_excavation",
        title = "Sloped Excavation (Trapezoidal)",
        titleHi = "ढलान युक्त खुदाई",
        subtitle = "Excavation with Side Slope 1:N for Deep Pits",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("slope", "excavation", "trapezoid", "prismoidal", "batter"),
        fields = listOf(
            CalcFieldSpec("l", "Bottom Length", "6.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("w", "Bottom Width", "4.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("d", "Depth", "3.0", FieldUnitKind.LENGTH, LengthUnit.M),
            CalcFieldSpec("slope", "Side Slope (H:V, e.g. 0.5 for 0.5:1)", "0.5", FieldUnitKind.NONE, allowZero = true)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val l = ctx.lengthMeters("l") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid bottom length."))
            val w = ctx.lengthMeters("w") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid bottom width."))
            val d = ctx.lengthMeters("d") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid depth."))
            val s = ctx.doubleOrNull("slope") ?: 0.5
            if (l <= 0 || w <= 0 || d <= 0 || s < 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid dimensions."))
            val topL = l + 2.0 * s * d
            val topW = w + 2.0 * s * d
            val aBot = l * w
            val aTop = topL * topW
            val aMid = ((l + topL) / 2.0) * ((w + topW) / 2.0)
            val vol = (d / 6.0) * (aBot + 4.0 * aMid + aTop)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Prismoidal Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Volume in CFT", UnitConverter.fmt(vol * UnitConverter.CU_FT_IN_CU_M, p), "CFT", isPrimary = true),
                        CalcResultItem("Top Dimensions", "${UnitConverter.fmt(topL, p)} × ${UnitConverter.fmt(topW, p)}", "m"),
                        CalcResultItem("Top Area", UnitConverter.fmt(aTop, p), "m²")
                    ),
                    formula = "V = (D/6) × (A_bottom + 4·A_mid + A_top)",
                    steps = listOf(
                        "Top L = L + 2·s·D = ${UnitConverter.fmt(topL, p)} m; Top W = ${UnitConverter.fmt(topW, p)} m",
                        "A_bot = ${UnitConverter.fmt(aBot, p)} m², A_mid = ${UnitConverter.fmt(aMid, p)} m², A_top = ${UnitConverter.fmt(aTop, p)} m²",
                        "V = ${UnitConverter.fmt(vol, p)} m³"
                    ),
                    assumptions = "Uses exact prismoidal formula assuming uniform side slope on all 4 sides."
                )
            )
        }
    )

    private fun backfillingAndCompaction() = CalcToolSpec(
        id = "earth_backfill",
        title = "Backfilling & Compaction Estimator",
        titleHi = "बैकफिलिंग और कॉम्पैक्शन",
        subtitle = "Net Backfill = Excavated - Substructure + Compaction Factor",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("backfill", "compaction", "soil", "filling", "plinth"),
        fields = listOf(
            CalcFieldSpec("excavated", "Total Excavated Pit Volume (m³)", "45", FieldUnitKind.VOLUME_CU_M),
            CalcFieldSpec("substructure", "Footing + Pedestal + Plinth Vol (m³)", "14", FieldUnitKind.VOLUME_CU_M, allowZero = true),
            CalcFieldSpec("compFactor", "Compaction / Bulking Factor", "1.20", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val exc = ctx.doubleOrNull("excavated") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter excavated volume."))
            val sub = ctx.doubleOrNull("substructure") ?: 0.0
            val cf = ctx.doubleOrNull("compFactor") ?: 1.20
            if (exc <= 0 || sub < 0 || cf <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Invalid input."))
            val warnings = if (sub > exc) listOf("Substructure volume exceeds excavated volume.") else emptyList()
            val netCompacted = (exc - sub).coerceAtLeast(0.0)
            val looseReq = netCompacted * cf
            val surplusSoil = (exc - looseReq).coerceAtLeast(0.0)
            val borrowSoil = (looseReq - exc).coerceAtLeast(0.0)
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Net Compacted Backfill", UnitConverter.fmt(netCompacted, p), "m³", isPrimary = true),
                        CalcResultItem("Loose Soil Required", UnitConverter.fmt(looseReq, p), "m³", isPrimary = true),
                        CalcResultItem("Surplus for Disposal", UnitConverter.fmt(surplusSoil, p), "m³"),
                        CalcResultItem("Extra Borrow Needed", UnitConverter.fmt(borrowSoil, p), "m³")
                    ),
                    formula = "Net Backfill = V_exc - V_sub; Loose Soil = Net × Compaction Factor",
                    steps = listOf(
                        "Net Void = ${UnitConverter.fmt(exc, p)} - ${UnitConverter.fmt(sub, p)} = ${UnitConverter.fmt(netCompacted, p)} m³",
                        "Loose Soil = ${UnitConverter.fmt(netCompacted, p)} × ${UnitConverter.fmt(cf, 2)} = ${UnitConverter.fmt(looseReq, p)} m³"
                    ),
                    assumptions = "Standard compacted soil shrinkage requires ~1.15–1.25× loose soil volume.",
                    warnings = warnings
                )
            )
        }
    )

    private fun cutAndFillEarthwork() = CalcToolSpec(
        id = "earth_cut_fill",
        title = "Cut & Fill Level Earthwork",
        titleHi = "कट एंड फिल अर्थवर्क",
        subtitle = "Formation Level vs Existing Ground Level Volume",
        category = CalcCategory.EARTHWORK,
        keywords = listOf("cut", "fill", "formation", "level", "earthwork", "grading"),
        fields = listOf(
            CalcFieldSpec("area", "Site / Grid Area (m²)", "500", FieldUnitKind.AREA_SQ_M),
            CalcFieldSpec("egl", "Average Existing Ground Level (m)", "100.65", FieldUnitKind.NONE),
            CalcFieldSpec("fgl", "Target Formation Level (m)", "100.00", FieldUnitKind.NONE)
        ),
        compute = { ctx ->
            val p = ctx.settings.decimalPrecision
            val area = ctx.doubleOrNull("area") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter valid area."))
            val egl = ctx.doubleOrNull("egl") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter existing ground level."))
            val fgl = ctx.doubleOrNull("fgl") ?: return@CalcToolSpec Result.failure(IllegalArgumentException("Enter formation level."))
            if (area <= 0) return@CalcToolSpec Result.failure(IllegalArgumentException("Area must be positive."))
            val diff = egl - fgl
            val vol = abs(diff) * area
            val type = if (diff >= 0) "CUTTING (Excavation)" else "FILLING (Embankment)"
            Result.success(
                CalcOutcome(
                    results = listOf(
                        CalcResultItem("Operation Type", type, "", isPrimary = true),
                        CalcResultItem("Earthwork Volume", UnitConverter.fmt(vol, p), "m³", isPrimary = true),
                        CalcResultItem("Average Depth Diff", UnitConverter.fmt(abs(diff), p + 1), "m"),
                        CalcResultItem("Volume in CFT", UnitConverter.fmt(vol * UnitConverter.CU_FT_IN_CU_M, p), "CFT")
                    ),
                    formula = "Volume = Area × |EGL - FGL|",
                    steps = listOf("Level Diff = ${UnitConverter.fmt(egl, 3)} - ${UnitConverter.fmt(fgl, 3)} = ${UnitConverter.fmt(diff, 3)} m"),
                    assumptions = "Uniform average elevation method across the grid area."
                )
            )
        }
    )
}

package com.example.features.calculators

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.i18n.AppLanguage
import com.example.domain.calculators.CalculatorRegistry
import com.example.features.dashboard.NestedCategoryCatalog
import com.example.ui.MainViewModel
import com.example.ui.components.EngineeringCard
import com.example.ui.components.EngineeringTopBar
import com.example.ui.theme.LocalEngineeringPalette

/**
 * LEVEL 2 — Category Folder Grid (e.g. Home > Concrete & RCC -> Subcategory Folders)
 */
@Composable
fun CategoryFolderScreen(
    categoryId: String,
    viewModel: MainViewModel,
    onOpenSubcategory: (String, String) -> Unit,
    onOpenCalculator: (String, String) -> Unit,
    onNavigateRoute: (String) -> Unit,
    onBack: () -> Unit
) {
    val palette = LocalEngineeringPalette.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isHindi = settings.language == AppLanguage.HINDI
    val cat = remember(categoryId) { NestedCategoryCatalog.categoryById(categoryId) }

    if (cat == null) {
        Column(Modifier.fillMaxSize().background(palette.concreteBg)) {
            EngineeringTopBar(title = "Category Not Found", onBack = onBack)
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Unknown folder '$categoryId'", color = palette.inkMuted)
            }
        }
        return
    }

    var searchQuery by remember { mutableStateOf("") }
    val trimmed = searchQuery.trim()
    val allToolsInCat = remember(cat) {
        cat.subcategories.flatMap { it.toolIds }.distinct().mapNotNull { CalculatorRegistry.byId(it) }
    }
    val matchingTools = remember(trimmed, allToolsInCat) {
        if (trimmed.isEmpty()) emptyList()
        else {
            val q = trimmed.lowercase()
            allToolsInCat.filter {
                it.title.lowercase().contains(q) ||
                    it.titleHi.lowercase().contains(q) ||
                    it.subtitle.lowercase().contains(q) ||
                    it.keywords.any { k -> k.contains(q) }
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = if (isHindi) cat.titleHi else cat.titleEn,
            subtitle = "Home > ${cat.titleEn}",
            onBack = onBack
        )

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            // Compact teal-reference layout: keep three tiles across on phones,
            // expand only on larger tablets/desktop widths.
            val columns = when {
                maxWidth >= 900.dp -> 4
                else -> 3
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Compact Folder Search
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().testTag("folder_search_input"),
                        placeholder = { Text("Search inside ${cat.titleEn}...", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = cat.accent) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = palette.concreteCard,
                            unfocusedContainerColor = palette.concreteCard,
                            focusedBorderColor = cat.accent,
                            unfocusedBorderColor = palette.metallicBorder
                        )
                    )
                }

                // Companion Studio Card (when available for this folder)
                if (cat.studioShortcutRoute != null && cat.studioShortcutTitle != null && trimmed.isEmpty()) {
                    item {
                        EngineeringCard(
                            accentColor = cat.accent,
                            onClick = { onNavigateRoute(cat.studioShortcutRoute) },
                            modifier = Modifier.testTag("folder_studio_shortcut")
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(cat.studioShortcutTitle, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = palette.inkPrimary)
                                    if (cat.studioShortcutSubtitle != null) {
                                        Text(cat.studioShortcutSubtitle, style = MaterialTheme.typography.bodySmall, color = palette.inkMuted)
                                    }
                                }
                                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, tint = cat.accent)
                            }
                        }
                    }
                }

                if (trimmed.isNotEmpty()) {
                    item {
                        Text(
                            text = "${matchingTools.size} matching calculators in ${cat.titleEn}",
                            style = MaterialTheme.typography.labelLarge,
                            color = palette.inkMuted
                        )
                    }
                    items(matchingTools, key = { it.id }) { tool ->
                        EngineeringCard(
                            accentColor = cat.accent,
                            onClick = { onOpenCalculator(tool.id, "Home > ${cat.titleEn}") }
                        ) {
                            Text(
                                text = if (isHindi) tool.titleHi else tool.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = palette.inkPrimary
                            )
                            Text(tool.subtitle, style = MaterialTheme.typography.bodySmall, color = palette.inkMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                } else {
                    val subRows = cat.subcategories.chunked(columns)
                    items(subRows, key = { row -> row.joinToString("_") { it.id } }) { rowSubs ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            rowSubs.forEach { sub ->
                                val countLabel = when {
                                    sub.toolIds.isNotEmpty() -> "${sub.toolIds.size} Tools"
                                    else -> "Studio"
                                }
                                EngineeringCard(
                                    accentColor = cat.accent,
                                    onClick = {
                                        if (sub.toolIds.isEmpty() && sub.directRoute != null) {
                                            onNavigateRoute(sub.directRoute)
                                        } else {
                                            onOpenSubcategory(cat.id, sub.id)
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .heightIn(min = 104.dp)
                                        .testTag("subfolder_${sub.id}")
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(cat.accent.copy(alpha = 0.14f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Rounded.Folder, contentDescription = sub.titleEn, tint = cat.accent, modifier = Modifier.size(19.dp))
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = palette.concreteSurfaceAlt
                                        ) {
                                            Text(
                                                text = countLabel,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = palette.inkSecondary,
                                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(5.dp))
                                    Text(
                                        text = if (isHindi) sub.titleHi else sub.titleEn,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = palette.inkPrimary,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = sub.subtitleEn,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = palette.inkMuted,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            repeat(columns - rowSubs.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * LEVEL 3 — Subcategory Tools Screen (e.g. Home > Concrete & RCC > Slab & Screed)
 */
@Composable
fun SubcategoryToolsScreen(
    categoryId: String,
    subId: String,
    viewModel: MainViewModel,
    onOpenCalculator: (String, String) -> Unit,
    onNavigateRoute: (String) -> Unit,
    onBack: () -> Unit
) {
    val palette = LocalEngineeringPalette.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteToolIds.collectAsStateWithLifecycle()
    val isHindi = settings.language == AppLanguage.HINDI
    val resolved = remember(categoryId, subId) { NestedCategoryCatalog.subcategoryById(categoryId, subId) }

    if (resolved == null) {
        Column(Modifier.fillMaxSize().background(palette.concreteBg)) {
            EngineeringTopBar(title = "Subcategory Not Found", onBack = onBack)
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Unknown subcategory '$subId'", color = palette.inkMuted)
            }
        }
        return
    }

    val (cat, sub) = resolved
    val breadcrumb = "Home > ${cat.titleEn} > ${sub.titleEn}"
    val tools = remember(sub) { NestedCategoryCatalog.toolsInSubcategory(sub) }
    var search by remember { mutableStateOf("") }
    val filtered = remember(search, tools) {
        val q = search.trim().lowercase()
        if (q.isEmpty()) tools
        else tools.filter {
            it.title.lowercase().contains(q) ||
                it.titleHi.lowercase().contains(q) ||
                it.subtitle.lowercase().contains(q)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(palette.concreteBg)) {
        EngineeringTopBar(
            title = if (isHindi) sub.titleHi else sub.titleEn,
            subtitle = breadcrumb,
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (tools.size > 3) {
                item {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth().testTag("subfolder_search_input"),
                        placeholder = { Text("Filter ${sub.titleEn} tools...", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = cat.accent) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = palette.concreteCard,
                            unfocusedContainerColor = palette.concreteCard,
                            focusedBorderColor = cat.accent,
                            unfocusedBorderColor = palette.metallicBorder
                        )
                    )
                }
            }

            if (sub.directRoute != null && sub.directRouteLabel != null) {
                item {
                    Button(
                        onClick = { onNavigateRoute(sub.directRoute) },
                        colors = ButtonDefaults.buttonColors(containerColor = cat.accent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("subfolder_direct_studio")
                    ) {
                        Text(sub.directRouteLabel, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
            }

            items(filtered, key = { it.id }) { tool ->
                val isFav = favoriteIds.contains(tool.id)
                EngineeringCard(
                    accentColor = cat.accent,
                    onClick = { onOpenCalculator(tool.id, breadcrumb) },
                    modifier = Modifier.testTag("tool_card_${tool.id}")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = if (isHindi) tool.titleHi else tool.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.inkPrimary,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Icon(Icons.Rounded.Verified, contentDescription = "Verified Formula", tint = palette.skyBlue, modifier = Modifier.size(14.dp))
                            }
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = tool.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = palette.inkMuted,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { viewModel.toggleFavorite(tool.id) },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                contentDescription = "Favorite",
                                tint = if (isFav) palette.orange else palette.inkMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

# Phase E — Advanced RCC Quantity Tools

Added 10 additional registered calculator specs in `PhaseDConcreteCalculators.kt` via the `advancedRccTools()` list:

1. Multi-Footing Concrete Quantity
2. Combined Footing Concrete Volume (average-thickness approximation)
3. Raft Foundation Concrete (uniform thickness + allowance)
4. RCC Reinforcement Quantity Estimator (assumed kg/m³, not design/BBS)
5. Concrete Mix Material Split (user-entered ratio and dry factor)
6. Beam Shuttering Area (sides + optional soffit)
7. Column Shuttering Area
8. Bored Pile Concrete Volume (allowance)
9. Concrete Pour & Truck Planner
10. Advanced RCC quantity helpers grouped under phase E IDs

All are registered through `PhaseDConcreteCalculators.all()` which is already included in `CalculatorRegistry.allTools`.


## Safety / scope
These are quantity estimators and planning tools, not structural design, code-compliance, mix-design approval, or reinforcement detailing. Actual drawings, approved mix designs, site measurements and project specifications govern.

## Validation
- Duplicate IDs were not detected within the new ten specs.
- Kotlin syntax/type shape checked with temporary model stubs using `kotlinc` (passed).
- Full Android/Gradle build and runtime validation remain pending.

# Phase J – Road & Highway Engineering

Added 10 calculator specifications in `PhaseJRoadHighwayCalculators.kt` and registered the phase in `CalculatorRegistry`.

1. Road Camber & Crossfall
2. Superelevation Calculator
3. Horizontal Circular Curve Elements
4. Symmetrical Vertical Curve
5. Transition Curve Length
6. Road Gradient & Level Calculator
7. Bituminous Mix Tonnage & Trucks
8. Road Marking Paint Quantity
9. Road Sign Board & Post Quantity
10. Pavement Crossfall Level Difference

Validation performed:
- Kotlin syntax/type-shape compilation passed against lightweight model/unit stubs.
- Registry includes Phase J.
- Full Android Gradle build and device runtime tests have not been performed.

Engineering note: these are preliminary geometry and quantity estimators. Confirm governing IRC/MoRTH/project specifications, product data and design checks before construction use. They are not substitutes for approved highway design.

# Phase L – Electrical & Solar Engineering

Added 10 preliminary estimation calculators:
1. Single-Phase Power & Current
2. Three-Phase Power & Current
3. Cable Voltage Drop Estimator
4. Conductor Area from Voltage-Drop Limit
5. Connected Load & Demand Calculator
6. Transformer kVA & Loading
7. Earth Electrode Resistance Screening
8. Solar PV Array Sizing
9. Inverter & Battery Backup Sizing
10. Electrical Energy & Bill Estimator

The tools are registered in CalculatorRegistry. Kotlin syntax/type-shape compilation passed against temporary model stubs. This is not a full Android Gradle build or device runtime test. Electrical outputs are preliminary estimators and do not replace licensed electrical design, code compliance, manufacturer data or site testing.

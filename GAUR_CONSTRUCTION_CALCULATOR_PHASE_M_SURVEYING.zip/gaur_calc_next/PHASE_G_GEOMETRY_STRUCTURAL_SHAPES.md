# Phase G – Advanced Geometry & Structural Shapes

Integrated into `app/src/main/java/com/example/domain/calculators/PhaseGStructuralGeometryCalculators.kt`
and registered in `CalculatorRegistry.kt`.

## Added calculators (10)
1. Ellipse Geometry – area, approximate perimeter and axes
2. Regular Polygon Geometry – area, perimeter and apothem
3. Composite Area – Two Rectangles – combined area and centroid
4. I-Section Properties – area, Ix/Iy, elastic section moduli
5. T-Section Properties – area, centroid, Ix/Iy and top section modulus
6. Equal/Unequal L-Section Properties – area, centroid and centroidal inertias
7. C-Channel Section Properties – area, centroid and centroidal inertias
8. Rectangular Hollow Section Properties – area, inertias, section moduli and radii of gyration
9. Quadrilateral Area & Centroid – shoelace area and centroid from four ordered vertices
10. Rectangle Section Properties – area, Ix/Iy, section moduli and radii of gyration

## Validation
- 10 Phase G calculator specifications found.
- All Phase G IDs are unique.
- Full calculator source ID scan found no duplicate IDs.
- Phase G Kotlin file compiled successfully using temporary model/unit stubs with `kotlinc`.
- Full Android/Gradle build and device runtime tests were not performed; the uploaded project does not contain `gradlew` or `gradle/wrapper/gradle-wrapper.jar`.

## Engineering scope
These are idealised geometric-property estimators. They do not perform structural member design, code checks, buckling checks, connection design, or capacity verification. Rolled-section fillets and manufacturing tolerances are not included.
